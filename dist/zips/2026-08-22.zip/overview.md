# WORLDSCOPE morning brief — 2026-08-22

## Headline
2204 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (479) · Russian Internal News (state + in-exile) (394) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (180) · Chinese Internal News (179) · U.S. Weather + Severe / Climate Outlooks (127) · Local News: St. Louis + Atlanta (112) · State-Level News (110) · Ukrainian Internal News (national + local Kyiv) (44) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30) · State Legislative Action (28)

## What changed today
### International News + Multilateral Institutions — 479 new of 1023 total
  - (2026-08-22) [Global] Marseille kick off new Ligue 1 season by thrashing Strasbourg at home
      Algerian international striker Amine Gouiri scored a second-half double for Marseille, who powered to a 4-0 victory over Strasbourg in the curtain-raiser for the new Ligue 1 season on Friday evening.
  - (2026-08-22) [Global] Russian strikes in Ukraine kill at least two a day after deadly drone attack on shopping centre
      At least two people were reported dead early Saturday by local authorities, after Russian strikes on Ukraine. The strikes came after a series of Russian bombings killed at least 20 people in Ukraine on Friday, including…
  - (2026-08-22) [Global] Canada vows to match US tariffs 'dollar for dollar' after failed trade negotiations
      Canadian Prime Minister Mark Carney vowed that his country will match the US tariffs "dollar for dollar to protect our workers and businesses", after hefty US tariffs on some Canadian products took effect on Saturday fol…
  - (2026-08-22) [Global] South Korea ship to test alternative Arctic route as Mideast conflict disrupts shipping
      South Korea on Saturday was set to send its first trial container through the Arctic as the Middle East war has rattled global shipping – sending governments and shipping firms scrambling to seek alternative routes. Envi…
  - (2026-08-21) [Global] Search continues after deadly mine collapse on Cameroon-Central African Republic border
      In tonight’s edition: a deadly landslide at a gold mine in the Central African Republic leaves dozens dead, with victims from Cameroon and Chad. Meanwhile, Ethiopia is turning to Bordeaux expertise and grapevines in a bi…
  - (2026-08-21) [Global] Deadly 'double-tap' Russian drone strikes target Ukraine shopping centre
      A pair of Russian drone strikes that hit a shopping centre in the Ukrainian city of Kryvyi Rih Friday killed at least 15 people and wounded scores more, authorities said. Ukrainian President Volodymyr Zelensky accused Mo…

### Russian Internal News (state + in-exile) — 394 new of 1030 total
  - (2026-08-22) От Калининграда до Владивостока: Народный фронт, МАЕР и «Таврида.АРТ» запустили всероссийскую акцию ко Дню флага | LEDE: Россиян поздравили с Днем Государственного флага масштабной цифровой акц] (ru:…
      Россиян поздравили с Днем Государственного флага масштабной цифровой акцией, объединившей всю страну. Ровно в 10 часов утра по московскому времени дан старт кампании: Государственный флаг был поднят на медиафасаде в стол…
  - (2026-08-22) ИИ-копия босса оказалась хуже реальности: главные ИИ-глюки августа | LEDE: Искусственный интеллект (ИИ) порой так «помогает» человеку, что подводит его под уголовную статью. В первой половине а] (ru:…
      Искусственный интеллект (ИИ) порой так «помогает» человеку, что подводит его под уголовную статью. В первой половине августа ИИ успел побывать в роли цифровой копии начальника, депутата, подсказчика для судьи. Последстви…
  - (2026-08-22) Новая музыка смертельно опасна: новости, которые вы могли пропустить | LEDE: На этой неделе стало известно, что выход музыкального альбома буквально убивает десятки людей, а белые голуби, выпущ] (ru:…
      На этой неделе стало известно, что выход музыкального альбома буквально убивает десятки людей, а белые голуби, выпущенные на свадьбе, быстро погибают. Робот обогнал Усэйна Болта, низкокачественный мультфильм делает своег…
  - (2026-08-22) Курултай Казахстана: от степной демократии к новому парламенту | LEDE: 23 августа в Казахстане пройдут выборы первого созыва нового однопалатного парламента – курултая, который был учрежден в р] (ru:…
      23 августа в Казахстане пройдут выборы первого созыва нового однопалатного парламента – курултая, который был учрежден в рамках реализации поправок к конституции взамен существовавших более 30 лет мажилиса и сената. Каку…
  - (2026-08-22) Как августовский путч поставил точку в истории СССР: хронология, графики и карты | LEDE: Утром 19 августа советским гражданам сообщили по телевидению, что президент СССР Михаил Горбачев болен и] (ru:…
      Утром 19 августа советским гражданам сообщили по телевидению, что президент СССР Михаил Горбачев болен и не может управлять государством. Его полномочия взял на себя вице-президент Геннадий Янаев, а в стране учрежден Гос…
  - (2026-08-22) Что вы знаете про российский флаг? | LEDE: В честь праздника «Ведомости» подготовили проверочно-развлекательный тест вместе с Игорем Юргиным – Героем России и выпускником федеральной программы ] (ru:…
      В честь праздника «Ведомости» подготовили проверочно-развлекательный тест вместе с Игорем Юргиным – Героем России и выпускником федеральной программы «Время героев», возглавившим департамент госполитики в сфере воспитани…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 180 new of 834 total
  - (2026-08-22) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-21) [FIRMS] thermal anomaly 52.266, 33.595 (FRP 2.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-21 2341Z, FRP 2.52 MW
  - (2026-08-21) [FIRMS] thermal anomaly 51.219, 34.156 (FRP 0.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-21 2341Z, FRP 0.52 MW
  - (2026-08-21) [FIRMS] thermal anomaly 51.077, 34.842 (FRP 1.13 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-21 2341Z, FRP 1.13 MW
  - (2026-08-21) [FIRMS] thermal anomaly 51.366, 25.810 (FRP 0.36 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-21 2341Z, FRP 0.36 MW
  - (2026-08-21) [FIRMS] thermal anomaly 50.368, 34.972 (FRP 0.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-21 2341Z, FRP 0.5 MW

### Chinese Internal News — 179 new of 284 total
  - (2026-08-20) 西方资本为掌控“第四权”给人家贴“红色”标签可谓无所不用其极！ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTFB0RjBLOWZRbkNiZjFHdENXQVVpN1RjdDAybTZpcjBhajFsVEV3NGN3cVI0Nl94VV85SkttRDhtQWk0NVhpc01nRn] (zh:…
      西方资本为掌控“第四权”给人家贴“红色”标签可谓无所不用其极！ 风闻
  - (2026-08-20) 马来西亚总理安瓦尔重申：涉台表态没说错，美国也不许自己领土分离 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1RY1RHMklCY2VuWTR2TkphOXNJTzhHbzZqZVlKTUdwaVhYMEVBeU90ckFiWkI3bTRTQUdaQnZ5b3BsQT] (zh:…
      马来西亚总理安瓦尔重申：涉台表态没说错，美国也不许自己领土分离 guancha.cn
  - (2026-08-20) AI制药重大里程碑：不只是癌症疫苗，更是“一人一药”-观察者网 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1GSFdMSEpwZkY5c3JlcEdKR3QweTNlM3d1VHJKRkFUaUdjcXFTN3ZHREphSTNRLVFfNndBaUdDVERuQ2] (zh:…
      AI制药重大里程碑：不只是癌症疫苗，更是“一人一药”-观察者网 guancha.cn
  - (2026-08-21) 肯尼迪号“复古”：恢复雷达照射器 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE81LU96b3ZaQjVxWVZ2ajFTTm02Z3dNdThjUzd5ellUS0tSNW1XSGg3Wm0tbTVSclRISlo2RDkxaDRYQ18tOVZNVkJJSEd4d] (zh:…
      肯尼迪号“复古”：恢复雷达照射器 guancha.cn
  - (2026-08-21) 中铁成都局回应“旅客买票占座放零食” - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBsZDlUQ2ZvOUlUUWV6eW9tdUxIUHhpRGFpWEhjWWgxZHdUbGJwdlN5dzVHSVBDS1RvRFJrRHl1NGc4UGg4ZTlEaVJJd3I] (zh:…
      中铁成都局回应“旅客买票占座放零食” guancha.cn
  - (2026-08-21) 美国对华关上的大门，该打开了 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE13MVpwR0ZHdWxHVXFmejh0c181M1Nnd2JNN0F4bGRRNVUxX1B2QjZXRmp6TzRpc3NsTGUyek9xMk1Qa2I0MHd2eFZNUW1Dd2l] (zh:…
      美国对华关上的大门，该打开了 guancha.cn

### U.S. Weather + Severe / Climate Outlooks — 127 new of 144 total
  - (2026-08-22) [Moderate] Special Weather Statement: Special Weather Statement issued August 22 at 4:21AM CDT by NWS Norman OK
      At 421 AM CDT, Doppler radar was tracking a strong thunderstorm near Nardin, moving southeast at 25 mph. HAZARD...Wind gusts of 40 mph and half inch hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down t…
  - (2026-08-22) [Moderate] Special Weather Statement: Special Weather Statement issued August 22 at 4:20AM CDT by NWS Brownsville TX
      The combination of hot temperatures and humidity levels will produce heat index values between 105 and 110 degrees for several hours this afternoon into this evening. A few locations may briefly experience heat index val…
  - (2026-08-22) [Moderate] Special Weather Statement: Special Weather Statement issued August 22 at 4:20AM CDT by NWS Hastings NE
      At 420 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from near Hazard to 7 miles northeast of Eddyville to near Oconto. Movement was south at 35 mph. HAZARD...Wind gusts of 50 to 55 mph.…
  - (2026-08-22) [Moderate] Special Weather Statement: Special Weather Statement issued August 22 at 5:18AM EDT by NWS Louisville KY
      Clear skies and light winds has allowed for dense valley fog to develop. Patchy fog is also possible outside of the valley areas. Visibilities may drop to a quarter of a mile at times. Slow down in fog and use your low b…
  - (2026-08-22) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-22) [Severe] Red Flag Warning: Red Flag Warning issued August 22 at 3:17AM MDT until August 22 at 9:00PM MDT by NWS Pocatello ID
      ...CRITICAL FIRE WEATHER CONDITIONS ARE EXPECTED ON SATURDAY DUE TO SCATTERED THUNDERSTORM ACTIVITY ACROSS MUCH OF EASTERN IDAHO... * AFFECTED AREA...Fire Weather Zone 410 Upper Snake River Valley/Idaho Falls BLM, Fire W…

### Local News: St. Louis + Atlanta — 112 new of 255 total
  - (2026-08-22) [St. Louis] US is set to impose 50% tariffs on $20 billion worth of Canadian products
      Canada immediately said it would retaliate with its own tariffs after failed last-minute negotiations between the historic allies.
  - (2026-08-22) [St. Louis] 3 states to take big water cuts as Colorado River supplies continue to plunge
      A prolonged drought and low snowpack are adding more stress on Western states that rely on the Colorado River's water.
  - (2026-08-22) [St. Louis] 3 boys, 1 man recovering after pair of dogs attacked them in Belleville neighborhood
      Ashley Jett, Director of Animal Services and Rescue, confirms the dogs are now under quarantine at the St. Clair County Animal Control Center.
  - (2026-08-22) [St. Louis] Man charged with shooting, injuring another man in Clayton Thursday
      Anyone with information related to this investigation is encouraged to contact the Clayton Police Department Detective Bureau at 314-290-8416.
  - (2026-08-22) [St. Louis] Dellwood Mayor Reggie Jones dies at 53, leaving behind decades of community leadership
      Regional leaders, faith communities, and local youth organizations mourn the loss of the long-serving public servant.
  - (2026-08-22) [St. Louis] Brian Hickerson's brother speaks out on Hayden Panettiere's death, recalls finding her unconscious
      In a new interview, Zach Hickerson recalled that Panettiere's on-and-off again boyfriend administered Narcan after finding her unconscious.

### State-Level News — 110 new of 597 total
  - (2026-08-22) [California] Governor Newsom announces appointments 8.21.26
  - (2026-08-21) [California] FREE MONEY FOR KIDS: Governor Newsom and First Partner celebrate one million families claim CalKIDS “baby bonds” accounts
  - (2026-08-21) [Connecticut] Housing, CSCU auditing, school technology: CT politics news
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/08/FLOCK-SIGNS-0821-JL-003-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-08-21) [Connecticut] Electric Boat cheers move into new campus at former Crystal Mall
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/ELECTRIC-BOAT-0821-SG-13-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcse…
  - (2026-08-21) [Arizona] Mayes declines to prosecute Hobbs for Sunshine Residential bribery accusations
      Attorney General Kris Mayes says there’s no evidence that Gov. Katie Hobbs broke the law when her administration awarded a pay increase to a foster care provider that donated more than $400,000 to her political campaign.…
  - (2026-08-21) [Arizona] ‘All hands on deck’ for immigration gutted fentanyl investigations, report says
      WASHINGTON — Fentanyl seizures decreased by 39% during the first year of the second Trump administration after U.S. Immigration and Customs Enforcement shifted the Department of Homeland Security’s criminal investigation…

### Ukrainian Internal News (national + local Kyiv) — 44 new of 120 total
  - (2026-08-22) Russian Strikes Damage Infrastructure and Utilities in Odesa Region, Injuring 1
      Russian overnight strikes on the Odesa region damaged transport, industrial, energy, and residential infrastructure, leaving one person injured and causing power and water outages, according to Regional Military Administ…
  - (2026-08-22) Who Is Lev Shlosberg, the Russian Politician Jailed for Opposing Russia’s War?
      Russian opposition politician Lev Shlosberg has been sentenced to 11 years and one month in a penal colony over anti-war statements and a social-media repost. His record stretches from exposing the covert deployment of R…
  - (2026-08-22) German Foreign Minister Johann Wadephul Arrives in Kyiv
      German Foreign Minister Johann Wadephul arrived in Kyiv on Saturday, Aug. 22, to demonstrate continued support ahead of Ukraine’s 35th Independence Day. Wadephul emphasized the need for Europe to remain united and highli…
  - (2026-08-22) Modern Independent Ukraine at 35: Achievements and Problems
      During a recent cultural festival on the grounds of Kyiv’s St. Sophia’s Cathedral, prominent diplomats, dissidents, writers and cultural figures discussed Ukraine’s key achievements and problems.
  - (2026-08-22) Ukraine Appoints 16 New Judges to High Anti-Corruption Court
      President Volodymyr Zelensky appointed 16 new judges to the High Anti-Corruption Court (HACC) on Aug. 21, assigning 11 to the first instance and five to the Appeals Chamber. HACC Chief of Staff Bohdan Kryklyvenko noted t…
  - (2026-08-22) Ukraine Downs 182 Drones and Missiles in Mass Russian Attack
      The Ukrainian Air Force reported intercepting 182 drones out of 217 launched, along with three Kh-31P/Kh-59 aviation missiles and six “Banderol” munitions during an early Saturday morning attack. Russian forces targeted…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-22) [SHAN LAO HU TONG LLC] Form 4 (Reporting)
      filed 2026-08-22 01:44 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [JI XIANG HU TONG HOLDINGS LTD] Form 4 (Reporting)
      filed 2026-08-22 01:44 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [Wu Lei] Form 4 (Reporting)
      filed 2026-08-22 01:44 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [GigaCloud Technology Inc] Form 4 (Issuer)
      filed 2026-08-22 01:44 UTC · role: Issuer — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [GoodRx Holdings, Inc.] Form 4 (Issuer)
      filed 2026-08-22 01:38 UTC · role: Issuer — Filed: 2026-08-21 AccNo: 0001193125-26-361608 Size: 34 KB
  - (2026-08-22) [Francisco Partners GP IV, L.P.] Form 4 (Reporting)
      filed 2026-08-22 01:38 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001193125-26-361608 Size: 34 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### State Legislative Action — 28 new of 134 total
  - (2026-08-22) [Alaska SB 280] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughp…
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re…
  - (2026-08-22) [Alaska SB 268] An Act relating to minimum paid sick leave requirements for individuals employed in seafood processing.
      An Act relating to minimum paid sick leave requirements for individuals employed in seafood processing.
  - (2026-08-21) [Alaska HB 189] An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent…
      An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent fund dividend by including payment t…
  - (2026-08-21) [Alaska HB 242] An Act relating to sexual assault.
      An Act relating to sexual assault.
  - (2026-08-21) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-08-21) [Alaska HB 217] An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
      An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.

### Government & military aircraft airborne (OpenSky) — 26 new of 27 total
  - (2026-08-22) SAMU05 (France)
      icao24: 39ca81 · position: (44.0975, 5.7914) · alt: 1988m · 267km/h
  - (2026-08-22) KAF3218 (Kuwait)
      icao24: 7061f5 · position: (22.6009, 55.7731) · alt: 7010m · 589km/h
  - (2026-08-22) JAF3LV (Belgium)
      icao24: 44d1ba · position: (39.7169, 7.8548) · alt: 10363m · 827km/h
  - (2026-08-22) JAF5KH (Belgium)
      icao24: 44d1a5 · position: (40.1145, 24.4325) · alt: 11582m · 870km/h
  - (2026-08-22) JAF74C (Belgium)
      icao24: 44d1b3 · position: (36.6392, 26.2942) · alt: 8839m · 769km/h
  - (2026-08-22) JAF3MJ (Belgium)
      icao24: 44d1b4 · position: (47.9634, 1.2019) · alt: 10972m · 926km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-22) [Israel-Iran-Hezbollah axis · keywords] Israeli settler blockades part of escalating violence against Palestinians in the occupied West Bank
      cbc.ca · English · tone NA
  - (2026-08-22) [Israel-Iran-Hezbollah axis · keywords] Israel denounces Türkiye as Ankara requests Interpol Red Notice for Netanyahu
      europe.chinadaily.com.cn · English · tone NA
  - (2026-08-22) [Israel-Iran-Hezbollah axis · keywords] Turkey requests international arrest warrant for Netanyahu over Gaza flotilla arrest
      premiumtimesng.com · English · tone NA
  - (2026-08-22) [Israel-Iran-Hezbollah axis · keywords] Implications of Mecca defense pact for Israel , India
      jpost.com · English · tone NA
  - (2026-08-22) [Israel-Iran-Hezbollah axis · keywords] Production of strategic military equipment tripled during US - Israeli aggression : Defense Ministry
      presstv.co.uk · English · tone NA
  - (2026-08-22) [Israel-Iran-Hezbollah axis · keywords] Trkiye asks Interpol to help arrest Netanyahu
      nigeriasun.com · English · tone NA

### World News (by country, top stories) — 24 new of 24 total
  - (2026-08-22) [China] The golden thread of social exchange - Chinadaily . com . cn
      europe.chinadaily.com.cn · English
  - (2026-08-22) [China] When adornments became symbols of love and loss
      europe.chinadaily.com.cn · English
  - (2026-08-22) [China] Lin - gang Special Area eyes 7 . 5 % growth
      europe.chinadaily.com.cn · English
  - (2026-08-22) [China] Argentina Paredes suspended 10 matches by FIFA over World Cup final clash
      europe.chinadaily.com.cn · English
  - (2026-08-22) [China] Israel denounces Türkiye as Ankara requests Interpol Red Notice for Netanyahu
      europe.chinadaily.com.cn · English
  - (2026-08-22) [China] Theme parks add immersive features to draw young visitors
      europe.chinadaily.com.cn · English

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 54 total
  - (2026-08-22) [The Register] Skylab completists, clear some shelf space for 26 DVDs
      Decades of archive hunting recover downlinks, silent reels, and footage once thought lost
  - (2026-08-22) [The Register] Casio decides it's about time the simple digital watch got a little smarter
      F-B100W adds Bluetooth and step tracking while keeping a two-year battery
  - (2026-08-22) [TechCrunch] Michael Polansky is training an AI model on skin that’s still alive
      Michael Polansky — better known publicly as Lady Gaga's partner and a former top deputy to Sean Parker — has quietly spent years building an AI-driven startup that keeps living human skin tissue alive for weeks outside t…
  - (2026-08-22) [TechCrunch] Japanese space tech startup Letara expands beyond satellite thrusters with $16M
      Japanese space startup Letara is betting its hybrid rocket technology can move beyond small satellite thrusters into a broader market for space, defense and security, after raising ¥2.6 billion ($16 million).
  - (2026-08-21) [The Hacker News] 14 Trojanized npm Packages Drop RedC2 4.0 Linux Backdoor With AI-Assisted C2
      Cybersecurity researchers have discovered a set of trojanized npm packages that masquerade as working calendar and streak utilities but are engineered to stealthily deliver an artificial intelligence (AI)-powered Linux i…
  - (2026-08-21) [Schneier on Security] Friday Squid Blogging: Neon Flying Squid
      The neon flying squid can fly in formation. The shoal of about 100 squid rose unexpectedly from a patch of the Pacific Ocean around 370 miles from Tokyo and glided near the boat for about 30 metres. The astonished resear…

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 101 total
  - (2026-08-21) [OFAC] Issuance of Venezuela-related General Licenses and Associated Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Issuance of Venezuela-related General Licenses and Associated Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 61 Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 61 Authorizing the Supply Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] 1266 - Office of Foreign Assets Control (.gov)
      1266 Office of Foreign Assets Control (.gov)
  - (2026-08-22) [USASpending] $30,721,269,898 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-08-22) [USASpending] $17,319,586,106 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:

### USGS earthquakes (M4.5+, past day) — 13 new of 28 total
  - (2026-08-22) M 6.2 - Scotia Sea
      M6.2 · Scotia Sea · depth 10 km
  - (2026-08-22) M 5.7 - Scotia Sea
      M5.7 · Scotia Sea · depth 10 km
  - (2026-08-22) M 5.3 - southern Mid-Atlantic Ridge
      M5.3 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-08-22) M 5.2 - 38 km NNE of Ruteng, Indonesia
      M5.2 · 38 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-22) M 5.0 - 45 km SE of Lukatan, Philippines
      M5.0 · 45 km SE of Lukatan, Philippines · depth 107.802 km
  - (2026-08-22) M 5.0 - 6 km S of Kitcharao, Philippines
      M5.0 · 6 km S of Kitcharao, Philippines · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-22) Dota 2: TEAM VISION vs Team Yandex (BO3) - The International Playoffs
      yes price: 55% · 24h volume: $1,728,205 · resolves 2026-08-22
  - (2026-08-22) LoL: Team WE vs LGD Gaming (BO3) - LPL Group Ascend
      yes price: 20% · 24h volume: $1,072,691 · resolves 2026-08-22
  - (2026-08-22) LoL: Team WE vs LGD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $820,959 · resolves 2026-08-22
  - (2026-08-22) Dota 2: TEAM VISION vs Team Yandex - Game 1 Winner
      yes price: 32% · 24h volume: $789,019 · resolves 2026-08-22
  - (2026-08-22) Will Brentford FC win on 2026-08-22?
      yes price: 46% · 24h volume: $770,787 · resolves 2026-08-22
  - (2026-08-22) LoL: Team WE vs LGD Gaming - Game 2 Winner
      yes price: 0% · 24h volume: $692,105 · resolves 2026-08-22

### U.S. Federal Action — 11 new of 14 total
  - (2026-08-24) Response to Clean Air Act Section 176A Petition From New Hampshire
  - (2026-08-24) Employer Contributions to Trump Accounts and Nondiscrimination Rules for Dependent Care Assistance Programs
  - (2026-08-24) Temporary Suspension of Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Alcoholic Beverages, Dairy, and Motor Vehicles
  - (2026-08-24) Education Department General Administrative Regulations
      The Secretary of Education proposes to amend the Education Department General Administrative Regulations (EDGAR) and other provisions in 2 CFR parts 3474 and 3485 to update the regulations and better align them with othe…
  - (2026-08-24) Revisions to the Entity List
      In this rule, the Bureau of Industry and Security (BIS) revises the Export Administration Regulations (EAR) by removing two addresses associated with Arrow Electronics (Hong Kong) Co., Ltd. from the Entity List under the…
  - (2026-08-24) Removal From the Entity List
      In this rule, the Bureau of Industry and Security (BIS) amends the Export Administration Regulations (EAR) by removing one entity from the Entity List under the destination of Turkey.

### Paper Trading Scorecard — 9 new of 130 total
  - (2026-08-22) [Polymarket] Will Solana reach $160 by December 31, 2026?
      This market will immediately resolve to “Yes” if any Binance 1-minute candle for Solana (SOL/USDT) between November 24, 2025, 14:30 and December 31, 2026, 23:59 in the ET timezone has a final “High” price equal to or gre…
  - (2026-08-22) [Manifold] Will GTA 6 come out on November 19, 2026?
  - (2026-08-22) [Manifold] Will the GTA VI leaker be publicly identified before GTA VI releases?
  - (2026-08-22) [Manifold] Will Tesla's Cybercab enter public Robotaxi service in Austin by August 31, 2026?
  - (2026-08-22) [Manifold] Will I promote to Masters?
  - (2026-08-22) [Manifold] Will Sandwich Cat break all time high in 30 days ??

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-08-21) U.S. Court of Appeals, 5th Cir.: In Re: Media Matters for America
  - (2026-08-21) U.S. Court of Appeals, 5th Cir.: Norcave Properties v. IRS
  - (2026-08-21) U.S. Court of Appeals, 5th Cir.: United States v. London
  - (2026-08-21) U.S. Court of Appeals, 1st Cir.: Air-Con, Inc. v. Daikin Applied Latin America, LLC
  - (2026-08-21) U.S. Court of Appeals, 1st Cir.: Skeffington v. Curtis
  - (2026-08-21) U.S. Court of Appeals, 1st Cir.: United States v. Bourget

### Commentary & analysis (last 7 days) — 1 new of 6 total
  - (2026-08-22) [Marginal Revolution] What should I ask Annie Lowrey?
      Yes I will be doing a Conversation with her. She has a new and very interesting book coming out, namely The Time Tax: How the Government Wastes Our Time―and How to Fix It. More generally, from Wikipedia: Annie M. Lowrey……

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-22) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=20, 14d-median=20; carrying terms: proposing, establish, national, action, certain, proposed, proposes, coast, within, public, navigable, establishing
- state_bills: today=134, 7d-median=134, 14d-median=129; carrying terms: commissioner, university, transfer, funds, required, child, requires, election, known, related, provides, various
- state_news: today=597, 7d-median=597, 14d-median=614; carrying terms: network, required, child, known, candidate, related, according, congress, second, affordable, survey, experience
- local_news: today=255, 7d-median=235, 14d-median=232; carrying terms: driver, child, house, faces, metro, target, trump, crash, arrested, august, charles, state
- foreign_news: today=1023, 7d-median=978, 14d-median=1009; carrying terms: prime, driver, shunxin, township, victim, southwest, banca, according, congress, iranian, caption, diversity
- chinese_internal: today=284, 7d-median=284, 14d-median=276; carrying terms: cbmizkfvx, title, cbmibefvx, target, cbmiw, cbmibkfvx, china, lxtfb, market, google, articles, blank
- russian_internal: today=1030, 7d-median=1030, 14d-median=1053; carrying terms: httperror, telegram, reuters, blank, media, https, client, target, times, patriot, europe, street
- ukrainian_internal: today=120, 7d-median=108, 14d-median=111; carrying terms: donald, officials, prime, ballistic, according, destroyed, efforts, defense, border, independent, president, title
- ukraine_theater: today=834, 7d-median=887, 14d-median=973; carrying terms: vdjjb, zpzjhenjzqzg, aznlrnnib, vugxoyuzqrfzpcnjsd, psxzd, vhzhfxdzdmnxzzddnkaelkujdvswewqziwtelcqw, tmrougt, bnhcclzba, dlbllmz, utjhxzfqxemdgx, wgvqtdljtf, tddtbezsm
- paper_bets: today=130, 7d-median=140, 14d-median=137; carrying terms: industrial, fuentes, funds, november, prime, leaders, general, washington, erupt, succeed, career, performing
- weather: today=144, 7d-median=166, 14d-median=180; carrying terms: streams, rainfall, norton, worth, boston, chance, thunderstorms, flood, valley, disregard, rivers, monday
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jtsjol, dexjpus, rates, recession, cpiaucsl, pcepilfe, vixcls, treasury, unrate, headline, funds, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, proxy, credit, rates, russell, crude, agriculture, equities, treasury, commodities, large, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=101, 7d-median=93, 14d-median=96; carrying terms: destabilising, stability, against, schools, funds, occupation, enable, agency, network, acronym, laboratory, blank
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, https, error, unauthorized, congresstrading, client, httperror, quiver, quantitative
- billionaires: today=30, 7d-median=34, 14d-median=34; carrying terms: gates, ortega, larry, hathaway, ellison, mukesh, yiming, amancio, ballmer, spacex, london, facebook
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, state, company, supreme, court, connecticut, trust, america, general, delaware, center, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, filed, issuer, holdings, management, partners, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, cycle, senate, robert, warner, filing, elect, trone, angels, sherrod, receipts, booker
- gdelt_regions: today=24, 7d-median=12, 14d-median=12; carrying terms: japan, english, korea, south
- gdelt_gkg: today=25, 7d-median=41, 14d-median=31; carrying terms: english, trump, hezbollah, israel, keywords, netanyahu, israeli, against, benjamin, india, hamas, august
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=27, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, france, germany, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: autochthonous, consecutive, barisal, cluster, notified, rates, cruise, involved, beginning, discharged, fourth, divisions
- cisa_kev: today=12, 7d-median=10, 14d-median=9; carrying terms: authentication, vendor, injection, remediation, command, secure, vulnerability, firewall, cisco, product, inspection, ancillary
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=300, 14d-median=300
- usgs_quakes: today=28, 7d-median=24, 14d-median=20; carrying terms: depth, indonesia, russia, ruteng, islands, japan, kuril, south, region, philippines, banda, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, winner, august, championship, champions, league, interest, meeting, resolves, september, donetsk, shakhtar
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, class, revolution, conversable, marginal, https, conversableeconomist, marginalrevolution, impossible, future, links, assorted
- tech_news: today=54, 7d-median=56, 14d-median=57; carrying terms: technica, known, hacking, according, spectrum, navigate, provides, digital, still, techcrunch, computer, customers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: rounds, angus, shontel, marcy, donald, rutherford, hagerty, smith, gomez, waters, norton, chicago
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, markets, either, consensus, market, decision, sufficient, identify, module, placed, paper, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*