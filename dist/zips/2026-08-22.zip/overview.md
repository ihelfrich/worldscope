# WORLDSCOPE morning brief — 2026-08-22

## Headline
2038 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (403) · Russian Internal News (state + in-exile) (348) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (179) · Chinese Internal News (168) · U.S. Weather + Severe / Climate Outlooks (114) · State-Level News (104) · Local News: St. Louis + Atlanta (101) · GDELT GKG — themes / entities / watch areas (75) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (36) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 403 new of 1016 total
  - (2026-08-22) [Global] China’s new moon mission could unlock secret of lunar ice: Why that matters
      The Chang'e-7 seeks to find out more about the water trapped within the moon's shadowed craters.
  - (2026-08-22) [Global] ‘It was a tsunami’: Floods leave death trail in India’s Assam
      From father searching for his daughter's body to man who drowned trying to save a friend, floods take devastating toll.
  - (2026-08-22) [Global] Inundated Philippine communities seek answers over flood control funds
      Al Jazeera’s Jamela Alindogan reports from Northern Philippines where inundated communities are demanding answers.
  - (2026-08-22) [Global] Palestinian teen shot and killed in West Bank attack, UN responds
      A 17-year-old Palestinian was killed and another person critically injured in a settler attack in the occupied West Bank
  - (2026-08-22) [Global] Nigeria and the Sahel: A growing security divide
      A widening diplomatic rift is complicating efforts to confront a shared cross-border security threat.
  - (2026-08-22) [Global] At least 13 Tunisians missing as migrant boat headed for Italy capsizes
      Thousands of people have died since 2014 trying to cross the Mediterranean Sea and reach Europe.

### Russian Internal News (state + in-exile) — 348 new of 1015 total
  - (2026-08-22) Россия нанесла удар по Украине. В Киеве и Запорожье есть погибшие. В Одесской области поврежден вокзал | LEDE: Российские военные в ночь на 22 августа нанесли удар по Киеву, сообщили местные] (ru: Рос…
      Российские военные в ночь на 22 августа нанесли удар по Киеву, сообщили местные власти. В Дарницком районе города загорелся склад. По предварительным данным, один человек погиб, несколько человек получили ранения.
  - (2026-08-22) Не спорит в интернете, не посещает сайты в зонах .com и .io, не звонит «Леше ФСБ» — и никому не доверяет. Мы прочитали памятки МВД и собрали образ идеального россиянина (по версии полиции) | LE] (ru:…
      МВД России регулярно выпускает памятки для россиян о том, как обезопасить себя от окружающих угроз. Но наряду с разумными и важными предостережениями (вроде того, чтобы не отправлять деньги незнакомым людям), в этих памя…
  - (2026-08-22) Украина впервые нанесла удар по Ozon — загорелся склад компании в Самарской области. В том же регионе горит НПЗ | LEDE: Украинские беспилотники в ночь на 22 августа впервые нанесли удары по ] (ru: Укр…
      Украинские беспилотники в ночь на 22 августа впервые нанесли удары по логистическому центру маркетплейса Ozon — в результате атаки загорелся склад в Самарской области. Также в регионе повреждено промышленное предприятие,…
  - (2026-08-21) Правительство разрешило людям без руки или ноги водить автобусы | LEDE: Премьер-министр России Михаил Мишустин изменил перечень медицинских ограничений для управления автобусами, трамваями, ] (ru: Пра…
      Премьер-министр России Михаил Мишустин изменил перечень медицинских ограничений для управления автобусами, трамваями, троллейбусами и грузовиками. Его распоряжение опубликовано на официальном портале правовой информации.
  - (2026-08-21) Россия ударила по крупнейшему торговому центру Кривого Рога — а через полчаса ударила снова, когда там шла спасательная операция . 16 человек погибли, 130 ранены | LEDE: Российская армия ата] (ru: Рос…
      Российская армия атаковала крупнейший торговый центр Кривого Рога, заявил председатель совета обороны города Александр Вилкул. Судя по видео, опубликованным в соцсетях, речь идет о торговом центре «Солнечная галерея». По…
  - (2026-08-22) Над Севастополем за сутки нейтрализовали три беспилотника ВСУ | LEDE: ] (ru: Над Севастополем за сутки нейтрализовали три беспилотника ВСУ)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 179 new of 835 total
  - (2026-08-22) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-20) [Liveuamap] Israel&039;s Prime Minister&039;s Office says it has not approved the entry of the Board of Peace&039;s International Stabilization Force (ISF) into the Gaza Strip. "Israel has made it cle…
      Israel&039;s Prime Minister&039;s Office says it has not approved the entry of the Board of Peace&03
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2026-08-20) [Liveuamap] Romania deployed F-16 fighter jets to destroy a marine drone approaching the Neptun Deep offshore gas project in the Black Sea. Officials said the drone threatened hundreds of workers and…
      Romania deployed F-16 fighter jets to destroy a marine drone approaching the Neptun Deep offshore gas project in the Black Sea. Offi
  - (2026-08-20) [Liveuamap] At South Slobozhansky(Kharkiv) direction clashes yesterday near Starytsa and Lyman, Volokhivka, Karayichne, Okhrimivka and Bochkove, - General Staff of Armed Forces of Ukraine reports - Li…
      At South Slobozhansky(Kharkiv) direction clashes yesterday near Starytsa and Lyman, Volokhivka, Karayichne, Okhrimivka and Bochk
  - (2026-08-20) [Liveuamap] At least 10 people wounded as result of Russian strikes at the groceries in Kramatorsk and Sloviansk - Liveuamap
      At least 10 people wounded as result of Russian strikes at the groceries in Kramatorsk and Sloviansk <font color

### Chinese Internal News — 168 new of 286 total
  - (2026-08-21) 葛小波辞任国联民生证券总裁 7年间完成上市及民生证券并购 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5IclhEY0Z1aDFmUmV5akhQRWRkeG5RZHloNWlhZzhCemU0MnItNXpSUkFZX1JiTW5NUnlMRm94MWppY0dJa2w4aFhnZ] (zh:…
      葛小波辞任国联民生证券总裁 7年间完成上市及民生证券并购 财新
  - (2026-08-21) 广西横州水库溃坝洪灾共致107人遇难、7人失联 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBaZEJNcHJjYV9VeE5MajJ2d1JHT1dYdnZDZ3VaWDhnQkhtVDFjbmdXNmZsZ2JYYlRUVjlhVVJ5V2J0OGxu] (zh:…
      广西横州水库溃坝洪灾共致107人遇难、7人失联 china.caixin.com
  - (2026-08-22) 末代皇帝，人民的皇帝｜猎读 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBNVWZKbno0SVkyc1Z0dVJITHdSYUhpam1YakU1eVhkcjRvbkxmVld0X3RyNGpHSDU3Vm5wQ0pkTEVuUlNjNU1MNVF3dW9OQVJoQXpZc2to] (zh:…
      末代皇帝，人民的皇帝｜猎读 财新
  - (2026-08-22) 第二届世界人形机器人运动会今日开幕 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5xaVBFOEhIeEwwMG1UMGFzS1ZuRE9IZTFuZ0ZtMjFUM3NiN3NibFBjYUtLNVlZTVk0WlJnMTdZcmphR0hSUm1RVXlXdHNOSmxJODFG] (zh:…
      第二届世界人形机器人运动会今日开幕 财新
  - (2026-08-22) 空客：AI硬件代替跨境电商成为货运增量 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFBHMFRDNUUxajlLZFRvS0EzMlExam8xMVhuZHZmaENzYXBES3dmYmhOVHJSVlJIZXJnV3F5Ry1VZVV5RzJlbVVqR0RrTWpOUkc5cT] (zh:…
      空客：AI硬件代替跨境电商成为货运增量 财新
  - (2026-08-22) 国产闪存龙头长存控股科创板IPO获受理 拟募资330亿元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1sQ3hDQ1FLSnhjN0lrNE1pYW5KUnRDNlZvMGluejdjQUNjU1dTanBYejBud0xzTDRHN0VvVlBDcUhFaHBJcjBGQlZDR] (zh:…
      国产闪存龙头长存控股科创板IPO获受理 拟募资330亿元 财新

### U.S. Weather + Severe / Climate Outlooks — 114 new of 159 total
  - (2026-08-22) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 22 at 2:24AM CDT until August 22 at 3:15AM CDT by NWS North Platte NE
      SVRLBF The National Weather Service in North Platte has issued a * Severe Thunderstorm Warning for... Southeastern Holt County in north central Nebraska... Northeastern Wheeler County in north central Nebraska... * Until…
  - (2026-08-22) [Moderate] Heat Advisory: Heat Advisory issued August 22 at 2:23AM CDT until August 22 at 8:00PM CDT by NWS Fort Worth TX
      * WHAT...Heat index values up to 106. * WHERE...Portions of north and central Texas. * WHEN...Until 8 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity will increase the risk for heat-related illnesses…
  - (2026-08-22) [Moderate] Heat Advisory: Heat Advisory issued August 22 at 2:23AM CDT until August 22 at 8:00PM CDT by NWS Fort Worth TX
      * WHAT...Heat index values up to 108. * WHERE...Navarro, Anderson, and Henderson Counties. * WHEN...Until 8 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity will increase the risk for heat-related illn…
  - (2026-08-22) [Moderate] Heat Advisory: Heat Advisory issued August 22 at 2:23AM CDT until August 22 at 8:00PM CDT by NWS Fort Worth TX
      * WHAT...Temperatures up to 104. * WHERE...Cooke and Montague Counties. * WHEN...Until 8 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity will increase the risk for heat-related illnesses to occur, par…
  - (2026-08-22) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 22 at 2:23AM CDT until August 22 at 8:00PM CDT by NWS Fort Worth TX
      * WHAT...Dangerously hot conditions with heat index values up to 108. * WHERE...North Texas * WHEN...Until 8 PM CDT this evening. * IMPACTS...Heat related illnesses increase significantly during extreme heat and high hum…
  - (2026-08-22) [Moderate] Heat Advisory: Heat Advisory issued August 22 at 2:23AM CDT until August 22 at 8:00PM CDT by NWS Fort Worth TX
      * WHAT...Heat index values up to 108. * WHERE...Bosque, Falls, Freestone, Hill, Limestone, McLennan, Leon, and Robertson Counties. * WHEN...Until 8 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity will…

### State-Level News — 104 new of 595 total
  - (2026-08-22) [California] Governor Newsom announces appointments 8.21.26
  - (2026-08-21) [California] FREE MONEY FOR KIDS: Governor Newsom and First Partner celebrate one million families claim CalKIDS “baby bonds” accounts
  - (2026-08-21) [Connecticut] Housing, CSCU auditing, school technology: CT politics news
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/08/FLOCK-SIGNS-0821-JL-003-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-08-21) [Connecticut] Electric Boat cheers move into new campus at former Crystal Mall
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/ELECTRIC-BOAT-0821-SG-13-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcse…
  - (2026-08-21) [Arizona] Mayes declines to prosecute Hobbs for Sunshine Residential bribery accusations
      Attorney General Kris Mayes says there’s no evidence that Gov. Katie Hobbs broke the law when her administration awarded a pay increase to a foster care provider that donated more than $400,000 to her political campaign.…
  - (2026-08-21) [Arizona] ‘All hands on deck’ for immigration gutted fentanyl investigations, report says
      WASHINGTON — Fentanyl seizures decreased by 39% during the first year of the second Trump administration after U.S. Immigration and Customs Enforcement shifted the Department of Homeland Security’s criminal investigation…

### Local News: St. Louis + Atlanta — 101 new of 245 total
  - (2026-08-21) [St. Louis] Proposed charter school could be a first for Riverview Gardens, set to open next year
  - (2026-08-21) [St. Louis] GroveFest won’t return this year, but Oktoberfest and bar crawl planned in its place
  - (2026-08-21) [St. Louis] Reggie Jones, mayor of Dellwood, dies Friday
  - (2026-08-22) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-08-21) [St. Louis] Dellwood Mayor Reggie Jones dies - First Alert 4
      Dellwood Mayor Reggie Jones dies First Alert 4
  - (2026-08-22) [St. Louis] Family visiting St. Louis for medical care awakened by volleys of gunfire outside a short-term rental - First Alert 4
      <a href="https://news.google.com/rss/articles/CBMiywFBVV95cUxOSW5ZQUlvbDFqNi01UXRQZTNHSks5dENCV1dFYzRYM0VvSGgzT1JlS1NaRHk0bDMzYXlBMElrSU9zSFdtMzF6YXN1TEZnbVNSREFGeTBlU3JrUjA1Q2piTnlaUm1ramxXWE5HRjRZRUFZdWxWQl9HY3RoRXZ3QV…

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-08-22) [Russia oil sanctions perimeter · themes] 8月新能源汽车预计销量104万辆 每卖出3辆车只有1辆油车
      finance.sina.com.cn · Chinese · tone NA
  - (2026-08-22) [Russia oil sanctions perimeter · themes] Libyanın akaryakıt altyapısını Türkiyenin Deha ı yeniden yapılandıracak - Haber Hürriyeti
      haberhurriyeti.com · Turkish · tone NA
  - (2026-08-22) [Russia oil sanctions perimeter · themes] Trump Sebut Iran Belum Siap untuk Kesepakatan , AS Siapkan Sanksi Baru
      jawapos.com · Indonesian · tone NA
  - (2026-08-22) [Russia oil sanctions perimeter · themes] El USS Abraham Lincoln : Estados Unidos debe exigir la verdad
      spanish.christianpost.com · Spanish · tone NA
  - (2026-08-22) [Russia oil sanctions perimeter · themes] 墨西哥两名渔民靠冷藏箱在海上漂流5天获救 ， 5天没吃没喝
      finance.sina.com.cn · Chinese · tone NA
  - (2026-08-22) [Russia oil sanctions perimeter · themes] 十五五 时期 ， 美丽重庆建设如何推进 ？ 来看规划→ - 华龙网 - 重庆市委市政府官方新闻门户
      cqnews.net · Chinese · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-22) [SHAN LAO HU TONG LLC] Form 4 (Reporting)
      filed 2026-08-22 01:44 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [JI XIANG HU TONG HOLDINGS LTD] Form 4 (Reporting)
      filed 2026-08-22 01:44 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [Wu Lei] Form 4 (Reporting)
      filed 2026-08-22 01:44 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [GigaCloud Technology Inc] Form 4 (Issuer)
      filed 2026-08-22 01:44 UTC · role: Issuer — Filed: 2026-08-21 AccNo: 0001628280-26-058507 Size: 19 KB
  - (2026-08-22) [GoodRx Holdings, Inc.] Form 4 (Issuer)
      filed 2026-08-22 01:38 UTC · role: Issuer — Filed: 2026-08-21 AccNo: 0001193125-26-361608 Size: 34 KB
  - (2026-08-22) [Francisco Partners GP IV, L.P.] Form 4 (Reporting)
      filed 2026-08-22 01:38 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001193125-26-361608 Size: 34 KB

### Ukrainian Internal News (national + local Kyiv) — 36 new of 114 total
  - (2026-08-22) Скільки ракет у РФ, що таке "Бандеролі", російський Starlink та вкиклики для Хмари – про війну за тиждень | LEDE: ] (uk: Скільки ракет у РФ, що таке "Бандеролі", російський Starlink та вкиклики для Хм…
  - (2026-08-22) В ЄС відреагували на удар РФ по Кривому Рогу | LEDE: ] (uk: В ЄС відреагували на удар РФ по Кривому Рогу)
  - (2026-08-22) Мелоні: Думала, з Трампом все буде простіше | LEDE: Джорджа Мелоні прокоментувала конфліктні стосунки з Дональдом Трампом та вказала на важливість єдності Заходу.] (uk: Мелоні: Думала, з Трампом все б…
      Джорджа Мелоні прокоментувала конфліктні стосунки з Дональдом Трампом та вказала на важливість єдності Заходу.
  - (2026-08-22) Ейфелеву вежу підсвітять синьо-жовтими кольорами до Дня Незалежності України | LEDE: ] (uk: Ейфелеву вежу підсвітять синьо-жовтими кольорами до Дня Незалежності України)
  - (2026-08-22) ПС: Росія атакувала ракетами та безпілотниками, є влучання та падіння на понад 50 локаціях | LEDE: Вночі 22 серпня Росія обстріляла Україну ракетами, дронами та "Бандеролями". Основні удари — К] (uk:…
      Вночі 22 серпня Росія обстріляла Україну ракетами, дронами та "Бандеролями". Основні удари — Київщина та Одещина.
  - (2026-08-22) Пункт пропуску на кордоні з Молдовою відновив роботу через добу | LEDE: Пропускні операції у міжнародному пункті "Табаки" на кордоні з Молдовою знову працюють після атаки РФ.] (uk: Пункт пропуску на к…
      Пропускні операції у міжнародному пункті "Табаки" на кордоні з Молдовою знову працюють після атаки РФ.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### State Legislative Action — 28 new of 134 total
  - (2026-08-22) [Alaska SB 280] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughp…
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re…
  - (2026-08-22) [Alaska SB 268] An Act relating to minimum paid sick leave requirements for individuals employed in seafood processing.
      An Act relating to minimum paid sick leave requirements for individuals employed in seafood processing.
  - (2026-08-21) [Alaska HB 189] An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent…
      An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent fund dividend by including payment t…
  - (2026-08-21) [Alaska HB 242] An Act relating to sexual assault.
      An Act relating to sexual assault.
  - (2026-08-21) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-08-21) [Alaska HB 217] An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
      An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.

### IT, InfoSys & cybersecurity news (last 7 days) — 14 new of 54 total
  - (2026-08-22) [TechCrunch] Michael Polansky is training an AI model on skin that’s still alive
      Michael Polansky — better known publicly as Lady Gaga's partner and a former top deputy to Sean Parker — has quietly spent years building an AI-driven startup that keeps living human skin tissue alive for weeks outside t…
  - (2026-08-22) [TechCrunch] Japanese space tech startup Letara expands beyond satellite thrusters with $16M
      Japanese space startup Letara is betting its hybrid rocket technology can move beyond small satellite thrusters into a broader market for space, defense and security, after raising ¥2.6 billion ($16 million).
  - (2026-08-21) [The Hacker News] 14 Trojanized npm Packages Drop RedC2 4.0 Linux Backdoor With AI-Assisted C2
      Cybersecurity researchers have discovered a set of trojanized npm packages that masquerade as working calendar and streak utilities but are engineered to stealthily deliver an artificial intelligence (AI)-powered Linux i…
  - (2026-08-21) [Schneier on Security] Friday Squid Blogging: Neon Flying Squid
      The neon flying squid can fly in formation. The shoal of about 100 squid rose unexpectedly from a patch of the Pacific Ocean around 370 miles from Tokyo and glided near the boat for about 30 metres. The astonished resear…
  - (2026-08-21) [The Register] AWS Security makes an inscrutable choice
      Quarantining leaked credentials is not good enough
  - (2026-08-21) [The Register] Cloverleaf deal is latest example of Nvidia using its war chest to patch cracks in the AI bubble
      Nv's new chips need new datacenters, but you can't have bit barns without power

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 101 total
  - (2026-08-21) [OFAC] Issuance of Venezuela-related General Licenses and Associated Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Issuance of Venezuela-related General Licenses and Associated Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] 1266 - Office of Foreign Assets Control (.gov)
      1266 Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 61 Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 61 Authorizing the Supply Office of Foreign Assets Control (.gov)
  - (2026-08-22) [USASpending] $30,721,269,898 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-08-22) [USASpending] $17,319,586,106 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-22) [China] Second Ministerial Meeting of China - Indonesia Joint Foreign and Defense Ministerial Dialogue held in Jakarta
      shanghainews.net · English
  - (2026-08-22) [China] Moderna soars as experimental cancer treatment clears key test
      shanghainews.net · English
  - (2026-08-22) [China] Air Weapons : Rusty Dagger Cruise Missile
      strategypage.com · English
  - (2026-08-22) [China] Chinese film
      hongkongherald.com · English
  - (2026-08-22) [China] China Evergrande founder gets life imprisonment
      taiwansun.com · English
  - (2026-08-22) [China] China embodied AI enters critical phase for large - scale application : experts
      taiwansun.com · English

### Government & military aircraft airborne (OpenSky) — 12 new of 12 total
  - (2026-08-22) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (45.3976, -2.2198) · alt: 10965m · 905km/h
  - (2026-08-22) JAF56C (Bulgaria)
      icao24: 4520aa · position: (38.5073, -5.0917) · alt: 10972m · 901km/h
  - (2026-08-22) JAF62J (Belgium)
      icao24: 44d1a5 · position: (36.8029, 27.0883) · on ground
  - (2026-08-22) JAF7HW (Belgium)
      icao24: 44d1c2 · position: (35.5834, -11.7839) · alt: 10668m · 800km/h
  - (2026-08-22) GAF649 (Germany)
      icao24: 3f7b3c · position: (34.2293, 29.8903) · alt: 13106m · 909km/h
  - (2026-08-22) NCR852 (United States)
      icao24: a7488c · position: (41.1136, -82.7185) · alt: 12192m · 789km/h

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-22) Will Brentford FC win on 2026-08-22?
      yes price: 46% · 24h volume: $745,422 · resolves 2026-08-22
  - (2026-08-22) Dota 2: Nigma Galaxy vs BoomBoys (BO3) - The International Playoffs
      yes price: 40% · 24h volume: $657,417 · resolves 2026-08-22
  - (2026-08-22) LoL: Team WE vs LGD Gaming (BO3) - LPL Group Ascend
      yes price: 36% · 24h volume: $519,179 · resolves 2026-08-22
  - (2026-08-22) Dota 2: TEAM VISION vs Team Yandex (BO3) - The International Playoffs
      yes price: 74% · 24h volume: $437,964 · resolves 2026-08-22
  - (2026-08-22) Will Sunderland AFC win on 2026-08-22?
      yes price: 36% · 24h volume: $416,738 · resolves 2026-08-22
  - (2026-08-22) Will Ségolène Royal win the 2027 French presidential election?
      yes price: 0% · 24h volume: $309,949 · resolves 2027-04-30

### USGS earthquakes (M4.5+, past day) — 9 new of 29 total
  - (2026-08-22) M 5.3 - southern Mid-Atlantic Ridge
      M5.3 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-08-22) M 5.2 - 38 km NNE of Ruteng, Indonesia
      M5.2 · 38 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-22) M 5.0 - 45 km SE of Lukatan, Philippines
      M5.0 · 45 km SE of Lukatan, Philippines · depth 107.802 km
  - (2026-08-22) M 5.0 - 6 km S of Kitcharao, Philippines
      M5.0 · 6 km S of Kitcharao, Philippines · depth 10 km
  - (2026-08-22) M 4.9 - 167 km SE of San Jose Village, Northern Mariana Islands
      M4.9 · 167 km SE of San Jose Village, Northern Mariana Islands · depth 10 km
  - (2026-08-22) M 4.7 - 71 km NNW of Ende, Indonesia
      M4.7 · 71 km NNW of Ende, Indonesia · depth 10 km

### Paper Trading Scorecard — 8 new of 129 total
  - (2026-08-22) [Polymarket] Will Solana reach $160 by December 31, 2026?
      This market will immediately resolve to “Yes” if any Binance 1-minute candle for Solana (SOL/USDT) between November 24, 2025, 14:30 and December 31, 2026, 23:59 in the ET timezone has a final “High” price equal to or gre…
  - (2026-08-22) [Manifold] Will the GTA VI leaker be publicly identified before GTA VI releases?
  - (2026-08-22) [Manifold] Will Tesla's Cybercab enter public Robotaxi service in Austin by August 31, 2026?
  - (2026-08-22) [Manifold] Will I promote to Masters?
  - (2026-08-22) [Manifold] Will Sandwich Cat break all time high in 30 days ??
  - (2026-08-22) [Manifold] Will Cristiano Ronaldo reach 1,000 career goals before he retires?

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-08-21) U.S. Court of Appeals, 5th Cir.: In Re: Media Matters for America
  - (2026-08-21) U.S. Court of Appeals, 5th Cir.: Norcave Properties v. IRS
  - (2026-08-21) U.S. Court of Appeals, 5th Cir.: United States v. London
  - (2026-08-21) U.S. Court of Appeals, 1st Cir.: Air-Con, Inc. v. Daikin Applied Latin America, LLC
  - (2026-08-21) U.S. Court of Appeals, 1st Cir.: Skeffington v. Curtis
  - (2026-08-21) U.S. Court of Appeals, 1st Cir.: United States v. Bourget

### Commentary & analysis (last 7 days) — 1 new of 6 total
  - (2026-08-22) [Marginal Revolution] What should I ask Annie Lowrey?
      Yes I will be doing a Conversation with her. She has a new and very interesting book coming out, namely The Time Tax: How the Government Wastes Our Time―and How to Fix It. More generally, from Wikipedia: Annie M. Lowrey……

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-22) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=0, 7d-median=20, 14d-median=20; carrying terms: program, establish, action, provide, proposes, state, proposed, proposing, national, certain, final, specifically
- state_bills: today=134, 7d-median=134, 14d-median=129; carrying terms: agency, program, conditions, election, protection, assistance, providing, permits, executive, enforcement, establish, training
- state_news: today=595, 7d-median=595, 14d-median=595; carrying terms: massachusetts, major, crucial, program, polling, taxes, increase, majority, lawmakers, patients, article, lawsuit
- local_news: today=245, 7d-median=235, 14d-median=230; carrying terms: woman, public, house, https, officer, families, county, north, child, dekalb, reported, injured
- foreign_news: today=1016, 7d-median=978, 14d-median=1007; carrying terms: trade, explaining, afternoon, banco, major, single, hunan, extravagance, karnataka, reaching, street, flames
- chinese_internal: today=286, 7d-median=286, 14d-median=271; carrying terms: cbmix, lxtfb, https, politics, lxtfa, blank, global, people, cbmibkfvx, target, china, cbmixkfvx
- russian_internal: today=1015, 7d-median=1015, 14d-median=1040; carrying terms: europe, street, laquo, media, times, reuters, istories, novaya, forbidden, gazeta, title, target
- ukrainian_internal: today=114, 7d-median=108, 14d-median=108; carrying terms: least, destroyed, moscow, several, warehouse, despite, update, public, against, ukraine, assessment, hromadske
- ukraine_theater: today=835, 7d-median=887, 14d-median=945; carrying terms: eujivkxfafoxvxlasdg, odedmafhfs, klwrysnfib, lkzulrcm, wfpstwjick, combat, cbmingfbvv, cbmiigfbvv, hauxvxvgwwt, grmvmaux, zgdkbdjbrv, zzchniouvksldbmhuxqthkaevmtk
- paper_bets: today=129, 7d-median=140, 14d-median=135; carrying terms: pirates, polymarket, chair, rippling, north, achieved, nebraska, celsius, december, president, georgia, inflation
- weather: today=159, 7d-median=166, 14d-median=177; carrying terms: especially, cramps, extreme, values, afternoon, afdhgx, significantly, dangerously, lying, return, peachtree, special
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: recession, money, unemployment, labor, consumption, rates, payems, payrolls, balance, cpilfesl, latest, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, agriculture, large, proxy, corporate, crypto, crude, futures, rates, close, china, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=101, 7d-median=93, 14d-median=96; carrying terms: contract, sovereignty, trade, proliferation, transactions, facilitate, transnistrian, management, mediterranean, mufswgh, hfufrmmg, performance
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quiver, httperror, quantitative, error, client, unauthorized, congresstrading, quiverquant
- billionaires: today=0, 7d-median=34, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, state, international, court, supreme, company, trade, connecticut, delaware, america, alabama, james
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, holdings, management, partners, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ossoff, receipts, robert, committee, warner, michael, angels, alexandria, johnson, trone, jonathan, james
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=75, 7d-median=49, 14d-median=37; carrying terms: english, russian, themes, indonesian, china, chinese, perimeter, sanctions, trump, spanish, russia, greek
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=12, 7d-median=30, 14d-median=30; carrying terms: position, belgium, ground, germany, kingdom, bulgaria, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: circulation, diphtheria, welfare, workers, jerusalem, north, fifth, vaccine, periods, young, ongoing, seven
- cisa_kev: today=12, 7d-median=10, 14d-median=9; carrying terms: vendor, vulnerability, cisco, firewall, product, authentication, remediation, injection, command, secure, windows, metabase
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=285, 14d-median=285
- usgs_quakes: today=29, 7d-median=24, 14d-median=18; carrying terms: depth, indonesia, russia, islands, ruteng, south, region, philippines, japan, kuril, banda, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: champions, interest, shakhtar, rates, september, league, resolves, donetsk, championship, meeting, august, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, revolution, https, economist, class, conversable, conversableeconomist, impossible, marginalrevolution, future, links, assorted
- tech_news: today=54, 7d-median=56, 14d-median=56; carrying terms: hacking, schneier, weekday, navigate, digital, technica, technologies, infrastructure, review, computerweekly, online, newsletter
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: lawler, ossoff, trade, schatz, shomari, hayes, capito, chuck, brian, bonamici, sullivan, casten
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, claude, converges, placed, unavailable, consensus, either, decision, sufficient, today, placement, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*