# WORLDSCOPE morning brief — 2026-09-20

## Headline
2621 new items across 20 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (657) · Russian Internal News (state + in-exile) (448) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (285) · Chinese Internal News (227) · Local News: St. Louis + Atlanta (138) · State Legislative Action (120) · U.S. Weather + Severe / Climate Outlooks (115) · State-Level News (92) · Ukrainian Internal News (national + local Kyiv) (56) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (30)

## What changed today
### International News + Multilateral Institutions — 657 new of 982 total
  - (2026-09-20) [Global] Largest attack on Moscow sees Ukraine fire hundreds of drones, mayor says
      Moscow's mayor says 450 drones were downed during the overnight barrage, in which two people died.
  - (2026-09-20) [Global] Ed Sheeran admits 'mistakes' at first show since Macklemore controversy
      The singer spoke about Israel and Gaza after Macklemore was dropped from his tour for making pro-Palestinian remarks on stage.
  - (2026-09-20) [Global] German elections under way which could decide fate of Chancellor Merz
      The chancellor is facing intense political pressure which will increase if his party struggles in Sunday's polls.
  - (2026-09-19) [Global] Houthis say they targeted Saudi capital with ballistic missiles
      A reported strike on a fuel depot at Riyadh airport caused delays on Saturday, as Saudi Arabia says it shot down a ballistic missile aimed at the capital.
  - (2026-09-19) [Global] Nato welcomes Greenland deal as Trump says it will give US 'permanent security control'
      Denmark and the US have reached an agreement after months of threats from Donald Trump to annex the territory.
  - (2026-09-19) [Global] Our head teacher was an abuser. We joined forces to get justice - now we're married
      Students spent years collecting evidence against their Indonesian principal, before falling in love.

### Russian Internal News (state + in-exile) — 448 new of 542 total
  - (2026-09-20) Явка на выборах в Госдуму превысила 50% | LEDE: Явка избирателей на выборах депутатов Госдумы IX созыва превысила 50,46%, следует из данных Центральной избирательной комиссии России на 13:40] (ru: Явк…
      Явка избирателей на выборах депутатов Госдумы IX созыва превысила 50,46%, следует из данных Центральной избирательной комиссии России на 13:40 по Москве 20 сентября.
  - (2026-09-20) По всей Москве на избирательных участках из-за сбоя перестали выдавать бумажные бюллетени | LEDE: В Москве на избирательных участках перестали выдавать бумажные бюллетени из-за неполадок в р] (ru: По…
      В Москве на избирательных участках перестали выдавать бумажные бюллетени из-за неполадок в работе системы электронных списков, сообщили «Медузе» избиратели.
  - (2026-09-20) Лауреат Нобелевской премии мира Дмитрий Муратов в эфире CNN призвал Уиткоффа добиться, чтобы российских политзаключенных освободили | LEDE: Лауреат Нобелевской премии мира и бывший главный р] (ru: Лау…
      Лауреат Нобелевской премии мира и бывший главный редактор «Новой газеты» Дмитрий Муратов в интервью американскому телеканалу CNN рассказал о российских политзаключенных.
  - (2026-09-20) Третий день выборов в Госдуму. Что происходит. В Москве перестали выдавать бумажные бюллетени. В регионах полиция задерживает наблюдателей. Материал обновляется | LEDE: . ] (ru: Третий день выборов в…
      .
  - (2026-09-20) Бывший глава штаба Надеждина Дмитрий Кисиев заявил, что его задержали у избирательного участка в Сербии | LEDE: Полиция Сербии задержала бывшего главу штаба Бориса Надеждина, политтехнолога ] (ru: Быв…
      Полиция Сербии задержала бывшего главу штаба Бориса Надеждина, политтехнолога Дмитрия Кисиева рядом с посольством России в Белграде.
  - (2026-09-20) Пользователи в России пожаловались на проблемы с доступом в App Store | LEDE: Российские пользователи сообщают о проблемах с доступом к App Store — магазину приложений Apple, следует из данн] (ru: Пол…
      Российские пользователи сообщают о проблемах с доступом к App Store — магазину приложений Apple, следует из данных сервиса «Сбой.рф».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 285 new of 487 total
  - (2026-09-20) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-19) [FIRMS] thermal anomaly 45.536, 34.966 (FRP 4.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-19 1043Z, FRP 4.55 MW
  - (2026-09-19) [FIRMS] thermal anomaly 45.540, 34.969 (FRP 4.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-19 1043Z, FRP 4.55 MW
  - (2026-09-19) [FIRMS] thermal anomaly 45.543, 34.968 (FRP 2.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-19 1043Z, FRP 2.78 MW
  - (2026-09-19) [FIRMS] thermal anomaly 45.547, 34.968 (FRP 2.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-19 1043Z, FRP 2.78 MW
  - (2026-09-19) [FIRMS] thermal anomaly 45.550, 34.967 (FRP 1.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-19 1043Z, FRP 1.9 MW

### Chinese Internal News — 227 new of 269 total
  - (2026-09-20) 商品详情 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5zd284YWFxS2tCdE1CUDZHazVqMmx6dWdJSk5CeW5hZHZOZlBOVWdKdUgySkZFTWxRVnRPQ0pwX0hianlRVThaZG14enVVZDFkUTNzd1U3WkJnYjFfO] (zh:…
      商品详情 财新
  - (2026-09-18) 财新闻｜HYROX失禁选手发文道歉 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1zYkVkcTlFRHNNUGJWZGRPbUFVRFZjNENKNU42a1hnSlJ1bEtJNXVOa0ZCZFlfVENSRHBSWXNERllvamk3THRVRzV] (zh:…
      财新闻｜HYROX失禁选手发文道歉 mini.caixin.com
  - (2026-09-19) 人事观察｜上海市政府高层再变动 52岁华源再任副市长 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFB6VW5taFl0NFNIdlkwMV93Tk5ldXN3Z2NSRFBkaDRraGNhMkF3ZE1XTFVmOTQyLVJfa1MwOGZETFMtS] (zh:…
      人事观察｜上海市政府高层再变动 52岁华源再任副市长 china.caixin.com
  - (2026-09-18) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1KdlN4RG11NzJYTFl6SmxSOTI3aEdCWTBDT195QVd3OXpYX3Y0VW9JR19CNnl4eEJBWkVtZEQ3NU1YNEU3cXhPanc3UzM4Sm] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-09-20) 通过民间借贷获取大额回报 南阳原副市长阿颖被移送司法 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE12YTRWY2t6cG5kOVhmM0VPd2pJcTJFeUhCSjB0aloxYW8zdFhkZzh0T244U3A3Ukk2SkMyeHF3Y1dUd] (zh:…
      通过民间借贷获取大额回报 南阳原副市长阿颖被移送司法 china.caixin.com
  - (2026-09-19) “玩玩就会”的三不像，匹克球怎么就流行起来的？｜体坛 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9HZ3BHRnFWS0JtQ2N6Y29vREd5UE1ORWlQQ2lyOVhsd2dTUTdldXg4cWg0ZE8wb2N4WXpVLUwzU2NQVH] (zh:…
      “玩玩就会”的三不像，匹克球怎么就流行起来的？｜体坛 mini.caixin.com

### Local News: St. Louis + Atlanta — 138 new of 224 total
  - (2026-09-20) [St. Louis] Missouri's first ballots are in the mail as federal court weighs congressional map; 3 have already come back in St. Louis County
      Election directors say the votes are final. One county sent ballots with no warning; another plans to. The 8th Circuit heard the case Thursday but issued no ruling.
  - (2026-09-20) [St. Louis] 2 injured, including police officer, in shooting near Notre Dame Stadium during football game
      Police believe the officer was hit by either shrapnel or a ricochet.
  - (2026-09-20) [St. Louis] Gunfire at teen party in St. Ann leaves 2 injured; suspect shot by police
      Two people were shot and a suspect was critically injured by police after gunfire erupted during a gathering involving about 400 teenagers in St. Ann.
  - (2026-09-20) [St. Louis] Ed Sheeran calls situation in Gaza 'catastrophic and unjustifiable' as he opens solo concert
      “My heart has been broken by the scale of devastation and loss of civilians’ lives, of children’s lives,” Sheeran said in the night at Lincoln Financial Field.
  - (2026-09-20) [St. Louis] US military says it killed four in strike on alleged drug-smuggling boat in the Caribbean
      The latest attack brings the number of people who have been killed in boat strikes by the U.S. military to at least 231.
  - (2026-09-20) [St. Louis] Heat and a losing season didn't keep Cardinals fans from Busch Stadium as 2026 winds down
      Fans from Poplar Bluff to southern Illinois turned out in the heat as the Cardinals near the season's end. Ballpark Village expects the Blues to fill the lull.

### State Legislative Action — 120 new of 180 total
  - (2026-09-20) [California AB 1828] County recorder: county clerks: bonds.
      (1) Existing law requires a legal document assistant, unlawful detainer assistant, process server, or professional copier to be registered by the county clerk in the county where their principal place of business is loca…
  - (2026-09-20) [California AB 2372] Vehicles: tolls.
      Existing law provides for the exemption of authorized emergency vehicles from the payment of a toll or charge on a vehicular crossing, toll highway, or high-occupancy toll (HOT) lane when the authorized emergency vehicle…
  - (2026-09-20) [California AB 282] Elections: seizure of election materials.
      Under existing law, a county elections official is required to prepare a certified statement of the results of an election and submit it to the county board of supervisors within 30 days of the election. This bill would…
  - (2026-09-20) [California AB 1945] Municipal utility districts: prepay option: termination of service.
      The Municipal Utility District Act establishes the formation of a municipal utility district for the provision of light, heat, water, or power within the district's jurisdiction. The act prohibits a district furnishing l…
  - (2026-09-20) [California AB 502] Elections: deceptive media in advertisements.
      Existing law prohibits a person or entity from knowingly distributing an election communication containing materially deceptive content that portrays specified candidates and officials as doing or saying something that t…
  - (2026-09-20) [California AB 1586] Opioid overdose reversal medication: school resource officers.
      Existing law authorizes a school district, county office of education, and charter school to provide emergency naloxone hydrochloride or another opioid antagonist to school nurses and trained personnel who have volunteer…

### U.S. Weather + Severe / Climate Outlooks — 115 new of 116 total
  - (2026-09-20) [Moderate] Gale Warning: Gale Warning issued September 20 at 3:57AM AKDT until September 21 at 5:00PM AKDT by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…
  - (2026-09-20) [Moderate] Gale Warning: Gale Warning issued September 20 at 3:55AM AKDT until September 20 at 5:00PM AKDT by NWS Juneau AK
      Offshore waters forecast for Gulf of Alaska east of 144W Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and swel…
  - (2026-09-20) [Moderate] Gale Warning: Gale Warning issued September 20 at 3:55AM AKDT until September 20 at 5:00PM AKDT by NWS Juneau AK
      Offshore waters forecast for Gulf of Alaska east of 144W Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and swel…
  - (2026-09-20) [Moderate] Gale Warning: Gale Warning issued September 20 at 3:54AM AKDT until September 20 at 4:00PM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, south winds 25 to 30 kt with gusts up to 40 kt and seas 11 to 16 ft. For the Gale Warning, south winds 25 to 35 kt with gusts up to 45 kt and seas 16 to 21 ft expected. For th…
  - (2026-09-20) [Moderate] Gale Warning: Gale Warning issued September 20 at 3:54AM AKDT until September 20 at 1:00PM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, southeast winds 25 to 30 kt with gusts up to 40 kt and seas 9 to 13 ft. For the Gale Warning, southeast winds 30 to 35 kt with gusts up to 50 kt and seas 16 to 21 ft expected.…
  - (2026-09-20) [Moderate] Gale Warning: Gale Warning issued September 20 at 3:54AM AKDT until September 20 at 1:00PM AKDT by NWS Juneau AK
      * WHAT...For the Gale Warning, east winds 25 to 35 kt with gusts up to 40 kt and seas 12 to 17 ft expected. For the Small Craft Advisory, southeast winds 20 to 30 kt with gusts up to 40 kt and seas 13 to 18 ft expected.…

### State-Level News — 92 new of 428 total
  - (2026-09-19) [California] What they are saying: California leaders praise Governor Newsom’s democracy defending action ahead of November elections
      Source
  - (2026-09-19) [California] Governor Newsom signs bill expanding fuel options to help Californians save at the pump, amid Donald Trump’s gas price crisis
      Source
  - (2026-09-19) [California] Governor Newsom expands film and TV tax credits with new legislation, creates tax credit to support post-production jobs
      Source
  - (2026-09-19) [California] Governor Newsom signs new laws to protect California elections from Trump interference
      Source
  - (2026-09-19) [California] Governor Newsom signs bill to protect California’s sovereignty and guard against unauthorized military deployments
      <a href="https://www.gov.ca.gov/2026/09/19/governor-newsom-signs-bill-to-protect-californias-sovereignty-and-guard-against-unauthorized-mili
  - (2026-09-20) [Connecticut] St. Monica’s, a pillar of Hartford community, learns to live with less
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/09/AGING_HARTFORD_CONGREGATION-Service-0809-SG-01-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…

### Ukrainian Internal News (national + local Kyiv) — 56 new of 135 total
  - (2026-09-20) Ukraine Strikes Russian Buk-M3, Nebo-U Radar, and Drone Site
      Ukrainian forces struck a Russian Buk-M3 air defense complex, a Nebo-U radar station, a drone production site in Severodonetsk, and command posts across occupied Zaporizhzhia, Donetsk, and Luhansk regions, the General St…
  - (2026-09-20) German State Elections Test Merz as Far Right Surges in East
      Voters in Berlin and Mecklenburg-Western Pomerania have cast ballots in two crucial state elections testing Chancellor Friedrich Merz’s federal government. In the eastern state, the far-right AfD is locked in a tight rac…
  - (2026-09-20) Russian Drone Strikes Ukrposhta Mobile Branch in Sumy
      Russian forces carried out a targeted drone strike against a mobile post office vehicle belonging to Ukraine’s national postal operator, Ukrposhta, in the Sumy region, severely wounding postal workers delivering pensions…
  - (2026-09-20) From Mountain Range to Economic Bridge: Bukovel’s C8 Opens New Chapter for Europe
      The inaugural Carpathian Eight Summit in Bukovel united eight nations around a shared vision for turning the Carpathian region into an integrated economic and security corridor linking Ukraine with the EU. With nearly $1…
  - (2026-09-20) Russia Fired 2,000 Drones and 19 Missiles This Week, Zelensky Says
      Russian forces launched over 2,000 strike drones, 1,700 guided aerial bombs, and 19 missiles of various types against Ukraine over the past week, President Volodymyr Zelensky announced on Sunday, Sept. 20. Zelensky highl…
  - (2026-09-20) ‘Find a Safe place’: Poland Orders Shelter as Russian Strikes Hit Ukraine Gas Station
      Poland ordered residents in the eastern Lubelskie and Podkarpackie regions to seek shelter amid a Russian air attack on western Ukraine. Polish aircraft were scrambled after a jet-powered drone approached the border and…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-20) RCH307 (United States)
      icao24: ae145f · position: (53.3832, 1.9386) · alt: 9753m · 639km/h
  - (2026-09-20) JAF50T (Bulgaria)
      icao24: 4520ce · position: (34.5467, -6.282) · alt: 3139m · 534km/h
  - (2026-09-20) JAF94H (Bulgaria)
      icao24: 4520aa · position: (36.1548, -7.081) · alt: 11277m · 873km/h
  - (2026-09-20) CFC3197 (Canada)
      icao24: c2b369 · position: (63.9182, -24.2164) · alt: 7559m · 620km/h
  - (2026-09-20) GAF931 (Germany)
      icao24: 3f5d91 · position: (50.8711, 7.124) · on ground · 12km/h
  - (2026-09-20) GAF649 (Germany)
      icao24: 3f7dc1 · position: (55.5197, 12.5621) · alt: 1424m · 530km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 24 new of 107 total
  - (2026-09-19) [FARA] Short Form Registrauon Statement Sample OMB_1124_0005B_SF - Department of Justice (.gov)
      Short Form Registrauon Statement Sample OMB_1124_0005B_SF Department of Justice (.gov)
  - (2026-09-19) [FARA] Exhibit A to Registration Statement SampleOMB_1124_0006B_EA - Department of Justice (.gov)
      Exhibit A to Registration Statement SampleOMB_1124_0006B_EA Department of Justice (.gov)
  - (2026-09-19) [FARA] Amendment to Registration Statement SampleOMB_1124_0003B_AM - Department of Justice (.gov)
      Amendment to Registration Statement SampleOMB_1124_0003B_AM Department of Justice (.gov)
  - (2026-09-19) [FARA] Supplemental Statement SampleOMB_1124_0002B_SS - Department of Justice (.gov)
      Supplemental Statement SampleOMB_1124_0002B_SS Department of Justice (.gov)
  - (2026-09-20) [USASpending] $30,912,550,571 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-09-20) [USASpending] $27,613,237,659 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.

### IT, InfoSys & cybersecurity news (last 7 days) — 20 new of 57 total
  - (2026-09-20) [BleepingComputer] Researchers escape OpenAI Codex sandbox to run commands on host
      Researchers escaped OpenAI's Codex sandbox two ways, one running commands on a developer's machine from its most locked-down mode. OpenAI has patched both. [...]
  - (2026-09-20) [The Register] How Windows turned months of inactivity into a 7-hour update hostage situation
      Windows is getting more efficient. The updates, not so much
  - (2026-09-20) [Ars Technica] An undercover Google analyst infiltrated a notorious supply-chain hacking gang
      Google’s threat intelligence group said it had a mole inside TeamPCP's inner circle.
  - (2026-09-20) [Ars Technica] Don't call it an SUV: The Ferrari Purosangue review
      Unlike previous Ferrari four-seaters, this one is better for humans than cargo.
  - (2026-09-20) [Ars Technica] T. rex teeth indicate it ran as warm as an elephant
      Isotope ratios provide a hint that the giants were actively managing temperatures.
  - (2026-09-19) [BleepingComputer] BragJack attacks hijack AI browser agents through malicious extensions
      BragJack, a proof-of-concept attack from Forever Security's Gal Weizman, hijacks the AI assistants in Chrome, Edge, Opera Neon, Perplexity Comet, and Claude in Chrome using one malicious extension. The Prompt Forcing tec…

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-09-20) M 6.4 - 49 km NNE of Kainantu, Papua New Guinea
      M6.4 · 49 km NNE of Kainantu, Papua New Guinea · depth 104.329 km
  - (2026-09-20) M 5.3 - 64 km W of Cafayate, Argentina
      M5.3 · 64 km W of Cafayate, Argentina · depth 10 km
  - (2026-09-20) M 5.3 - 108 km ESE of Yigo Village, Guam
      M5.3 · 108 km ESE of Yigo Village, Guam · depth 10 km
  - (2026-09-20) M 5.3 - Reykjanes Ridge
      M5.3 · Reykjanes Ridge · depth 10 km
  - (2026-09-19) M 5.2 - Reykjanes Ridge
      M5.2 · Reykjanes Ridge · depth 10 km
  - (2026-09-20) M 5.1 - 14 km WNW of Naze, Japan
      M5.1 · 14 km WNW of Naze, Japan · depth 68.834 km

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-09-20) Will Hakeem Jeffries win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $1,320,897 · resolves 2028-11-07
  - (2026-09-20) Vikings vs. Bears
      yes price: 34% · 24h volume: $904,353 · resolves 2026-09-20
  - (2026-09-20) Spread: BAL (-8.5)
      yes price: 50% · 24h volume: $846,285 · resolves 2026-09-20
  - (2026-09-20) Steelers vs. Patriots
      yes price: 32% · 24h volume: $795,014 · resolves 2026-09-20
  - (2026-09-20) Bengals vs. Texans
      yes price: 42% · 24h volume: $682,298 · resolves 2026-09-20
  - (2026-09-20) Will Manchester City FC win on 2026-09-20?
      yes price: 72% · 24h volume: $633,550 · resolves 2026-09-20

### Paper Trading Scorecard — 13 new of 125 total
  - (2026-09-20) [Polymarket] Will Josh Shapiro win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-09-20) [Polymarket] Will Avengers: Doomsday be the top grossing movie of 2026?
      This market will resolve according to the title of the film with the highest 2026 gross according to the "Gross" column on https://www.boxofficemojo.com/year/2026/?grossesOption=calendarGrosses once data for December 31…
  - (2026-09-20) [Manifold] Will Democrat Angie Nixon win Miami Dade County in the Florida Senate Election?
  - (2026-09-20) [Manifold] Will I follow the "benevolent observer challenge" next week? (Ṁ10 Bonus)
  - (2026-09-20) [Manifold] US airstrikes Yemen in September?
  - (2026-09-20) [Manifold] Will any Millenium Problem in Biology be solved by EoY 2027?

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-09-18) U.S. Court of Appeals, 6th Cir.: Commw. of Ky. v. Express Scripts, Inc.
  - (2026-09-18) Hawaii Supreme Court: July 2026 Notice of Passing the Hawai'i Bar Examination
  - (2026-09-18) Hawaii Supreme Court: State v. Turno
  - (2026-09-18) Hawaii Supreme Court: State v. Biton
  - (2026-09-17) U.S. Court of Appeals, 6th Cir.: UEC Holdings, Inc. v. Steven Hatcher
  - (2026-09-17) Florida Supreme Court: Benjamin Davis Smiley, Jr. v. State of Florida & Benjamin Davis Smiley, Jr. v. Secretary, Department of Corrections

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=18, 14d-median=18; carrying terms: final, management, certain, proposed, proposing, navigable, proposes, program, national, action, establishing, specifically
- state_bills: today=180, 7d-median=79, 14d-median=88; carrying terms: government, makes, duties, above, education, public, pilot, licensure, certain, agreements, necessary, unless
- state_news: today=428, 7d-median=683, 14d-median=549; carrying terms: story, according, government, became, columbia, funds, grant, loading, education, public, plant, final
- local_news: today=224, 7d-median=236, 14d-median=227; carrying terms: according, public, court, weekend, class, missouri, center, around, cbmirgfbvv, business, restaurant, dekalb
- foreign_news: today=982, 7d-median=1045, 14d-median=1004; carrying terms: according, final, court, strait, joint, victims, paris, threats, weekend, moment, europe, keralam
- chinese_internal: today=269, 7d-median=282, 14d-median=282; carrying terms: cbmibefvx, chinese, cbmibkfvx, cbmiakfvx, title, cbmixkfvx, china, https, cbmiykfvx, cbmigwfbvv, caixin, cbmix
- russian_internal: today=542, 7d-median=1067, 14d-median=1059; carrying terms: europe, httperror, server, russian, openai, reuters, media, blank, world, politico, financial, https
- ukrainian_internal: today=135, 7d-median=136, 14d-median=135; carrying terms: according, government, russian, threat, pressure, missiles, transport, update, ministers, critical, remains, europe
- ukraine_theater: today=487, 7d-median=417, 14d-median=450; carrying terms: rfzwdsnfvpnvy, swvnrvaxtdz, cbmilgfbvv, russian, ufdbvgfztwg, cuxpnkuxv, polygons, ozbvbkn, intercepted, sgjtyxhrcju, joint, ddnsrzniverxc
- paper_bets: today=125, 7d-median=126, 14d-median=128; carrying terms: nebraska, achieved, kansas, earthquake, pirates, break, jinping, republican, carolina, mexico, party, johnson
- weather: today=116, 7d-median=114, 14d-median=114; carrying terms: rainfall, tonight, following, discussion, aviation, thunderstorms, rivers, across, hazardous, above, north, portions
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: indicator, recession, pcepilfe, vixcls, nonfarm, latest, crude, commodities, cpiaucsl, jolts, openings, dexuseu
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, china, range, equities, large, nasdaq, close, yield, agriculture, crypto, crude, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=107, 7d-median=107, 14d-median=107; carrying terms: government, schools, syria, russian, actions, designations, member, funds, proliferation, oblasts, transnistria, public
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, client, congresstrading, unauthorized, quiverquant, httperror, quiver, https, error
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, appeals, state, supreme, company, blanche, trade, connecticut, international, delaware, robert, university
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, holdings, therapeutics, andrew, robert, technologies, young, natera, definium
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, brown, disbursements, michael, house, david, ocasio, talarico, james, sherrod, cortez, johnson
- gdelt_regions: today=0, 7d-median=0, 14d-median=6
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: hezbollah, minister, attack, israel, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: kingdom, position, belgium, germany, bulgaria, ground, canada, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: beginning, being, several, diphtheria, disease, coinci, according, barasat, ingredient, discontinued, infections, government
- cisa_kev: today=21, 7d-median=21, 14d-median=21; carrying terms: artifactory, netscaler, buffer, authentication, chromium, google, function, remediation, injection, product, jfrog, microsoft
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=15, 7d-median=13, 14d-median=12; carrying terms: depth, indonesia, japan, colombia, ruteng, argentina, guinea, papua, hihifo, tonga, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, counter, strike, playoffs, election, presidential, gaming, russia, nomination, group
- commentary: today=0, 7d-median=6, 14d-median=6; carrying terms: revolution, conversable, class, https, economist, evidence, conversableeconomist, marginal, explain, story, recent, prices
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: according, government, critical, cyber, against, company, technology, https, computerweekly, security, hacker, including
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: homeland, composite, dexter, cline, keating, sessions, hinds, tammy, lankford, beatty, rosen, carey
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, unavailable, market, identify, consensus, converges, sufficient, today, placement, evidence, markets, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] ECB press: Boris Vujčić: Interview with Reuters
- [2026-09-18] ECB press: ECB Consumer Expectations Survey results – August 2026
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*