# WORLDSCOPE morning brief — 2026-08-09

## Headline
2620 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (601) · Russian Internal News (state + in-exile) (530) · Ukraine Theater (total-war monitoring) (404) · World leaders & government officials (324) · Chinese Internal News (169) · U.S. Weather + Severe / Climate Outlooks (142) · State-Level News (125) · Local News: St. Louis + Atlanta (106) · Ukrainian Internal News (national + local Kyiv) (53) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25) · Paper Trading Scorecard (19)

## What changed today
### International News + Multilateral Institutions — 601 new of 951 total
  - (2026-08-08) [Global] Israel accused of weaponising archaeology at ancient West Bank sites
      Israel is planning large-scale land expropriations in historic, Palestinian areas of the West Bank.
  - (2026-08-08) [Global] Hundreds arrested over French wildfires, but who is to blame?
      The government is trying to attribute blame for the unprecedented fires which tore through the country last month.
  - (2026-08-08) [Global] Hormuz talks positive, Oman says, as Iran warns deal would not open strait
      Both sides suggest progress in talks to agree a new shipping route through the strait, but a breakthrough remains unclear.
  - (2026-08-09) [Global] Perez Hilton faces long recovery after reports he self-harmed during livestream
      The US blogger is in a "serious but stable" condition in hospital, according to his family.
  - (2026-08-08) [Global] Trump's ex-lawyer Todd Blanche narrowly confirmed as US attorney general
      The vote cements Trump's former criminal defence lawyer as the nation's top law enforcement official despite a rare pushback from some Republicans.
  - (2026-08-08) [Global] US offers $1bn to Colombia on new right-wing president's first day of office
      Abelardo de la Espriella used his maiden speech to promise an "all-out war" on what he calls "narco-terrorism".

### Russian Internal News (state + in-exile) — 530 new of 880 total
  - (2026-08-09) Электросамокаты опасны? Объективных данных мало, но ученые выяснили, что в случае аварии риск получить черепно-мозговую травму окажется почти в четыре раза выше, чем на мотоцикле | LEDE: В н] (ru: Эле…
      В научном журнале Scientific Reports вышла статья, в которой оценили, что опаснее: ездить на электросамокате, велосипеде или мотоцикле. Из-за невозможности получить все необходимые данные авторы не пытались выяснить, кто…
  - (2026-08-09) BBC: бывший глава сирийской разведки, сбежавший из страны после свержения Асада, может находиться в России | LEDE: Бывший руководитель сирийской разведки Хуссам Лука может находиться в Росси] (ru: BBC…
      Бывший руководитель сирийской разведки Хуссам Лука может находиться в России. Об этом говорится в материале BBC News. Его предполагаемое местонахождение установили по контактам в записной книжке, найденной в его заброшен…
  - (2026-08-09) Говорят, баня помогает пережить жару. Это правда? А полезно ли туда вообще ходить? И кому точно нельзя? | LEDE: В соцсетях и СМИ все чаще стали говорить о том, что баня и сауна помогают адап] (ru: Гов…
      В соцсетях и СМИ все чаще стали говорить о том, что баня и сауна помогают адаптироваться к волнам жары. Мы решили выяснить, так ли это, а заодно рассказать, могут ли бани быть полезны чем-то еще. А также кому и как они м…
  - (2026-08-09) В 1980-х бортпроводники создали целую сеть, чтобы контрабандой ввозить лекарства от СПИДа в Бразилию. HBO Max снял об этом сериал — его называют новым «Жарким соперничеством» | LEDE: В 1980-] (ru: В 1…
      В 1980-е бортпроводники бразильской авиакомпании Varig выстроили целую сеть по перевозке из США в Бразилию лекарства от СПИДа азидотимидин (АЗТ), где его еще не было в продаже. В 2025 году по этим событиям сняли сериал «…
  - (2026-08-09) Россия нанесла удар по Одессе и Харькову. Два человека погибли, больше 20 пострадали. Повреждены жилые дома | LEDE: Российские войска утром 9 августа нанесли удар по Салтовскому району Харьк] (ru: Рос…
      Российские войска утром 9 августа нанесли удар по Салтовскому району Харькова, сообщил глава Харьковской областной администрации Олег Синегубов.
  - (2026-08-09) Украина атаковала Белгород, погибли три человека, пострадали 25. В Новороссийске «обломки дронов» упали на территории предприятий | LEDE: Украина в ночь на 9 августа атаковала беспилотниками] (ru: Укр…
      Украина в ночь на 9 августа атаковала беспилотниками Белгород, сообщил временно исполняющий обязанности губернатора области Александр Шуваев.

### Ukraine Theater (total-war monitoring) — 404 new of 701 total
  - (2026-08-09) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-08) [FIRMS] thermal anomaly 44.740, 33.743 (FRP 4.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 4.38 MW
  - (2026-08-08) [FIRMS] thermal anomaly 44.729, 33.683 (FRP 2.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 2.91 MW
  - (2026-08-08) [FIRMS] thermal anomaly 44.809, 33.779 (FRP 14.72 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 14.72 MW
  - (2026-08-08) [FIRMS] thermal anomaly 44.170, 28.282 (FRP 2.2 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 2.2 MW
  - (2026-08-08) [FIRMS] thermal anomaly 45.258, 31.676 (FRP 6.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 6.85 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 169 new of 228 total
  - (2026-08-08) 社会共益 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE14MWxNZU1BSVRkWW1DWFRod0NVSXdmenZJeERFcm5iOUF5c29nTUMxTUtzUlExUXhkY2R3bEFkSGctZG9lZ2dfOTNXNDloeTFF] (zh:…
      社会共益 deepview.caixin.com
  - (2026-08-07) 市场动态 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE5aT1pNNWV3bGVtczJXdjhPVG5CYUU4WHFHb18zQVFBNVRoQXcyc2JXaDl1Um5sWFVzazBjWnFDNnk5UEVoWjZmVXE3X1NjeGtL] (zh:…
      市场动态 deepview.caixin.com
  - (2026-08-07) 消费者价格指数 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE82MzFFYjdMMEVMWTVuam9Ua2FuS3hBVUlnNzdSME5RX1JraU5LaHlfSjU1OVZPV2Rrbm9SNnB2OW9LTVpVTlRRMjdjZG5hS] (zh:…
      消费者价格指数 deepview.caixin.com
  - (2026-08-08) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1xUm12RC1wRjhNYUVqclJkam9BUjVkSFhFR3J1TWpmaVhfRGpoTVhKRkVwVXBtWG9qdE5EbUNOQ1JOY2dwMENnX3R5YUZkdH] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-08-09) 最新封面报道｜夯实社保 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFA4c0d1YnJla0E3VUNHSHN6YnFsSkRVWUZVRlpKMnNSWV9SaHZ1RUpEQWF2ZFRuLTh0ZW51b2JqdEJJYXM4dklBV2tEdl92MXQzMlMyTjRp] (zh:…
      最新封面报道｜夯实社保 财新周刊
  - (2026-08-09) 多家上市公司宣布：收到美国关税退税 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBkdjZzY1JTQ1AwYkc1bUc2b3FHLWU2eU1IYzllODBVZ0FFdVd5Y21vQmZpNlVWckN4X25QWDhBUHhzT3VVUGFlcUgtRFJ2V1lNdW1B] (zh:…
      多家上市公司宣布：收到美国关税退税 财新

### U.S. Weather + Severe / Climate Outlooks — 142 new of 168 total
  - (2026-08-09) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-09) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 9 at 4:36AM CDT until August 9 at 5:00AM CDT by NWS Sioux Falls SD
      At 435 AM CDT, a severe thunderstorm was located near Superior, or near Spirit Lake, moving northeast at 25 mph. HAZARD...Golf ball size hail and 60 mph wind gusts. SOURCE...Radar indicated. IMPACT...People and animals o…
  - (2026-08-09) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 9 at 4:34AM CDT until August 9 at 5:00AM CDT by NWS Des Moines IA
      SVRDMX The National Weather Service in Des Moines has issued a * Severe Thunderstorm Warning for... Western Emmet County in northwestern Iowa... * Until 500 AM CDT. * At 434 AM CDT, a severe thunderstorm was located over…
  - (2026-08-09) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 9 at 4:32AM CDT until August 9 at 5:00AM CDT by NWS Sioux Falls SD
      SVRFSD The National Weather Service in Sioux Falls has issued a * Severe Thunderstorm Warning for... Southeastern Dickinson County in northwestern Iowa... * Until 500 AM CDT. * At 432 AM CDT, a severe thunderstorm was lo…
  - (2026-08-09) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 9 at 4:30AM CDT until August 9 at 4:45AM CDT by NWS Kansas City/Pleasant Hill MO
      At 430 AM CDT, a severe thunderstorm was located 7 miles northwest of Pattonsburg, or 10 miles southeast of Albany, moving southeast at 30 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated.…
  - (2026-08-09) [Moderate] Special Weather Statement: Special Weather Statement issued August 9 at 4:30AM CDT by NWS Twin Cities/Chanhassen MN
      At 430 AM CDT, Doppler radar was tracking a strong thunderstorm over Somerset, or 18 miles north of River Falls, moving east at 40 mph. HAZARD...Penny size hail. SOURCE...Radar indicated. IMPACT...Minor damage to outdoor…

### State-Level News — 125 new of 477 total
  - (2026-08-08) [Arkansas] New Mexico scientists announce discovery of ‘beefy’ new bird-like dinosaur in San Juan County
      The New Mexico Museum of Natural History and Science announced Tuesday that two of its paleontologists had identified a new bird-like dinosaur species after first discovering an unusual skull fossil in San Juan County in…
  - (2026-08-08) [Arkansas] US Senate bill would require waiver before schools buy foreign food products
      Saying it is an effort to support American agriculture, a new piece of legislation from U.S. Sens. Tim Sheehy, a Montana Republican, and Adam Schiff, a California Democrat, would require schools to submit a waiver to the…
  - (2026-08-08) [Arkansas] ‘The Bird-Watchers’ of Memphis: tracking ICE flights and documenting detainees in shackles
      This story was originally published by the Institute for Public Service Reporting Memphis. On a Saturday morning in July, Joni Laney, a 73-year-old retired English teacher, parked her car in a small lot overlooking Wilso…
  - (2026-08-08) [Arkansas] Some data centers are building their own power plants. In Oklahoma, most want to plug into the grid
      Oklahoma passed a law last year allowing energy-hungry facilities to build their own power. But as data center announcements sprout up across Oklahoma, most include plans to work with local utilities. Last month, Gov. Ke…
  - (2026-08-07) [Arkansas] US Senate leaves town for recess after passing stopgap spending bill, blocking photo ID for voting
      WASHINGTON — The U.S. Senate adjourned for its summer recess early Saturday after approving a stopgap spending bill but declining to advance legislation that would require photo ID for voting. In a rare overnight session…
  - (2026-08-07) [Arkansas] Todd Blanche confirmed by the US Senate as attorney general; Collins, Murkowski vote no
      WASHINGTON — After a lengthy battle over the status of President Donald Trump’s nearly $1.8 billion “anti-weaponization” fund, Todd Blanche was confirmed as attorney general by the U.S. Senate early Saturday. Blanche, th…

### Local News: St. Louis + Atlanta — 106 new of 201 total
  - (2026-08-09) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-08-09) [St. Louis] Winning numbers for Powerball's $863M jackpot
      The lump sum value of Saturday's jackpot was $370.7 million before taxes.
  - (2026-08-09) [St. Louis] Pentagon pushes defense companies to boost weapons production after concerns of depleted stocks
      The memo comes as recent fighting with Iran used up more of the U.S. military’s already diminished stockpiles of advanced missile interceptors.
  - (2026-08-09) [St. Louis] Verizon resolves issue affecting phone service across US
      Thousands of Verizon customers reported being unable to make or take phone calls Saturday.
  - (2026-08-09) [St. Louis] Dangerous heat and humidity return to St. Louis Sunday through Wednesday | Weather Impact Alert
      Heat index temperatures will rise above 105 degrees throughout the St. Louis region this week.
  - (2026-08-09) [St. Louis] Perez Hilton still hospitalized, will have 'long process' to recovery, family says
      Perez Hilton's family said his condition was "serious but stable" and "treatment and recovery will be a long process."

### Ukrainian Internal News (national + local Kyiv) — 53 new of 106 total
  - (2026-08-09) Зеленський: За тиждень РФ випустила по Україні 61 ракету, 56 із них – по балістичній траєкторії | LEDE: Протягом останнього тижня Росія застосувала проти України 61 ракету різних типів, з яких ] (uk:…
      Протягом останнього тижня Росія застосувала проти України 61 ракету різних типів, з яких 56 атакували по балістичній траєкторії, а також понад 1560 ударних безпілотників і 1540 керованих авіабомб.
  - (2026-08-09) Іран озвучив свої вимоги до США для відкриття Ормузької протоки | LEDE: ] (uk: Іран озвучив свої вимоги до США для відкриття Ормузької протоки)
  - (2026-08-09) У Харкові кількість постраждалих від удару зросла до 23, під завалами шукають людей | LEDE: Унаслідок російського удару по багатоповерхівці у Харкові 23 постраждалих, 2 загиблих, серед поранени] (uk:…
      Унаслідок російського удару по багатоповерхівці у Харкові 23 постраждалих, 2 загиблих, серед поранених є 5-річна дитина.
  - (2026-08-09) У Румунії зникла загроза зупинки АЕС – вода у Дунаї піднялася | LEDE: ] (uk: У Румунії зникла загроза зупинки АЕС – вода у Дунаї піднялася)
  - (2026-08-09) "Мадяр": СБС уразили С-400 у Геленджику, який напередодні бив ракетами по Україні | LEDE: Сили безпілотних систем атакували ЗРК С-400 у Геленджику та ще чотири цілі ППО РФ у ніч на 9 серпня.] (uk: "Ма…
      Сили безпілотних систем атакували ЗРК С-400 у Геленджику та ще чотири цілі ППО РФ у ніч на 9 серпня.
  - (2026-08-09) У Косові депутатка закидала прем’єра яйцями у залі парламенту | LEDE: ] (uk: У Косові депутатка закидала прем’єра яйцями у залі парламенту)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-09) [Israel-Iran-Hezbollah axis · keywords] Iran war : Houthis claim attack on Saudi oil facility
      dw.com · English · tone NA
  - (2026-08-09) [Israel-Iran-Hezbollah axis · keywords] ICC oversight body urges Chad and Venezuela to reverse withdrawal
      venezuelastar.com · English · tone NA
  - (2026-08-09) [Israel-Iran-Hezbollah axis · keywords] Iran makes new Hormuz demands as missile hits Emirati ship
      kenyastar.com · English · tone NA
  - (2026-08-09) [Israel-Iran-Hezbollah axis · keywords] Iran makes new Hormuz demands as missile hits Emirati ship
      batonrougepost.com · English · tone NA
  - (2026-08-09) [Israel-Iran-Hezbollah axis · keywords] Missile for missile , fire for fire : Iraq militia vows retaliation against US , Saudi Arabia
      timesofindia.indiatimes.com · English · tone NA
  - (2026-08-09) [Israel-Iran-Hezbollah axis · keywords] Missiles can only be countered with missiles : Iraqi militia vows revenge over US - Saudi strikes
      aninews.in · English · tone NA

### Paper Trading Scorecard — 19 new of 137 total
  - (2026-08-09) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-08-09) [Manifold] Will I complete my goal by tomorrow night?
  - (2026-08-09) [Manifold] Will Chinese humanoid robot companies ship 50x more units than US companies by EOY 2027
  - (2026-08-09) [Manifold] Will there be an event held at Lighthaven between Aug 24 - Sept 10
  - (2026-08-09) [Manifold] Will users be able to donate unused AI-token allowances to open-source projects by 2027?
  - (2026-08-09) [Manifold] Will there be a codex limit reset on Monday August 10, 2026?

### Government & military aircraft airborne (OpenSky) — 18 new of 18 total
  - (2026-08-09) SAMU05 (France)
      icao24: 39ca81 · position: (45.2001, 5.7442) · on ground
  - (2026-08-09) JAF66L (Belgium)
      icao24: 44d1ba · position: (50.7387, 3.9191) · alt: 4244m · 720km/h
  - (2026-08-09) JAF7CB (Belgium)
      icao24: 44d1a7 · position: (44.5603, -3.7594) · alt: 10363m · 901km/h
  - (2026-08-09) JAF9CK (Belgium)
      icao24: 44d1b3 · position: (50.1021, 2.6275) · alt: 8107m · 863km/h
  - (2026-08-09) JAF99Y (Belgium)
      icao24: 44d1b4 · position: (47.3319, -0.7581) · alt: 10972m · 887km/h
  - (2026-08-09) JAF7PN (Belgium)
      icao24: 44d1a2 · position: (46.6162, 6.6278) · alt: 10972m · 872km/h

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-08-08) M 5.6 - 42 km E of Noda, Japan
      M5.6 · 42 km E of Noda, Japan · depth 34 km
  - (2026-08-08) M 5.6 - southeast of Easter Island
      M5.6 · southeast of Easter Island · depth 10 km
  - (2026-08-09) M 5.0 - 180 km NW of Sabang, Indonesia
      M5.0 · 180 km NW of Sabang, Indonesia · depth 10 km
  - (2026-08-09) M 4.9 - 68 km ESE of Atka, Alaska
      M4.9 · 68 km ESE of Atka, Alaska · depth 60.301 km
  - (2026-08-09) M 4.9 - 237 km E of Levuka, Fiji
      M4.9 · 237 km E of Levuka, Fiji · depth 589.12 km
  - (2026-08-08) M 4.8 - northern Mid-Atlantic Ridge
      M4.8 · northern Mid-Atlantic Ridge · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-09) LoL: Dplus KIA vs KT Rolster - Game 2 Winner
      yes price: 100% · 24h volume: $888,277 · resolves 2026-08-09
  - (2026-08-09) LoL: Dplus KIA vs KT Rolster - Game 1 Winner
      yes price: 0% · 24h volume: $677,369 · resolves 2026-08-09
  - (2026-08-09) LoL: Dplus KIA vs KT Rolster (BO3) - LCK Round 3-4 Legend Group
      yes price: 57% · 24h volume: $663,318 · resolves 2026-08-09
  - (2026-08-09) LoL: Invictus Gaming vs LNG Esports - Game 2 Winner
      yes price: 100% · 24h volume: $597,657 · resolves 2026-08-09
  - (2026-08-09) LoL: Invictus Gaming vs LNG Esports - Game 1 Winner
      yes price: 100% · 24h volume: $571,113 · resolves 2026-08-09
  - (2026-08-09) US announces end of Iranian blockade by August 9, 2026?
      yes price: 3% · 24h volume: $412,398 · resolves 2026-08-09

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: SEC V.
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: The Retail Property Trust v. Nassau Cnty. Dep't of Assessment
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: United States v. Browning
  - (2026-08-06) Supreme Court of California: Gorobets v. Jaguar Land Rover North America, LLC
  - (2026-08-06) Supreme Court of California: People v. Hyatt
  - (2026-08-06) D.C. Court of Appeals: Ball v. Hubbard

### IT, InfoSys & cybersecurity news (last 7 days) — 11 new of 56 total
  - (2026-08-09) [The Register] Ransomware gangs skip the CEO, head straight for the 40-something IT manager
      Gen Xers who feel triggered by this should remember to unplug the network cable and call the cops
  - (2026-08-08) [BleepingComputer] Hackers breach TrueConf to trojanize client installers with backdoors
      The Head Mare hacktivist group has been exploiting vulnerabilities in unpatched TrueConf video conferencing servers to replace client installers with malicious versions that deliver backdoors. [...]
  - (2026-08-08) [The Register] Devs to Anthropic, OpenAI, Cursor, and friends: Make security and privacy the default
      Researchers scour social media to measure developer concerns about AI coding tools
  - (2026-08-08) [The Register] South Korean satellite spots SpaceX lunar impact
      Before and after shots of Elon's ejecta snapped by Danuri
  - (2026-08-08) [Ars Technica] The first self-driving vehicle on Mars has proven to be a smashing success
      About 90 percent of the distance driven by Perseverance has been autonomous.
  - (2026-08-08) [Ars Technica] DeepMind’s hurricane breakthrough has surprised weather scientists
      Open source WeatherNext model can make accurate predictions with lower-resolution weather data.

### GDACS — global disaster alerts — 10 new of 251 total
  - (2026-08-08) [Green] Earthquake in Southeast Of Easter Island
      Earthquake · Green alert · Southeast Of Easter Island · Magnitude 5.6M, Depth:10km
  - (2026-08-08) [Green] Earthquake in Southeast Of Easter Island
      Earthquake · Green alert · Southeast Of Easter Island · Magnitude 5.6M, Depth:10km
  - (2026-08-08) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.6M, Depth:34km
  - (2026-08-08) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.6M, Depth:34km
  - (2026-08-01) [Green] Forest fires in The Democratic Republic of Congo
      Wildfire · Green alert · The Democratic Republic of Congo · Green impact for forestfire in 11878 ha
  - (2026-08-01) [Green] Forest fires in The Democratic Republic of Congo
      Wildfire · Green alert · The Democratic Republic of Congo · Green impact for forestfire in 11878 ha

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 99 total
  - (2026-08-09) [USASpending] $10,560,504,772 → WASHINGTON RIVER PROTECTION SOLUTIONS LLC: MANAGEMENT OF THE HANFORD SITE TANK FARMS
      Agency: Department of Energy. Description: MANAGEMENT OF THE HANFORD SITE TANK FARMS
  - (2026-08-09) [USASpending] $4,811,722,791 → LEIDOS BIOMEDICAL RESEARCH INC: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
      Agency: Department of Health and Human Services. Description: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
  - (2026-08-09) [USASpending] $876,771,741 → HII MISSION TECHNOLOGIES CORP: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT
      Agency: General Services Administration. Description: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT NETWORK OF ENGINEERING AND EMERGING OPERATIONS (JNEEO)
  - (2026-08-09) [USASpending] $873,510,388 → BCCG A JOINT VENTURE: CONSTRUCTION OF BORDER BARRIER WALL SYSTEM.
      Agency: Department of Homeland Security. Description: CONSTRUCTION OF BORDER BARRIER WALL SYSTEM.
  - (2026-08-09) [USASpending] $684,259,961 → LEIDOS, INC.: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
      Agency: Department of Transportation. Description: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
  - (2026-08-09) [USASpending] $680,032,258 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-09) [Marginal Revolution] One of the better pro-natalist Lieder
      The post One of the better pro-natalist Lieder appeared first on Marginal REVOLUTION.
  - (2026-08-09) [Marginal Revolution] Is there a Balkan fertility paradox? (from my email)
      The Balkans may be the only region other than central Asia where fertility has increased from 2015 to 2026.* All of the highest fertility rates in Europe are in the Balkans. As of 2024: Montenegro (1.8), Bulgaria (1.73)…
  - (2026-08-08) [Marginal Revolution] The future of warfare? (from my email)
      As weapon systems increase in effectiveness, they will generally target one another rather than humans. Lower loss of life will ease conflict entry and hinder exit. Warfare will veer further from industrial competition i…

### Macro indicators — latest values (FRED) — 1 new of 21 total
  - (2026-08-07) [Rates] 10y–2y Spread (recession indicator) (T10Y2Y)
      latest: 0.46 as of 2026-08-07

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-09) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: notice, proposing, safety, provide, amendment, certain, standards, rulemaking, final, proposes, program, operations
- state_bills: today=0, 7d-median=118, 14d-median=129; carrying terms: sharing, changes, employees, support, provisions, facility, approval, owner, appropriation, limitations, development, legislative
- state_news: today=477, 7d-median=717, 14d-median=766; carrying terms: patrol, healthcare, changes, desantis, replace, support, since, attorneys, release, increase, approval, generations
- local_news: today=201, 7d-median=239, 14d-median=234; carrying terms: south, since, world, killed, woman, inside, appeared, state, friday, https, attachment, nearly
- foreign_news: today=951, 7d-median=1034, 14d-median=1038; carrying terms: preserving, weight, tibetan, support, since, release, beijing, increase, straits, guizhou, league, undesirable
- chinese_internal: today=228, 7d-median=261, 14d-median=264; carrying terms: https, people, chinese, global, caixin, google, record, china, price, cbmiykfvx, lxtfa, cbmib
- russian_internal: today=880, 7d-median=1056, 14d-median=940; carrying terms: wildberries, novaya, axios, client, found, media, telegram, bloomberg, variety, journal, istories, gazeta
- ukrainian_internal: today=106, 7d-median=107, 14d-median=127; carrying terms: changes, support, killed, combat, reactions, commander, range, additional, across, correspondents, launched, staff
- ukraine_theater: today=701, 7d-median=639, 14d-median=670; carrying terms: unauthorized, https, snapshot, google, polygons, polygon, community, daily, liveuamap, frontline, httperror, alerts
- paper_bets: today=137, 7d-median=140, 14d-median=139; carrying terms: democratic, goldman, drought, zohran, verve, official, world, mbappe, pennsylvania, senate, jpmorgan, career
- weather: today=168, 7d-median=177, 14d-median=174; carrying terms: south, portions, afdlwx, northern, increase, early, denver, weekend, short, current, tampa, montgomery
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: money, openings, unemployment, consumption, vixcls, personal, dexchus, cpiaucsl, pcepilfe, dexjpus, latest, assets
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, corporate, proxy, bitcoin, silver, natural, china, nasdaq, agriculture, equities, range, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=101, 14d-median=102; carrying terms: south, burma, democratic, jihad, events, support, middle, activities, amended, violent, military, technologies
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, unauthorized, quiver, client, congresstrading, quantitative, https, error, quiverquant
- billionaires: today=30, 7d-median=40, 14d-median=38; carrying terms: alice, italy, steve, amancio, zhang, india, tadashi, china, fashion, nasdaq, googl, thomas
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, johnson, supreme, delaware, county, appeals, california, blanche, hernandez, company, energy, corporation
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, michael, richard, therapeutics, group, daniel, william, brian
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, house, disbursements, michael, receipts, brown, alexandria, filing, robert, james, david, elect
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, china
- gdelt_gkg: today=25, 7d-median=50, 14d-median=36; carrying terms: english, hezbollah, israel, keywords, netanyahu, hormuz, attacks, israeli, peace, strikes, warns, lebanon
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=18, 7d-median=19, 14d-median=17; carrying terms: position, belgium, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: south, routine, resulting, democratic, representing, healthcare, municipality, october, paralytic, bengal, infections, dhaka
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: sensitive, arista, password, fortinet, injection, coded, deserialization, secure, fortios, management, untrusted, center
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=251, 7d-median=233, 14d-median=236; carrying terms: italy, democratic, denmark, brazil, orange, china, indonesia, minor, drought, forest, depth, australia
- usgs_quakes: today=13, 7d-median=13, 14d-median=15; carrying terms: depth, islands, japan, region, indonesia, philippines, kermadec, sarangani, alaska, argentina, solomon, antonio
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, september, volume, resolves, ceasefire, august, effective, prime, hormuz, returns, traffic, strait
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: revolution, https, class, economist, marginal, conversable, conversableeconomist, strong, marginalrevolution, college, economic, future
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: systems, world, techcrunch, campaign, computer, targeted, industry, daily, weekday, across, attacks, cyber
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: norman, brandon, mcdonald, ezell, goldman, moskowitz, debbie, trent, gomez, daines, lalota, marie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, paper, consensus, claude, unavailable, market, identify, converges, either, decision, module, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*