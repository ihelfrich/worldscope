# WORLDSCOPE morning brief — 2026-08-09

## Headline
2392 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (581) · Russian Internal News (state + in-exile) (514) · Ukraine Theater (total-war monitoring) (343) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (134) · State-Level News (107) · GDELT GKG — themes / entities / watch areas (95) · Local News: St. Louis + Atlanta (90) · Ukrainian Internal News (national + local Kyiv) (47) · Sanctions & Designations (recent) (30) · Paper Trading Scorecard (20) · Government & military aircraft airborne (OpenSky) (15)

## What changed today
### International News + Multilateral Institutions — 581 new of 973 total
  - (2026-08-08) [Global] Is football AI-proof? Why tech investors wanted a slice of the World Cup
      What was the thinking of the investors backing the now-canned plan, and are such proposals in the future inevitable?
  - (2026-08-08) [Global] Israel accused of weaponising archaeology at ancient West Bank sites
      Israel is planning large-scale land expropriations in historic, Palestinian areas of the West Bank.
  - (2026-08-08) [Global] Hundreds arrested over French wildfires, but who is to blame?
      The government is trying to attribute blame for the unprecedented fires which tore through the country last month.
  - (2026-08-08) [Global] Hormuz talks positive, Oman says, as Iran warns deal would not open strait
      Both sides suggest progress in talks to agree a new shipping route through the strait, but a breakthrough remains unclear.
  - (2026-08-09) [Global] Perez Hilton faces long recovery after reports he self-harmed during livestream
      The US blogger is in a "serious but stable" condition in hospital, according to his family.
  - (2026-08-08) [Global] Trump's ex-lawyer Todd Blanche narrowly confirmed as US attorney general
      The vote cements Trump's former criminal defence lawyer as the nation's top law enforcement official despite a rare pushback from some Republicans.

### Russian Internal News (state + in-exile) — 514 new of 867 total
  - (2026-08-09) В 1980-х бортпроводники создали целую сеть, чтобы контрабандой ввозить лекарства от СПИДа в Бразилию. HBO Max снял об этом сериал — его называют новым «Жарким соперничеством» | LEDE: В 1980-] (ru: В 1…
      В 1980-е бортпроводники бразильской авиакомпании Varig выстроили целую сеть по перевозке из США в Бразилию лекарства от СПИДа азидотимидин (АЗТ), где его еще не было в продаже. В 2025 году по этим событиям сняли сериал «…
  - (2026-08-09) Россия нанесла удар по Одессе и Харькову. Два человека погибли, больше 20 пострадали. Повреждены жилые дома | LEDE: Российские войска утром 9 августа нанесли удар по Салтовскому району Харьк] (ru: Рос…
      Российские войска утром 9 августа нанесли удар по Салтовскому району Харькова, сообщил глава Харьковской областной администрации Олег Синегубов.
  - (2026-08-09) Украина атаковала Белгород, погибли три человека, пострадали 25. В Новороссийске «обломки дронов» упали на территории предприятий | LEDE: Украина в ночь на 9 августа атаковала беспилотниками] (ru: Укр…
      Украина в ночь на 9 августа атаковала беспилотниками Белгород, сообщил временно исполняющий обязанности губернатора области Александр Шуваев.
  - (2026-08-08) Из Кембриджа уволился Джейсон Ардей. Он не умел читать и писать до 18 лет, а в 37 стал самым молодым темнокожим профессором в университете. Сейчас его обвинили в плагиате, а к его биографии воз] (ru:…
      Профессор социологии в Кембриджском университете Джейсон Ардей 5 августа подал в отставку после того, как вуз начал расследование в его отношении из-за обвинений в плагиате. 41-летний Ардей заявил, что «хочет вернуть себ…
  - (2026-08-08) Иск о снятии «Яблока» с выборов в Госдуму рассмотрит судья, объявивший «Мемориал» экстремистской организацией | LEDE: Иск партии «Родина» с требованием отменить регистрацию федерального спис] (ru: Иск…
      Иск партии «Родина» с требованием отменить регистрацию федерального списка своего конкурента на выборах в Госдуму — партии «Яблоко» — рассмотрит судья Верховного суда РФ Вячеслав Кириллов. Он известен участием в резонанс…
  - (2026-08-08) The Telegraph: УЕФА выплатила шестизначную сумму предполагаемой любовнице Джанни Инфантино во время его работы в организации | LEDE: Предполагаемая любовница Джанни Инфантино получила шестиз] (ru: The…
      Предполагаемая любовница Джанни Инфантино получила шестизначную сумму в качестве выходного пособия от УЕФА в то время, когда он занимал пост генерального секретаря организации, говорится в расследовании The Daily Telegra…

### Ukraine Theater (total-war monitoring) — 343 new of 488 total
  - (2026-08-08) [FIRMS] thermal anomaly 44.740, 33.743 (FRP 4.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 4.38 MW
  - (2026-08-08) [FIRMS] thermal anomaly 44.729, 33.683 (FRP 2.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 2.91 MW
  - (2026-08-08) [FIRMS] thermal anomaly 44.809, 33.779 (FRP 14.72 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 14.72 MW
  - (2026-08-08) [FIRMS] thermal anomaly 44.170, 28.282 (FRP 2.2 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 2.2 MW
  - (2026-08-08) [FIRMS] thermal anomaly 45.258, 31.676 (FRP 6.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 6.85 MW
  - (2026-08-08) [FIRMS] thermal anomaly 45.601, 33.126 (FRP 6.65 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-08 1032Z, FRP 6.65 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 134 new of 160 total
  - (2026-08-09) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 9 at 2:51AM CDT until August 9 at 3:15AM CDT by NWS Aberdeen SD
      At 251 AM CDT, a severe thunderstorm was located over Devoe, or 14 miles east of Faulkton, moving southeast at 25 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail damage to v…
  - (2026-08-09) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 9 at 2:49AM CDT until August 9 at 3:45AM CDT by NWS Sioux Falls SD
      SVRFSD The National Weather Service in Sioux Falls has issued a * Severe Thunderstorm Warning for... Northwestern Clay County in northwestern Iowa... East central O'Brien County in northwestern Iowa... * Until 345 AM CDT…
  - (2026-08-09) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-09) [Moderate] Special Weather Statement: Special Weather Statement issued August 9 at 2:31AM CDT by NWS Twin Cities/Chanhassen MN
      At 231 AM CDT, Doppler radar was tracking a strong thunderstorm over Blaine, or 14 miles north of Minneapolis, moving east at 35 mph. HAZARD...Penny size hail. SOURCE...Radar indicated. IMPACT...Minor damage to outdoor o…
  - (2026-08-09) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 9 at 12:31AM MST until August 9 at 8:00PM MST by NWS Flagstaff AZ
      * WHAT...Dangerously hot conditions expected below 4500 feet, with daytime temperatures ranging from 95 to 105 degrees at Havasupai Gardens, 110 to 115 degrees at Phantom Ranch, and 102 to 106 at Page. * WHERE...Lower el…
  - (2026-08-09) [Moderate] Special Weather Statement: Special Weather Statement issued August 9 at 2:29AM CDT by NWS Twin Cities/Chanhassen MN
      At 229 AM CDT, Doppler radar was tracking a line of strong thunderstorms extending from over Rice to 6 miles northwest of Zimmerman, or extending from 16 miles north of St. Cloud to 23 miles east of St. Cloud, moving eas…

### State-Level News — 107 new of 473 total
  - (2026-08-08) [Colorado] As Trump pushes for a massive $1.5T in defense spending, a few states brace for a windfall
      WASHINGTON — Congress is considering a hike of hundreds of billions in dollars in defense spending, which would represent a surge in military funding not seen since World War II. Whatever the exact level of spending ulti…
  - (2026-08-08) [Alaska] Cruise ship helps stranded skiff and crew in Southeast Alaska as Zuckerberg yacht stands by
      A small cruise ship operating in Southeast Alaska made an unexpected detour on Monday night to help a 21-foot skiff that ran out of fuel between Petersburg and Juneau. Michael Love, a software developer from New York Cit…
  - (2026-08-08) [Arkansas] New Mexico scientists announce discovery of ‘beefy’ new bird-like dinosaur in San Juan County
      The New Mexico Museum of Natural History and Science announced Tuesday that two of its paleontologists had identified a new bird-like dinosaur species after first discovering an unusual skull fossil in San Juan County in…
  - (2026-08-08) [Arkansas] US Senate bill would require waiver before schools buy foreign food products
      Saying it is an effort to support American agriculture, a new piece of legislation from U.S. Sens. Tim Sheehy, a Montana Republican, and Adam Schiff, a California Democrat, would require schools to submit a waiver to the…
  - (2026-08-08) [Arkansas] ‘The Bird-Watchers’ of Memphis: tracking ICE flights and documenting detainees in shackles
      This story was originally published by the Institute for Public Service Reporting Memphis. On a Saturday morning in July, Joni Laney, a 73-year-old retired English teacher, parked her car in a small lot overlooking Wilso…
  - (2026-08-08) [Arkansas] Some data centers are building their own power plants. In Oklahoma, most want to plug into the grid
      Oklahoma passed a law last year allowing energy-hungry facilities to build their own power. But as data center announcements sprout up across Oklahoma, most include plans to work with local utilities. Last month, Gov. Ke…

### GDELT GKG — themes / entities / watch areas — 95 new of 95 total
  - (2026-08-09) [Russia oil sanctions perimeter · themes] Tiempo hoy en Talca : jornada del 9 de agosto de 2026
      vlnradio.cl · Spanish · tone NA
  - (2026-08-09) [Russia oil sanctions perimeter · themes] 大道行天下丨以心相交 ， 成其久远 中国元首外交的世界情怀与大国气派
      news.sina.com.cn · Chinese · tone NA
  - (2026-08-09) [Russia oil sanctions perimeter · themes] Iran rejects Oman talks link to Hormuz reopening
      kashmirreader.com · English · tone NA
  - (2026-08-09) [Russia oil sanctions perimeter · themes] 拔老樹吹歪電線杆 ！ 淡水龍捲風總長度2 . 5公里 「 龍捲風權威 」 曝災情 | 生活 | 三立新聞網 SETN . COM
      setn.com · Chinese · tone NA
  - (2026-08-09) [Russia oil sanctions perimeter · themes] Iran Demands U . S . Action To Reopen Strait Of Hormuz
      whoradio.iheart.com · English · tone NA
  - (2026-08-09) [Russia oil sanctions perimeter · themes] 白海豚 云系庞大影响面广 ， 全省大部有大雨暴雨部分大暴雨
      baijiahao.baidu.com · Chinese · tone NA

### Local News: St. Louis + Atlanta — 90 new of 171 total
  - (2026-08-09) [St. Louis] Page D9 eedition image
  - (2026-08-09) [St. Louis] Page D9 eedition image
  - (2026-08-09) [St. Louis] Page D9 eedition image
  - (2026-08-09) [St. Louis] Starches should be a modest part of a mixed meal
      DR. KEITH ROACH
  - (2026-08-09) [St. Louis] Reverse is the first gear to wave the white flag
  - (2026-08-09) [St. Louis] Granada billed as 'elegance in a new, efficient size'

### Ukrainian Internal News (national + local Kyiv) — 47 new of 102 total
  - (2026-08-09) "Мадяр": СБС уразили С-400 у Геленджику, який напередодні бив ракетами по Україні | LEDE: Сили безпілотних систем атакували ЗРК С-400 у Геленджику та ще чотири цілі ППО РФ у ніч на 9 серпня.] (uk: "Ма…
      Сили безпілотних систем атакували ЗРК С-400 у Геленджику та ще чотири цілі ППО РФ у ніч на 9 серпня.
  - (2026-08-09) У Косові депутатка закидала прем’єра яйцями у залі парламенту | LEDE: ] (uk: У Косові депутатка закидала прем’єра яйцями у залі парламенту)
  - (2026-08-09) На трасі "Одеса – Рені" обмежили рух через російські удари: немає проїзду до пунктів пропуску з Молдовою | LEDE: Через російські атаки на Одещині частково обмежено рух на трасі Одеса – Рені, не] (uk:…
      Через російські атаки на Одещині частково обмежено рух на трасі Одеса – Рені, недоступні деякі пункти пропуску.
  - (2026-08-09) Начальник ГШ Болгарії: Український дрон міг опинитись в країні через РЕБ | LEDE: Начальник Генерального штабу Болгарії, адмірал Еміл Ефтімов заявив, що безпілотник, який вважають українським ап] (uk:…
      Начальник Генерального штабу Болгарії, адмірал Еміл Ефтімов заявив, що безпілотник, який вважають українським апаратом "Мая", міг опинитись на території країни під впливом засобів радіоелектронної боротьби і інцидент є п…
  - (2026-08-09) РФ масовано вдарила ракетами по Одесі: є пошкодження, 8 людей поранено | LEDE: Росія завдала ракетного удару по Одесі вночі 9 серпня: 6 людей постраждали, пошкоджено будинки та автівки.] (uk: РФ масов…
      Росія завдала ракетного удару по Одесі вночі 9 серпня: 6 людей постраждали, пошкоджено будинки та автівки.
  - (2026-08-09) У трьох областях через російські атаки загинули 3 людини, ще 27 поранені | LEDE: Внаслідок російських обстрілів загинули 3 людини, 27 поранені, серед них 6 дітей у трьох областях України.] (uk: У трьо…
      Внаслідок російських обстрілів загинули 3 людини, 27 поранені, серед них 6 дітей у трьох областях України.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 20 new of 138 total
  - (2026-08-09) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-08-09) [Manifold] Will I complete my goal by tomorrow night?
  - (2026-08-09) [Manifold] Will Chinese humanoid robot companies ship 50x more units than US companies by EOY 2027
  - (2026-08-09) [Manifold] Will there be an event held at Lighthaven between Aug 24 - Sept 10
  - (2026-08-09) [Manifold] Will users be able to donate unused AI-token allowances to open-source projects by 2027?
  - (2026-08-09) [Manifold] Will there be a codex limit reset on Monday August 10, 2026?

### Government & military aircraft airborne (OpenSky) — 15 new of 15 total
  - (2026-08-09) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (48.2636, 1.0344) · alt: 4343m · 668km/h
  - (2026-08-09) JAF76T (Bulgaria)
      icao24: 4520aa · position: (45.5245, -0.5162) · alt: 10980m · 927km/h
  - (2026-08-09) JAF66L (Belgium)
      icao24: 44d1ba · position: (38.403, -0.2675) · alt: 2133m · 506km/h
  - (2026-08-09) JAF63N (Belgium)
      icao24: 44d1a5 · position: (41.1304, 1.8445) · alt: 10660m · 872km/h
  - (2026-08-09) JAF99Y (Belgium)
      icao24: 44d1b4 · position: (37.0191, -7.9733) · on ground
  - (2026-08-09) SAMU26 (France)
      icao24: 39ac18 · position: (45.3148, 4.4968) · alt: 1257m · 216km/h

### Court opinions of consequence (federal & state) — 14 new of 60 total
  - (2026-08-06) Supreme Court of California: Gorobets v. Jaguar Land Rover North America, LLC
  - (2026-08-06) Supreme Court of California: People v. Hyatt
  - (2026-08-06) U.S. Court of Appeals, 11th Cir.: Dish Network L.L.C. v. Gaby Fraifer
  - (2026-08-06) D.C. Court of Appeals: Ball v. Hubbard
  - (2026-08-06) D.C. Court of Appeals: Hatcherson-Ross v. United States
  - (2026-08-06) D.C. Court of Appeals: Hawkins v. United States

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-08-08) M 5.6 - 42 km E of Noda, Japan
      M5.6 · 42 km E of Noda, Japan · depth 34 km
  - (2026-08-08) M 5.6 - southeast of Easter Island
      M5.6 · southeast of Easter Island · depth 10 km
  - (2026-08-09) M 5.0 - 180 km NW of Sabang, Indonesia
      M5.0 · 180 km NW of Sabang, Indonesia · depth 10 km
  - (2026-08-09) M 4.9 - 68 km ESE of Atka, Alaska
      M4.9 · 68 km ESE of Atka, Alaska · depth 60.301 km
  - (2026-08-09) M 4.9 - 237 km E of Levuka, Fiji
      M4.9 · 237 km E of Levuka, Fiji · depth 589.12 km
  - (2026-08-08) M 4.8 - northern Mid-Atlantic Ridge
      M4.8 · northern Mid-Atlantic Ridge · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-09) Dota 2: Amaru Gaming vs Team Jenz - Game 1 Winner
      yes price: 50% · 24h volume: $1,579,032 · resolves 2026-08-09
  - (2026-08-09) LoL: Invictus Gaming vs LNG Esports - Game 1 Winner
      yes price: 100% · 24h volume: $388,149 · resolves 2026-08-09
  - (2026-08-09) US announces end of Iranian blockade by August 9, 2026?
      yes price: 4% · 24h volume: $356,008 · resolves 2026-08-09
  - (2026-08-09) Counter-Strike: Sinners vs EYEBALLERS (BO3) - Esports World Cup Open Qualifier Play-Ins
      yes price: 50% · 24h volume: $300,864 · resolves 2026-08-09
  - (2026-08-09) Counter-Strike: Virtus.pro vs Sashi Esport (BO3) - Esports World Cup Open Qualifier Play-Ins
      yes price: 55% · 24h volume: $277,051 · resolves 2026-08-09
  - (2026-08-09) LoL: Dplus KIA vs KT Rolster (BO3) - LCK Round 3-4 Legend Group
      yes price: 62% · 24h volume: $241,306 · resolves 2026-08-09

### GDACS — global disaster alerts — 10 new of 254 total
  - (2026-08-08) [Green] Earthquake in Southeast Of Easter Island
      Earthquake · Green alert · Southeast Of Easter Island · Magnitude 5.6M, Depth:10km
  - (2026-08-08) [Green] Earthquake in Southeast Of Easter Island
      Earthquake · Green alert · Southeast Of Easter Island · Magnitude 5.6M, Depth:10km
  - (2026-08-08) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.6M, Depth:34km
  - (2026-08-08) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.6M, Depth:34km
  - (2026-08-01) [Green] Forest fires in The Democratic Republic of Congo
      Wildfire · Green alert · The Democratic Republic of Congo · Green impact for forestfire in 11878 ha
  - (2026-08-01) [Green] Forest fires in The Democratic Republic of Congo
      Wildfire · Green alert · The Democratic Republic of Congo · Green impact for forestfire in 11878 ha

### IT, InfoSys & cybersecurity news (last 7 days) — 10 new of 56 total
  - (2026-08-08) [BleepingComputer] Hackers breach TrueConf to trojanize client installers with backdoors
      The Head Mare hacktivist group has been exploiting vulnerabilities in unpatched TrueConf video conferencing servers to replace client installers with malicious versions that deliver backdoors. [...]
  - (2026-08-08) [The Register] Devs to Anthropic, OpenAI, Cursor, and friends: Make security and privacy the default
      Researchers scour social media to measure developer concerns about AI coding tools
  - (2026-08-08) [The Register] South Korean satellite spots SpaceX lunar impact
      Before and after shots of Elon's ejecta snapped by Danuri
  - (2026-08-08) [Ars Technica] The first self-driving vehicle on Mars has proven to be a smashing success
      About 90 percent of the distance driven by Perseverance has been autonomous.
  - (2026-08-08) [Ars Technica] DeepMind’s hurricane breakthrough has surprised weather scientists
      Open source WeatherNext model can make accurate predictions with lower-resolution weather data.
  - (2026-08-08) [TechCrunch] Planned Amazon data center could become the biggest climate polluter in the U.S.
      As part of a planned Texas data center, Amazon is investing in an on-site power plant that could reportedly become the largest source of climate pollution in the United States.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 37 total
  - (2026-08-09) MOVER ▲ Germán Larrea Mota Velasco & family — $68.90B (+$0.24B since yesterday)
      Mexico · Metals & Mining · source: Mining
  - (2026-08-09) MOVER ▲ Amancio Ortega — $148.76B (+$0.24B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-09) MOVER ▲ Bernard Arnault & family — $148.46B (+$0.24B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-09) MOVER ▲ Carlos Slim Helu & family — $122.20B (+$0.19B since yesterday)
      Mexico · Telecom · source: Telecom
  - (2026-08-09) MOVER ▲ Francoise Bettencourt Meyers & family — $95.53B (+$0.15B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-09) MOVER ▲ Tadashi Yanai & family — $68.29B (+$0.13B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 87 total
  - (2026-08-09) [USASpending] $10,560,504,772 → WASHINGTON RIVER PROTECTION SOLUTIONS LLC: MANAGEMENT OF THE HANFORD SITE TANK FARMS
      Agency: Department of Energy. Description: MANAGEMENT OF THE HANFORD SITE TANK FARMS
  - (2026-08-09) [USASpending] $4,811,722,791 → LEIDOS BIOMEDICAL RESEARCH INC: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
      Agency: Department of Health and Human Services. Description: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
  - (2026-08-09) [USASpending] $876,771,741 → HII MISSION TECHNOLOGIES CORP: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT
      Agency: General Services Administration. Description: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT NETWORK OF ENGINEERING AND EMERGING OPERATIONS (JNEEO)
  - (2026-08-09) [USASpending] $873,510,388 → BCCG A JOINT VENTURE: CONSTRUCTION OF BORDER BARRIER WALL SYSTEM.
      Agency: Department of Homeland Security. Description: CONSTRUCTION OF BORDER BARRIER WALL SYSTEM.
  - (2026-08-09) [USASpending] $684,259,961 → LEIDOS, INC.: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
      Agency: Department of Transportation. Description: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
  - (2026-08-09) [USASpending] $680,032,258 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-09) [Japan] No to Nuclear : why nuclear power and nuclear weapons are interlinked threats to humanity
      nuclear-news.net · English
  - (2026-08-09) [Japan] OpenAI Rogue Agent Hacked More Than Just Hugging Face
      explosion.com · English
  - (2026-08-09) [Japan] AC Shadows Preview : 10 Key Takeaways From 6 Hours Hands - On
      explosion.com · English
  - (2026-08-09) [Japan] Takaichi administration move toward militarization sparks concerns
      japanherald.com · English
  - (2026-08-09) [Japan] Japan defense ministry to request record - high budget for FY2027
      japanherald.com · English
  - (2026-08-09) [Japan] 1st LD - Writethru : China urges Japanese authorities to stop playing with fire on issue of nuclear weapons : spokesperson
      japanherald.com · English

### Chinese Internal News — 5 new of 16 total
  - (2026-08-08) Global pharma giants turn to Chinese biotech to tap innovation, valuation growth
  - (2026-08-09) [feed error] Guancha 观察者网 (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Aguancha.cn&hl=zh-CN&gl=CN&ceid=CN:zh-Hans
  - (2026-08-09) [feed error] People's Daily 人民日报 (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Apeople.com.cn+OR+site%3Apeople.cn&hl=zh-CN&gl=CN&ceid=CN:zh-Hans
  - (2026-08-09) [feed error] Caixin Global (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Acaixinglobal.com&hl=en-US&gl=US&ceid=US:en
  - (2026-08-09) [feed error] Caixin 财新 (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Acaixin.com&hl=zh-CN&gl=CN&ceid=CN:zh-Hans

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-09) [Marginal Revolution] One of the better pro-natalist Lieder
      The post One of the better pro-natalist Lieder appeared first on Marginal REVOLUTION.
  - (2026-08-09) [Marginal Revolution] Is there a Balkan fertility paradox? (from my email)
      The Balkans may be the only region other than central Asia where fertility has increased from 2015 to 2026.* All of the highest fertility rates in Europe are in the Balkans. As of 2024: Montenegro (1.8), Bulgaria (1.73)…
  - (2026-08-08) [Marginal Revolution] The future of warfare? (from my email)
      As weapon systems increase in effectiveness, they will generally target one another rather than humans. Lower loss of life will ease conflict entry and hinder exit. Warfare will veer further from industrial competition i…

### Macro indicators — latest values (FRED) — 1 new of 21 total
  - (2026-08-07) [Rates] 10y–2y Spread (recession indicator) (T10Y2Y)
      latest: 0.46 as of 2026-08-07

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-09) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: final, action, provide, safety, proposes, rulemaking, notice, proposed, standards, certain, proposing, program
- state_bills: today=0, 7d-median=118, 14d-median=129; carrying terms: action, changes, circumstances, permits, certification, legislative, systems, owner, entity, purposes, based, rights
- state_news: today=473, 7d-median=717, 14d-median=758; carrying terms: three, little, number, controversial, illinois, changes, budget, executive, difficult, leaves, second, legislative
- local_news: today=171, 7d-median=239, 14d-median=230; carrying terms: three, illinois, world, stlmag, based, uploads, south, arrested, friday, accused, another, loading
- foreign_news: today=973, 7d-median=1034, 14d-median=1034; carrying terms: helped, jingnan, timeout, three, inspected, little, cropped, blaze, attracted, number, understanding, praised
- chinese_internal: today=16, 7d-median=261, 14d-median=266; carrying terms: caixin, global, people, record, google, chinese, https, china, price, growth, target, trading
- russian_internal: today=867, 7d-median=1056, 14d-median=943; carrying terms: wildberries, patriot, axios, street, novaya, forbidden, telegram, gazeta, found, insider, https, variety
- ukrainian_internal: today=102, 7d-median=107, 14d-median=125; carrying terms: three, critical, snapshot, changes, region, damage, forces, broader, additional, regional, verified, strike
- ukraine_theater: today=488, 7d-median=488, 14d-median=627; carrying terms: extra, cartography, firms, coverage, client, daily, alerts, snapshot, viirs, deepstatemap, token, google
- paper_bets: today=138, 7d-median=140, 14d-median=138; carrying terms: johnny, chase, washington, governor, goals, polymarket, levels, speed, humans, pirates, fusion, whose
- weather: today=160, 7d-median=177, 14d-median=173; carrying terms: angeles, ruskin, effect, afdhgx, rivers, little, issued, action, southeast, worth, smoke, health
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: assets, dexjpus, personal, cpiaucsl, growth, latest, payems, rates, cpilfesl, walcl, jtsjol, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, credit, nasdaq, yield, bitcoin, rates, commodities, large, futures, russell, equities, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=87, 7d-median=101, 14d-median=102; carrying terms: protecting, integrity, combat, latinscript, federation, hybrid, prohibiting, russia, snapshot, adopted, occupation, region
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, https, client, quiver, unauthorized, quantitative, httperror, quiverquant
- billionaires: today=37, 7d-median=40, 14d-median=37; carrying terms: finance, tiktok, semiconductors, france, steve, zhang, telecom, discount, retail, facebook, bettencourt, mukesh
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: johnson, court, delaware, county, appeals, supreme, blanche, california, international, arizona, hernandez, company
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, michael, richard, therapeutics, group, daniel, william, brian
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, ossoff, alexandria, johnson, filing, trone, receipts, house, jonathan, lindsey, cortez, graham
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, japanherald, china
- gdelt_gkg: today=95, 7d-median=50, 14d-median=49; carrying terms: english, israel, hezbollah, trump, spanish, themes, keywords, russian, russia, netanyahu, chinese, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=15, 7d-median=19, 14d-median=16; carrying terms: position, belgium, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: mosquitoes, continued, initiated, accordance, acute, given, october, poultry, majority, three, received, ratio
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: actor, orchestrator, arista, langflow, injection, exposure, fortinet, command, information, vulnerability, velocloud, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=254, 7d-median=233, 14d-median=245; carrying terms: macedonia, philippines, herzegovina, france, bulgaria, monaco, kazakhstan, congo, ethiopia, germany, wildfire, marino
- usgs_quakes: today=13, 7d-median=13, 14d-median=16; carrying terms: depth, japan, islands, region, indonesia, philippines, argentina, kermadec, sarangani, alaska, solomon, antonio
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, normal, september, august, effective, returns, ceasefire, prime, hormuz, strait
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: revolution, class, economist, conversable, marginal, https, conversableeconomist, marginalrevolution, college, strong, future, economic
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: industry, health, world, against, models, cybersecurity, systems, newsletter, companies, target, cyber, record
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: salazar, sanders, suozzi, gilbert, monica, keating, administrator, young, jahana, darin, davids, higgins
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, market, paper, markets, claude, converges, either, unavailable, sufficient, placement, evidence, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*