# WORLDSCOPE morning brief — 2026-10-08

## Headline
3465 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (846) · Russian Internal News (state + in-exile) (731) · State-Level News (367) · World leaders & government officials (324) · Chinese Internal News (243) · U.S. Weather + Severe / Climate Outlooks (206) · Local News: St. Louis + Atlanta (192) · Ukraine Theater (total-war monitoring) (186) · Ukrainian Internal News (national + local Kyiv) (64) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (40) · Forbes Real-Time Billionaires (top 30 + biggest movers) (30)

## What changed today
### International News + Multilateral Institutions — 846 new of 1042 total
  - (2026-10-08) [Global] Anne Carson wins Nobel prize in literature 2026
  - (2026-10-07) [Global] Canada to indefinitely bar mental illness as sole reason for access to euthanasia
  - (2026-10-07) [Global] ‘Another coup d’état’: fears grow as Flávio Bolsonaro vows to ‘re-democratise’ Brazil
  - (2026-10-08) [Global] South Korea threatens legal action if fuel shipments to Russia found to have broken law
  - (2026-10-08) [Global] Japan beer giants raided over suspicions they colluded to set the price of beverages
  - (2026-10-08) [Global] Indonesia accused of ‘gross negligence’ in wildfires lawsuit as haze tests region

### Russian Internal News (state + in-exile) — 731 new of 1208 total
  - (2026-10-08) В Москве простились с Анатолием Кашпировским — самым известным «целителем» позднего СССР. Фотографии | LEDE: 8 октября на Троекуровском кладбище в Москве прошла церемония прощания с Анатолие] (ru: В М…
      8 октября на Троекуровском кладбище в Москве прошла церемония прощания с Анатолием Кашпировским (он умер 3 октября в возрасте 87 лет). Он (наряду с Алланом Чумаком, умершим девять лет назад) был самым известным телевизио…
  - (2026-10-08) Роскомнадзор запретил два романа-антиутопии Ольги Птицевой — об альтернативной России, где к власти пришла Партия холода | LEDE: Роскомнадзор запретил романы «Двести третий день зимы» и «Вес] (ru: Рос…
      Роскомнадзор запретил романы «Двести третий день зимы» и «Весна воды» писательницы Ольги Птицевой. Уведомление об этом 7 октября появилось на странице портала «Год литературы», внимание на него обратило издание «Верстка»…
  - (2026-10-08) Последствия удара по рейсовым автобусам в Краматорске. Фотографии. Осторожно: это страшные кадры | LEDE: 8 октября Россия атаковала Краматорск, прифронтовой город в Донецкой области. Удар, в] (ru: Пос…
      8 октября Россия атаковала Краматорск, прифронтовой город в Донецкой области. Удар, вероятно, был нанесен управляемой авиабомбой. Под него попали два рейсовых автобуса с пассажирами. По последним данным, 33 человека поги…
  - (2026-10-08) Евросоюз исключил миллиардера Михаила Гуцериева из белорусского санкционного списка. Он остается под санкциями против России | LEDE: Послы стран ЕС 7 октября исключили российского миллиардер] (ru: Евр…
      Послы стран ЕС 7 октября исключили российского миллиардера Михаила Гуцериева из санкционного списка Беларуси, передает «Радио Свобода».
  - (2026-10-08) Умерла Маргарет Гамильтон — программистка проекта «Аполлон». Она написала код для высадки на Луну и доказала, что карьеру можно совмещать с материнством. А ее маленькая дочь однажды помогла най] (ru:…
      В США в возрасте 90 лет умерла Маргарет Гамильтон — первая женщина-программист в космической программе NASA «Апполон». Вы наверняка видели ее фотографию — с огромными томами кода для лунной программы.
  - (2026-10-08) Лауреатом Нобелевской премии по литературе стала канадская писательница Энн Карсон | LEDE: В Стокгольме объявили имя лауреата Нобелевской премии по литературе. Награду присудили канадской пи] (ru: Лау…
      В Стокгольме объявили имя лауреата Нобелевской премии по литературе. Награду присудили канадской писательнице Энн Карсон «за смелое и изобретательное творчество, создавшее в игривом диалоге с классической традицией новые…

### State-Level News — 367 new of 754 total
  - (2026-10-08) [California] They made misleading election claims. Now they’re targeting CA counties
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/091726_Clint_Curtis_SO_CM_13.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-10-08) [California] The UC got rid of the SAT in admissions. It may be on its way back
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/072926_STONEGARDENFOLO_ZM_CM_20.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-10-08) [California] How election deniers are using public records to sow doubt in California
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/091726_Clint_Curtis_SO_CM_10.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-10-08) [California] Newsom apologized to tribes for historic harms, but vetoed 2 bills that would have empowered them
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/08/052024_Delta_LE_CM_24.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="A w…
  - (2026-10-08) [California] Unsure about the bond measures on California’s ballot? These 2 questions can help
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/06/060722_Fresno_Election_LV_MG_013.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-10-07) [California] ¿Por qué multimillonarios de otros estados están financiando una medida de identificación de votantes en California?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/092926-Winklevoss-and-Uihlein-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 243 new of 279 total
  - (2026-10-07) 破解一个多世纪的化学谜题 法日化学家荣获2026诺贝尔化学奖 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5YRVM5dzR6aXpneWFwZ0dGY1dwSlBwaXRJb2JxaUV1RVlyeklrbzkzOW52ZjZUTW1LcnJVRnJma1FJQm5XRHFlSTN] (zh:…
      破解一个多世纪的化学谜题 法日化学家荣获2026诺贝尔化学奖 财新
  - (2026-10-06) 财新闻｜贵州“村超”首个海外赛区签约，“村超”模式正式走出国门 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1lVkJHMHZyMHMtcUluRlhzUU5Vem4zNkJzSDU0U05EWGVpblNmTTBzczJOYmNGSThFRjA2ZHFMalN5MWtnYWs2TE] (zh:…
      财新闻｜贵州“村超”首个海外赛区签约，“村超”模式正式走出国门 财新
  - (2026-10-08) 为帮女友挂专家号，程序员写出“抢号软件”，后帮人收费抢号获利上万元，还搞瘫医院挂号系统……法院判了 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE85anFGS2lleG5NMFBreFA0NXRqdDBhdlR6cm16dFEyWjhHWnBYbjh4a05maFBFdUltZlFG] (zh:…
      为帮女友挂专家号，程序员写出“抢号软件”，后帮人收费抢号获利上万元，还搞瘫医院挂号系统……法院判了 财新
  - (2026-10-08) 三位致力于环保资源共享的中国学人｜故事 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE94LUh6N2kxakc1andIaTdoOWtPZXlDcWJMeFc5cVJrRElBZzMwSTRESjcwbm5tUFhsOV9TbDdNZDlFQ2xzM2dRQXBTbVNuUEd5OU] (zh:…
      三位致力于环保资源共享的中国学人｜故事 财新
  - (2026-10-08) 巍峨大佛与无名工匠｜千年麦积山石窟⑥（完） - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFB5dVpUcUR2eGphVkRfazB5a3RvQUVTUW5FQ2pPT0lyZ2NTYzJzMGItWHFlbmdzSHRfbURPTHE5ZDliVlYwMmVEVkV6WG9vMVR5] (zh:…
      巍峨大佛与无名工匠｜千年麦积山石窟⑥（完） 财新
  - (2026-10-08) 获了诺奖的“中微子”是什么子｜解释 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9GZEJFWldhZXBIWndaNXZ5aHpHSXQ1X1RaRnc2NnFfVmdmdlBYSzc2R0FiMUs0M21ZRVpGYTd2Si1RZGZpRnBKZ0dZXzdfcGRjMW11] (zh:…
      获了诺奖的“中微子”是什么子｜解释 财新

### U.S. Weather + Severe / Climate Outlooks — 206 new of 207 total
  - (2026-10-08) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-08) [Severe] Flood Warning: Flood Warning issued October 8 at 10:05AM EDT by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Astor affecting Lake and Volusia Counties. .The St Johns River at Astor continues a steady rise within Minor Flood Stage and is fo…
  - (2026-10-08) [Severe] Flood Warning: Flood Warning issued October 8 at 8:40AM CDT until October 11 at 10:00AM CDT by NWS Mobile AL
      ...The National Weather Service in Mobile has issued a Flood Warning for the following rivers in Alabama... Styx River Near Elsanor affecting Baldwin County. For the Styx River...including Elsanor...Moderate flooding is…
  - (2026-10-08) [Severe] Flood Warning: Flood Warning issued October 8 at 8:38AM CDT by NWS Mobile AL
      ...The National Weather Service in Mobile has issued a Flood Warning for the following rivers in Florida... Shoal River Near Crestview affecting Okaloosa County. For the Shoal River...including Crestview...Minor flooding…
  - (2026-10-08) [Severe] Flood Warning: Flood Warning issued October 8 at 8:37AM CDT until October 11 at 9:00PM CDT by NWS Mobile AL
      ...The National Weather Service in Mobile has issued a Flood Warning for the following rivers in Alabama...Florida... Perdido River Near Barrineau Park affecting Baldwin and Escambia Counties. For the Perdido River...inc…
  - (2026-10-08) [Severe] Flood Warning: Flood Warning issued October 8 at 8:35AM CDT until October 11 at 1:00PM CDT by NWS Mobile AL
      ...The National Weather Service in Mobile has issued a Flood Warning for the following rivers in Alabama...Florida... Blackwater River Near Baker affecting Escambia, Covington, Okaloosa and Santa Rosa Counties. For the B…

### Local News: St. Louis + Atlanta — 192 new of 233 total
  - (2026-10-08) [St. Louis] Little Big Town is the real thing on ‘It’s a Dying Art’
      Little Big Town’s new album isn’t perfect, because they didn’t want it to be. “You’re going to hear little subtle mistakes or something, but that’s just part of why it doesn’t sound like AI,” Little Big Town’s Phillip Sw…
  - (2026-10-08) [St. Louis] Northside cleanup effort gets a boost through new MOU with the city
      It took two tries, but Donnell “Malik” Sims finally has a North City trash pickup program up and running. Sims, a longtime community activist, has for years led a group of volunteers cleaning up lots on the Northside. On…
  - (2026-10-08) [St. Louis] 3 employee ownership models that go beyond ESOPs
      When most people think about employee-owned companies, they probably think of an employee stock ownership plan, or ESOP. It’s the most common form of employee ownership in the U.S., and for good reason: ESOPs can offer s…
  - (2026-10-08) [St. Louis] New nonprofit PrideFull aims to connect LGBTQ St. Louisans with affirming therapists
      With a passion for supporting the queer community and a mission to improve access to mental health services in St. Louis, the new nonprofit PrideFull aims to become the first of its kind in the area to connect LGBTQ clie…
  - (2026-10-08) [St. Louis] Where in the Lou? – 10/8/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-10-07) [St. Louis] Where to spend Halloween night in St. Louis
      Looking for a spooky way to spend your Halloween night? Look no further than this collection of screenings, performances, parties, and more. Tickets sell out early, so be sure to grab yours ASAP to make sure your All Hal…

### Ukraine Theater (total-war monitoring) — 186 new of 584 total
  - (2026-10-07) [FIRMS] thermal anomaly 45.440, 29.618 (FRP 4.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-07 1009Z, FRP 4.76 MW
  - (2026-10-07) [FIRMS] thermal anomaly 45.439, 29.614 (FRP 4.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-07 1009Z, FRP 4.76 MW
  - (2026-10-07) [FIRMS] thermal anomaly 45.229, 28.841 (FRP 15.58 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-07 1009Z, FRP 15.58 MW
  - (2026-10-07) [FIRMS] thermal anomaly 45.440, 29.617 (FRP 13.35 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-07 1009Z, FRP 13.35 MW
  - (2026-10-07) [FIRMS] thermal anomaly 45.439, 29.613 (FRP 10.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-07 1009Z, FRP 10.29 MW
  - (2026-10-07) [FIRMS] thermal anomaly 45.230, 28.840 (FRP 15.12 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-07 1009Z, FRP 15.12 MW

### Ukrainian Internal News (national + local Kyiv) — 64 new of 139 total
  - (2026-10-08) Росіяни вдарили КАБом по громаді на Дніпропетровщині, загинули двоє чоловіків | LEDE: 8 жовтня у Васильківській громаді російський авіаудар зруйнував будинки і забрав життя двох 62-річних чолов] (uk:…
      8 жовтня у Васильківській громаді російський авіаудар зруйнував будинки і забрав життя двох 62-річних чоловіків. Деталі від ОВА.
  - (2026-10-08) Фіцо поділився думками про статую оголеного Трампа у Європарламенті | LEDE: Глава уряду Словаччини Роберт Фіцо заявив, що поява статуї оголеного президента США Дональда Трампа у Європарламенті ] (uk:…
      Глава уряду Словаччини Роберт Фіцо заявив, що поява статуї оголеного президента США Дональда Трампа у Європарламенті засвідчила для нього занепад Євросоюзу.
  - (2026-10-08) Росія наступає, Франція втрачає: що рухає змінами в Африці та в чому звинувачують Україну | LEDE: ] (uk: Росія наступає, Франція втрачає: що рухає змінами в Африці та в чому звинувачуют)
  - (2026-10-08) Окупанти вдарили по Сумах з артилерії: 1 людина загинула, серед поранених – діти | LEDE: Внаслідок удару російської далекобійної артилерії по Сумах загинула одна людина, четверо поранені, серед] (uk:…
      Внаслідок удару російської далекобійної артилерії по Сумах загинула одна людина, четверо поранені, серед них двоє дітей. Пошкоджено цивільну інфраструктуру.
  - (2026-10-08) У Києві кількість загиблих від російських атак зросла до чотирьох, постраждали 18 людей | LEDE: У столиці від початку доби 8 жовтня внаслідок російських атак загинули троє людей, ще 14 постражд] (uk:…
      У столиці від початку доби 8 жовтня внаслідок російських атак загинули троє людей, ще 14 постраждали, двоє поранених перебувають у тяжкому стані.
  - (2026-10-08) Росіяни вдень атакували Київщину: горять склади, 3 постраждалих | LEDE: Російські війська атакували склади у Бучанському районі. Одна людина – в лікарні, ще двоє отримали допомогу на місці. Так] (uk:…
      Російські війська атакували склади у Бучанському районі. Одна людина – в лікарні, ще двоє отримали допомогу на місці. Також на Київщині пошкоджено будинок і вантажівку.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-08) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-10-08 14:15 UTC — Filed: 2026-10-08 AccNo: 0001839882-26-050079 Size: 561 KB
  - (2026-10-08) 424B2 - TORONTO DOMINION BANK (0000947263) (Filer)
      filed 2026-10-08 14:14 UTC — Filed: 2026-10-08 AccNo: 0001140361-26-039090 Size: 302 KB
  - (2026-10-08) 497K - SUNAMERICA SERIES TRUST (0000892538) (Filer)
      filed 2026-10-08 14:14 UTC — Filed: 2026-10-08 AccNo: 0001193125-26-417543 Size: 7 KB
  - (2026-10-08) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-10-08 14:12 UTC — Filed: 2026-10-08 AccNo: 0001918704-26-031002 Size: 460 KB
  - (2026-10-08) 424B2 - ROYAL BANK OF CANADA (0001000275) (Filer)
      filed 2026-10-08 14:12 UTC — Filed: 2026-10-08 AccNo: 0000950103-26-015342 Size: 128 KB
  - (2026-10-08) 497K - SUNAMERICA SERIES TRUST (0000892538) (Filer)
      filed 2026-10-08 14:12 UTC — Filed: 2026-10-08 AccNo: 0001193125-26-417542 Size: 7 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 40 new of 55 total
  - (2026-10-08) [BleepingComputer] OAuth grants pile up faster than you can review them. Here's how to keep up.
      OAuth grants create data highways between SaaS apps, AI agents, and other tools. And, they are multiplying faster than any security team can review them. As the recent Klue breach showed, attackers are taking notice and…
  - (2026-10-08) [BleepingComputer] Uranium crypto exchange hacker convicted for stealing $53 million
      A Maryland man was found guilty of stealing more than $53 million after hacking the decentralized crypto exchange Uranium Finance twice in April 2021. [...]
  - (2026-10-08) [BleepingComputer] Microsoft Teams to get support for third-party deepfake detection tools
      Microsoft will soon introduce support for third-party deepfake detection solutions and impersonation protection in Teams meetings. [...]
  - (2026-10-08) [BleepingComputer] ASOS links data breach to social engineering attack, credential theft
      ASOS is sending updates to affected customers about the cybersecurity incident it suffered earlier this week, confirming that hackers accessed some personal data. [...]
  - (2026-10-08) [BleepingComputer] Owner of Empire cybercrime market gets 40 years in prison
      The co-creator of Empire Market, one of the largest dark web marketplaces before its shutdown, has been sentenced to 40 years in prison for facilitating $430 million in illegal transactions from 2018 to 2020. [...]
  - (2026-10-08) [The Hacker News] Wazza Phishkit Targets Banking, Government, and Manufacturing Across the US, EU, and Australia
      Phishing kits are no longer limited to copying a familiar login page and waiting for a victim to enter credentials. Attackers are increasingly building filtering, session management, and traffic controls into the infrast…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-10-08) #1 Elon Musk — $1016.04B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-10-08) #2 Jeff Bezos — $377.48B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-10-08) #3 Larry Page — $287.83B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-10-08) #4 Michael Dell — $279.76B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-10-08) #5 Sergey Brin — $264.88B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-10-08) #6 Mark Zuckerberg — $247.02B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 30 total
  - (2026-10-08) PAT511 (United States)
      icao24: adfe4c · position: (35.7685, -81.3157) · alt: 7010m · 499km/h
  - (2026-10-08) PAT057 (United States)
      icao24: adfe91 · position: (33.787, -118.0547) · alt: 53m · 263km/h
  - (2026-10-08) SAMU45 (France)
      icao24: 39ca85 · position: (47.7797, 2.1473) · alt: 243m · 246km/h
  - (2026-10-08) SAMU13 (France)
      icao24: 39ca81 · position: (43.3795, 5.3639) · alt: 236m · 13km/h
  - (2026-10-08) SAMU59 (France)
      icao24: 39b5d1 · position: (50.5991, 3.0762) · alt: 251m · 199km/h
  - (2026-10-08) FNY55A2 (France)
      icao24: 39a408 · position: (48.1707, 1.6203) · alt: 13106m · 728km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-08) [Russia oil sanctions perimeter · themes] Nasuni推AI數據平台與高速傳輸工具 助企業管理大數據邊緣運算
      n.yam.com · Chinese · tone NA
  - (2026-10-08) [Russia oil sanctions perimeter · themes] Voile : après les régates de lIRC Cup à Bonifacio , le Tour de Corse attend son départ
      ici.fr · French · tone NA
  - (2026-10-08) [Russia oil sanctions perimeter · themes] Economía estable , pero con turbulencias a la vista
      hoy.com.do · Spanish · tone NA
  - (2026-10-08) [Russia oil sanctions perimeter · themes] Detectan tres factores en caída de 12 % en exportaciones automotrices
      vanguardia.com.mx · Spanish · tone NA
  - (2026-10-08) [Russia oil sanctions perimeter · themes] Cel puțin 28 de morți , între care copii , după ce Rusia a lovit o clădire rezidențială . „ Acesta este genul de „ cadou pe care Putin și l - a făcut de ziua…
      ziare.com · Romanian · tone NA
  - (2026-10-08) [Russia oil sanctions perimeter · themes] সৌদি আরবে দুই বিমানবন্দরে হুথিদের ক্ষেপণাস্ত্র হামলায় নিহত ৩ , আহত ৩৬
      dhakatimes24.com · Bengali · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 24 new of 111 total
  - (2026-10-08) [USASpending] $22,653,589,200 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-10-08) [USASpending] $1,151,375,068 → IOWA STATE UNIVERSITY OF SCIENCE AND TECHNOLOGY: MULTI-PROGRAM NATIONAL PHYSICAL RESEARCH INCLUDING RARE EART
      Agency: Department of Energy. Description: MULTI-PROGRAM NATIONAL PHYSICAL RESEARCH INCLUDING RARE EARTHS AND USE OF AMES MPC.
  - (2026-10-08) [USASpending] $1,115,135,672 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…
  - (2026-10-08) [USASpending] $662,257,531 → AMENTUM SPACEPORT LLC: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT
      Agency: National Aeronautics and Space Administration. Description: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT
  - (2026-10-08) [USASpending] $551,780,977 → HANFORD LABORATORY MANAGEMENT AND INTEGRATION LLC: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN TH
      Agency: Department of Energy. Description: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN THE 222-S LABORATORY COMPLEX.
  - (2026-10-08) [USASpending] $544,992,327 → NOVITAS SOLUTIONS, INC.: A/B MAC JURISDICTION L
      Agency: Department of Health and Human Services. Description: A/B MAC JURISDICTION L

### U.S. Federal Action — 23 new of 23 total
  - (2026-10-08) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A350-941 and -1041 airplanes. This proposed AD was prompted by a girt bar fitting safety hook on an airplane in the production line wa…
  - (2026-10-08) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A318, A319, A320, and A321 series airplanes. This proposed AD was prompted by a finding that severe corrosion could occur on affected…
  - (2026-10-08) Impact Aid Programs
      The U.S. Department of Education (Department) amends the regulations that govern Impact Aid Programs (IAP) to make technical changes, to include correcting grammatical, spelling, and typographical errors; correcting or u…
  - (2026-10-08) Removal of Obsolete Portion of Regulation Relating to Care and Treatment of Ineligible Individuals
      The Indian Health Service (IHS) of the Department of Health and Human Services (HHS or "the Department") is issuing this final rule to remove obsolete language appearing in the Code of Federal Regulations (CFR). The lang…
  - (2026-10-08) Removal of Obsolete/Suspended Regulations
      The Indian Health Service (IHS) of the Department of Health and Human Services (HHS or "the Department") is issuing this final rule to remove regulations appearing in the Code of Federal Regulations (CFR). The regulation…
  - (2026-10-08) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2019-20- 07, which applied to The Boeing Company Model 787-8, 787-9, and 787-10 airplanes. AD 2019-20-07 required repetitive operational checks of the leading edge (LE)…

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-10-08) M 6.3 - 102 km NE of Norsup, Vanuatu
      M6.3 · 102 km NE of Norsup, Vanuatu · depth 10 km
  - (2026-10-08) M 5.5 - 17 km SW of Burias, Philippines
      M5.5 · 17 km SW of Burias, Philippines · depth 52.054 km
  - (2026-10-08) M 5.5 - west of Macquarie Island
      M5.5 · west of Macquarie Island · depth 10 km
  - (2026-10-07) M 5.2 - Chagos Archipelago region
      M5.2 · Chagos Archipelago region · depth 10 km
  - (2026-10-08) M 5.1 - 236 km E of Levuka, Fiji
      M5.1 · 236 km E of Levuka, Fiji · depth 602.272 km
  - (2026-10-08) M 5.0 - 92 km N of Ruteng, Indonesia
      M5.0 · 92 km N of Ruteng, Indonesia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-10-08) LoL: Natus Vincere vs JD Gaming (BO3) - Demacia Cup Global Invitational Group Stage
      yes price: 0% · 24h volume: $1,513,785 · resolves 2026-10-08
  - (2026-10-08) Dota 2: Aurora vs 1win - Game 1 Winner
      yes price: 18% · 24h volume: $985,584 · resolves 2026-10-08
  - (2026-10-08) Will Donald Trump win the Nobel Peace Prize in 2026?
      yes price: 1% · 24h volume: $925,405 · resolves 2027-04-01
  - (2026-10-08) LoL: Natus Vincere vs JD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $876,761 · resolves 2026-10-08
  - (2026-10-08) Valorant: Team Vitality vs Nongshim RedForce (BO3) - VCT Champions Playoffs
      yes price: 100% · 24h volume: $875,921 · resolves 2026-10-08
  - (2026-10-08) Shanghai Rolex Masters: Cameron Norrie vs Dalibor Svrcina
      yes price: 0% · 24h volume: $855,338 · resolves 2026-10-15

### Paper Trading Scorecard — 14 new of 128 total
  - (2026-10-08) [Manifold] Will AI break crypto?
  - (2026-10-08) [Manifold] Will any US Senate candidate lead the polling average by 5% or more and lose?
  - (2026-10-08) [Manifold] Will we "lose public key cryptography" by EoY 2028?
  - (2026-10-08) [Manifold] Will Trump be impeached within 3 month after the midterms ?
  - (2026-10-08) [Manifold] Will someone Any% Super Mario Odyssey in under 55 minutes by EOY 2028
  - (2026-10-08) [Manifold] This statement is a lie.

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-10-08) U.S. Court of Appeals, 11th Cir.: United States v. Junior Xavier Chirino-Lovera
  - (2026-10-07) U.S. Court of Appeals, 11th Cir.: Curtrina Martin v. USA
  - (2026-10-07) U.S. Court of International Trade: Pitts Enterprises, Inc. v. United States
  - (2026-10-07) U.S. Court of Appeals, 3rd Cir.: Sandoz Inc v. United Therapeutics Corporation
  - (2026-10-07) U.S. Court of Appeals, 6th Cir.: United States v. Nathan Goddard
  - (2026-10-01) Florida Supreme Court: In Re: Amendments to Florida Probate Rules 5.015, 5.630, and 5.648

### State Legislative Action — 7 new of 62 total
  - (2026-10-08) [California SB 402] Health care coverage: autism.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care and makes a willful violation of the act…
  - (2026-10-08) [California SB 395] Alcoholic beverages: additional licenses: hospitality zone.
      Existing law, the Alcoholic Beverage Control Act, administered by the Department of Alcoholic Beverage Control, regulates the sale and distribution of alcoholic beverages and the granting of licenses for the manufacture,…
  - (2026-10-07) [District of Columbia B 26-0829] Shared Housing Agreements and Resolution Effort Pilot Program Amendment Act of 2026
      Shared Housing Agreements and Resolution Effort Pilot Program Amendment Act of 2026
  - (2026-10-07) [District of Columbia B 26-0834] Reeves Center Surplus Declaration and Disposition Approval Act of 2026
      Reeves Center Surplus Declaration and Disposition Approval Act of 2026
  - (2026-10-07) [District of Columbia B 26-0845] Poplar Point Acquisition and Disposition Approval Act of 2026
      Poplar Point Acquisition and Disposition Approval Act of 2026
  - (2026-10-07) [District of Columbia B 26-0846] Poplar Point Economic Development Anchor Disposition Act of 2026
      Poplar Point Economic Development Anchor Disposition Act of 2026

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-08) [Marginal Revolution] How and why did the Victorians succeed?
      From Samuel Hughes, in Works in Progress: The elites of Victorian Britain operated differently. Their schools and universities were not terribly academic and had very little STEM. As adults, they got up late, drank a lot…
  - (2026-10-08) [Marginal Revolution] What I’ve been reading
      1. Begoña Gómez Urzaiz, The Abandoners: On Mothers and Monsters. A wonderful book about mothers who abandon their children, and properly unsentimental. You will never think about Muriel Spark the same way again. Vashti B…
  - (2026-10-07) [Marginal Revolution] Wednesday assorted links
      1. Palo Alto Networks (cybersecurity firm, check out YTD). 2. OAI doing math again. Quasi-Riemann! And just one metric of import. 3. The AI agents pitching literary magazines. 4. Redux of my 2022 post on the effective al…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-08) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=23, 7d-median=26, 14d-median=24; carrying terms: national, safety, rulemaking, regulatory, proposed, state, action, final, standards, provisions, program, certain
- state_bills: today=62, 7d-median=105, 14d-median=106; carrying terms: years, funds, specified, contracts, adopt, generally, prevention, health, prohibits, providing, violation, water
- state_news: today=754, 7d-median=698, 14d-median=651; carrying terms: political, legal, azgovernor, width, clark, decade, rally, prevention, featured, beach, election, arizona
- local_news: today=233, 7d-median=233, 14d-median=229; carrying terms: width, former, investigation, atlanta, saportareport, according, async, resize, south, school, figure, being
- foreign_news: today=1042, 7d-median=1012, 14d-median=1015; carrying terms: german, needed, political, shortages, legal, width, auckland, tigray, election, scale, readtimeout, brain
- chinese_internal: today=279, 7d-median=253, 14d-median=266; carrying terms: china, cbmiakfvx, color, cbmiykfvx, cbmia, target, cbmigwfbvv, cbmiaefvx, https, cbmixkfvx, cbmizkfvx, cbmib
- russian_internal: today=1208, 7d-median=1074, 14d-median=1036; carrying terms: russian, error, title, media, https, target, bloomberg, europe, financial, blank, httperror, forbidden
- ukrainian_internal: today=139, 7d-median=137, 14d-median=131; carrying terms: assessment, ministers, political, moscow, troops, facility, campaign, scale, institute, facilities, launched, volodymyr
- ukraine_theater: today=584, 7d-median=564, 14d-median=548; carrying terms: hwzwjvmze, swvnrvaxtdz, iyntatqxj, wfbvv, bkpgznjkzks, xywtty, cnvichb, taras, tytwk, nmsehgvzdtstc, uzvbwd, equipment
- paper_bets: today=128, 7d-median=123, 14d-median=122; carrying terms: humans, minister, funds, participation, problem, experience, inflation, solved, majors, anthropic, break, state
- weather: today=207, 7d-median=141, 14d-median=142; carrying terms: significant, southern, temperatures, afdbox, oxnard, flooding, louis, across, strong, beach, seattle, atlantic
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: effective, recession, money, indicator, energy, assets, jolts, funds, sheet, walcl, jtsjol, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, russell, silver, crude, close, nasdaq, treasury, natural, large, bitcoin, futures, china
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=111, 7d-median=121, 14d-median=112; carrying terms: russian, russia, funds, libya, political, sandia, wfbvv, greer, destabilising, belarus, taliban, snapshot
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, https, quiverquant, error, httperror, unauthorized, quiver, congresstrading, quantitative
- billionaires: today=30, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: mason, national, supreme, corporation, court, appeals, union, state, william, connecticut, roman, company
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, financial, filer, holdings, trust, jpmorgan, chase, finance, america
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: alexandria, trone, talarico, senate, graham, james, raised, elect, shawn, pinkston, angels, cooper
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=25, 7d-median=49, 14d-median=25; carrying terms: english, russia, sanctions, themes, perimeter, vietnamese, chinese, spanish, french, romanian, ukrainian, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, canada, kingdom, ground, germany, eagle, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: posing, posting, detected, cruise, noted, humans, chikv, years, significant, ganga, broader, includ
- cisa_kev: today=13, 7d-median=17, 14d-median=17; carrying terms: magento, adobe, cisco, remediation, commerce, validation, bounds, vulnerability, product, buffer, multiple, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=17, 7d-median=16, 14d-median=16; carrying terms: depth, islands, indonesia, japan, south, region, philippines, papua, guinea, russia, ruteng, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, shakhtar, resolves, champions, donetsk, price, championship, volume, october, winner, group, interest
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, conversableeconomist, economist, https, marginal, conversable, revolution, basic, taxes, income, property, spending
- tech_news: today=55, 7d-median=56, 14d-median=57; carrying terms: years, companies, going, https, tools, newsletter, technology, according, security, review, computer, edition
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: eleanor, stephanie, espaillat, moore, sheehy, olszewski, hegseth, alsobrooks, salazar, murphy, fischbach, horsford
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, claude, unavailable, today, paper, placed, converges, decision, identify, module, placement, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-29] Fed press (events + announcements): Agencies publish resolution plan feedback letters for 15 banking organizations
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] ECB press: Philip R. Lane: Diagnostic Challenges for ECB Monetary Policy
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*