# WORLDSCOPE morning brief — 2026-11-26

## Headline
3009 new items across 29 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (874) · Russian Internal News (state + in-exile) (487) · State-Level News (325) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (158) · U.S. Weather + Severe / Climate Outlooks (140) · GDELT GKG — themes / entities / watch areas (139) · World News (by country, top stories) (101) · Ukrainian Internal News (national + local Kyiv) (72) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · IT, InfoSys & cybersecurity news (last 7 days) (37)

## What changed today
### International News + Multilateral Institutions — 874 new of 1063 total
  - (2026-11-26) [Global] New UK-EU treaty has 10-year termination clause, BBC understands
      Text of the treaties will be published this afternoon, alongside legislation designed to enact the bulk of the deal.
  - (2026-11-26) [Global] Poundland collapses putting 11,000 jobs at risk
      The discount chain has fallen into administration after its owners failed to find a buyer.
  - (2026-11-25) [Global] What's gone wrong at Poundland?
      Poundland has collapse into administration. Why?
  - (2026-11-26) [Global] US announces new tariffs on host of countries including China
      The new levies would hit many of America's biggest trading partners, including China and the EU.
  - (2026-11-26) [Global] US approves SpaceX plan to send a million data satellites to space
      The Starmind constellation aims to be the most cost and energy-efficient way to meet the growing demand for AI computing power.
  - (2026-11-25) [Global] US stocks fall further as fears over AI intensify
      All three main US indexes were down in early trading, with the tech-dominated Nasdaq down almost 4%.

### Russian Internal News (state + in-exile) — 487 new of 927 total
  - (2026-11-26) В Волгограде пятилетняя девочка из многодетной семьи умерла от истощения. Ее родителей задержали | LEDE: В Вологде умерла пятилетняя девочка, которая воспитывалась в многодетной семье вместе] (ru: В В…
      В Вологде умерла пятилетняя девочка, которая воспитывалась в многодетной семье вместе с десятью братьями и сестрами. Об этом сообщила пресс-служба регионального СК.
  - (2026-11-26) Суд закрыл для прессы процесс над журналистом «Новой газеты» Олегом Ролдугиным. Его обвиняют в незаконном использовании персональных данных | LEDE: В Никулинском районном суде Москвы 26 нояб] (ru: Суд…
      В Никулинском районном суде Москвы 26 ноября началось рассмотрение уголовного дела против журналиста «Новой газеты» Олега Ролдугина, которого обвиняют в незаконном использовании персональных данных (часть 3 статьи 272.1…
  - (2026-11-26) Маск пообещал по две акции SpaceX каждому ребенку в США. Месяц назад он говорил, что подарит только по одной | LEDE: Миллиардер Илон Маск заявил, что подарит каждому ребенку в США по две акц] (ru: Мас…
      Миллиардер Илон Маск заявил, что подарит каждому ребенку в США по две акции компании SpaceX.
  - (2026-11-26) Суд в Томске взыскал 5,4 миллиарда рублей с бывшего владельца «Кириешек» Дениса Штенгелова. Год назад его объявили «экстремистом» | LEDE: Арбитражный суд Томской области удовлетворил иск стр] (ru: Суд…
      Арбитражный суд Томской области удовлетворил иск структур холдинга «КДВ Групп» к своему основателю и бывшему владельцу Денису Штенгелову. Суд постановил взыскать с бизнесмена 5,45 миллиарда рублей, сообщает «Коммерсант».
  - (2026-11-26) Гордон Рамзи станет новым ведущим Top Gear | LEDE: Ведущим автомобильного шоу Top Gear, которое перезапускает BBC Studios, станет шеф-повар Гордон Рамзи. ] (ru: Гордон Рамзи станет новым ведущим Top G…
      Ведущим автомобильного шоу Top Gear, которое перезапускает BBC Studios, станет шеф-повар Гордон Рамзи.
  - (2026-11-26) Умер гитарист Duran Duran Энди Тейлор | LEDE: Умер гитарист британской рок-группы Duran Duran Энди Тейлор. ] (ru: Умер гитарист Duran Duran Энди Тейлор)
      Умер гитарист британской рок-группы Duran Duran Энди Тейлор.

### State-Level News — 325 new of 671 total
  - (2026-11-25) [California] CalPERS está cambiando las reglas para los jubilados con trabajos de medio tiempo. Te explicamos por qué
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/03/CalPERS-MG-07-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="The CalP…
  - (2026-11-25) [California] California presenta demanda para bloquear la norma de Trump que niega la ayuda a familias con estatus migratorio mixto
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/022326_For-Sale-Rent-LV_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-11-25) [California] More California seniors are working — only some of them want to
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/013024_Bieber-Electric-Rates_MG_CM_19.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-11-25) [California] The research center that stands to gain $4 billion from a ballot initiative doesn’t have a CEO
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/081924-UCLA-Research-Park-GETTY-CM-001.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-11-25) [California] How many Native people are missing or murdered in California? The state still can’t say
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/092223-Native-American-Day-MG-32.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-11-25) [California] El Niño-fueled king tides batter California’s coast — what is the state doing about it?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/112426_Alameda-Flooding_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 158 new of 181 total
  - (2026-11-26) [St. Louis] Holiday shopping safety: How to protect yourself from scams and theft
      Black Friday shoppers should watch for online scams, protect their personal information and stay alert in crowded stores to avoid theft during the holiday season.
  - (2026-11-26) [St. Louis] FAA orders ground stop in Miami after cargo plane goes off runway
      There were no reported injuries after a cargo plane overran the runway at Miami International Airport and prompted a ground stop and delays Wednesday night.
  - (2026-11-26) [St. Louis] Greenwich Rx recalled medications nationwide. Here's how to check yours
      Greenwich Rx recalled certain medications nationwide over sterility concerns that could put patients at risk of serious infections.
  - (2026-11-26) [St. Louis] WATCH: Meteor joins drone show at Indiana holiday celebration: 'Biggest, brightest meteor I’ve ever seen!'
      A meteor appeared while the city celebrated their annual "Night of Lights" in downtown Fort Wayne, Indiana.
  - (2026-11-26) [St. Louis] Plane crash off Mississippi coast kills extended family of 6 on fishing trip
      A family of six from Florida has died in a plane crash off the coast of Mississippi. The crash happened Tuesday as they returned from a fishing trip.
  - (2026-11-26) [St. Louis] FCC says SpaceX can deploy 1 million satellites for data centers in space. Scientists are skeptical
      The FCC approved SpaceX's plan to launch a million satellites for data centers in space.

### U.S. Weather + Severe / Climate Outlooks — 140 new of 142 total
  - (2026-11-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-26) [Severe] Flash Flood Warning: Flash Flood Warning issued November 26 at 3:50AM EST until November 26 at 8:00AM EST by NWS Raleigh NC
      FFWRAH The National Weather Service in Raleigh has issued a * Flash Flood Warning for... Northeastern Chatham County in central North Carolina... Southern Durham County in central North Carolina... Northeastern Harnett C…
  - (2026-11-26) [Moderate] Gale Warning: Gale Warning issued November 26 at 2:41AM CST until November 27 at 9:00AM CST by NWS Milwaukee/Sullivan WI
      * WHAT...Northeast to north winds 25 to 30 kt with gusts up to 35 kt and waves 7 to 13 ft expected. * WHERE...Southern third of the open waters of Lake Michigan. * WHEN...From 3 PM Thursday to 9 AM CST Friday. * IMPACTS.…
  - (2026-11-26) [Moderate] Gale Warning: Gale Warning issued November 26 at 2:41AM CST until November 27 at 9:00AM CST by NWS Milwaukee/Sullivan WI
      * WHAT...Northeast to north winds 25 to 30 kt with gusts up to 35 kt and waves 7 to 13 ft expected. * WHERE...Southern third of the open waters of Lake Michigan. * WHEN...From 3 PM Thursday to 9 AM CST Friday. * IMPACTS.…
  - (2026-11-26) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 26 at 2:36AM CST until November 26 at 12:00PM CST by NWS Lincoln IL
      * WHAT...Wet snow. Additional snow accumulations up to one inch. * WHERE...Portions of west central Illinois. * WHEN...Until noon CST today. * IMPACTS...Plan on slippery road conditions. Roads, and especially bridges and…
  - (2026-11-26) [Moderate] Wind Advisory: Wind Advisory issued November 26 at 3:32AM EST until November 27 at 5:00AM EST by NWS Upton NY
      * WHAT...Northeast winds 25 to 35 mph with gusts up to 55 mph expected. A few gusts to 60 mph are possible for coastal Connecticut and Southern Westchester County * WHERE...Portions of southern Connecticut, northeast New…

### GDELT GKG — themes / entities / watch areas — 139 new of 139 total
  - (2026-11-26) [Russia oil sanctions perimeter · themes] Russia's oil refinery runs plunge to lowest in over two decades as Ukrainian drone strikes continue
      hindustantimes.com · English · tone -6.20525059665871
  - (2026-11-26) [Russia oil sanctions perimeter · keywords] US-led consortium agrees to acquire assets from Russian oil company Lukoil
      ksat.com · English · tone -2.16666666666667 · 16 other outlets
  - (2026-11-26) [Russia oil sanctions perimeter · keywords] Pumping of crude oil from Oil Terminal to Petrotel-Lukoil Ploiesti refinery, resumed
      actmedia.eu · English · tone -3.07692307692308
  - (2026-11-26) [Russia oil sanctions perimeter · keywords] Top House Democrat Demands Halt to $10B Lukoil Deal
      kyivpost.com · English · tone -2.57234726688103
  - (2026-11-26) [Russia oil sanctions perimeter · near] LIVE updates : Kyiv hit by ballistic missiles as Trump, NATO's Rutte urge Russia not to expand war
      news.az · English · tone -4.79041916167665 · 17 other outlets
  - (2026-11-26) [Russia oil sanctions perimeter · near] Ukraine says major prisoner swap with Russia could begin as early as late November--China Economic Net
      en.ce.cn · English · tone -3.68098159509202 · 7 other outlets

### World News (by country, top stories) — 101 new of 101 total
  - (2026-11-26) [Brazil] Trump administration targets China, EU, Brazil with new tariffs
      jamaica-gleaner.com · English · 5 other outlets ran this story
  - (2026-11-26) [Brazil] Brazil expresses indignation over proposed new US tariffs
      prokerala.com · English · 2 other outlets ran this story
  - (2026-11-26) [Brazil] U.S. proposes new tariffs on Brazilian imports
      venezuelastar.com · English · 2 other outlets ran this story
  - (2026-11-26) [Brazil] New Zealand man arrested in Brazil over suspected baby trafficking scheme
      nzherald.co.nz · English · 1 other outlets ran this story
  - (2026-11-26) [Brazil] Prosus: The long game in Brazil, first flicker at JET and new earnings yardstick
      dailymaverick.co.za · English
  - (2026-11-26) [Brazil] Meet "Hope": It took 28 days to hatch this rare blue macaw in Brazil, but 26 years to bring its species back
      moneycontrol.com · English

### Ukrainian Internal News (national + local Kyiv) — 72 new of 136 total
  - (2026-11-26) Росіяни атакували відділення пошти на Донеччині: загинула жінка, 3 поранених | LEDE: Одна людина загинула та ще три дістали поранення внаслідок російського удару по поштовому відділенні у Билба] (uk:…
      Одна людина загинула та ще три дістали поранення внаслідок російського удару по поштовому відділенні у Билбасівці на Донеччині ввечері 25 листопада.
  - (2026-11-26) Нідерланди слідом за Німеччиною підтримали ідею прив'язки бюджету ЄС з фінансуванням України | LEDE: У Нідерландах підтримують вимогу Німеччини не погоджувати наступний довгостроковий бюджет Єв] (uk:…
      У Нідерландах підтримують вимогу Німеччини не погоджувати наступний довгостроковий бюджет Євросоюзу на 2028-2034 роки без згоди всіх держав-членів ЄС брати участь у фінансуванні України.
  - (2026-11-26) Угорщина приєднується до Міжнародної коаліції за повернення українських дітей | LEDE: ] (uk: Угорщина приєднується до Міжнародної коаліції за повернення українських дітей)
  - (2026-11-26) "Зливав" дані про позиції підрозділу фейковій війковослужбовиці Нацгвардії: боєць отримав підозру | LEDE: Правоохоронці повідомили про підозру військовослужбовцю, який передавав координати місц] (uk:…
      Правоохоронці повідомили про підозру військовослужбовцю, який передавав координати місць дислокації українських військових та відеозаписи з позицій.
  - (2026-11-26) У Польщі вдалося врятувати чоловіка, який підпалив себе у центрі Варшави | LEDE: Чоловік, ймовірно громадянин України, перебуває у реанімації. Посольство встановило контакт із матір'ю та допома] (uk:…
      Чоловік, ймовірно громадянин України, перебуває у реанімації. Посольство встановило контакт із матір'ю та допомагає родині.
  - (2026-11-26) У Литві не бачать потреби закривати кордон з РФ | LEDE: Наразі Литва не бачить підстав для закриття своїх пунктів пропуску на кордоні з Росією.] (uk: У Литві не бачать потреби закривати кордон з РФ)
      Наразі Литва не бачить підстав для закриття своїх пунктів пропуску на кордоні з Росією.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-26) [ASP Isotopes Inc.] Form 4 (Issuer)
      filed 2026-11-26 02:47 UTC · role: Issuer — Filed: 2026-11-25 AccNo: 0001477932-26-007320 Size: 6 KB
  - (2026-11-26) [Wider Todd] Form 4 (Reporting)
      filed 2026-11-26 02:47 UTC · role: Reporting — Filed: 2026-11-25 AccNo: 0001477932-26-007320 Size: 6 KB
  - (2026-11-26) [Reeves William Brian Poppic] Form 4 (Reporting)
      filed 2026-11-26 02:30 UTC · role: Reporting — Filed: 2026-11-25 AccNo: 0001193125-26-478901 Size: 5 KB
  - (2026-11-26) [Fold Holdings, Inc.] Form 4 (Issuer)
      filed 2026-11-26 02:30 UTC · role: Issuer — Filed: 2026-11-25 AccNo: 0001193125-26-478901 Size: 5 KB
  - (2026-11-26) [GRI Bio, Inc.] Form 4 (Issuer)
      filed 2026-11-26 02:27 UTC · role: Issuer — Filed: 2026-11-25 AccNo: 0001822557-26-000007 Size: 5 KB
  - (2026-11-26) [SIMPSON CAMILLA V] Form 4 (Reporting)
      filed 2026-11-26 02:27 UTC · role: Reporting — Filed: 2026-11-25 AccNo: 0001822557-26-000007 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-26) [United Kingdom] Duran Duran star Andy Taylor dies aged 65 after illness as Birmingham band pays tribute to icon
      domain: birminghammail.co.uk · language: English · tone: 3.40479192938209 · 164 other outlets ran this story
  - (2026-11-26) Michael Hampton, Parliament-Funkadelic Guitarist Known as Kidd Funkadelic, Dies at 70
      domain: 1077thebounce.com · language: English · tone: 0.31055900621118 · 82 other outlets ran this story
  - (2026-11-26) [United States] Angelina Jolie and Brad Pitt settle French winery legal battle
      domain: andoveradvertiser.co.uk · language: English · tone: -1.71052631578947 · 76 other outlets ran this story
  - (2026-11-26) [Egypt] 31 Killed, 21 Injured After Fuel Tanker Crash Sparks Fire In Cairo
      domain: oneindia.com · language: English · tone: -8.68544600938967 · 62 other outlets ran this story
  - (2026-11-26) [United Kingdom] Political figures expected to attend Ann Widdecombe memorial service
      domain: midweekherald.co.uk · language: English · tone: -4.06091370558376 · 57 other outlets ran this story
  - (2026-11-26) [United Kingdom] Fred Sirieix: Why I've opened a restaurant in a women's prison
      domain: cambstimes.co.uk · language: English · tone: 0.967741935483871 · 57 other outlets ran this story

### IT, InfoSys & cybersecurity news (last 7 days) — 37 new of 56 total
  - (2026-11-26) [The Hacker News] Drupal Warns of New Highly Critical Site Takeover Vulnerability Under Active Exploitation
      Drupal has warned of a new "highly critical" security flaw impacting Drupal core that it said has been exploited in the wild. The vulnerability, tracked as CVE-2026-136716 (CVSS score: N/A), has been described as a case…
  - (2026-11-26) [The Hacker News] Hackers Exploit 10 Vulnerabilities Across Mitel, Juniper, Vates, and Danfoss Products
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Wednesday added 10 security flaws to its Known Exploited Vulnerabilities (KEV) catalog, including five vulnerabilities impacting Mitel MiCollab that wer…
  - (2026-11-26) [The Hacker News] 1Password Hacked, Customer Data and Source Code Stolen in GitHub Account Breach
      Popular password management software 1Password on Wednesday disclosed a security incident involving its backend systems that led to the unauthorized access of some customer information, but emphasized that customer passw…
  - (2026-11-26) [The Hacker News] 13 Malicious NuGet Packages Turn Fake .NET Job Assessments Into Malware Delivery Traps
      Cybersecurity researchers have discovered 13 malicious NuGet packages that are designed to target Windows .NET developers under the guise of a fake take-home job assessment. "Most of the packages pose as WinUI 3 and WPF…
  - (2026-11-25) [BleepingComputer] Palo Alto Networks warns of Fragnesia flaw exploited in PAN-OS attacks
      Threat actors are chaining exploits for the PHP2Shell and Fragnesia vulnerabilities to target Palo Alto Networks devices with management interfaces exposed to the internet. [...]
  - (2026-11-25) [BleepingComputer] 1Password customer data stolen after employee GitHub account breach
      1Password has disclosed a data breach after a an employee's corporate GitHub account was hacked and used to deploy malicious code to the company's backend services to steal customer data. [...]

### Wikidata leader-roster changes (48h) — 36 new of 62 total
  - (2026-11-26) [Chad] Mahamat Déby (Q16206405) edited
      /* wbsetclaim-create:1||1 */ [[Property:P569]]: 1 January 1984, Add date of birth 1984-01-01 from Store norske leksikon, beside the other value (sources disagree); the item says 1984-04-04. Case checked in [[User:OKA bot…
  - (2026-11-26) [Dominican Republic] Luis Abinader (Q16594097) edited
      /* undo:0||2574953434|~2026-61590-15 */ Deshecho vandalismo.
  - (2026-11-26) [Lithuania] Gitanas Nausėda (Q9268379) edited
      /* wbsetclaim-create:1||1 */ [[Property:P569]]: 19 April 1964, Add date of birth 1964-04-19 from Store norske leksikon, beside the other value (sources disagree); the item says 1964-05-19. Case checked in [[User:OKA bot/…
  - (2026-11-26) [Nicaragua] Daniel Ortega (Q57402) edited
      /* wbsetclaim-update-references:1||1|1 */ [[Property:P569]]: 11 November 1945, source for date of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])
  - (2026-11-26) [Rwanda] Paul Kagame (Q1231345) edited
      /* wbsetclaim-create:1||1 */ [[Property:P19]]: [[Q668180]], Add place of birth Muhanga (Q668180) from Store norske leksikon, beside the other value (sources disagree); the item says Ruhango (Q12884189). Case checked in […
  - (2026-11-26) [Oman] Haitham bin Tarik Al Said (Q12250314) edited
      /* wbsetclaim-create:1||1 */ [[Property:P569]]: 13 October 1954, Add date of birth 1954-10-13 from Store norske leksikon, beside the other value (sources disagree); the item says 1955-10-11. Case checked in [[User:OKA bo…

### GDACS — global disaster alerts — 35 new of 100 total
  - (2026-11-26) [Green] Earthquake in México
      Earthquake · Green alert · México · Magnitude 4.6M, Depth:10km
  - (2026-11-26) [Green] Earthquake in Off E. Coast Of N. Island, N.Z.
      Earthquake · Green alert · Off E. Coast Of N. Island, N.Z. · Magnitude 5M, Depth:10km
  - (2026-11-26) [Green] Earthquake in Off E. Coast Of N. Island, N.Z.
      Earthquake · Green alert · Off E. Coast Of N. Island, N.Z. · Magnitude 5.2M, Depth:12.687km
  - (2026-11-24) [Green] Forest fires in Benin, Burkina Faso
      Wildfire · Green alert · Benin, Burkina Faso · Green impact for forestfire in 5579 ha
  - (2026-11-21) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 5831 ha
  - (2026-11-21) [Green] Forest fires in South Africa
      Wildfire · Green alert · South Africa · Green impact for forestfire in 5088 ha

### Court opinions of consequence (federal & state) — 34 new of 60 total
  - (2026-11-25) U.S. Court of Appeals, 5th Cir.: Gonzalez v. Federal Bureau of Prisons
  - (2026-11-25) U.S. Court of Appeals, 5th Cir.: Medco Energi v. Cantor
  - (2026-11-25) U.S. Court of Appeals, 5th Cir.: United States v. Woolridge
  - (2026-11-25) U.S. Court of Appeals, 9th Cir.: United States v. Tran
  - (2026-11-25) U.S. Court of Appeals, 9th Cir.: Mona Murillo v. J. Castillo
  - (2026-11-25) U.S. Court of Appeals, 9th Cir.: Yount v. Whole Foods Market Pacific Northwest, LLC

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 23 new of 23 total
  - (2026-11-27) Expeditious Enforcement of Capital Sentences and the Pursuit of Justice for Victims of Heinous Crimes
  - (2026-11-27) Heightened Import Disclosures for Supply Chain Visibility; Extension of Comment Period
      This document announces that U.S. Customs and Border Protection (CBP) will extend the comment period for an additional 45 days for interested parties to submit comments on the advance notice of proposed rulemaking (ANPRM…
  - (2026-11-27) Special Local Regulation; Savannah River, Savannah, GA
      The Coast Guard is establishing a temporary special local regulation (SLR) for the navigable waters of the Savannah River from the Talmadge Bridge to Eastern Wharf. This action is necessary to provide for the safety of l…
  - (2026-11-27) Agricultural Foreign Investment Disclosure Act of 1978
      On June 25, 2026, the United States Department of Agriculture (the Agency) published a proposed rule to update its regulations regarding the Agricultural Foreign Investment Disclosure Act of 1978 (AFIDA) (91 FR 38315) an…
  - (2026-11-27) Implementation of HAVANA Act of 2021; Correction
      The Department of Justice is correcting a final rule that published in the Federal Register of October 27, 2026, implementing parts of the HAVANA Act of 2021. Due to an editorial error, two instructions were inadvertentl…
  - (2026-11-27) Federal Motor Vehicle Safety Standards: Automatic Emergency Braking Systems for Light Vehicles
      NHTSA proposes to modify Federal Motor Vehicle Safety Standard No. 127; Automatic emergency braking systems for light vehicles. NHTSA proposes to delay the compliance date by two years so that manufacturers have more tim…

### Paper Trading Scorecard — 17 new of 75 total
  - (2026-11-26) [Manifold] Will AI's mathematical abilities be important to AI capabilities growth before 2030?
  - (2026-11-26) [Manifold] Will Bill Gates go to prison before 2030?
  - (2026-11-26) [Manifold] Daily Coinflip
  - (2026-11-26) [Manifold] Will the prime factors of RSA-2048 be known before July 2027?
  - (2026-11-26) [Manifold] Will an unofficial PC port run GTA VI at 60 fps by December 31, 2026?
  - (2026-11-26) [Manifold] Will P=NP get cracked before me?

### Government & military aircraft airborne (OpenSky) — 16 new of 17 total
  - (2026-11-26) SAMU974 (France)
      icao24: 3a1e46 · position: (-20.9282, 55.3936) · alt: 883m · 242km/h
  - (2026-11-26) GAF433 (Germany)
      icao24: 3ea048 · position: (51.7162, 9.6095) · alt: 6545m · 649km/h
  - (2026-11-26) JAF4GM (Belgium)
      icao24: 44d1a6 · position: (39.0794, 23.0087) · alt: 11887m · 821km/h
  - (2026-11-26) JAF7YC (Belgium)
      icao24: 44d1a7 · position: (38.2254, -9.5668) · alt: 10668m · 1004km/h
  - (2026-11-26) JAF2JT (Belgium)
      icao24: 44d1b4 · position: (37.1048, -4.3341) · alt: 4465m · 642km/h
  - (2026-11-26) JAF9JH (Belgium)
      icao24: 44d1c2 · position: (42.2789, 1.3431) · alt: 11582m · 762km/h

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-24) [F3X] FOR LOVE OF COUNTRY, INC.
      cycle 2026 · filing #2049346 · receipts $0.00M
  - (2026-11-24) [F3] DELAWARE VICTORY 2026
      cycle 2026 · filing #2049418
  - (2026-11-24) [F6] THE COMMITTEE TO ELECT JUSTIN MURPHY 2024
      cycle 2026 · filing #2049293
  - (2026-11-24) [F1] NATIONAL STRIPPER WELL ASSOCIATION PAC (NSWA PAC)
      cycle 2026 · filing #2049537
  - (2026-11-24) [F3X] GUN OWNERS ACTION FUND
      cycle 2026 · filing #2049265
  - (2026-11-24) [F99] FAA MANAGERS ASSOCIATION INC. PAC
      cycle 2026 · filing #-1003949

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 87 total
  - (2026-11-26) [USASpending] $31,228,812,311 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-11-26) [USASpending] $17,752,289,340 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy. Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-11-26) [USASpending] $15,130,809,109 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE
      Agency: Department of Energy. Description: OPERATION AND MAINTENANCE LINEAR ACCELLERATOR
  - (2026-11-26) [USASpending] $11,316,434,233 → ALLIANCE FOR ENERGY INNOVATION, LLC: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWAB
      Agency: Department of Energy. Description: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWABLE ENERGY LABORATORY
  - (2026-11-26) [USASpending] $3,875,509,200 → PANTEXAS DETERRENCE, LLC: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION
      Agency: Department of Energy. Description: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION OF THE PANTEX PLANT
  - (2026-11-26) [USASpending] $3,460,139,987 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…

### Chinese Internal News — 13 new of 41 total
  - (2026-11-26) Carmakers look to strengthen China’s electric mobility lead at Guangzhou auto show
  - (2026-11-26) China pushes brain-computer interface breakthroughs as Neuralink advances towards market
  - (2026-11-26) Chinese AI trade turns cautious after Wall Street volatility, Anthropic’s rocky debut
  - (2026-11-26) Falling knife or bottom-fishing? Gold investors seek answers from Fed and PBOC
  - (2026-11-26) Alibaba sells US$482 million in ZTO Express shares as AI focus sharpens
  - (2026-11-26) HSBC sees more than 100,000 users of its stablecoin in first month since launch

### CISA Known Exploited Vulnerabilities (last 14d) — 10 new of 26 total
  - (2026-11-25) CVE-2026-103406 · Hewlett Packard Enterprise (HPE) Juniper Session Smart Conductor and Session Smart Router: Hewlett Packard Enterprise (HPE) Juniper Session Smart Conductor and Session Smart Router O…
      vendor: Hewlett Packard Enterprise (HPE) · product: Juniper Session Smart Conductor and Session Smart Router · CISA remediation by 2026-11-28
  - (2026-11-25) CVE-2026-133469 · Vates Xen Orchestra: Vates Xen Orchestra Improper Validation of Specified Type of Input Vulnerability
      vendor: Vates · product: Xen Orchestra · CISA remediation by 2026-11-28
  - (2026-11-25) CVE-2025-41450 · Danfoss AK-SM 800A Series: Danfoss AK-SM 800A Series Improper Authentication Vulnerability
      vendor: Danfoss · product: AK-SM 800A Series · CISA remediation by 2026-12-09
  - (2026-11-25) CVE-2023-25914 · Danfoss AK-SM 800A Series: Danfoss AK-SM 800A Series Path Traversal Vulnerability
      vendor: Danfoss · product: AK-SM 800A Series · CISA remediation by 2026-11-28
  - (2026-11-25) CVE-2023-25915 · Danfoss AK-SM 800A Series: Danfoss AK-SM 800A Series Improper Input Validation Vulnerability
      vendor: Danfoss · product: AK-SM 800A Series · CISA remediation by 2026-11-28
  - (2026-11-25) CVE-2026-133324 · Mitel MiCollab: Mitel MiCollab Not Failing Securely Vulnerability
      vendor: Mitel · product: MiCollab · CISA remediation by 2026-11-28

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-11-26) Counter-Strike: Lynn Vision vs PVISION (BO3) - PGL Major Singapore Stage 1
      yes price: 20% · 24h volume: $1,103,902 · resolves 2026-11-26
  - (2026-11-26) Counter-Strike: Heroic vs FaZe (BO3) - PGL Major Singapore Stage 1
      yes price: 100% · 24h volume: $1,091,457 · resolves 2026-11-26
  - (2026-11-26) Map Handicap: PV (-1.5) vs Lynn Vision (+1.5)
      yes price: 60% · 24h volume: $496,209 · resolves 2026-11-26
  - (2026-11-26) Will the US confirm that aliens exist before 2027?
      yes price: 2% · 24h volume: $492,881 · resolves 2027-01-01
  - (2026-11-26) Will Chiang Wan-an win the next Taipei Mayor election?
      yes price: 58% · 24h volume: $426,587 · resolves 2026-11-29
  - (2026-11-26) Will Puma Shen win the next Taipei Mayor election?
      yes price: 41% · 24h volume: $339,116 · resolves 2026-11-29

### Commentary & analysis (last 7 days) — 7 new of 11 total
  - (2026-11-26) [Marginal Revolution] My excellent Conversation with Moxie Marlinspike of Signal
      Here is the audio, video, and transcript. From the episode summary: Tyler and Moxie discuss whether AI could break cryptography, Marlinspike’s own private AI chat service, his case for surveilling AI models instead of th…
  - (2026-11-25) [Adam Tooze] Chartbook 485 Recursively accelerating accumulation: Speedball capitalism speeds up.
      On 12 November pioneering chip-CEO Jensen Huang was forced out of Nvidia in a swirl of allegations about inappropriate relationships and feverish speculation about a Chinese honey-trap.
  - (2026-11-25) [Adam Tooze] Top Links 1296 WSJ on Trump’s state capitalism. China’s household assets. Global heatwave and long-range drone strike.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-11-25) [Noah Smith] How to make Thanksgiving even better
      A few ideas.
  - (2026-11-25) [Marginal Revolution] AI in research
      We found that recent frontier models are now consistently proposing research designs that human and LLM graders alike judge more compelling than what the very top expert in the field has been developing. Yet these outsta…
  - (2026-11-25) [Marginal Revolution] Wednesday assorted links
      1. Macrohistory in six facts. 2. Patrick Collison on Tocqueville. 3. The minimum wage: current vs. lifetime perspectives. By Francisco Libano-Monteiro, on the economics job market from LSE. 4. Kurt Rosenwinkel, Ruby My D…

### USGS earthquakes (M4.5+, past day) — 6 new of 6 total
  - (2026-11-26) M 5.2 - 183 km N of Hicks Bay, New Zealand
      M5.2 · 183 km N of Hicks Bay, New Zealand · depth 12.687 km
  - (2026-11-26) M 5.0 - 184 km N of Hicks Bay, New Zealand
      M5.0 · 184 km N of Hicks Bay, New Zealand · depth 10 km
  - (2026-11-25) M 5.0 - 67 km NNE of Luwuk, Indonesia
      M5.0 · 67 km NNE of Luwuk, Indonesia · depth 106.384 km
  - (2026-11-25) M 4.8 - 190 km N of Hicks Bay, New Zealand
      M4.8 · 190 km N of Hicks Bay, New Zealand · depth 10 km
  - (2026-11-25) M 4.7 - 13 km NW of Port-Vila, Vanuatu
      M4.7 · 13 km NW of Port-Vila, Vanuatu · depth 51.54 km
  - (2026-11-26) M 4.6 - 97 km SW of Puerto Madero, Mexico
      M4.6 · 97 km SW of Puerto Madero, Mexico · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-11-26) MOVER ▼ Larry Page — $227.28B ($-4.51B since yesterday)
      United States · Technology · source: Google
  - (2026-11-26) MOVER ▼ Sergey Brin — $209.27B ($-4.14B since yesterday)
      United States · Technology · source: Google
  - (2026-11-26) MOVER ▼ Steve Ballmer — $153.61B ($-1.57B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-11-26) MOVER ▲ Carlos Slim Helu & family — $124.02B (+$0.97B since yesterday)
      Mexico · Telecom · source: Telecom

### Ukraine Theater (total-war monitoring) — 1 new of 5 total
  - (2026-11-26) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=23, 7d-median=17, 14d-median=20; carrying terms: airworthiness, published, applicable, airplanes, final, management, rulemaking, directives, certain, action, public, national
- state_bills: today=0, 7d-median=68, 14d-median=73; carrying terms: relating, health, state, providing, medical, alaska, school, emergency, local, board, including, public
- state_news: today=671, 7d-median=651, 14d-median=671; carrying terms: spending, executive, across, government, legislative, workers, elected, being, virginia, according, house, planned
- local_news: today=181, 7d-median=212, 14d-median=250; carrying terms: across, court, being, according, stlmag, house, round, season, journal, still, community, local
- foreign_news: today=1063, 7d-median=1024, 14d-median=1012; carrying terms: senior, hours, spending, across, concerns, swissinfo, sipri, russian, begin, workers, being, airlines
- chinese_internal: today=41, 7d-median=271, 14d-median=293; carrying terms: chinese, global, china, market, google, caixin, https, nvidia, investors, firms, sales, huang
- russian_internal: today=927, 7d-median=943, 14d-median=943; carrying terms: spacex, bloomberg, russian, politico, claude, media, axios, reuters, telegram, times, istories, press
- ukrainian_internal: today=136, 7d-median=129, 14d-median=129; carrying terms: across, chinese, russian, offensive, hromadske, european, according, leaders, donald, aircraft, residential, country
- ukraine_theater: today=5, 7d-median=273, 14d-median=271; carrying terms: credentials, google, acled, gmail, known, snapshot, token, accepted, email, cartography, incorrect, alerts
- paper_bets: today=75, 7d-median=75, 14d-median=77; carrying terms: judgment, manifold, criminal, derrick, justice, fusion, nominal, mbappe, recognized, general, decrease, jackson
- weather: today=142, 7d-median=136, 14d-median=127; carrying terms: norton, today, across, following, visibility, continues, afdmfl, north, weather, front, northwest, deeper
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dcoilwtico, dexuseu, crude, openings, money, assets, sheet, dexchus, cpiaucsl, headline, unemployment, personal
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, equities, russell, treasury, corporate, bitcoin, close, natural, large, agriculture, credit, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=87, 7d-median=102, 14d-median=100; carrying terms: groups, burundi, cyber, herzegovina, military, prohibiting, government, democratic, restrictive, weapons, protests, relation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quiver, httperror, quiverquant, congresstrading, https, quantitative, error, client
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: berkshire, ellison, jensen, charles, google, googl, italy, walton, technologies, julia, arnault, yanai
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, court, state, blanche, company, charles, miller, commerce, america, smith, stewart, county
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, holdings, william, brian, joseph, poppic, reeves, david, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, ocasio, filing, sayed, david, brown, cooper, cortez, jonathan, krishnamoorthi, abdul, jackson
- gdelt_regions: today=101, 7d-median=103, 14d-median=103; carrying terms: japan, english, turkish, indiatimes, israel, ukraine, strikes, german, arabia, nigeria, russia, colombia
- gdelt_gkg: today=139, 7d-median=134, 14d-median=132; carrying terms: israel, english, keywords, sanctions, trump, netanyahu, attack, hezbollah, north, russian, indiatimes, tinubu
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: trump, crash, domain, outlets, police, injured, language, english, killed, story, shooting, australia
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=17, 7d-median=17, 14d-median=17; carrying terms: position, belgium, france, germany, kingdom, canada, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: infections, ethiopia, ventilation, eight, etiology, within, probable, across, inconclusive, democratic, following, august
- cisa_kev: today=26, 7d-median=21, 14d-median=17; carrying terms: improper, remediation, critical, vendor, incorrect, bypass, vulnerability, cisco, channel, injection, product, alternate
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=62, 7d-median=59, 14d-median=54; carrying terms: toollabs, quickstatements, wbeditentity, update, wbsetsitelink, property, edited, wbsetdescription, republic, batch, wbsetclaim, remove
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: indonesia, depth, republic, alert, islands, flood, green, sudan, fires, earthquake, australia, india
- usgs_quakes: today=6, 7d-median=12, 14d-median=12; carrying terms: depth, indonesia, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, november, volume, december, league, change, increase, meeting, championship, champions, donetsk
- commentary: today=11, 7d-median=4, 14d-median=6; carrying terms: revolution, marginal, https, marginalrevolution, links, conversable, economist, human, years, assorted, research, global
- tech_news: today=56, 7d-median=63, 14d-median=63; carrying terms: cyber, today, added, following, edition, versions, computerweekly, attacks, blogging, bleepingcomputer, according, known
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: huffman, senior, norton, pappas, panetta, wesley, eugene, adviser, katie, bernard, haridopolos, vance
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, converges, claude, today, decision, markets, module, identify, paper, unavailable, placement, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-18] ECB press: Boris Vujčić: Financial Stability Review - November 2026
- [2026-11-18] ECB press: Risks from AI valuations, fiscal imbalances and geoeconomic tensions weigh on financial stability outlook
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks
- [2026-11-19] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of First Security Bancorp
- [2026-11-20] ECB press: Christine Lagarde: Acting in time
- [2026-11-20] Fed speeches: Waller, Opening Remarks
- [2026-11-20] Fed press (events + announcements): Federal Reserve Board releases results from survey of senior financial officers at banks about their strategies and practices for managing reserve balances
- [2026-11-20] Fed speeches: Cook, The U.S. Economy in Global Context
- [2026-11-20] Fed press (events + announcements): Federal Reserve announces College Fed Challenge winners
- [2026-11-23] ECB press: ECB expands acceptance of DLT-based assets as eligible Eurosystem collateral
- [2026-11-23] ECB press: Philip R. Lane: Climate change and monetary policy
- [2026-11-24] ECB press: Boris Vujčić: Resilience in an age of shocks: lessons from central and eastern Europe

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*