# WORLDSCOPE morning brief — 2026-10-02

## Headline
3402 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (804) · Russian Internal News (state + in-exile) (730) · State-Level News (392) · World leaders & government officials (324) · Chinese Internal News (216) · Local News: St. Louis + Atlanta (206) · U.S. Weather + Severe / Climate Outlooks (154) · Ukraine Theater (total-war monitoring) (145) · State Legislative Action (84) · Ukrainian Internal News (national + local Kyiv) (66) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 804 new of 1018 total
  - (2026-10-02) [Global] 'I was not going to let others die' - pilot of Flydubai flight describes cockpit attack by co-pilot
      Capt Smit Machchhar tells Indian Prime Minister Narendra Modi he opened the cockpit door to let others in during the attack.
  - (2026-10-02) [Global] School protests send shivers down French government's spine
      A movement that started nearly two weeks ago has spread, and in France young people on the streets spells trouble, writes Hugh Schofield.
  - (2026-10-02) [Global] Christa Pike in critical condition after surviving two lethal injections, lawyer says
      Pike’s lawyers have asked for her death sentence to be commuted following the botched execution.
  - (2026-10-02) [Global] 'Ashamed': Cornell students gather to voice anger over alleged gang rape
      Students tell the BBC that the tension on campus has become palpable since allegations from 2024 resurfaced.
  - (2026-10-02) [Global] Seoul warns 'further action' if Ukraine does not apologise over prisoner-of-war row
      President Lee Jae Myung also accused Kyiv of "attempting to provoke a war on the Korean Peninsula".
  - (2026-10-02) [Global] Japan's first mayor to take maternity leave lands on TIME100 Next list
      Shoko Kawata's maternity leave drew mixed reactions in Japan, a country struggling to lift birth rates.

### Russian Internal News (state + in-exile) — 730 new of 1181 total
  - (2026-10-02) Больницу в Иркутской области закрыли на карантин из-за «особо опасной инфекции». По данным СМИ, одна из пациенток умерла от легочной чумы | LEDE: В Шелехове Иркутской области закрыли стацион] (ru: Бол…
      В Шелехове Иркутской области закрыли стационарное отделение районной больницы из-за подозрений на «особо опасную инфекцию», которую могли диагностировать у одного из пациентов.
  - (2026-10-02) Трамп советовался с нейросетью Grok о том, как венесуэльцы отнесутся к свержению Мадуро | LEDE: В декабре 2025 года техномиллиардер Илон Маск провел непубличную встречу с президентом США Дон] (ru: Тра…
      В декабре 2025 года техномиллиардер Илон Маск провел непубличную встречу с президентом США Дональдом Трампом в Белом доме. Во время этой встречи Трамп несколько часов задавал Grok — нейросети Маска — вопросы о своем през…
  - (2026-10-02) Война. 1682-й день. Россия готовится уничтожить электроэнергетику Украины. Такой план Минобороны РФ оказался в распоряжении Киева | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире расск] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-02) «Я сказал себе: дверь совсем рядом, просто открой ее». Капитан рейса Flydubai пришел в себя. Вот что он рассказал о нападении второго пилота | LEDE: Рейс FZ1073 авиакомпании Flydubai из Дуба] (ru: «Я…
      Рейс FZ1073 авиакомпании Flydubai из Дубая в Тель-Авив едва не закончился катастрофой: второй пилот напал с ножом на капитана; по предварительным данным, он собирался разбить самолет. На борту находились 174 пассажира, б…
  - (2026-10-02) Зеленский заявил, что Путин приказал военным отказаться от правил ведения войны при обстрелах Украины | LEDE: Владимир Путин приказал военным начальникам отказаться от правил ведения войны п] (ru: Зел…
      Владимир Путин приказал военным начальникам отказаться от правил ведения войны при воздушных ударах по Украине. Об этом в интервью Financial Times заявил президент Украины Владимир Зеленский. Он утверждает, что такую инф…
  - (2026-10-02) Следственный комитет возбудил дело из-за изъятия в США миллионов «православного олигарха» Малофеева | LEDE: Следственный комитет России отчитался, что возбудил уголовное дело о «присвоении» ] (ru: Сле…
      Следственный комитет России отчитался, что возбудил уголовное дело о «присвоении» властями США денег российского бизнесмена, основателя канала «Царьград» Константина Малофеева. Заявление с требованием начать расследовани…

### State-Level News — 392 new of 804 total
  - (2026-10-01) [Alabama] Executive Order 746
      Link
  - (2026-10-01) [Alabama] Governor Ivey Announces Additional Alabama Rural Health Transformation Program Grants Totaling Nearly $55 Million
      MONTGOMERY – Governor Kay Ivey on Thursday announced the awarding of 34 grants totaling nearly $55 million to healthcare providers and institutions throughout the state as part of the second round of Alabama Rural Health…
  - (2026-10-01) [Alabama] Governor Ivey Makes the Case for Alabama to Train America’s Next Generation of Space Leaders, Launches Bid for U.S. Space Academy
      MONTGOMERY – Governor Kay Ivey on Thursday announced Alabama is entering the competition to become the home of the proposed United States Space Academy, putting forward Huntsville as the state’s preferred location to edu…
  - (2026-10-02) [Alaska] Alaska Manufacturing Day 2026
      WHEREAS, craftsmanship and ingenuity are embedded in the legacy of Alaska and have helped shape our State into what it is today; and WHEREAS, Alaska’s staggering size, natural beauty, vast resources, and strategic locati…
  - (2026-10-01) [California] CARE Court implementation and progress are accelerating, reaching more than 10,000 Californians in crisis
      Source
  - (2026-10-02) [California] ‘High-ranking’ officer illegally snooped on officials with police network
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/052325_LA-Traffic_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 216 new of 265 total
  - (2026-10-02) 兼容并蓄的造像风格｜千年麦积山石窟③ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE10XzlSSU5zR2hJUFNHY3hleVdUOHpYSWVYdXoxU2oteERwTkpVVjVMVFMtSUl0QXdJVXdBdHZ1ODd3WHZJbXM2MlVYSWIwZlpnMW1] (zh:…
      兼容并蓄的造像风格｜千年麦积山石窟③ 财新
  - (2026-10-02) 李白的诗与大唐的GDP｜经济哲思 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1BZFNjLXdta0JWb2doNEVFanIzVkdHQ1d1ODFWV1hqNlgyMFhaaWpXTjZIOHc1QWxkaUx0VnpZSE9Nd3NPM1JOdWpuTmp4eE1iTklKV] (zh:…
      李白的诗与大唐的GDP｜经济哲思 财新
  - (2026-10-02) 朱学东：八月廿四的咸汤团子｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Idmllb0phLUdsb3Nuc1hCdmJOYnREeHJNSHV1SlRaWFk3WUlwNXgxOTNzRk1CNXBsNUx3Njh0OFlIUUg0UHc3c3kxekZPTHNSTkRxe] (zh:…
      朱学东：八月廿四的咸汤团子｜饮食 财新
  - (2026-10-02) 9月财新中国新经济指数降至34.1 主要受科技投入下降影响 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBXOVBSWS1sNU5QTEVvbDU4UjEyTWNHdGRfRzV4aFdtN0kteTQ0ZnYzbjY3SFNMaE4yc05DclRydFVoLVdmVzFreE1U] (zh:…
      9月财新中国新经济指数降至34.1 主要受科技投入下降影响 财新
  - (2026-10-02) 分析｜78年历史大检察厅落幕：韩国检察权改革走向何处？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE00cWZDdWNtdUFFS2RXZkQ3QzZrU29VZ1VmTFhKb05PVDBDTkxEcngwMkQ3WU02emFkSDlCX1BMWVlVR1RRRGtKTkQtQU] (zh:…
      分析｜78年历史大检察厅落幕：韩国检察权改革走向何处？ 财新
  - (2026-10-01) 广西涠洲岛海域设立禁渔区 保护布氏鲸 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5kWXBMTnZsNVlISUE4VVpZZFJCWlRydE5UY0x4SjQ0ek53VHFSRENwY1luQXlocE5KNWVQSF9XM0ptRC1BTTJPT1dMaGcxNG5OSEh] (zh:…
      广西涠洲岛海域设立禁渔区 保护布氏鲸 财新

### Local News: St. Louis + Atlanta — 206 new of 243 total
  - (2026-10-02) [St. Louis] Ask George: How many wine clubs are there in St. Louis?
      Ask George: How many wine clubs are there in St. Louis? — Hannah W., Gray Summit, Mo Wine clubs in St. Louis typically offer either curated bottle subscriptions, often featuring two shop-selected wines each month, or dis…
  - (2026-10-02) [St. Louis] Concerns about Flock continue in Missouri, despite governor’s order
      This story was commissioned by the River City Journalism Fund. Flock Safety’s automatic license plate readers have been hailed as a game changer for law enforcement. But privacy concerns are so pervasive on both sides of…
  - (2026-10-02) [St. Louis] Aldermen will consider censure of Tyus—but the impact isn’t clear
      No one is banking on Alderwoman Sharon Tyus apologizing for saying that she wanted to shoot fellow alder Rasheen Aldridge. But that doesn’t mean that her colleagues aren’t going to try to make her. Later today, the full…
  - (2026-10-02) [St. Louis] What’s True in the Lou? – 10/2/26
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-10-01) [St. Louis] St. Louis beer blends to try at home
      Six years ago, I wrote a story about mixing beer. Not beer cocktails or beer with lemonade or soda. Two perfectly good beers, pouring them into the same glass and seeing whether they could become something that neither b…
  - (2026-10-01) [St. Louis] St. Louis’ Music & Me brings social-emotional learning songs to Nine PBS
      St. Louis kids have been singing about their “big feelings” with Laren Loveless for years. Soon, families who have never stepped foot in a Music & Me class will be able to sing along, too. Laren and Aimee Loveless, the h…

### U.S. Weather + Severe / Climate Outlooks — 154 new of 156 total
  - (2026-10-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-02) [Severe] Flood Warning: Flood Warning issued October 2 at 8:23AM CDT until October 3 at 10:00PM CDT by NWS Lincoln IL
      ...The National Weather Service in Lincoln has issued a Flood Warning for the following rivers in Illinois... Spoon River at London Mills affecting Knox and Fulton Counties. .The following forecasts are based on observed…
  - (2026-10-02) [Severe] Flood Warning: Flood Warning issued October 2 at 8:21AM CDT until October 2 at 8:51PM CDT by NWS Topeka KS
      ...The Flood Warning continues for the following rivers in Kansas... Salt Creek near Lyndon affecting Osage County. ...The Flood Warning is extended for the following rivers in Kansas... Marais Des Cygnes River above Rea…
  - (2026-10-02) [Severe] Flood Warning: Flood Warning issued October 2 at 8:21AM CDT until October 3 at 4:47AM CDT by NWS Topeka KS
      ...The Flood Warning continues for the following rivers in Kansas... Salt Creek near Lyndon affecting Osage County. ...The Flood Warning is extended for the following rivers in Kansas... Marais Des Cygnes River above Rea…
  - (2026-10-02) [Severe] Flood Warning: Flood Warning issued October 2 at 8:10AM CDT until October 3 at 2:12AM CDT by NWS Hastings NE
      ...The Flood Warning continues for the following rivers in Nebraska... Little Blue River Near Deweese affecting Nuckolls and Clay Counties. * WHAT...Minor flooding is occurring. * WHERE...Little Blue River near Deweese.…
  - (2026-10-02) [Severe] Flood Warning: Flood Warning issued October 2 at 8:09AM CDT until October 3 at 12:11AM CDT by NWS Topeka KS
      ...The Flood Warning continues for the following rivers in Kansas... Black Vermillion River near Frankfort affecting Marshall County. Big Blue River near Blue Rapids affecting Marshall County. Little Blue River near Barn…

### Ukraine Theater (total-war monitoring) — 145 new of 531 total
  - (2026-10-02) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-01) [Liveuamap] Another drone strike at the Pivdennyi bridge in Kyiv - liveuamap.com
      Another drone strike at the Pivdennyi bridge in Kyiv liveuamap.com
  - (2026-10-01) [Liveuamap] Yemeni government forces: We carried out 15 raids on Houthi sites and reinforcements in the province of Taiz - yemen.liveuamap.com
      Yemeni government forces: We carried out 15 raids on Houthi sites and reinforcements in the province of Taiz &
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - liveuamap.com
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com liveuamap.com
  - (2016-04-27) [Liveuamap] Israel-Palestine - israelpalestine.liveuamap.com
      Israel-Palestine israelpalestine.liveuamap.com
  - (2026-10-02) [Liveuamap] Interactive map of news today in Africa in English - africa.liveuamap.com - africa.liveuamap.com
      Interactive map of news today in Africa in English - africa.liveuamap.com africa.liveuamap.com

### State Legislative Action — 84 new of 105 total
  - (2026-10-02) [Alaska SB 180] An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regul…
      An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska; and prov…
  - (2026-10-02) [California SB 226] Infrastructure revitalization financing districts.
      Existing law authorizes a legislative body of a city to designate one or more proposed infrastructure revitalization financing districts, as specified, which are legally constituted governmental entities established for…
  - (2026-10-02) [California AB 1776] Cartwright Act: violations.
      Existing law, commonly known as the Cartwright Act, identifies certain acts as unlawful restraints of trade and unlawful trusts and prescribes provisions for its enforcement. Chapter 338 of the Statutes of 2025 provides…
  - (2026-10-02) [California AB 2761] Vehicles: crash data.
      Under existing law, the Department of the California Highway Patrol is responsible for enforcement of all laws regulating the operation of vehicles and use of the highways, as specified. Existing law gives the Commission…
  - (2026-10-02) [California SB 1379] County of Riverside: separation of county offices: in-custody reports.
      Existing law generally regulates the government of counties. Existing law authorizes the board of supervisors of a county to consolidate the duties of various county offices in various combinations, including combining t…
  - (2026-10-02) [California AB 672] Real property tax: welfare exemption: community land trusts.
      Existing property tax law, pursuant to constitutional authorization, provides for a "welfare exemption" for property used exclusively for religious, hospital, scientific, or charitable purposes and that is owned or opera…

### Ukrainian Internal News (national + local Kyiv) — 66 new of 139 total
  - (2026-10-02) Росіяни влучили КАБом у будинок в Харкові: одна людина загинула, серед постраждалих діти | LEDE: У п'ятницю вдень російські загарбники завдали удару по 2-х районах Харкова керованими авіаційним] (uk:…
      У п'ятницю вдень російські загарбники завдали удару по 2-х районах Харкова керованими авіаційними бомбами, внаслідок чого загинула людина, серед постраждалих є діти, під завалами можуть знаходитись ще люди.
  - (2026-10-02) Зеленський обіцяє у жовтні 400 перехоплювачів реактивних дронів, але їх ефективність різна | LEDE: Президент Володимир Зеленський каже, що одну з моделей швидкісних дронів-перехоплювачів для бо] (uk:…
      Президент Володимир Зеленський каже, що одну з моделей швидкісних дронів-перехоплювачів для боротьби з російськими реактивними безпілотниками Україна зможе виготовити в кількості близько 400 одиниць ще в жовтні, але є пи…
  - (2026-10-02) Японія запровадила нові санкції проти РФ: у списку 33 компанії, фізособи та судна "тіньового флоту" | LEDE: Уряд Японії додав до санкційного списку 33 російські компанії, 9 осіб і ще фірми з Ту] (uk:…
      Уряд Японії додав до санкційного списку 33 російські компанії, 9 осіб і ще фірми з Туреччини та ОАЕ через агресію РФ проти України.
  - (2026-10-02) Генерал, расист, політик. Як Роберто Ванначчі став зіркою в Італії та чим це загрожує Україні | LEDE: ] (uk: Генерал, расист, політик. Як Роберто Ванначчі став зіркою в Італії та чим це заг)
  - (2026-10-02) ЗМІ опублікували інформацію про росіянина, який міг організувати диверсію в аеропорту Лейпцига | LEDE: Російський байкер Олег Льовушкін, якого пов'язують із співробітником російської військової] (uk:…
      Російський байкер Олег Льовушкін, якого пов'язують із співробітником російської військової розвідки, міг організувати спробу диверсії в аеропорту Лейпциг-Галле в Німеччині.
  - (2026-10-02) Пентагон направляє морських піхотинців у країни Балтії для місії НАТО | LEDE: Спеціалізований підрозділ морських піхотинців, розгорнутий у Європі, передислокують до регіону Балтійського моря дл] (uk:…
      Спеціалізований підрозділ морських піхотинців, розгорнутий у Європі, передислокують до регіону Балтійського моря для підтримки операції Baltic Sentry з посиленої пильності під керівництвом НАТО.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-10-02) [Russia oil sanctions perimeter · keywords] Putin Warns Russia Could Use All Weapon if Kaliningrad Is Attacked , Admits Ukraine Strikes Cost 1 % of GDP
      ibtimes.com.au · English · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · keywords] Japan mulls new anti - Russian sanctions
      en.apa.az · English · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · keywords] UK Hits Eight Russian Ships in New Sanctions Package
      gcaptain.com · English · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · keywords] U . S . Targets Iran Rail and Shadow Banking Networks as Maritime Blockade Tightens
      gcaptain.com · English · tone NA
  - (2026-10-02) [Israel-Iran-Hezbollah axis · themes] Países musulmanes condenan enérgicamente el intento de ataque hutí contra la ciudad saudí de Medina
      diariosigloxxi.com · Spanish · tone NA
  - (2026-10-02) [Israel-Iran-Hezbollah axis · themes] Dont worry about diesel shortages , Government says , as US urges use of reserves
      dunfermlinepress.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-02) [Jellison William R] Form 4 (Reporting)
      filed 2026-10-02 13:25 UTC · role: Reporting — Filed: 2026-10-02 AccNo: 0001122976-26-000136 Size: 5 KB
  - (2026-10-02) [AVIENT CORP] Form 4 (Issuer)
      filed 2026-10-02 13:25 UTC · role: Issuer — Filed: 2026-10-02 AccNo: 0001122976-26-000136 Size: 5 KB
  - (2026-10-02) 497K - COLUMBIA FUNDS SERIES TRUST I (0000773757) (Filer)
      filed 2026-10-02 13:24 UTC — Filed: 2026-10-02 AccNo: 0001193125-26-411345 Size: 67 KB
  - (2026-10-02) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-10-02 13:24 UTC — Filed: 2026-10-02 AccNo: 0001918704-26-030108 Size: 806 KB
  - (2026-10-02) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-10-02 13:24 UTC — Filed: 2026-10-02 AccNo: 0001918704-26-030108 Size: 806 KB
  - (2026-10-02) [LIGOCKI KATHLEEN] Form 4 (Reporting)
      filed 2026-10-02 13:23 UTC · role: Reporting — Filed: 2026-10-02 AccNo: 0001193125-26-411341 Size: 7 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 40 new of 57 total
  - (2026-10-02) [BleepingComputer] Dell asks admins to patch max severity CSM flaws as soon as possible
      Dell has patched two maximum severity vulnerabilities in the Container Storage Modules (CSM) that connect Dell enterprise storage arrays to Kubernetes environments. [...]
  - (2026-10-02) [BleepingComputer] Microsoft’s X account hacked in crypto pump-and-dump scheme
      On Thursday, unknown attackers hijacked the official Microsoft account on X, which has over 13 million followers, in what appeared to be a pump-and-dump scheme promoting a crypto token. [...]
  - (2026-10-02) [The Hacker News] OpenAI Parts Ways With Three Safety Researchers Over Sensitive Information Mishandling
      OpenAI has parted ways with three members of its safety team after they leaked private information in violation of company policies, The Wall Street Journal reported. "We have parted ways with three individuals for viola…
  - (2026-10-02) [The Hacker News] Why CISOs Struggle to Answer the Board's Three Hardest Questions, and How to Fix the Report
      The quarterly board meeting is two weeks out. The security team is pulling exports from the identity provider, the cloud posture tool, the vulnerability scanner, the SIEM and the EDR console. Someone is building a spread…
  - (2026-10-02) [The Hacker News] Android 17 Advanced Protection Locks Accessibility Services to Verified Accessibility Tools
      Google has announced a new security measure that limits access to Android's accessibility services to verified applications classified as Accessibility Tools when Advanced Protection is enabled. With malicious Android ap…
  - (2026-10-02) [The Hacker News] Critical FortiMail Zero-Day Flaw Exploited in Attacks Allows Unauthenticated Arbitrary File Writes
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA), on Thursday, added a critical security flaw impacting Fortinet FortiMail to its Known Exploited Vulnerabilities (KEV) catalog, following reports of active…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-02) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (34.9094, -6.1846) · alt: 11269m · 837km/h
  - (2026-10-02) SAMU37 (France)
      icao24: 39ca87 · position: (49.2033, -0.3576) · alt: 45m · 86km/h
  - (2026-10-02) CFC2558 (Canada)
      icao24: c2b5c1 · position: (45.4757, -76.7227) · alt: 6705m · 469km/h
  - (2026-10-02) KAF3208 (Kuwait)
      icao24: 7061f6 · position: (48.1668, 17.2018) · on ground · 16km/h
  - (2026-10-02) GAF701 (Germany)
      icao24: 3f59f3 · position: (51.2841, 3.9203) · alt: 11582m · 764km/h
  - (2026-10-02) JAF12M (Belgium)
      icao24: 44d1a2 · position: (49.7864, 2.2934) · alt: 9166m · 826km/h

### U.S. Federal Action — 19 new of 21 total
  - (2026-10-02) Continuation of the National Emergency With Respect to the Situation in and in Relation to Syria
  - (2026-10-02) Inaugurating the Era of Super Intelligence
  - (2026-10-02) Eliminating Disease-Carrying Pests and Restoring Enjoyment of the Great Outdoors
  - (2026-10-02) Streamlining Access to Government Services Through America.gov
  - (2026-10-02) Presidential Determination on Refugee Admissions for Fiscal Year 2027
  - (2026-10-02) Global Benchmark for Efficient Drug Pricing (GLOBE) Model
      This final rule implements the Global Benchmark for Efficient Drug Pricing Model (GLOBE Model), a new mandatory Medicare payment model under section 1115A of the Social Security Act. The GLOBE Model will test whether a p…

### Paper Trading Scorecard — 14 new of 122 total
  - (2026-10-02) [Manifold] Democrats win 2026 Alaska and Wisconsin Governor election?
  - (2026-10-02) [Manifold] GPT-6.1+ Astra released in October?
  - (2026-10-02) [Manifold] Will OBI (Brazilian Olympiad in Informatics) change its date?
  - (2026-10-02) [Manifold] Will Gemini 4 Argon be released publicly before October 15
  - (2026-10-02) [Manifold] Will Democrats win 52 seats or more in the 2026 Senate Elections? (Fetterman Proof Majority)
  - (2026-10-02) [Manifold] Parshasb Crack her tonight

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-10-02) M 5.1 - 159 km SE of Gizo, Solomon Islands
      M5.1 · 159 km SE of Gizo, Solomon Islands · depth 10 km
  - (2026-10-01) M 5.1 - 176 km SE of Lata, Solomon Islands
      M5.1 · 176 km SE of Lata, Solomon Islands · depth 10 km
  - (2026-10-01) M 5.1 - 171 km SE of Lata, Solomon Islands
      M5.1 · 171 km SE of Lata, Solomon Islands · depth 10 km
  - (2026-10-01) M 5.1 - 108 km ENE of Miyako, Japan
      M5.1 · 108 km ENE of Miyako, Japan · depth 35 km
  - (2026-10-02) M 5.0 - 63 km SW of Panguna, Papua New Guinea
      M5.0 · 63 km SW of Panguna, Papua New Guinea · depth 38.25 km
  - (2026-10-02) M 5.0 - south of the Fiji Islands
      M5.0 · south of the Fiji Islands · depth 557.245 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-10-02) LoL: Solary vs T1 Academy (BO5) - World Star Challengers Invitational Playoffs
      yes price: 0% · 24h volume: $1,476,717 · resolves 2026-10-02
  - (2026-10-02) Valorant: T1 vs JD Gaming (BO3) - VCT Champions Group A
      yes price: 98% · 24h volume: $1,060,152 · resolves 2026-10-02
  - (2026-10-02) Will Renan Santos win the 2026 Brazilian presidential election?
      yes price: 0% · 24h volume: $768,239 · resolves 2026-10-05
  - (2026-10-02) China Open: Hubert Hurkacz vs Arthur Gea
      yes price: 40% · 24h volume: $681,334 · resolves 2026-10-09
  - (2026-10-02) Will the U.S. invade Iran before 2027?
      yes price: 16% · 24h volume: $556,964 · resolves 2027-01-01
  - (2026-10-02) LoL: Solary vs T1 Academy - Game 4 Winner
      yes price: 0% · 24h volume: $396,841 · resolves 2026-10-02

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-10-01) U.S. Court of Appeals, 5th Cir.: United States v. Serna
  - (2026-10-01) U.S. Court of Appeals, 6th Cir.: William Fambrough v. City of E. Cleveland, Ohio
  - (2026-10-01) D.C. Court of Appeals: 2461 Corporation T/A Madam's Organ v. District of Columbia Alcoholic Beverage and Cannabis Board
  - (2026-10-01) D.C. Court of Appeals: Euceda v. United States
  - (2026-10-01) D.C. Court of Appeals: In re Socci
  - (2026-10-01) Delaware Supreme Court: Gemini Insurance Company v. Bausch & Lomb Americas, Inc.

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 121 total
  - (2026-10-01) [OFAC] Iran-related Designations and Designations Updates; Transnational Criminal Organizations Designation; Publication of Iran-related Determination; Publication of Amended Iran-related Frequently A…
      Iran-related Designations and Designations Updates; Transnational Criminal Organizations Designation; Publication of Iran-related Determination; Publication of Amended Iran-related Frequently Asked Question Office of For…
  - (2026-10-01) [OFAC] DETERMINATION PURSUANT TO SECTION 1(a)(i) OF EXECUTIVE ORDER 13902 Automotive and Rail Sectors of the Iranian Economy Section 1 - Office of Foreign Assets Control (.gov)
      DETERMINATION PURSUANT TO SECTION 1(a)(i) OF EXECUTIVE ORDER 13902 Automotive and Rail Sectors of the Iranian Economy Section 1 Office of Foreign Assets Control (.gov)
  - (2026-09-28) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 49B Authorizing Negotiatio - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 49B Authorizing Negotiatio Office of Foreign Assets Control (.gov)
  - (2026-10-01) [OFAC] 61764 Federal Register/Vol. 91, No. 188/Wednesday, September 30, 2026/Rules and Regulations - Office of Foreign Assets Control (.gov)
      61764 Federal Register/Vol. 91, No. 188/Wednesday, September 30, 2026/Rules and Regulations Office of Foreign Assets Control (.gov)
  - (2026-09-25) [FARA] Short Form Registrauon Statement Sample OMB_1124_0005B_SF - Department of Justice (.gov)
      Short Form Registrauon Statement Sample OMB_1124_0005B_SF Department of Justice (.gov)
  - (2026-09-27) [FARA] Exhibit A to Registration Statement SampleOMB_1124_0006B_EA - Department of Justice (.gov)
      Exhibit A to Registration Statement SampleOMB_1124_0006B_EA Department of Justice (.gov)

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-02) [Marginal Revolution] A Normal Debate?
      Computer scientists Arvind Narayanan & Sayash Kapoor wrote AI as Normal Technology The statement “AI is normal technology” is three things: a description of current AI, a prediction about the foreseeable future of AI, an…
  - (2026-10-02) [Marginal Revolution] What should I ask Tom Griffiths?
      Yes I will be doing a Conversation with him. Looking at Wikipedia: Thomas L. Griffiths (born c. 1978) is an Australian academic who is the Henry R. Luce Professor of Information Technology, Consciousness, and Culture at…
  - (2026-10-02) [Marginal Revolution] My excellent Conversation with Luis Garicano
      Here is the audio, video, and transcript. Here is part of the episode summary: Tyler and Luis start their conversation with Spain — housing, NIMBYism, and the productivity crisis; Spanish literature and why the Civil War…
  - (2026-10-01) [Conversable Economist] Interview with Gita Gopinath: Trade and Currencies
      Tyler Cowen serves up the questions in “Gita Gopinath on Trade, Currencies, and Economic Transformation” (Conversations with Tyler, September 25, 2026). Gopinath has just returned to Harvard after a stint at the IMF, and…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Macro indicators — latest values (FRED) — 1 new of 21 total
  - (2026-08-01) [Growth] Personal consumption (PCE)
      latest: 22308.5 as of 2026-08-01

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 18 total
  - (2026-10-01) CVE-2026-104286 · Fortinet FortiMail: Fortinet FortiMail Path Traversal Vulnerability
      vendor: Fortinet · product: FortiMail · CISA remediation by 2026-10-04

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=18, 14d-median=18; carrying terms: program, action, state, final, regulatory, procedures, certain, proposed, provisions, management, changes, office
- state_bills: today=105, 7d-median=105, 14d-median=106; carrying terms: service, registration, protection, person, county, resources, entity, personal, corporations, prevention, development, education
- state_news: today=804, 7d-median=604, 14d-median=683; carrying terms: spend, service, gubernatorial, county, latest, resources, loading, arkansas, behind, table, reported, human
- local_news: today=243, 7d-median=231, 14d-median=231; carrying terms: county, police, dining, georgia, local, public, cbmirafbvv, shooting, atlanta, killed, weekend, world
- foreign_news: today=1018, 7d-median=1018, 14d-median=1018; carrying terms: flights, french, killing, marks, emmanuel, reported, australian, entity, expected, issued, former, interview
- chinese_internal: today=265, 7d-median=270, 14d-median=271; carrying terms: cbmiy, cbmia, global, cbmixkfvx, title, chinese, cbmic, caixin, cbmiykfvx, color, cbmizkfvx, cbmib
- russian_internal: today=1181, 7d-median=1011, 14d-median=1029; carrying terms: gazeta, journal, laquo, target, openai, raquo, istories, forbidden, media, europe, politico, times
- ukrainian_internal: today=139, 7d-median=129, 14d-median=131; carrying terms: killing, powered, moscow, latest, reported, occupied, ballistic, months, title, launch, energy, power
- ukraine_theater: today=531, 7d-median=531, 14d-median=442; carrying terms: viirs, bxnfjvrmy, service, nnzbobjdnzmfxmtntz, shyzuvztugu, latest, avrasu, cuxoymzrwxbieuddvfz, npakluvxfjbe, polygons, tawsycvbhvhvwrlr, ministry
- paper_bets: today=122, 7d-median=120, 14d-median=124; carrying terms: december, office, democratic, industrial, zohran, general, republican, drought, prime, kalshi, career, fusion
- weather: today=156, 7d-median=144, 14d-median=127; carrying terms: mount, central, advisory, warning, service, visibility, creek, offshore, galveston, county, alert, including
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, spread, pcepilfe, money, supply, dexchus, cpilfesl, walcl, vixcls, dcoilwtico, assets, payrolls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, rates, china, corporate, large, futures, credit, crypto, bitcoin, commodities, crude, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=121, 7d-median=104, 14d-median=104; carrying terms: combat, jjmudpzw, occupation, central, daesh, satisfying, state, integrity, zimbabwe, undermining, sovereignty, usaspending
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quantitative, error, quiverquant, unauthorized, client, httperror, quiver, congresstrading
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: corporation, court, supreme, appeals, connecticut, state, delaware, bryant, company, arizona, robert, board
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, filer, trust, financial, finance, america, investment, chase, jpmorgan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, receipts, ocasio, brown, michael, filing, robert, james, alexandria, ossoff, house, raised
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=50, 7d-median=50, 14d-median=50; carrying terms: english, sanctions, trump, ukraine, spanish, themes, perimeter, russian, chinese, russia, german, keywords
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, germany, france, kingdom, canada, bulgaria, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: tshopo, alerted, institut, december, sometimes, generation, disembarked, central, democratic, disease, brings, institute
- cisa_kev: today=18, 7d-median=18, 14d-median=19; carrying terms: remediation, product, products, overflow, traversal, improper, injection, multiple, based, bounds, incorrect, authorization
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=14, 7d-median=17, 14d-median=15; carrying terms: depth, indonesia, islands, south, japan, ruteng, papua, guinea, alaska, solomon
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, league, shakhtar, championship, champions, donetsk, meeting, interest, october, group
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, economist, marginal, https, class, conversable, conversableeconomist, wealth, marginalrevolution, taxes, because, increases
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: access, cybersecurity, computer, research, state, years, infrastructure, going, daily, today, computerweekly, spectrum
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: sykes, debbie, lynch, hillary, simpson, stephen, jeanne, philadelphia, kagan, analilia, heinrich, warnock
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, converges, module, placed, decision, identify, paper, either, sufficient, evidence, market, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-28] Fed speeches: Cook, An Update on AI and the Economy
- [2026-09-29] ECB press: ECB amends monetary policy implementation guidelines as part of regular review
- [2026-09-29] Fed speeches: Bowman, Opening Remarks
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-29] Fed press (events + announcements): Agencies publish resolution plan feedback letters for 15 banking organizations
- [2026-09-30] ECB press: Frank Elderson: Supervisory risk appetite, efficiency and effectiveness
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] ECB press: Isabel Schnabel: Monetary policy in a world of overlapping shocks
- [2026-09-30] ECB press: Christine Lagarde: Interview with La Croix
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] ECB press: Christine Lagarde: Where AI risks meet

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*