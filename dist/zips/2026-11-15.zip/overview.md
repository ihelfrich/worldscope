# WORLDSCOPE morning brief — 2026-11-15

## Headline
2848 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (656) · Russian Internal News (state + in-exile) (481) · World leaders & government officials (324) · Chinese Internal News (204) · State Legislative Action (159) · Local News: St. Louis + Atlanta (132) · Ukraine Theater (total-war monitoring) (121) · U.S. Weather + Severe / Climate Outlooks (118) · GDELT GKG — themes / entities / watch areas (115) · World News (by country, top stories) (106) · State-Level News (99) · Ukrainian Internal News (national + local Kyiv) (53)

## What changed today
### International News + Multilateral Institutions — 656 new of 906 total
  - (2026-11-15) [India] PNB fund misappropriation case: Bank says genuine claims to be honoured, FIR registered in Gr Noida
  - (2026-11-15) [India] Guwahati-bound IndiGo flight returns to Pune due to technical issue; all 192 persons onboard safe
  - (2026-11-15) [India] Human rights commission seeks report on parking woes of city buses in Kozhikode
  - (2026-11-15) [India] How a Delhi extortion plot led police to Mad Sandhu murder accused who was planning attack on Amitabh Bachchan
  - (2026-11-15) [India] Cyber fraud reporting rises amid faster police interventions
  - (2026-11-15) [India] Rainfall expected in Tamil Nadu as depression to turn severe cyclonic storm over Bay of Bengal by November 17

### Russian Internal News (state + in-exile) — 481 new of 786 total
  - (2026-11-15) SpaceX впервые вернула корабль Starship на стартовую башню, поймав его над землей механическими «руками» | LEDE: SpaceX впервые в истории вернула корабль Starship — после орбитального полета] (ru: Spa…
      SpaceX впервые в истории вернула корабль Starship — после орбитального полета его поймали над землей при помощи механических манипуляторов на стартовой башне Mechazilla в Южном Техасе.
  - (2026-11-15) В Таганроге украинские беспилотники атаковали электроподстанцию, погиб главный инженер. В Татарстане после атаки горит предприятие «Сибура» | LEDE: Украинские беспилотники атаковали Таганрог] (ru: В Т…
      Украинские беспилотники атаковали Таганрог, повреждены две подстанции, есть погибший и пострадавшие, сообщил глава региона Юрий Слюсарь.
  - (2026-11-15) Бывший главред Individuum Алексей Киселев дал «Медузе» первое интервью после закрытия издательства. Об арестах коллег, цензуре в «Эксмо» и ботах, проверяющих книги на «экстремизм» | LEDE: 12] (ru: Быв…
      12 ноября холдинг «Эксмо» объявил о создании нового издательства «Тропы». Его ближайшие планы — опубликовать книги, не успевшие выйти в Individuum. Специализация у «Тропов» заявлена та же, что и у предшественника — нон-ф…
  - (2026-11-14) Сенаторы потребовали от Маска сохранить документы об ограничениях в работе Starlink для Украины. Они планируют провести расследование | LEDE: Сенаторы от Демократической партии Джин Шахин и ] (ru: Сен…
      Сенаторы от Демократической партии Джин Шахин и Крис Кунс потребовали от основателя SpaceX Илона Маска сохранить все документы, которые касаются ограничений, введенных на использование Украиной спутников Starlink и их во…
  - (2026-11-14) На каких условиях Кремль готов завершить войну? СМИ опубликовали список максималистских требований Путина. Они касаются не только Евросоюза и НАТО, но, например, еще Молдовы, Финляндии и даже Ц] (ru:…
      После длительного перерыва Россия и Украина возобновили мирные переговоры при посредничестве США. 10-11 ноября стороны провели два раунда обсуждений в Абу-Даби, после чего спецпосланники Дональда Трампа слетали в Москву…
  - (2026-11-14) Бывший белгородский губернатор Вячеслав Гладков отказался от телеграм-канала с 400 тысячами подписчиков. В Кремле недовольны, что он продолжал его вести, утверждает «Коммерсант» | LEDE: Посо] (ru: Быв…
      Посол России в частично признанной Абхазии и бывший губернатор Белгородской области Вячеслав Гладков объявил, что больше не будет вести свой телеграм-канал «Настоящий Гладков».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 204 new of 274 total
  - (2026-11-13) 财新闻｜文旅部通报2026年第七批旅游市场强制消费问题典型案例 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE82SXRQMXhwY3o3QXBjbmhLdEZtUlNHY0FXOE5tVUtMb0J5ZFhHUFRRVXRidnZlQzRBTjZIWEF1bUN6TVhBc2dGa0] (zh:…
      财新闻｜文旅部通报2026年第七批旅游市场强制消费问题典型案例 财新
  - (2026-11-15) 英雄联盟全球总决赛，中国战队BLG夺冠 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5pQ0UwTHRXTHZaY2tNSFBZZ0xDc3B1amtGSHlTaVNuYXQ5VmZfX0REVkRLUTZxQTB6dXJYYVl4d1N5VUZCUkVfUzhLRHNRWG95SW] (zh:…
      英雄联盟全球总决赛，中国战队BLG夺冠 财新
  - (2026-11-14) 偶遇“好人生命中最好的那一部分”｜廷滕寺的人与诗① - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1CRnVvcW9NVHdINi1feTVsaDJoRjNISkJiQ21qZUxBdHZ3WG9yUW9xZUNFWERWdkp1WDI3QlQtUzRJN0tHZ3c0X0JNNVhX] (zh:…
      偶遇“好人生命中最好的那一部分”｜廷滕寺的人与诗① 财新
  - (2026-11-14) 国风｜55万部微短剧超94%为AI制作 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE45RmhnV1EwbXllbkw0eW1XTTA1QjJFSHQ2dkpwbXNzWDNVLVpJelJUR1BybGRhNDFYSEhDeGNTMGdIdHhsTnJLMkQxNEl5Q0VocU] (zh:…
      国风｜55万部微短剧超94%为AI制作 财新
  - (2026-11-15) 伍尔夫《奥兰多》：小说版的《第二性》｜带着问题去读书 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5qcnBla2ZQaWNLRjllU180LW1KQkx1T2p5T2g0SklMclVGaE5ldkxqUl81dVZiV2xTOWhoZ0tMZ2poVVdtcEV4ekNLNkt] (zh:…
      伍尔夫《奥兰多》：小说版的《第二性》｜带着问题去读书 财新
  - (2026-11-14) 最新封面报道之二｜美国AI基建拉锯 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE45Q253emVMNWR2dzdtQnBRRmZCaDhNX2xZbkRRcndlWHVJS3hhQnFtNEI5UTAxQTJIRmdPaEFEUHhmY2Vib0V5RXBEWVlaN2Vmb1JU] (zh:…
      最新封面报道之二｜美国AI基建拉锯 财新

### State Legislative Action — 159 new of 167 total
  - (2026-11-14) [Alaska SB 258] An Act relating to contracts for the licensing of software applications.
      An Act relating to contracts for the licensing of software applications.
  - (2026-11-14) [Alaska SB 217] An Act relating to employer contributions to the unemployment compensation fund; establishing an employer contribution for the state training and employment program; and providing for…
      An Act relating to employer contributions to the unemployment compensation fund; establishing an employer contribution for the state training and employment program; and providing for an effective date.
  - (2026-11-14) [Alaska SB 121] An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
      An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
  - (2026-11-14) [Alaska SB 62] An Act relating to the board of parole; and providing for an effective date.
      An Act relating to the board of parole; and providing for an effective date.
  - (2026-11-14) [Alaska SB 111] An Act relating to the diagnosis, maintenance, and repair of consumer products that use digital electronics to operate; adding an unlawful act to the Alaska Unfair Trade Practices and…
      An Act relating to the diagnosis, maintenance, and repair of consumer products that use digital electronics to operate; adding an unlawful act to the Alaska Unfair Trade Practices and Consumer Protection Act; and providi…
  - (2026-11-14) [Alaska SB 266] An Act relating to reimbursement for non-network health insurance claims.
      An Act relating to reimbursement for non-network health insurance claims.

### Local News: St. Louis + Atlanta — 132 new of 250 total
  - (2026-11-14) [St. Louis] Little Lager, Side Project earn national beer honors
      It’s turning into quite a November for Little Lager. First came the news that owner Manny Negron was preparing to open his long-awaited second location on Cherokee Street. Now, the Princeton Heights bar has been named on…
  - (2026-11-14) [St. Louis] Truck Norris Twisted Eats & Bar in Ellisville to close November 15
      Truck Norris Twisted Eats & Bar (15856 Clayton) will permanently close this Sunday, November 15, less than a year after the Ellisville restaurant temporarily shut down following an auto accident that destroyed its food t…
  - (2026-11-15) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-11-15) [St. Louis] Suspect shot, killed in south St. Louis officer-involved shooting
      A suspect was shot in an officer-involved shooting Saturday evening in south St. Louis. It's the second shooting involving a law enforcement officer Saturday in the City of St. Louis.
  - (2026-11-15) [St. Louis] Shots fired in Central West End, suspect in custody
      Police are responding to an apparent officer-involved shooting Saturday evening in St. Louis' Central West End neighborhood. One suspect has been taken into custody, police say.
  - (2026-11-15) [St. Louis] Woman arrested after dog abuse video circulates on social media
      A disturbing video circulating on social media that appeared to show a woman striking a small dog led to her arrest, according to the Bellefontaine Neighbors Police Department.

### Ukraine Theater (total-war monitoring) — 121 new of 271 total
  - (2026-11-15) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-14) [Liveuamap] Violent explosions amid airstrike in Zaporizhzhia – Zaporizhzhia, Zaporiz&039;ka oblast - Liveuamap
      Violent explosions amid airstrike in Zaporizhzhia – Zaporizhzhia, Zaporiz&039;ka oblast <font color="#6f
  - (2026-11-13) [Liveuamap] CENTCOM says Iran launched… – Manama, Bahrain - Liveuamap
      CENTCOM says Iran launched… – Manama, Bahrain Liveuamap
  - (2016-07-28) [Liveuamap] Iran news live map today | Liveuamap - Liveuamap
      Iran news live map today | Liveuamap Liveuamap
  - (2026-11-13) [Liveuamap] Nine people were killed… – Blue Nile, Sudan - Liveuamap
      Nine people were killed… – Blue Nile, Sudan Liveuamap
  - (2026-11-12) [Liveuamap] 1 person killed as result of drone strike in Shebekino – Belgorod Oblast, Russia - Liveuamap
      1 person killed as result of drone strike in Shebekino – Belgorod Oblast, Russia Liveuamap</font

### U.S. Weather + Severe / Climate Outlooks — 118 new of 120 total
  - (2026-11-15) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-15) [Moderate] Special Weather Statement: Special Weather Statement issued November 15 at 1:01AM CST by NWS San Angelo TX
      At 100 AM CST, Doppler radar was tracking a strong thunderstorm near Hords Creek Reservoir, or just northwest of Coleman, moving southeast at 25 mph. HAZARD...Wind gusts of 50 to 55 mph and pea size hail. SOURCE...Radar…
  - (2026-11-14) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 14 at 10:01PM AKST until November 15 at 10:00PM AKST by NWS Anchorage AK
      * WHAT...Mixed precipitation expected. Total snow accumulations between 6 and 12 inches and ice accumulations around a light glaze. * WHERE...East Turnagain Arm, including Portage Valley and Girdwood. * WHEN...Until 11 P…
  - (2026-11-14) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 14 at 10:01PM AKST until November 15 at 9:00PM AKST by NWS Anchorage AK
      * WHAT...Snow expected. Total snow accumulations between 3 and 5 inches. Winds gusting as high as 35 mph. * WHERE...Seward. * WHEN...Until 5 PM AKST Sunday. * IMPACTS...Travel could be very difficult. Roads, and especial…
  - (2026-11-14) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 14 at 10:01PM AKST until November 15 at 5:00PM AKST by NWS Anchorage AK
      * WHAT...Mixed precipitation expected. Total snow accumulations between 1 and 4 inches and ice accumulations around a light glaze. Lowest amounts near Chugiak, highest amounts South Anchorage and the Anchorage Hillside.…
  - (2026-11-14) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 14 at 10:01PM AKST until November 16 at 1:00PM AKST by NWS Anchorage AK
      * WHAT...Snow expected. Total snow accumulations between 6 and 12 inches. Winds gusting as high as 40 mph. Visibility as low as one half mile. * WHERE...Whittier. * WHEN...Until 9 PM AKST Sunday. * IMPACTS...Power outage…

### GDELT GKG — themes / entities / watch areas — 115 new of 115 total
  - (2026-11-15) [Russia oil sanctions perimeter · themes] Ukraine war briefing: US proposes Kyiv cede land to Russia for Nato membership, Zelenskyy says
      aol.co.uk · English · tone -3.33333333333333 · 1 other outlets
  - (2026-11-15) [Russia oil sanctions perimeter · themes] Inside the crew rescuing sailors from drone attacks in the Black Sea - 15-Nov-2026
      nzcity.co.nz · English · tone -3.88143966125617
  - (2026-11-15) [Russia oil sanctions perimeter · near] Ukraine…Russia War.… Day Number 1,726…Gulf Talks Centered on NATO/Ukraine…
      politicaldog101.com · English · tone -4.65116279069768 · 14 other outlets
  - (2026-11-15) [Russia oil sanctions perimeter · near] Ukraine peace deal cannot happen without Europe, says Trump's envoy Jared Kushner
      moneycontrol.com · English · tone -1.47492625368732 · 7 other outlets
  - (2026-11-15) [Russia oil sanctions perimeter · near] Russia lifts unofficial ban on targeting Zelenskyy after Ukraine's repeated strikes on key oil export hub: Report
      indiatimes.com · English · tone -3.33863275039746 · 4 other outlets
  - (2026-11-15) [Russia oil sanctions perimeter · near] Sabalenka apologizes for on-court outburst in WTA Finals loss to Svitolina
      mymotherlode.com · English · tone -2.51572327044025 · 2 other outlets

### World News (by country, top stories) — 106 new of 106 total
  - (2026-11-15) [Brazil] Readout - Prime Minister Carney meets with President of Brazil Luiz Inácio Lula da Silva
      timminspress.com · English · 1 other outlets ran this story
  - (2026-11-15) [Brazil] Lula Text Says Big Tech Power Is a Threat
      riotimesonline.com · English
  - (2026-11-15) [Brazil] ASEAN Summit: Carney pledges up to CAD 560 million for Brazil-led forest project
      aninews.in · English
  - (2026-11-15) [Brazil] Brazilian Freestyler Laura Comini Romero Hands Verbal Commitment to Iowa State for Fall 2027
      swimswam.com · English
  - (2026-11-15) [Brazil] Brazil records first mpox death in 2026
      philstar.com · English
  - (2026-11-15) [Brazil] PH, Brazil expand ties on trade, agri, sustainable energy
      sunstar.com.ph · English

### State-Level News — 99 new of 454 total
  - (2026-11-14) [California] Following United Nations summit, Governor Newsom brings California’s climate work to Poland, launches new partnership
      Source
  - (2026-11-14) [California] Tax the rich — sometimes. California voters sent mixed signals with ballot measures
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110526-CTA-March-RP-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-11-13) [Arizona] US loses its 'measles elimination status' after more than 25 years
      The number of confirmed measles cases across the U.S. this year has soared to 5,412 as of Nov. 12, more than double the 2,289 cases through all of 2025, according to the latest release of data from the federal Centers fo…
  - (2026-11-14) [Colorado] Colorado Senate Republicans pick Lisa Frizell as minority leader
      Colorado Senate Republicans unanimously selected Sen. Lisa Frizell of Castle Rock as their new minority leader on Saturday morning. The vote came after Gov.-elect Phil Weiser, a Democrat, named former Senate Minority Lea…
  - (2026-11-14) [Colorado] Extended legal protections for Afghans sought by Colorado Rep. Jason Crow
      WASHINGTON — Colorado Democratic Rep. Jason Crow, a military veteran, is making an attempt during Congress’ lame-duck session to provide legal protections for Afghanistan immigrants who aided the U.S. military for years,…
  - (2026-11-14) [Arkansas] Fueled by Democratic gains, women will hold a record of state legislative seats
      The number of women serving in state legislatures will set a new record following strong Democratic performance in last week’s midterm elections. Though many races remain too close to call, an analysis by the Center for…

### Ukrainian Internal News (national + local Kyiv) — 53 new of 117 total
  - (2026-11-15) Russian Glide Bombs Strike Zaporizhzhia, Injuring 6 Including Toddler
      Russian tactical aviation launched 12 guided aerial bomb (KAB) strikes against Zaporizhzhia on Saturday evening, Nov. 14, wounding six civilians – including a two-year-old child, three women, and two men – Acting Regiona…
  - (2026-11-15) Yet Another Russian War Crime
      On Nov. 2, Russian glide bombs destroyed a fortified underground school in Komyshuvakha, Zaporizhzhia, while residents collected humanitarian aid, killing at least 55. Extra concrete and seven meters of depth were not en…
  - (2026-11-15) ISW Russian Offensive Campaign Assessment, November 14, 2026
      War in Ukraine - Latest update, key takeaways and map from the Institute for the Study of War on November 14, 2026.
  - (2026-11-15) Ukraine War News Today - Top Stories and Breaking Updates from Kyiv Post
      Stay informed with the most important Ukraine breaking news today. This page compiles the top headlines and critical updates from across Ukraine, offering a real-time snapshot of key developments. Whether it’s military u…
  - (2026-11-14) Bulgaria Halts Arms Transfers and Financial Aid to Ukraine
      Bulgarian Prime Minister Rumen Radev has announced that Bulgaria lacks the financial capacity to support Ukraine due to an excessive budget deficit, and will cease supplying weapons and ammunition from its military stock…
  - (2026-11-14) Russia Uses Upgraded Iskander Missiles to Strike Kyiv Bridges
      Russia has outfitted its Iskander ballistic missiles with optical and radar homing seekers capable of adjusting terminal trajectories to hit targets within meters, deploying them against Kyiv’s bridges in an effort to sp…

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-14) [United States] All passengers and crew on New Orleans cruise ship survive crash with tanker on Mississippi River
      domain: thedailytimes.com · language: English · tone: -2.95930949445129 · 117 other outlets ran this story
  - (2026-11-15) [United States] Florida city cancels St. Patrick's Day parade, citing new anti-DEI law
      domain: wypr.org · language: English · tone: 1.14613180515759 · 60 other outlets ran this story
  - (2026-11-15) [United States] Richard Sterban, member of the celebrated country and gospel group The Oak Ridge Boys, dies at 83 – Winnipeg Free Press
      domain: winnipegfreepress.com · language: English · tone: 3.4965034965035 · 57 other outlets ran this story
  - (2026-11-14) [United States] United States Loses Measles Elimination Status for First Time Since 2000
      domain: wcbm.com · language: English · tone: -3.97727272727273 · 50 other outlets ran this story
  - (2026-11-15) [United States] How the nationwide ground stop canceled a rock and roll dream
      domain: fox5atlanta.com · language: English · tone: -3.19767441860465 · 49 other outlets ran this story
  - (2026-11-15) Gram Parsons Posthumously Inducted Into Rock Hall
      domain: kcrr.com · language: English · tone: 3.1055900621118 · 38 other outlets ran this story

### GDACS — global disaster alerts — 39 new of 100 total
  - (2026-11-15) [Green] Earthquake in Fiji
      Earthquake · Green alert · Fiji · Magnitude 5.5M, Depth:469.881km
  - (2026-11-15) [Green] Earthquake in Argentina
      Earthquake · Green alert · Argentina · Magnitude 4.8M, Depth:108.94km
  - (2026-11-14) [Green] Earthquake in East Central Pacific Ocean
      Earthquake · Green alert · East Central Pacific Ocean · Magnitude 4.7M, Depth:10km
  - (2026-11-14) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.5M, Depth:10km
  - (2026-11-14) [Green] Earthquake in Argentina
      Earthquake · Green alert · Argentina · Magnitude 4.7M, Depth:506.268km
  - (2026-11-14) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.6M, Depth:65.399km

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Wikidata leader-roster changes (48h) — 30 new of 53 total
  - (2026-11-15) [Cyprus] Nicos Christodoulides (Q48905549) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/65848|batch #65848]]: Import places from GND
  - (2026-11-15) [Andorra] Josep-Lluís Serrano Pentinat (Q93244592) edited
      /* wbremoveclaims-remove:1| */ [[Property:P19]]: [[Q15088]]
  - (2026-11-15) [Romania] Nicușor Dan (Q11163124) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/65846|batch #65846]]: Import places from GND
  - (2026-11-15) [Maldives] Mohamed Muizzu (Q116293030) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/65846|batch #65846]]: Import places from GND
  - (2026-11-15) [South Sudan] Salva Kiir Mayardit (Q57315) edited
      /* wbsetclaim-update:1||1 */ [[Property:P18]]: Salva Kiir at the Kremlin (2026-10-30) (cropped).jpg
  - (2026-11-15) [Vatican City] Leo XIV (Q6109517) edited
      /* wbsetclaim-create:2||1 */ [[Property:P4012]]: 2523330128

### Government & military aircraft airborne (OpenSky) — 25 new of 25 total
  - (2026-11-15) NCR899 (United States)
      icao24: ad3c48 · position: (44.8147, 20.3178) · alt: 15m · 318km/h
  - (2026-11-15) RCH4536 (United States)
      icao24: ae1448 · position: (61.2535, -149.8249) · on ground
  - (2026-11-15) RCH140 (United States)
      icao24: ae146a · position: (41.5372, -79.4579) · alt: 10058m · 868km/h
  - (2026-11-15) RCH3268 (United States)
      icao24: ae10c0 · position: (60.3113, -145.2108) · alt: 10363m · 833km/h
  - (2026-11-15) RCH1859 (United States)
      icao24: ae0563 · position: (39.5555, -80.2677) · alt: 8260m · 838km/h
  - (2026-11-15) NCR306 (United States)
      icao24: ab4ec6 · position: (32.5402, -83.2491) · alt: 8031m · 902km/h

### U.S. Federal Action — 21 new of 21 total
  - (2026-11-16) Presidential Determination Concerning Wildfire Suppression Activities in the United States
  - (2026-11-16) Veterans Day, 2026
  - (2026-11-16) Safety Zone; Huron River, Huron, OH
      The Coast Guard is establishing a temporary safety zone for navigable waters of the Huron River within a 150-yard radius of 41[deg]23'34.6" N, 82[deg]33'07.7" W in Huron, OH. The safety zone is needed to protect personne…
  - (2026-11-16) Accuracy of Advertising and Notice of Insured Status
      The NCUA Board (Board) is issuing this final rule to streamline its regulations governing advertising and the notice of insured status. This final rule eliminates provisions concerning the official advertising statement.…
  - (2026-11-16) Privacy of Consumer Financial Information
      The NCUA Board (Board) is issuing a final rule to make technical corrections to provisions of the NCUA's regulations. The technical amendments improve clarity by removing obsolete references to the privacy of consumer fi…
  - (2026-11-16) Nondiscrimination Requirements
      The NCUA Board (Board) is publishing this final rule to remove a redundant and outdated regulation regarding nondiscrimination in lending. The regulation was intended to summarize the Fair Housing Act (FHA) prohibitions…

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-13) [F24] CONSERVATIVES FOR AMERICAN EXCELLENCE INC.
      cycle 2026 · filing #2047671
  - (2026-11-13) [F2] STANTON, GREG
      cycle 2026 · filing #2047516
  - (2026-11-13) [F2] BARRINGER, PAUL
      cycle 2026 · filing #2047539
  - (2026-11-13) [F3X] TITUS VICTORY FUND
      cycle 2026 · filing #2047553 · receipts $0.04M
  - (2026-11-13) [F2] SHREVE, JEFFERSON
      cycle 2026 · filing #2047537
  - (2026-11-13) [F2] HOULAHAN, CHRISSY
      cycle 2026 · filing #2047544

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 63 total
  - (2026-11-15) [Ars Technica] SpaceX returned its Starship rocket on Saturday—but there's a catch
      It felt like stepping into the future.
  - (2026-11-15) [TechCrunch] Where was Nvidia’s security team?
      Nvidia’s security chief quietly left in August, and now that CEO Jensen Huang has stepped down over his relationships, including one with an executive at a company suspected of funneling chips to China, a former intellig…
  - (2026-11-14) [BleepingComputer] Cursor confirms security breach led to malicious Claude Code extension
      Cursor confirmed it suffered a security breach that let hackers distribute a malicious Claude Code extension through its marketplace after stealing credentials from AI infrastructure provider Fireworks AI. [...]
  - (2026-11-14) [BleepingComputer] US disrupts North Korean campaign behind $400 million crypto theft
      The U.S. government has disrupted a North Korean social engineering campaign called 'FaceStealer', responsible for stealing more than $400 million in cryptocurrency. [...]
  - (2026-11-14) [The Hacker News] Attackers Exploit UnrealIRCd Flaw That Enables Server-Level Command Injection
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Friday added a high-severity security flaw impacting UnrealIRCd, an open-source Internet Relay Chat (IRC) server, to its Known Exploited Vulnerabilities…
  - (2026-11-14) [Schneier on Security] Upcoming Speaking Engagements
      This is a current list of where and when I am scheduled to speak: I’m speaking at the Catalyst Summit in Brampton, Ontario, Canada, on Wednesday, November 18, 2026. I’m speaking at QT Qonference 2026 in Toronto, Ontario,…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-11-15) Utah vs. Arizona
      yes price: 100% · 24h volume: $1,698,186 · resolves 2026-11-15
  - (2026-11-15) Counter-Strike: Spirit vs FURIA (BO5) - BLAST Rivals Playoffs
      yes price: 60% · 24h volume: $508,801 · resolves 2026-11-15
  - (2026-11-15) Pepperdine Waves vs. Oregon Ducks
      yes price: 43% · 24h volume: $455,657 · resolves 2026-11-15
  - (2026-11-15) Spread: Lions (-2.5)
      yes price: 52% · 24h volume: $402,164 · resolves 2026-11-15
  - (2026-11-15) Will Bitcoin dip to $45,000 by December 31, 2026?
      yes price: 8% · 24h volume: $384,968 · resolves 2027-01-01
  - (2026-11-15) Will Jensen Huang rejoin NVIDIA by December 31, 2026?
      yes price: 11% · 24h volume: $342,353 · resolves 2027-01-01

### Paper Trading Scorecard — 13 new of 73 total
  - (2026-11-15) [Polymarket] Will a Chinese company have one of the top 3 AI models by December 31?
      This market will resolve to "Yes" if a Chinese company owns a model that ranks within the top 3, based on the Chatbot Arena LLM Leaderboard (https://arena.ai/) when the table under the "Leaderboard" tab is checked at any…
  - (2026-11-15) [Polymarket] Will LSU Tigers win the 2027 CFP National Championship?
      This market will resolve to "Yes" if the listed club is determined as the national champion of the 2026-27 College Football Playoff. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed…
  - (2026-11-15) [Polymarket] Will Bitcoin dip to $45,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "Low" price equal to or low…
  - (2026-11-15) [Polymarket] Will Roma win the 2026-27 Serie A Championship?
      This market will resolve according to the team that wins the 2026-27 Serie A Championship. If at any point it becomes impossible for a listed team to win the 2026-27 Serie A Championship per the rules of Serie A (e.g., t…
  - (2026-11-15) [Manifold] Will the Gävle goat be destroyed by fire (again) this year?
  - (2026-11-15) [Manifold] Will Jensen Huang be divorced before November 23, 2026?

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-11-15) M 5.5 - Fiji region
      M5.5 · Fiji region · depth 469.881 km
  - (2026-11-14) M 5.5 - northern Mid-Atlantic Ridge
      M5.5 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-11-14) M 4.9 - 7 km SE of Tagbina, Philippines
      M4.9 · 7 km SE of Tagbina, Philippines · depth 154.123 km
  - (2026-11-14) M 4.9 - south of the Kermadec Islands
      M4.9 · south of the Kermadec Islands · depth 12.019 km
  - (2026-11-15) M 4.8 - 19 km NW of Albardón, Argentina
      M4.8 · 19 km NW of Albardón, Argentina · depth 108.94 km
  - (2026-11-14) M 4.7 - east central Pacific Ocean
      M4.7 · east central Pacific Ocean · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 100 total
  - (2026-11-15) [USASpending] $7,933,559,693 → MISSION SUPPORT & TEST SERVICES LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION S
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION SUPPORT AND TEST SERVICES LLC (MSTS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY NATIONAL NUCLEAR SEC…
  - (2026-11-15) [USASpending] $811,355,481 → THE GEO GROUP, INC.: DETENTION SERVICES - SAN DIEGO
      Agency: Department of Justice. Description: DETENTION SERVICES - SAN DIEGO
  - (2026-11-15) [USASpending] $721,181,569 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-11-15) [USASpending] $326,922,529 → BOOZ ALLEN HAMILTON INC: AFRL SHADOW RAPTOR
      Agency: General Services Administration. Description: AFRL SHADOW RAPTOR
  - (2026-11-15) [USASpending] $317,457,831 → PERATON ENTERPRISE SOLUTIONS LLC: EDS TO#3, CONTRACTOR OWNED, CONTRACTOR OPERATED HOSTED DATA
      Agency: Department of Health and Human Services. Description: EDS TO#3, CONTRACTOR OWNED, CONTRACTOR OPERATED HOSTED DATA CENTER
  - (2026-11-15) [USASpending] $287,757,783 → ACCENTURE FEDERAL SERVICES LLC: CBP'S DATA CENTER SUPPORT SERVICES (DCSS).
      Agency: Department of Homeland Security. Description: CBP'S DATA CENTER SUPPORT SERVICES (DCSS).

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-11-13) U.S. Court of Appeals, 4th Cir.: Maura Kreitzer v. Safeco Insurance Company of America
  - (2026-11-13) Hawaii Supreme Court: In re: Magazu
  - (2026-11-12) Hawaii Supreme Court: Choi v. Association of Apartment Owners of Queen Emma Gardens and Touchstone Properties LTD.
  - (2026-11-12) Hawaii Supreme Court: In re: Eric Magazu
  - (2026-11-12) Hawaii Supreme Court: In re: Sarah Eden Coultas
  - (2026-11-12) Illinois Supreme Court: People v. Johnson

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 36 total
  - (2026-11-15) MOVER ▼ Amancio Ortega — $150.71B ($-0.45B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-11-15) MOVER ▼ Bernard Arnault & family — $120.51B ($-0.44B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-11-15) MOVER ▼ Francoise Bettencourt Meyers & family — $104.54B ($-0.38B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-11-15) MOVER ▼ Mukesh Ambani — $92.40B ($-0.20B since yesterday)
      India · Diversified · source: Diversified
  - (2026-11-15) MOVER ▼ Gautam Adani — $83.09B ($-0.18B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-11-15) MOVER ▲ Carlos Slim Helu & family — $125.53B (+$0.14B since yesterday)
      Mexico · Telecom · source: Telecom

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-11-15) [Marginal Revolution] Best films of 2026
      I thought this was a splendid and highly innovative year. Here is my list, in the order I saw them, noting that a link typically brings you to my review: Resurrection Testament of Ann Lee 28 Years Later Wuthering Heights…
  - (2026-11-14) [Marginal Revolution] Saturday assorted links
      1. Madrid vs. Catalonia. 2. Stephen Kovacevich, RIP (NYT). Brahms and the Diabellis stand among his towering pianistic achievements. He was one of my favorite pianists. 3. Queen at Sea is an excellent movie, though hard…
  - (2026-11-14) [Marginal Revolution] Privatize Air Traffic Control, Redux
      Yesterday the FAA grounded every domestic departure in the United States for more than four hours. Such groundings appear to be happening more often. The last nationwide grounding was in 2023, and regional ones have hit…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-15) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25; carrying terms: final, proposes, provide, airplanes, action, regulatory, directives, published, changes, issued, airworthiness, safety
- state_bills: today=167, 7d-median=97, 14d-median=97; carrying terms: health, vehicle, authority, income, relating, program, providing, insurance, approval, medical, emergency, reporting
- state_news: today=454, 7d-median=717, 14d-median=675; carrying terms: bottom, power, wyoming, ctmirror, county, division, women, limits, august, congressional, expect, person
- local_news: today=250, 7d-median=266, 14d-median=256; carrying terms: power, county, crash, south, woman, weekend, house, downtown, falcons, authorities, street, future
- foreign_news: today=906, 7d-median=997, 14d-median=992; carrying terms: arrest, power, bottom, women, leaves, houthis, pakistan, production, suspected, australian, sydney, crash
- chinese_internal: today=274, 7d-median=321, 14d-median=321; carrying terms: cbmiyefvx, stock, market, cbmix, growth, cbmizefvx, cbmiakfvx, china, cbmixkfvx, https, cbmizkfvx, articles
- russian_internal: today=786, 7d-median=1012, 14d-median=938; carrying terms: europe, istories, title, raquo, forbidden, apple, financial, russian, media, server, novayagazeta, journal
- ukrainian_internal: today=117, 7d-median=134, 14d-median=134; carrying terms: europe, power, toward, poland, remains, faces, according, intelligence, operation, following, ukrinform, police
- ukraine_theater: today=271, 7d-median=271, 14d-median=271; carrying terms: fedorov, wjhsr, pantsir, brave, clvwz, cwsehumnnpdkxjs, cbmijafbvv, bvlfctc, cjbsmhh, houthis, tvrmehbcmhluvgpuaflfdk, august
- paper_bets: today=73, 7d-median=75, 14d-median=71; carrying terms: rushing, solved, november, derrick, manifold, funds, labor, kylian, riemann, visit, rippling, industrial
- weather: today=120, 7d-median=135, 14d-median=130; carrying terms: objects, power, updated, afdokx, severe, afdlsx, front, ruskin, normal, montgomery, monitoring, afternoon
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: personal, unemployment, treasury, headline, dexjpus, cpilfesl, pcepilfe, crude, balance, funds, payems, latest
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, corporate, treasury, china, rates, equities, russell, silver, yield, crude, range, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=100, 7d-median=100, 14d-median=99; carrying terms: foreign, articles, cbmixkfvx, republic, sanctions, cbmiqkfvx, detect, google, provide, support, usaspending, https
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, https, error, quiverquant, quiver, congresstrading, httperror, unauthorized, quantitative
- billionaires: today=36, 7d-median=30, 14d-median=0; carrying terms: cryptocurrency, tadashi, francoise, julia, investments, tokyo, china, canada, tesla, mukesh, beverages, larry
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, state, supreme, court, company, florida, appeals, connecticut, blanche, arkansas, delaware, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, holdings, michael, brian, isaac, joseph
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: peltola, sherrod, raised, receipts, cortez, jackson, cycle, james, booker, david, jonathan, trone
- gdelt_regions: today=106, 7d-median=12, 14d-median=12; carrying terms: english, europe, south, trump, korea, japan, business, raises, korean, germany, minister, security
- gdelt_gkg: today=115, 7d-median=25, 14d-median=25; carrying terms: english, sanctions, russian, perimeter, trump, russia, keywords, themes, israel, hezbollah, netanyahu, security
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: english, killed, police, shooting, murder, india, press, australia, suspect, trump, domain, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=25, 7d-median=22, 14d-median=26; carrying terms: position, france, belgium, canada, germany, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: middle, biena, rwampara, international, january, coronavirus, epidemic, director, recalls, documented, nationwide, patient
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: value, return, critical, authentication, google, missing, remediation, product, vendor, vulnerability, cisco, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=53, 7d-median=53, 14d-median=0; carrying terms: wbremoveclaims, import, djibouti, faure, nhamadjo, dileita, alias, republic, edited, bulgaria, cleanup, languages
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forestfire, green, magnitude, wildfire, australia, botswana, sudan, impact, depth, forest, fires, alert
- usgs_quakes: today=11, 7d-median=14, 14d-median=12; carrying terms: depth, islands, region, ridge, south, indonesia, russia, philippines, atlantic, northern, argentina
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, presidential, donetsk, championship, league, israel, shakhtar, champions, november, nomination
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, class, conversable, https, economist, marginal, since, world, conversableeconomist, economic, marginalrevolution, working
- tech_news: today=63, 7d-median=63, 14d-median=61; carrying terms: https, intelligence, known, hacker, technica, apple, spectrum, world, access, today, targeting, discovered
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: patty, cleaver, cynthia, green, crapo, julia, treasury, hillary, director, salazar, kagan, salud
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, evidence, sufficient, either, converges, placement, placed, paper, markets, consensus, today, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*