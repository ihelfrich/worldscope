# WORLDSCOPE morning brief — 2026-08-30

## Headline
2103 new items across 21 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (601) · Russian Internal News (state + in-exile) (432) · World leaders & government officials (324) · Chinese Internal News (198) · Local News: St. Louis + Atlanta (109) · State-Level News (92) · U.S. Weather + Severe / Climate Outlooks (68) · Ukrainian Internal News (national + local Kyiv) (52) · Ukraine Theater (total-war monitoring) (46) · State Legislative Action (36) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (30)

## What changed today
### International News + Multilateral Institutions — 601 new of 984 total
  - (2026-08-30) [Global] Ferry carrying more than 250 passengers capsizes off northern Cyprus
      A ferry carrying more than 250 passengers capsized off the coast of northern Cyprus on Sunday after taking on water, Turkish media reported. Rescue crews were dispatched to the scene, with footage showing passengers in l…
  - (2026-08-30) [Global] US and Venezuela seal 25-year oil deal
      US President Donald Trump has called it “the biggest oil deal in world history”, while Venezuela’s interim president has assured the public that the country will retain control of its oil under the agreement. The “histor…
  - (2026-08-30) [Global] Argentines march on Peter Thiel's mansion
      In Argentina, protesters marched toward a mansion reportedly purchased by American tech billionaire Peter Thiel. Activists accuse Thiel of seeking to profit from the country’s natural resources and wielding excessive pol…
  - (2026-08-30) [Global] Nepal: Thousands still missing as death toll rises
      Nepalese authorities announced on Sunday that the provisional death toll from the devastating floods had risen to more than 730, with nearly 2,500 people still missing. Among the thousands of people missing is the husban…
  - (2026-08-30) [Global] 🔴 Iceland rejects restarting EU accession talks in referendum
  - (2026-08-30) [Global] Iceland rejects restarting EU accession talks in referendum
      Icelanders voted to reject reopening EU membership talks, official results showed Sunday, dealing a blow to the government's push to join the bloc and handing a win to those who argued the country's prized fishing waters…

### Russian Internal News (state + in-exile) — 432 new of 813 total
  - (2026-08-30) У берегов Северного Кипра перевернулось судно. На борту находились больше 270 человек | LEDE: Пассажирское судно, на борту которого находились больше 270 человек, перевернулось у берегов Сев] (ru: У б…
      Пассажирское судно, на борту которого находились больше 270 человек, перевернулось у берегов Северного Кипра, сообщает Reuters.
  - (2026-08-30) Война. 1649-й день. В результате российского удара по складу боеприпасов под Киевом погибли 38 человек. Бельгия снова выступает против использования активов РФ для поддержки Украины | LEDE: ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-08-30) Закончился сериал «Сто лет одиночества». Если вам не нравится подход к экранизации классики как у Кристофера Нолана, посмотрите этот проект. В нем все ровно так, как было в первоисточнике | LED] (ru:…
      На Netflix завершился второй сезон «Ста лет одиночества», а вместе с ним и сам сериал. Экранизация знаменитого романа Габриэля Гарсиа Маркеса, снятая режиссерами Лаурой Морой Ортегой, Алексом Гарсиа Лопесом и Карлосом Мо…
  - (2026-08-30) Жители Исландии проголосовали против возобновления переговоров о вступлении в Евросоюз | LEDE: В Исландии граждане проголосовали на референдуме за то, чтобы не возобновлять переговоры о всту] (ru: Жит…
      В Исландии граждане проголосовали на референдуме за то, чтобы не возобновлять переговоры о вступлении в Евросоюз, сообщает местная телерадиокомпания RUV.
  - (2026-08-30) Politico и Welt: Германия обвинит Россию в попытке диверсии в аэропорту Лейпцига и введет санкции | LEDE: Канцлер Германии Фридрих Мерц в ближайшие дни планирует обвинить Россию в попытке ди] (ru: Pol…
      Канцлер Германии Фридрих Мерц в ближайшие дни планирует обвинить Россию в попытке диверсии в аэропорту Лейпцига, где были найдены беспилотники со взрывчаткой. Об этом сообщили Politico и Welt am Sonntag со ссылкой на ист…
  - (2026-08-30) Минобороны РФ объявило о начале подготовки к массированным ударам по объектам энергетики Украины | LEDE: Минобороны России объявило, что «в соответствии с полученными указаниями» начало подг] (ru: Мин…
      Минобороны России объявило, что «в соответствии с полученными указаниями» начало подготовку к нанесению массированных ударов по объектам энергетики Украины. Об этом говорится в телеграм-канале ведомства.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 198 new of 286 total
  - (2026-08-28) Caixin Global – Latest China News & Headlines - Caixin Global
      Caixin Global – Latest China News & Headlines Caixin Global
  - (2026-08-28) 景甜发声：不会为钱出卖爱情与灵魂 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1ldDZUaDdqUUFTMFVxRnFFSGpENGFhMWE1RFRRMmtzSnUxQnBJQTJib2lJWnlKU0tBSEN6YXh2UHFIelZJb2VTRFhMWmpfdEpTcXZk] (zh:…
      景甜发声：不会为钱出卖爱情与灵魂 观察者
  - (2026-08-30) 日本首次向印度派战机，冲着中国？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9OM0gwM3BoeUhONlRHSXhDWm9HbVJIYXlmNnFDZmxIVHZ6VkxCQm5PTUtGTGdOUDZQWDZJTUVxQlk2OUQxbnkyZGJ1OTNOM2JMZm5v] (zh:…
      日本首次向印度派战机，冲着中国？ 观察者
  - (2026-08-30) “女子称在电梯间遭猥亵殴打”最新进展：虚构事实，被行拘！ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBsWDFLVC1JQkNnaWZNTGprYk1JaE9wUFhndkpoOFVrd0c5UjVNRGRZYWdrR1RUZHY0eEduQ2VhSHlTU1ZXM3l6OGhk] (zh:…
      “女子称在电梯间遭猥亵殴打”最新进展：虚构事实，被行拘！ 观察者
  - (2026-08-30) “多名乘客高铁二等座变无座”，哈尔滨铁路致歉：将认真汲取教训改进工作 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE9McmIwRzBvOE9Tb2JKeDl5cnotYWNRQXlLSXA4SDg5eWFfcktmbGprb0lFdUZZUm1SUkRxTVJzemZremk1V0] (zh:…
      “多名乘客高铁二等座变无座”，哈尔滨铁路致歉：将认真汲取教训改进工作 观察者
  - (2026-08-30) 西藏吉隆泥石流灾害已致16人遇难，546人失联 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE9FdEl5RC1rdzRwVlNuRWJtZGlaZ2NfQUF6bnZnR2l3NnFoUmI2WmcxTWR6d0NkcGVrZ2gySE5ySl9LbXVpSmJUMVpqb0tiZ] (zh:…
      西藏吉隆泥石流灾害已致16人遇难，546人失联 观察者

### Local News: St. Louis + Atlanta — 109 new of 211 total
  - (2026-08-29) [St. Louis] Picky Cafe opens in Lafayette Square on August 31
      Lafayette Square has a new urban garden, market, and cafe. Picky Cafe (1410 S. 18th) debuts on Monday, August 31, featuring a seasonal menu of breakfast, lunch, baked goods, coffee, and smoothies alongside a retail area…
  - (2026-08-29) [St. Louis] Suspected shooting in Chevys parking lot in Olivette
      Police are responding to a possible shooting Saturday afternoon in the parking lot of a Chevy's restaurant in Olivette, Missouri.
  - (2026-08-30) [St. Louis] William Jewell College mourning sudden passing of football player
      William Jewell College is mourning the sudden loss of a football player Saturday, who died after experiencing a medical emergency on the sideline.
  - (2026-08-29) [St. Louis] Cardinals emcee Todd Thomas - 'That One Guy' - stepping back after 30 years
      Todd Thomas, the St. Louis Cardinals' in-game emcee who famously implores fans to "make some noise," says he is stepping back from his regular gameday duties after 30 seasons.
  - (2026-08-29) [St. Louis] Woman shot, killed Saturday in south St. Louis, police say
      An investigation is underway after a woman was fatally shot Saturday in south St. Louis.
  - (2026-08-30) [St. Louis] Lawsuit challenges St. Louis data center permit over zoning concerns
      A coalition of St. Louis residents and advocacy groups filed a lawsuit Friday that challenges a proposed data center in Midtown.

### State-Level News — 92 new of 412 total
  - (2026-08-29) [California] California lawmakers strike wildfire deal that leaves out most of Newsom’s big demands
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082426-Eaton-Fire-Survivors-MG-CM-13.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-08-29) [California] Governor Newsom statement on compromise to address wildfire risk, support fire survivors, and create stronger accountability
      Source
  - (2026-08-30) [Arkansas] Photo essay: Communities embrace fire to protect against out-of-control blazes
      Story and photos by Alex Brown ROSLYN, Wash. — In less than an hour, this hillside will be ablaze — sparks flying, smoke swirling, the forest floor turning into a black carpet. That’s all part of the plan. Here in the sm…
  - (2026-08-30) [Arkansas] GOP path to retaining US House majority narrowing as midterms near
      WASHINGTON — With less than 70 days until midterm elections, Democrats remain favored to regain the majority in the U.S. House. President Donald Trump’s anemic approval ratings amid the war in Iran, concerns over the eco…
  - (2026-08-30) [Arkansas] Republicans won Arkansas by nationalizing campaigns. Could that strategy backfire?
      Arkansas Republicans began their takeover of the state’s politics 16 years ago by successfully tying Democrats at every level to a president who was deeply unpopular in the state. It didn’t matter whether you were runnin…
  - (2026-08-30) [Arkansas] Voting rights struggle continues, advocates say at March on Washington anniversary
      WASHINGTON — Just over two months from midterm elections and four months removed from a U.S. Supreme Court decision that gutted Voting Rights Act protections for majority Black U.S. House districts, and 63 years after Ma…

### U.S. Weather + Severe / Climate Outlooks — 68 new of 70 total
  - (2026-08-30) [Moderate] Special Weather Statement: Special Weather Statement issued August 30 at 6:28AM MDT by NWS Grand Junction CO
      At 628 AM MDT, Doppler radar was tracking a strong thunderstorm near Green River, moving northeast at 20 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs a…
  - (2026-08-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-30) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued August 30 at 4:22AM AKDT until September 1 at 4:00AM AKDT by NWS Fairbanks AK
      * WHAT...Snow and breezy winds expected. Total snow accumulations of 5 to 8 inches across higher elevations of the Richardson Highway north of Isabel Pass, with heavier amounts above pass level. Winds gusting as high as…
  - (2026-08-30) [Moderate] Gale Warning: Gale Warning issued August 30 at 4:17AM AKDT until August 31 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…
  - (2026-08-30) [Moderate] Gale Warning: Gale Warning issued August 30 at 4:17AM AKDT until August 31 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…
  - (2026-08-30) [Moderate] Gale Warning: Gale Warning issued August 30 at 4:17AM AKDT until August 31 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…

### Ukrainian Internal News (national + local Kyiv) — 52 new of 122 total
  - (2026-08-30) Хмара: Пропонував Федорову спільно продовжити роботу над проєктами | LEDE: Міністр оборони Євгеній Хмара заявив, що пропонував колишньому очільнику відомства Михайлу Федорову знайти формат для ] (uk:…
      Міністр оборони Євгеній Хмара заявив, що пропонував колишньому очільнику відомства Михайлу Федорову знайти формат для продовження спільної роботи над проєктами, однак конкретної посади не пропонував і відповіді не отрима…
  - (2026-08-30) У Ла-Манші затонуло рибальське судно: є зниклі безвісти | LEDE: ] (uk: У Ла-Манші затонуло рибальське судно: є зниклі безвісти)
  - (2026-08-30) На Волині ховають останки вбитих поляків | LEDE: В Острівках перепоховали 55 ексгумованих жертв подій у Волинській області. На церемонії були присутні представники Польщі та України.] (uk: На Волині х…
      В Острівках перепоховали 55 ексгумованих жертв подій у Волинській області. На церемонії були присутні представники Польщі та України.
  - (2026-08-30) Київ удень під атакою дронів: почалась пожежа, медики їдуть на виклик | LEDE: Удень 30 серпня Київ перебуває під атакою російських дронів. У Шевченківському районі виникла пожежа в нежитловій б] (uk:…
      Удень 30 серпня Київ перебуває під атакою російських дронів. У Шевченківському районі виникла пожежа в нежитловій будівлі, а в Голосіївський район викликали медиків.
  - (2026-08-30) "Флеш": Кількість реактивних "Шахедів" зросла на 67% | LEDE: За місяць кількість реактивних "Шахедів", що застосовує Росія проти України, зросла на 67% – із 1500 до понад 2500, повідомив Сергій] (uk:…
      За місяць кількість реактивних "Шахедів", що застосовує Росія проти України, зросла на 67% – із 1500 до понад 2500, повідомив Сергій Бескрестнов.
  - (2026-08-30) У Румунії підняли винищувачі через повітряну ціль біля кордону з Україною | LEDE: ] (uk: У Румунії підняли винищувачі через повітряну ціль біля кордону з Україною)

### Ukraine Theater (total-war monitoring) — 46 new of 236 total
  - (2026-08-30) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-30) [Liveuamap] At Kostiantynivka direction clashes yesterday near Kostyantynivka, Oleksiyevo-Druzhkivka, Illinivka, Novoselivka, Rusyn Yar, Novopavlivka, Sofiyivka, Kucheriv Yar and Dovha Balka, - Genera…
      At Kostiantynivka direction clashes yesterday near Kostyantynivka, Oleksiyevo-Druzhkivka, Illinivka, Novoselivka, Rusyn Yar, Novo
  - (2026-08-25) [Liveuamap] Iranian Foreign Minister Abbas Araqchi meets with his Omani counterpart Badr Al Busaidi in Tehran - iran.liveuamap.com
      Iranian Foreign Minister Abbas Araqchi meets with his Omani counterpart Badr Al Busaidi in Tehran <font colo
  - (2026-08-26) [Liveuamap] Iran's Minister of Energy: We have rebuilt the four power plants that were attacked at the beginning of the war - iran.liveuamap.com
      Iran's Minister of Energy: We have rebuilt the four power plants that were attacked at the beginning of the war &n
  - (2026-08-30) [Liveuamap] Day of news on live map - August, 13 2026 - News and incidents from Belarus in English on live map - Liveuamap
      Day of news on live map - August, 13 2026 - News and incidents from Belarus in English on live map Liveuamap
  - (2026-08-24) [Liveuamap] Day of news on live map - August, 08 2026 - Qatar news on live map - Liveuamap
      Day of news on live map - August, 08 2026 - Qatar news on live map Liveuamap

### State Legislative Action — 36 new of 64 total
  - (2026-08-30) [Alaska SB 19] An Act relating to the use and possession of electronic devices by prisoners.
      An Act relating to the use and possession of electronic devices by prisoners.
  - (2026-08-30) [California SB 1079] Department of Forestry and Fire Protection: Fire Innovation Unit.
      Existing law establishes the Department of Forestry and Fire Protection and establishes various programs for the prevention and reduction of wildfires. This bill, which would be operative until January 1, 2033, and upon…
  - (2026-08-30) [California AB 2414] Developmental services: direct support professionals.
      Existing law, the Lanterman Developmental Disabilities Services Act, requires the State Department of Developmental Services to contract with regional centers for the provision of community services and supports for pers…
  - (2026-08-30) [California AB 1546] Vehicles: driving under the influence.
      Under existing law, if a person is convicted of either driving under the influence (DUI) of any alcoholic beverage or drug, or under the combined influence of any alcoholic beverage and drug or driving while having 0.08%…
  - (2026-08-30) [California AB 1709] Covered platforms: age restriction: e-Safety Advisory Commission.
      Existing law, the Protecting Our Kids from Social Media Addiction Act, prohibits an operator of an addictive internet-based service or application from providing an addictive feed, as defined, to a user unless the operat…
  - (2026-08-30) [California AB 2575] Health care services: artificial intelligence.
      Existing law charges the Labor Commissioner with enforcement of various labor laws, including investigation of employee complaints. This bill would declare it is the policy of the state that a worker providing direct pat…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-30) JAF50T (Bulgaria)
      icao24: 4520d0 · position: (34.0707, -6.7376) · alt: 91m · 244km/h
  - (2026-08-30) JAF94H (Bulgaria)
      icao24: 4520aa · position: (34.3685, -8.8113) · alt: 11269m · 798km/h
  - (2026-08-30) SAMU691 (France)
      icao24: 39c994 · position: (45.7478, 4.9026) · on ground
  - (2026-08-30) GAF901 (Germany)
      icao24: 3ea12c · position: (54.8436, -1.0507) · alt: 12192m · 881km/h
  - (2026-08-30) JAF95N (Belgium)
      icao24: 44d1a6 · position: (43.2799, -1.8876) · alt: 11277m · 737km/h
  - (2026-08-30) JAF6JG (Belgium)
      icao24: 44d1a7 · position: (50.8984, 4.4876) · on ground

### Paper Trading Scorecard — 19 new of 138 total
  - (2026-08-30) [Polymarket] Will Anthropic have the best AI model at the end of September 2026?
      This market will resolve according to the company which owns the model which has the highest arena rank based on the arena.ai Text Arena (Overall) when the table under the "Leaderboard" tab is checked on September 30, 20…
  - (2026-08-30) [Polymarket] US-Iran Hormuz Agreement by September 15?
      This market will resolve to “Yes” if a diplomatic agreement between the United States and Iran over traffic in the strait of Hormuz is announced by the specified date, 11:59 PM ET. A diplomatic agreement refers to an off…
  - (2026-08-30) [Polymarket] Will Anna-Karin Hatt be the next Prime Minister of Sweden?
      Parliamentary elections are scheduled to be held in Sweden on September 13, 2026. This market will resolve to the next individual who is officially appointed and assumes office as Prime Minister of Sweden following the n…
  - (2026-08-30) [Manifold] Will my YouTube Channel have 30 subscribers before the end of September 2026?
  - (2026-08-30) [Manifold] Will Abdul El Sayeds winning margin be greater than Jocelyn Bensons?
  - (2026-08-30) [Manifold] Will there be a new contender on Felony Bench by end of 2026?

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-30) LoL: JD Gaming vs Team WE - Game 4 Winner
      yes price: 0% · 24h volume: $1,586,669 · resolves 2026-08-30
  - (2026-08-30) LoL: JD Gaming vs Team WE - Game 3 Winner
      yes price: 100% · 24h volume: $1,393,984 · resolves 2026-08-30
  - (2026-08-30) Will Sunderland AFC win on 2026-08-30?
      yes price: 42% · 24h volume: $1,320,521 · resolves 2026-08-30
  - (2026-08-30) LoL: JD Gaming vs Team WE (BO5) - LPL Playoffs
      yes price: 0% · 24h volume: $938,771 · resolves 2026-08-30
  - (2026-08-30) Will Brentford FC win on 2026-08-30?
      yes price: 38% · 24h volume: $930,544 · resolves 2026-08-30
  - (2026-08-30) Will Chelsea FC win on 2026-08-30?
      yes price: 52% · 24h volume: $883,294 · resolves 2026-08-30

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-08-30) M 5.8 - Kermadec Islands, New Zealand
      M5.8 · Kermadec Islands, New Zealand · depth 35 km
  - (2026-08-30) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 135.686 km
  - (2026-08-30) M 4.9 - 76 km WNW of Bengkulu, Indonesia
      M4.9 · 76 km WNW of Bengkulu, Indonesia · depth 78.208 km
  - (2026-08-29) M 4.8 - 13 km ENE of Himarë, Albania
      M4.8 · 13 km ENE of Himarë, Albania · depth 10 km
  - (2026-08-29) M 4.8 - 58 km ESE of Koshima, Japan
      M4.8 · 58 km ESE of Koshima, Japan · depth 35 km
  - (2026-08-29) M 4.8 - 184 km SE of Perryville, Alaska
      M4.8 · 184 km SE of Perryville, Alaska · depth 5 km

### IT, InfoSys & cybersecurity news (last 7 days) — 13 new of 56 total
  - (2026-08-30) [The Hacker News] TerminalFix Uses Fake Cloudflare CAPTCHAs to Deploy Reverse-Tunnel Backdoor
      Microsoft has disclosed details of a new ClickFix variant, dubbed TerminalFix, that aims to trick users into running a malicious command in Windows Terminal or PowerShell. "While traditional ClickFix campaigns direct vic…
  - (2026-08-30) [The Register] Turns out Brits would quite like their private messages to stay private
      Polling finds two-thirds don't trust this government, or any future one, with access to their encrypted chats
  - (2026-08-30) [Ars Technica] Inside Meta’s push to put robots to work in data centers
      The company is testing robots on tasks that can performed by technicians.
  - (2026-08-29) [BleepingComputer] Anthropic is cutting Claude Code's current weekly limits by 17%
      Anthropic is permanently increasing Claude Code's standard weekly usage limits by 25% for Pro, Max, Team, and seat-based Enterprise plans, but it's not as good as it sounds. [...]
  - (2026-08-29) [BleepingComputer] Brave browser adds email aliases to help users evade tracking
      The latest version of the Brave browser, 1.94, introduces a feature called 'Email Aliases' that allows users to generate disposable email addresses when signing up to a new service. [...]
  - (2026-08-29) [The Hacker News] Five Critical WordPress Plugin and Theme Flaws Enable Site Takeover or RCE
      Multiple critical security flaws have been disclosed in WordPress plugins and themes, including WPMU DEV Dashboard, Avada, TranslatePress, Pods, and GiveWP, that could lead to authentication bypass, account takeover, and…

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 111 total
  - (2026-08-27) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] Frequently Asked Questions - Recently Updated - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Recently Updated Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 61A Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 61A Authorizing the Supply Office of Foreign Assets Control (.gov)
  - (2026-08-30) [USASpending] $43,198,566,452 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-08-30) [USASpending] $41,519,790,022 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-30) [USASpending] $19,921,853,210 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-08-28) U.S. Court of Appeals, 10th Cir.: United States v. Moon Seals
  - (2026-08-28) U.S. Court of Appeals, 10th Cir.: Cronick v. City of Colorado Springs
  - (2026-08-28) U.S. Court of Appeals, 10th Cir.: Fischer v. XTO Energy
  - (2026-08-28) U.S. Court of Appeals, Federal Cir.: T-Mobile US, Inc. v. Kaifi LLC
  - (2026-08-28) U.S. Court of Appeals, Federal Cir.: Aml Ip, LLC v. Bath & Body Works Direct, Inc.
  - (2026-08-28) U.S. Court of Appeals, 3rd Cir.: Gabriel Buele Morocho v. Warden Philadelphia FDC

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-30) [Marginal Revolution] *Finding Emily*
      I very much enjoyed this British movie, which reminded me of the older-style romantic comedies, namely the ones that actually favor love and romance. It also has themes of class/accent, US/UK, is anti-media, anti-cancel…
  - (2026-08-30) [Marginal Revolution] China fact of the day
      Chinese actors and online influencers have a new rival: cost-effective advanced AI video generation programmes that are threatening millions of jobs in a once-vibrant area of China’s gig economy. The release of powerful…
  - (2026-08-29) [Marginal Revolution] Saturday assorted links
      1. Roger Myerson now has a Substack. 2. The future of higher education? 3. Another look at data centers in space. 4. “The Global Economics Lab is a non-partisan organization located at Harvard and draws on a network of f…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=25, 14d-median=22; carrying terms: public, proposed, management, establish, action, national, certain, temporary, safety, service, amends, unless
- state_bills: today=64, 7d-median=80, 14d-median=118; carrying terms: program, specified, include, authority, services, defined, control, support, development, eligible, emergency, governing
- state_news: today=412, 7d-median=648, 14d-median=632; carrying terms: black, support, across, braun, status, union, records, utility, residents, social, oregon, hampshire
- local_news: today=211, 7d-median=249, 14d-median=243; carrying terms: woman, injured, class, another, trump, falcons, district, google, charged, shooting, games, school
- foreign_news: today=984, 7d-median=1027, 14d-median=1023; carrying terms: organized, black, tallest, square, liberation, weight, burnham, rahul, wooden, strikes, reuters, guiyang
- chinese_internal: today=286, 7d-median=289, 14d-median=289; carrying terms: google, articles, chinese, cbmiaefvx, cbmibefvx, cbmickfvx, cbmix, lxtfa, https, cbmia, lxtfb, people
- russian_internal: today=813, 7d-median=1074, 14d-median=1066; carrying terms: nvidia, europe, street, russian, telegram, reuters, forbidden, politico, novayagazeta, financial, netflix, social
- ukrainian_internal: today=122, 7d-median=122, 14d-median=115; carrying terms: force, takeaways, drones, injured, support, ballistic, across, strikes, major, kremlin, bring, minister
- ukraine_theater: today=236, 7d-median=236, 14d-median=834; carrying terms: wuvwewewswphefvrm, uzaepktlmzulbyrmvdbuz, zngmyouy, afbvv, force, ntfzrmwv, dennbvhsmxbxbgrdsu, iywtlezvlvbw, fqdme, defence, bvewqwsej, takeaways
- paper_bets: today=138, 7d-median=133, 14d-median=133; carrying terms: career, speaker, nuclear, minnesota, mexico, polymarket, georgia, international, control, supervolcano, december, democratic
- weather: today=70, 7d-median=133, 14d-median=144; carrying terms: coastal, streams, morning, include, possible, georgia, statement, watch, across, major, valleys, nation
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: vixcls, payrolls, implied, jtsjol, energy, growth, jolts, cpilfesl, spread, dcoilwtico, dexuseu, dexjpus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, silver, natural, commodities, proxy, russell, large, close, credit, rates, crypto, china
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=108, 14d-median=101; carrying terms: bissau, public, sovereignty, qaida, program, central, mediterranean, aeronautics, square, savannah, embargo, xskfisuh
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, unauthorized, quiver, error, congresstrading, httperror, https, quiverquant, client
- billionaires: today=0, 7d-median=30, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, supreme, delaware, appeals, california, county, company, connecticut, america, thomas, cisneros
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, group, scott, michael, brian, joseph, financial, david, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, disbursements, sherrod, pinkston, committee, cycle, platner, receipts, trone, raised, ocasio, talarico
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=33; carrying terms: english, russian, perimeter, keywords, russia, trump, sanctions, ukrainian, attack, themes, against, strikes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, ground, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: infected, reference, public, fatal, spain, central, circulate, mauritania, nipah, epidemic, confirmed, identification
- cisa_kev: today=20, 7d-median=20, 14d-median=12; carrying terms: remediation, vendor, function, project, command, injection, product, vulnerability, authentication, microsoft, macos, service
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=14, 14d-median=17; carrying terms: depth, indonesia, ruteng, japan, islands, south, region, chile, sandwich, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, interest, august, meeting, september, shakhtar, resolves, volume, price, championship, donetsk, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, marginal, conversable, class, https, economist, demand, number, together, assorted, links, shows
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: against, services, schneier, across, models, technica, world, researchers, companies, cybersecurity, computer, record
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: shelley, levin, hageman, tiffany, durbin, mejia, jennifer, waller, liccardo, elise, womack, escobar
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, evidence, placement, identify, sufficient, decision, consensus, either, markets, converges, market, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*