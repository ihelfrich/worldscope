# WORLDSCOPE morning brief — 2026-08-30

## Headline
2509 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (572) · Ukraine Theater (total-war monitoring) (548) · Russian Internal News (state + in-exile) (509) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (90) · State Legislative Action (79) · State-Level News (70) · U.S. Weather + Severe / Climate Outlooks (67) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (38) · Forbes Real-Time Billionaires (top 30 + biggest movers) (30) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 572 new of 1004 total
  - (2026-08-30) [Global] Humanitarian crisis worsening in refuge for civilians fleeing Sudan’s civil war
  - (2026-08-29) [Global] Was it a mistake for 99 Colombian guerrillas to lay down their arms?
  - (2026-08-30) [Global] Pacific Islands Forum meeting in turmoil after several leaders pull out of Palau summit
  - (2026-08-30) [Global] Renee was at Gyirong Port minutes before flood struck, now her family want to travel from Australia to help search
  - (2026-08-30) [Global] ‘We owe it to history’ to defeat One Nation, PM tells Labor faithful – as it happened
  - (2026-08-30) [Global] One Nation’s Secret Harbour byelection win shows Labor is at a loss when it comes to calming angry voters | Analysis

### Ukraine Theater (total-war monitoring) — 548 new of 569 total
  - (2026-08-30) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-29) [FIRMS] thermal anomaly 52.183, 34.423 (FRP 1.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-29 0052Z, FRP 1.35 MW
  - (2026-08-29) [FIRMS] thermal anomaly 52.181, 34.430 (FRP 2.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-29 0052Z, FRP 2.71 MW
  - (2026-08-29) [FIRMS] thermal anomaly 52.179, 34.420 (FRP 1.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-29 0052Z, FRP 1.85 MW
  - (2026-08-29) [FIRMS] thermal anomaly 52.177, 34.427 (FRP 1.49 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-29 0052Z, FRP 1.49 MW
  - (2026-08-29) [FIRMS] thermal anomaly 52.090, 34.487 (FRP 0.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-29 0052Z, FRP 0.98 MW

### Russian Internal News (state + in-exile) — 509 new of 895 total
  - (2026-08-30) Жители Исландии проголосовали против возобновления переговоров о вступлении в Евросоюз | LEDE: В Исландии граждане проголосовали на референдуме за то, чтобы не возобновлять переговоры о всту] (ru: Жит…
      В Исландии граждане проголосовали на референдуме за то, чтобы не возобновлять переговоры о вступлении в Евросоюз, сообщает местная телерадиокомпания RUV.
  - (2026-08-30) Politico и Welt: Германия обвинит Россию в попытке диверсии в аэропорту Лейпцига и введет санкции | LEDE: Канцлер Германии Фридрих Мерц в ближайшие дни планирует обвинить Россию в попытке ди] (ru: Pol…
      Канцлер Германии Фридрих Мерц в ближайшие дни планирует обвинить Россию в попытке диверсии в аэропорту Лейпцига, где были найдены беспилотники со взрывчаткой. Об этом сообщили Politico и Welt am Sonntag со ссылкой на ист…
  - (2026-08-30) Минобороны РФ объявило о начале подготовки к массированным ударам по объектам энергетики Украины | LEDE: Минобороны России объявило, что «в соответствии с полученными указаниями» начало подг] (ru: Мин…
      Минобороны России объявило, что «в соответствии с полученными указаниями» начало подготовку к нанесению массированных ударов по объектам энергетики Украины. Об этом говорится в телеграм-канале ведомства.
  - (2026-08-30) Что объединяет жителей России, Латвии и Германии? Ненависть к испанским слизням. Рассказываем, откуда на самом деле эти вредители (не из Испании) и как с ними бороться | LEDE: По всей Европе] (ru: Что…
      По всей Европе испанские слизни пожирают урожай и вызывают большие проблемы и у фермеров, и у владельцев обычных огородов. Местные природоохранные ведомства выпускают памятки, как убивать слизней, но этих животных все ра…
  - (2026-08-30) Axios: директор ЦРУ во время визита в Москву предложил провести встречу Трампа, Путина и Зеленского | LEDE: Директор ЦРУ Джон Рэтклифф во время приезда в Москву предлагал провести трехсторон] (ru: Axi…
      Директор ЦРУ Джон Рэтклифф во время приезда в Москву предлагал провести трехстороннюю встречу между президентами США, России и Украины. Об этом сообщает Axios со ссылкой на источники.
  - (2026-08-30) Почти 500 беспилотников сбили над регионами России и Крымом. Украинские телеграм-каналы пишут о пожаре на НПЗ в Ленинградской области | LEDE: Украинские беспилотники в ночь на 30 августа ата] (ru: Поч…
      Украинские беспилотники в ночь на 30 августа атаковали Ленинградскую область. Губернатор региона Александр Дрозденко заявил, что за время атаки сбито 62 дрона.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 90 new of 176 total
  - (2026-08-29) [St. Louis] Picky Cafe opens in Lafayette Square on August 31
      Lafayette Square has a new urban garden, market, and cafe. Picky Cafe (1410 S. 18th) debuts on Monday, August 31, featuring a seasonal menu of breakfast, lunch, baked goods, coffee, and smoothies alongside a retail area…
  - (2026-08-29) [St. Louis] Opponents of St. Louis data center take their fight to court
  - (2026-08-30) [St. Louis] See the Aug. 30, 1926, front page: 18,000 see Pittsburgh take early lead over Cardinals
      Headlines from the Aug. 30, 1926, front page include: Thousands see Valentino's body borne to church
  - (2026-08-30) [St. Louis] Arneson, Norman
      Arneson, Norman
  - (2026-08-30) [St. Louis] Arneson, Norman
      Arneson, Norman Arne
  - (2026-08-30) [St. Louis] Bean, Adelaide
      Bean, Adelaide Blustein Itzkowitz

### State Legislative Action — 79 new of 122 total
  - (2026-08-30) [Alaska SB 19] An Act relating to the use and possession of electronic devices by prisoners.
      An Act relating to the use and possession of electronic devices by prisoners.
  - (2026-08-29) [California SB 113] Budget Act of 2026.
      The Budget Act of 2026 made appropriations for the support of state government for the 2026–27 fiscal year. This bill would amend that budget act by amending, adding, and repealing items of appropriation and making other…
  - (2026-08-29) [California AB 193] Public resources: Greenhouse Gas Reduction Fund: programs.
      The California Global Warming Solutions Act of 2006 requires the State Air Resources Board to adopt regulations for greenhouse gas emissions limits and emissions reduction measures to achieve the maximum technologically…
  - (2026-08-29) [California AB 186] Income taxes: film tax credits.
      (1) The Personal Income Tax Law and the Corporation Tax Law authorize various credits against the taxes imposed by those laws, including various motion picture credits, commonly referred to as motion picture credit 1.0,…
  - (2026-08-29) [California AB 196] School Energy Efficiency Stimulus Program.
      Existing law vests the Public Utilities Commission (PUC) with regulatory authority over public utilities, including electrical corporations and gas corporations. Existing law requires the PUC to require those electrical…
  - (2026-08-29) [California AB 187] Employment.
      (1) Existing law generally grants public employees the right to join employee organizations and to be represented by those organizations in their employment relations. Existing law requires specified public employers to…

### State-Level News — 70 new of 394 total
  - (2026-08-29) [California] Governor Newsom statement on compromise to address wildfire risk, support fire survivors, and create stronger accountability
      Source
  - (2026-08-29) [California] California lawmakers strike wildfire deal that leaves out most of Newsom’s big demands
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082426-Eaton-Fire-Survivors-MG-CM-13.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-08-30) [Connecticut] In Danbury, some are hiding from ICE. Others are following them.
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/Danbury-ICE-0827-SG-06-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpr…
  - (2026-08-30) [Arkansas] Voting rights struggle continues, advocates say at March on Washington anniversary
      WASHINGTON — Just over two months from midterm elections and four months removed from a U.S. Supreme Court decision that gutted Voting Rights Act protections for majority Black U.S. House districts, and 63 years after Ma…
  - (2026-08-30) [Maine] These Mainers spend their Saturdays shopping in stranger’s yards
      <img width="1024" height="683" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/08/43762621_20260822_Yard-Sales_5.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" dec…
  - (2026-08-30) [Maine] CMMC could use a little TLC | Victoria Hugo-Vidal
      <img width="1024" height="838" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/08/43766630_sj_cmhsterile_08263.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decod…

### U.S. Weather + Severe / Climate Outlooks — 67 new of 70 total
  - (2026-08-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-30) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 30 at 4:16AM CDT until August 30 at 5:00AM CDT by NWS Omaha/Valley NE
      SVROAX The National Weather Service in Omaha has issued a * Severe Thunderstorm Warning for... Southwestern Colfax County in northeastern Nebraska... Southern Platte County in northeastern Nebraska... Northwestern Butler…
  - (2026-08-30) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 30 at 4:13AM CDT until August 30 at 5:15AM CDT by NWS Bismarck ND
      SVRBIS The National Weather Service in Bismarck has issued a * Severe Thunderstorm Warning for... North Central McKenzie County in northwestern North Dakota... South Central Williams County in northwestern North Dakota..…
  - (2026-08-30) [Moderate] Special Weather Statement: Special Weather Statement issued August 30 at 4:06AM CDT by NWS Bismarck ND
      At 406 AM CDT /306 AM MDT/, Doppler radar was tracking a strong thunderstorm 8 miles northwest of Watford City, moving northeast at 10 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...Radar indicated.…
  - (2026-08-30) [Moderate] Special Weather Statement: Special Weather Statement issued August 30 at 4:03AM CDT by NWS Bismarck ND
      At 403 AM CDT /303 AM MDT/, Doppler radar was tracking a strong thunderstorm 9 miles northwest of Alexander, or 15 miles south of Williston, moving northeast at 10 mph. HAZARD...Wind gusts up to 40 mph and nickel size ha…
  - (2026-08-30) [Unknown] Air Quality Alert: Air Quality Alert issued August 30 at 4:00AM CDT by NWS Memphis TN
      AQAMEG The Shelby County Health Department has issued a Code Orange Ozone Forecast effective for Shelby County Tennessee, Crittenden County Arkansas, and DeSoto County Mississippi, including the city of Memphis for today…

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-30) [Philippines] False hospice enrollments disrupt care for California seniors as fraud crackdown widens Dateline united states
      domain: asianjournal.com · language: English · tone:
  - (2026-08-30) [United Kingdom] No early release for Pc Harper killers after release scheme change
      domain: maldonandburnhamstandard.co.uk · language: English · tone:
  - (2026-08-30) [Australia] The Cairo Bridal Shop by Tess Woods : How the author Egyptian heritage shaped her latest book
      domain: brisbanetimes.com.au · language: English · tone:
  - (2026-08-30) [India] Nepal tragedy : Death toll reaches 734 ; over 275 Indians missing | Rediff - TV
      domain: tv.rediff.com · language: English · tone:
  - (2026-08-30) [Ireland] Man ( 40s ) dies after being struck by van in Co Sligo
      domain: meathchronicle.ie · language: English · tone:
  - (2026-08-30) [United States] Nepal warns of more possible floods as communities grapple with devastation
      domain: durangoherald.com · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 38 new of 111 total
  - (2026-08-30) Глава УГКЦ закликав українців до єдності: Війну виграє або програє весь народ | LEDE: ] (uk: Глава УГКЦ закликав українців до єдності: Війну виграє або програє весь народ)
  - (2026-08-30) Генштаб: Сили оборони уразили Кіришський НПЗ та аеродром "Єйськ" | LEDE: Під ударами Сил оборони опинилися Кіришський нафтопереробний завод, аеродром "Єйськ" і склад БпЛА у Міллерово – підтверд] (uk:…
      Під ударами Сил оборони опинилися Кіришський нафтопереробний завод, аеродром "Єйськ" і склад БпЛА у Міллерово – підтверджені пожежі на об'єктах.
  - (2026-08-30) Зеленський: У селі Мила зросла кількість загиблих унаслідок удару РФ | LEDE: Унаслідок російського удару по селу Мила Київщини загинули 38 людей, ще 20 постраждали, четверо зникли безвісти. Сер] (uk:…
      Унаслідок російського удару по селу Мила Київщини загинули 38 людей, ще 20 постраждали, четверо зникли безвісти. Серед поранених – двоє дітей.
  - (2026-08-30) У Швейцарії сталася стрілянина на вечірці: є загиблий | LEDE: ] (uk: У Швейцарії сталася стрілянина на вечірці: є загиблий)
  - (2026-08-30) У Чехії під час демонстрації військової техніки перекинувся автомобіль: є постраждалі | LEDE: У Чехії під час демонстрації військової техніки у Військово-технічному музеї в Лешанах перекинувся ] (uk:…
      У Чехії під час демонстрації військової техніки у Військово-технічному музеї в Лешанах перекинувся броньований автомобіль Tatra Tadeas, внаслідок чого дві людини отримали поранення.
  - (2026-08-30) Росіяни атакували портову інфраструктуру Миколаєва | LEDE: 29 серпня російські війська атакували портову та енергетичну інфраструктуру Миколаєва дронами Shahed і ракетами. Постраждалих немає.] (uk: Ро…
      29 серпня російські війська атакували портову та енергетичну інфраструктуру Миколаєва дронами Shahed і ракетами. Постраждалих немає.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-08-30) #1 Elon Musk — $873.11B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-08-30) #2 Larry Page — $282.99B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-30) #3 Jeff Bezos — $273.52B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-08-30) #4 Sergey Brin — $261.05B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-30) #5 Michael Dell — $240.42B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-08-30) #6 Mark Zuckerberg — $198.51B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 21 new of 21 total
  - (2026-08-30) CFC2987 (Canada)
      icao24: c2b5b7 · position: (46.4034, 23.9495) · alt: 861m · 305km/h
  - (2026-08-30) JAF9CK (Belgium)
      icao24: 44d1a6 · position: (49.5224, 2.3696) · alt: 9951m · 937km/h
  - (2026-08-30) JAF3LV (Belgium)
      icao24: 44d1a7 · position: (40.2831, 7.8296) · alt: 11582m · 809km/h
  - (2026-08-30) JAF3NE (Belgium)
      icao24: 44d1a5 · position: (46.8358, 0.3583) · alt: 10363m · 863km/h
  - (2026-08-30) JAF63N (Belgium)
      icao24: 44d1b3 · position: (47.9569, 1.4188) · alt: 10363m · 908km/h
  - (2026-08-30) JAF66L (Belgium)
      icao24: 44d1b4 · position: (47.8955, 1.1819) · alt: 10363m · 886km/h

### Paper Trading Scorecard — 20 new of 140 total
  - (2026-08-30) [Polymarket] US-Iran Hormuz Agreement by September 15?
      This market will resolve to “Yes” if a diplomatic agreement between the United States and Iran over traffic in the strait of Hormuz is announced by the specified date, 11:59 PM ET. A diplomatic agreement refers to an off…
  - (2026-08-30) [Polymarket] Will Carlos Alcaraz win the 2026 Men's US Open?
      The 2026 U.S. Open tennis tournament is scheduled for August 23 - September 13, 2026. This market will resolve to the player that wins the 2026 U.S. Open Men’s Singles Tournament. If at any point it becomes impossible fo…
  - (2026-08-30) [Polymarket] Will Anna-Karin Hatt be the next Prime Minister of Sweden?
      Parliamentary elections are scheduled to be held in Sweden on September 13, 2026. This market will resolve to the next individual who is officially appointed and assumes office as Prime Minister of Sweden following the n…
  - (2026-08-30) [Manifold] Snap market: will my friend make it to the train station by 10 AM??
  - (2026-08-30) [Manifold] Will my YouTube Channel have 30 subscribers before the end of September 2026?
  - (2026-08-30) [Manifold] Will Abdul El Sayeds winning margin be greater than Jocelyn Bensons?

### Court opinions of consequence (federal & state) — 14 new of 60 total
  - (2026-08-28) U.S. Court of Appeals, 10th Cir.: United States v. Moon Seals
  - (2026-08-28) U.S. Court of Appeals, 10th Cir.: Cronick v. City of Colorado Springs
  - (2026-08-28) U.S. Court of Appeals, 10th Cir.: Fischer v. XTO Energy
  - (2026-08-28) U.S. Court of Appeals, 3rd Cir.: Gabriel Buele Morocho v. Warden Philadelphia FDC
  - (2026-08-28) U.S. Court of Appeals, 3rd Cir.: Patrick Santoro v. Tower Health
  - (2026-08-28) Hawaii Supreme Court: Iwasa v. Nago

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-08-30) LoL: Dplus KIA vs KT Rolster - Game 1 Winner
      yes price: 0% · 24h volume: $1,079,747 · resolves 2026-08-30
  - (2026-08-30) Counter-Strike: G2 vs Natus Vincere (BO3) - BLAST Open Porto Group A
      yes price: 52% · 24h volume: $636,035 · resolves 2026-08-30
  - (2026-08-30) Will Colorado Rapids SC win on 2026-08-29?
      yes price: 100% · 24h volume: $617,103 · resolves 2026-08-30
  - (2026-08-30) LoL: JD Gaming vs Team WE - Game 1 Winner
      yes price: 14% · 24h volume: $561,522 · resolves 2026-08-30
  - (2026-08-30) Will Chelsea FC win on 2026-08-30?
      yes price: 50% · 24h volume: $481,089 · resolves 2026-08-30
  - (2026-08-30) Will Bitcoin reach $100,000 in August?
      yes price: 0% · 24h volume: $457,852 · resolves 2026-09-01

### USGS earthquakes (M4.5+, past day) — 12 new of 13 total
  - (2026-08-30) M 5.8 - Kermadec Islands, New Zealand
      M5.8 · Kermadec Islands, New Zealand · depth 35 km
  - (2026-08-30) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 135.686 km
  - (2026-08-30) M 4.9 - 76 km WNW of Bengkulu, Indonesia
      M4.9 · 76 km WNW of Bengkulu, Indonesia · depth 78.208 km
  - (2026-08-29) M 4.8 - 13 km ENE of Himarë, Albania
      M4.8 · 13 km ENE of Himarë, Albania · depth 10 km
  - (2026-08-29) M 4.8 - 58 km ESE of Koshima, Japan
      M4.8 · 58 km ESE of Koshima, Japan · depth 35 km
  - (2026-08-29) M 4.8 - 184 km SE of Perryville, Alaska
      M4.8 · 184 km SE of Perryville, Alaska · depth 5 km

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 56 total
  - (2026-08-30) [The Hacker News] TerminalFix Uses Fake Cloudflare CAPTCHAs to Deploy Reverse-Tunnel Backdoor
      Microsoft has disclosed details of a new ClickFix variant, dubbed TerminalFix, that aims to trick users into running a malicious command in Windows Terminal or PowerShell. "While traditional ClickFix campaigns direct vic…
  - (2026-08-30) [The Register] Turns out Brits would quite like their private messages to stay private
      Polling finds two-thirds don't trust this government, or any future one, with access to their encrypted chats
  - (2026-08-29) [BleepingComputer] Anthropic is cutting Claude Code's current weekly limits by 17%
      Anthropic is permanently increasing Claude Code's standard weekly usage limits by 25% for Pro, Max, Team, and seat-based Enterprise plans, but it's not as good as it sounds. [...]
  - (2026-08-29) [BleepingComputer] Brave browser adds email aliases to help users evade tracking
      The latest version of the Brave browser, 1.94, introduces a feature called 'Email Aliases' that allows users to generate disposable email addresses when signing up to a new service. [...]
  - (2026-08-29) [The Hacker News] Five Critical WordPress Plugin and Theme Flaws Enable Site Takeover or RCE
      Multiple critical security flaws have been disclosed in WordPress plugins and themes, including WPMU DEV Dashboard, Avada, TranslatePress, Pods, and GiveWP, that could lead to authentication bypass, account takeover, and…
  - (2026-08-29) [The Register] AWS mumbles about its cost-busting networking tech when it should be shouting
      A lot of datacenter networks are run by absolute clowns. Not Amazon's

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 87 total
  - (2026-08-30) [USASpending] $43,198,566,452 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-08-30) [USASpending] $41,519,790,022 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-30) [USASpending] $19,921,853,210 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-08-30) [USASpending] $17,654,763,333 → HONEYWELL FEDERAL MANUFACTURING & TECHNOLOGIES, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SEC
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SECURITY CAMPUS -- CONTRACT NO. DE-NA0002839
  - (2026-08-30) [USASpending] $11,030,452,830 → ALLIANCE FOR ENERGY INNOVATION, LLC: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWAB
      Agency: Department of Energy. Description: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWABLE ENERGY LABORATORY
  - (2026-08-30) [USASpending] $2,744,085,731 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### Chinese Internal News — 6 new of 21 total
  - (2026-08-30) Will Hong Kong see fewer creditor-led commercial property sales as assets stabilise?
  - (2026-08-30) JD.com’s US$1.3b expansion could test Hong Kong’s footfall-driven retail property model
  - (2026-08-30) [feed error] Caixin 财新 (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Acaixin.com&hl=zh-CN&gl=CN&ceid=CN:zh-Hans
  - (2026-08-30) [feed error] People's Daily 人民日报 (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Apeople.com.cn+OR+site%3Apeople.cn&hl=zh-CN&gl=CN&ceid=CN:zh-Hans
  - (2026-08-30) [feed error] Guancha 观察者网 (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Aguancha.cn&hl=zh-CN&gl=CN&ceid=CN:zh-Hans
  - (2026-08-30) [feed error] Caixin Global (via Google News): HTTPError
      503 Server Error: Service Unavailable for url: https://news.google.com/rss/search?q=site%3Acaixinglobal.com&hl=en-US&gl=US&ceid=US:en

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-30) [Marginal Revolution] *Finding Emily*
      I very much enjoyed this British movie, which reminded me of the older-style romantic comedies, namely the ones that actually favor love and romance. It also has themes of class/accent, US/UK, is anti-media, anti-cancel…
  - (2026-08-30) [Marginal Revolution] China fact of the day
      Chinese actors and online influencers have a new rival: cost-effective advanced AI video generation programmes that are threatening millions of jobs in a once-vibrant area of China’s gig economy. The release of powerful…
  - (2026-08-29) [Marginal Revolution] Saturday assorted links
      1. Roger Myerson now has a Substack. 2. The future of higher education? 3. Another look at data centers in space. 4. “The Global Economics Lab is a non-partisan organization located at Harvard and draws on a network of f…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=25, 14d-median=21; carrying terms: national, public, certain, action, management, proposed, establish, safety, specifically, service, unless, temporary
- state_bills: today=122, 7d-median=92, 14d-median=128; carrying terms: persons, pursuant, contact, medical, based, requiring, court, district, county, support, prescribed, commission
- state_news: today=394, 7d-median=648, 14d-median=614; carrying terms: legislative, flgov, nonprofit, costs, green, latest, based, arizona, indiana, beach, building, district
- local_news: today=176, 7d-median=249, 14d-median=240; carrying terms: injured, following, national, sheriff, august, student, court, family, public, district, county, games
- foreign_news: today=1004, 7d-median=1027, 14d-median=1014; carrying terms: prosecutors, costs, sslerror, green, missile, latest, student, bachelor, plateau, congress, district, nantong
- chinese_internal: today=21, 7d-median=289, 14d-median=286; carrying terms: https, china, chinese, people, google, global, caixin, billion, mainland, surge, growth, property
- russian_internal: today=895, 7d-median=1074, 14d-median=1048; carrying terms: reuters, client, netflix, forbidden, title, httperror, politico, journal, telegram, media, russian, novayagazeta
- ukrainian_internal: today=111, 7d-median=112, 14d-median=113; carrying terms: overnight, aerial, national, missile, august, latest, update, reportedly, since, confirmed, media, support
- ukraine_theater: today=569, 7d-median=569, 14d-median=838; carrying terms: viirs, campaign, functions, firms, cartography, takeaways, client, snapshot, community, strike, deepstatemap, extra
- paper_bets: today=140, 7d-median=133, 14d-median=134; carrying terms: speaker, seats, artist, guilty, kalshi, johnson, break, manifold, total, recognized, otherwise, become
- weather: today=70, 7d-median=133, 14d-median=144; carrying terms: overnight, showers, afternoon, pinal, following, temperatures, effective, holly, pressure, flood, morning, humid
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: personal, implied, dexuseu, balance, walcl, vixcls, sheet, cpiaucsl, cpilfesl, energy, dcoilwtico, commodities
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, crypto, rates, credit, futures, close, crude, treasury, natural, large, range, china
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=87, 7d-median=105, 14d-median=100; carrying terms: recognition, entity, myanmar, rkiye, hybrid, events, legislation, independence, systems, illegal, sevastopol, national
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quiver, httperror, error, unauthorized, congresstrading, client, quantitative, quiverquant
- billionaires: today=30, 7d-median=30, 14d-median=34; carrying terms: amazon, arnault, julia, ortega, amancio, devasini, retail, metals, brokerage, charles, thomas, tiktok
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, appeals, america, connecticut, company, county, thomas, smith, international, cisneros
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, group, scott, robert, michael, brian, financial, david, joseph
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jonathan, robert, cycle, platner, committee, receipts, cortez, michael, angels, house, sherrod, johnson
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=41; carrying terms: english, keywords, trump, themes, perimeter, ukrainian, sanctions, russian, russia, attack, spanish, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, english, kingdom, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, ground, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: different, however, ebola, seven, aboard, bites, chikungunya, broader, individuals, individual, generation, woman
- cisa_kev: today=20, 7d-median=20, 14d-median=12; carrying terms: microsoft, command, injection, remediation, authentication, function, vulnerability, product, vendor, project, service, double
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=14, 14d-median=18; carrying terms: depth, indonesia, islands, japan, south, region, chile, sandwich, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: donetsk, champions, championship, september, rates, meeting, interest, resolves, shakhtar, league, price, august
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, marginal, revolution, https, class, economist, demand, number, together, shows, links, assorted
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: breach, patch, report, researchers, attacks, critical, hacker, around, across, https, agency, computerweekly
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: gillibrand, carol, timothy, fitzpatrick, schmitt, fernandez, murkowski, bryan, mario, garcia, michelle, marco
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, either, converges, placed, placement, market, consensus, evidence, paper, unavailable, claude, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*