# WORLDSCOPE morning brief — 2026-08-14

## Headline
4757 new items across 26 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (1118) · Russian Internal News (state + in-exile) (864) · International News + Multilateral Institutions (811) · State-Level News (481) · World leaders & government officials (324) · Chinese Internal News (234) · Local News: St. Louis + Atlanta (227) · U.S. Weather + Severe / Climate Outlooks (197) · State Legislative Action (126) · Ukrainian Internal News (national + local Kyiv) (72) · IT, InfoSys & cybersecurity news (last 7 days) (44) · Court opinions of consequence (federal & state) (42)

## What changed today
### Ukraine Theater (total-war monitoring) — 1118 new of 1487 total
  - (2026-08-14) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-13) [FIRMS] thermal anomaly 50.894, 34.213 (FRP 16.99 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 0900Z, FRP 16.99 MW
  - (2026-08-13) [FIRMS] thermal anomaly 50.897, 34.214 (FRP 20.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 0900Z, FRP 20.41 MW
  - (2026-08-13) [FIRMS] thermal anomaly 50.892, 34.204 (FRP 12.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 0900Z, FRP 12.76 MW
  - (2026-08-13) [FIRMS] thermal anomaly 45.259, 31.673 (FRP 10.99 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 1038Z, FRP 10.99 MW
  - (2026-08-13) [FIRMS] thermal anomaly 45.354, 30.903 (FRP 3.07 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 1038Z, FRP 3.07 MW

### Russian Internal News (state + in-exile) — 864 new of 1249 total
  - (2026-08-14) Консорциум Безоса купил долю в футбольном клубе «Ливерпуль» | LEDE: Консорциум инвесторов, куда входит основатель Amazon Джефф Безос, купил миноритарную долю английского футбольного клуба «Л] (ru: Кон…
      Консорциум инвесторов, куда входит основатель Amazon Джефф Безос, купил миноритарную долю английского футбольного клуба «Ливерпуль».
  - (2026-08-14) В Москве прошел обыск в клинике Василия Генералова. Там «лечат аутизм» изгнанием паразитов | LEDE: В Москве следователи пришли с обыском в клинику «ПланетаМед» Василия Генералова в рамках уг] (ru: В М…
      В Москве следователи пришли с обыском в клинику «ПланетаМед» Василия Генералова в рамках уголовного дела о мошенничестве и причинении тяжкого вреда здоровью по неосторожности.
  - (2026-08-14) Луиджи Манджоне признал вину по делу об убийстве главы страховой компании UnitedHealthcare Брайана Томпсона | LEDE: Луиджи Манджоне, обвиняемый по делу об убийстве гендиректора страховой ком] (ru: Луи…
      Луиджи Манджоне, обвиняемый по делу об убийстве гендиректора страховой компании UnitedHealthcare Брайана Томпсона в 2024 году, признал в федеральном суде свою вину.
  - (2026-08-14) Bloomberg: США решили проверить союзников по НАТО на лояльность политике Трампа | LEDE: Администрация США разослала союзникам по НАТО опросник, чтобы оценить их уровень поддержки внешней пол] (ru: Blo…
      Администрация США разослала союзникам по НАТО опросник, чтобы оценить их уровень поддержки внешней политики лидера Соединенных Штатов Дональда Трампа, сообщает Bloomberg 14 августа.
  - (2026-08-14) Reuters: нефтяной терминал «Шесхарис» в Новороссийске остановил работу из-за атак украинских беспилотников | LEDE: Нефтяной терминал «Шесхарис» в черноморском порту Новороссийск остановил ра] (ru: Reu…
      Нефтяной терминал «Шесхарис» в черноморском порту Новороссийск остановил работу после атаки украинских беспилотников, сообщили источники Reuters.
  - (2026-08-14) В Берлине открылся бесплатный общественный бассейн. Из-за неудачной формулировки на сайте он сразу же оказался в центре расистского скандала | LEDE: В Берлине бесплатный общественный бассейн] (ru: В Б…
      В Берлине бесплатный общественный бассейн, открытый несколько дней назад перед театром Volksbühne, временно закрыли на целый день на фоне скандала, вызванного слухами, что в этот день туда будут пускать только темнокожих…

### International News + Multilateral Institutions — 811 new of 1076 total
  - (2026-08-14) [Global] Teenage British cyclist Finlay ⁠Tarling dies in Tour of Portugal accident
      19-year-old British cyclist Finlay ⁠Tarling died ​following a "serious accident" during the eighth stage ​of the Tour of Portugal race, tour organisers and his team said on Friday.
  - (2026-08-14) [Global] Kenya: Mysterious illness kills more than a dozen elephants
      In Kenya, since the end of June, at least 19 elephants, mostly females or young animals, have died after displaying the same symptoms, notably partial paralysis preventing them from standing.
  - (2026-08-14) [Global] Race to free trapped quake survivor offers hope in Colombia
      Rescue workers rushed to free a survivor Friday in Colombia amid the rubble left by a powerful earthquake nearly four days earlier that killed at least 285 people and injured 4,000. Some 400 people were still missing and…
  - (2026-08-14) [Global] Europe: Raging wildfires scorch large swaths of the continent
      Firefighters across Europe battled multiple fires August 14 as a new wave of record-breaking heat baked a swath of the continent. The historic temperatures are linked to human-caused climate change, and are hitting count…
  - (2026-08-14) [Global] France wildfire forces 520 to evacuate
      Around 520 residents in France’s southwestern Landes region have been evacuated as a raging wildfire has burned through more than 1,000 hectares since Thursday. Significant reinforcements have been mobilised, while autho…
  - (2026-08-14) [Global] France blocks under 15 social media ban
      France’s Constitutional Council has blocked a bill that would have banned social media access for under-15s, ruling that it infringed on freedom of expression. It’s a setback for President Emmanuel Macron, who has champi…

### State-Level News — 481 new of 813 total
  - (2026-08-14) [California] IBank closes $236 million in bond financing for La Brea Tar Pits Reimagine Project
      Source
  - (2026-08-13) [California] ICYMI: California takes historic action against data brokers
      <a href="https://www.gov.ca.gov/2026/08/13/icymi-california-takes-hist
  - (2026-08-13) [California] As Trump’s EPA silences youth voices, California launches new Environmental Youth Council to shape our climate future
      Source
  - (2026-08-13) [California] Mientras la EPA de Trump silencia las voces de los jóvenes, California lanza un nuevo Consejo Asesor Juvenil Ambiental para ayudar a definir nuestro futuro climático
      Source
  - (2026-08-14) [California] Where’d the birds go? Federal staffing cuts hit CA refuge
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/081326_San_Joaquin_River-FL-DRW-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-08-14) [California] Interested in how California pays for state government? Here’s where to find the data
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 234 new of 286 total
  - (2026-08-13) 改革者图鉴： 历史镜头里的朱镕基 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1YSGJ0OEoybm5OMTdESm4wWEVKT3kySDVoeExFU3R0aXEtaGs3YmY1bzhfRGJxTnJsY2VKR0p1aHp0ZzB0Y2k1cWhPWjNGTlJfdkMtT] (zh:…
      改革者图鉴： 历史镜头里的朱镕基 财新
  - (2026-08-12) 富途老虎期权内幕交易案锁定45人 共获利1.55亿美元(含视频) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5JZm94ZnV4SHVYVjIxa25nR0JDeHdXMzNCaGxsS1VfenZsRkdMbW9CZ0hlTEVYWjNHaXRrbW1WbHFuMnNTaHZRS] (zh:…
      富途老虎期权内幕交易案锁定45人 共获利1.55亿美元(含视频) 财新
  - (2026-08-13) 财经早知道｜长鑫科技赶超腾讯，成中国大陆市值最高上市公司 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBTcnRuSWplcldXcUUtUHNhd2NOQXJCX1pHVWFRS0tXQkdwckMtU0NYOHdEVXNkRlZlcmlOMDZJTUZJSGFxZ1g5Y2Q1V] (zh:…
      财经早知道｜长鑫科技赶超腾讯，成中国大陆市值最高上市公司 财新
  - (2026-08-14) 今日开盘：小幅高开 沪指涨幅0.08% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1Lckt0NjhGY3BVcldBRy1oSnNhNXc0S3pYTDlYdEpDUjQtbFR5TGFQTXZnekpMZ3oxaFlUVW1JRnFVa0JUVExuczNSRWdSTWdXTX] (zh:…
      今日开盘：小幅高开 沪指涨幅0.08% 财新
  - (2026-08-13) T早报｜国补退坡京东二季度收入下滑；三家外卖平台将在京执行“红灯停表”；DeepSeek-V4-Pro正式版上线 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1kcllIbUgtV1FiU0w2XzFMQWk2ZTQ0NHBsNmlXZVdqZzJQcE54di1KNjdMdFJad] (zh:…
      T早报｜国补退坡京东二季度收入下滑；三家外卖平台将在京执行“红灯停表”；DeepSeek-V4-Pro正式版上线 财新
  - (2026-08-14) 武大靖执教，中国短道速滑能否弯道超车？｜体坛 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFAzOFhSbWhQRnBHVlE1V0JhUVpnWHdySENyLUxldThKX0VyTGc4SFR2RUlQSGpXek15RU5uOGZBSzE3OHVZdlBGSmMteXRISDJ] (zh:…
      武大靖执教，中国短道速滑能否弯道超车？｜体坛 财新

### Local News: St. Louis + Atlanta — 227 new of 255 total
  - (2026-08-14) [St. Louis] Ask George: When I see that a restaurant is having a soft opening, does that mean it’s open to the public?
      When I see that a restaurant is having a soft opening, does that mean it’s open to the public? —Nora M., St. Louis The term “soft opening” is a nebulous moniker that’s become even more so over the years, so the short ans…
  - (2026-08-14) [St. Louis] What’s True in the Lou? – 8/14/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-08-13) [St. Louis] Saint Louis Club contemplates closure over financial woes
      For nearly six decades, the private Saint Louis Club enjoyed one of the best views in the town—and cuisine to match. But the venerable club is facing mounting financial pressure after what some members say was an ill-adv…
  - (2026-08-13) [St. Louis] Where to hear live jazz in St. Louis
      Looking for a taste of jazz this weekend? This weekend marks the third annual CWE Jazz & Blues Festival on Saturday, August 15, from 1–7 p.m. The free, outdoor celebration brings together music, culture, and community. A…
  - (2026-08-13) [St. Louis] Lillian Stephen brings abstractly beautiful printmaking to the Kranzberg Gallery with ‘A Hum Beneath the Surface’
      The Kranzberg Gallery (501 N. Grand) is welcoming Lillian Stephen, printmaker and owner of L.C.Q.K.S., a shop specializing in beautifully designed fabric products, to host her first solo exhibition, A Hum Beneath the Sur…
  - (2026-08-13) [St. Louis] Elected official’s text message sends St. Louis data center vote into disarray
      Another dose of disarray was injected into the City of St. Louis’ effort to regulate data centers Wednesday. A city planning commission meeting abruptly went into recess after Don Roe, the executive director of planning…

### U.S. Weather + Severe / Climate Outlooks — 197 new of 198 total
  - (2026-08-14) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 14 at 4:18PM EDT until August 14 at 5:45PM EDT by NWS Tallahassee FL
      SVRTAE The National Weather Service in Tallahassee has issued a * Severe Thunderstorm Warning for... Mitchell County in southwestern Georgia... * Until 545 PM EDT. * At 418 PM EDT, a severe thunderstorm was located 8 mil…
  - (2026-08-14) [Moderate] Special Weather Statement: Special Weather Statement issued August 14 at 2:18PM MDT by NWS Pueblo CO
      At 218 PM MDT, Doppler radar was tracking a strong thunderstorm near Trinidad, moving northeast at 20 mph. HAZARD...Wind gusts up to 50 mph, brief penny size hail and torrential rainfall. SOURCE...Radar indicated. IMPACT…
  - (2026-08-14) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-14) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 14 at 1:17PM PDT until August 14 at 2:00PM PDT by NWS Las Vegas NV
      SVRVEF The National Weather Service in Las Vegas has issued a * Severe Thunderstorm Warning for... West Central Mohave County in northwestern Arizona... Southeastern Clark County in southern Nevada... * Until 200 PM PDT…
  - (2026-08-14) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 14 at 4:17PM EDT until August 14 at 4:30PM EDT by NWS Melbourne FL
      At 417 PM EDT, a severe thunderstorm was located over Austin Tindall Park, or near Buena Ventura Lakes, moving southwest at 10 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, s…
  - (2026-08-14) [Moderate] Special Weather Statement: Special Weather Statement issued August 14 at 4:16PM EDT by NWS Jacksonville FL
      At 415 PM EDT, Doppler radar was tracking a strong thunderstorm 7 miles southeast of Hastings, moving southeast at 10 mph. HAZARD...Wind gusts around 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock dow…

### State Legislative Action — 126 new of 129 total
  - (2026-08-13) [Alaska HB 309] An Act relating to the boundaries of the Jonesville Public Use Area; and providing for an effective date.
      An Act relating to the boundaries of the Jonesville Public Use Area; and providing for an effective date.
  - (2026-08-13) [Alaska HB 367] An Act relating to the privacy of consumer personal information; establishing the Consumer Personal Information Privacy Act; establishing data broker registration requirements; relatin…
      An Act relating to the privacy of consumer personal information; establishing the Consumer Personal Information Privacy Act; establishing data broker registration requirements; relating to social security numbers; making…
  - (2026-08-13) [Alaska HB 234] An Act relating to emergency medical dispatchers; classifying dispatchers in police or fire departments and in state trooper offices as peace officers under the public employees' retir…
      An Act relating to emergency medical dispatchers; classifying dispatchers in police or fire departments and in state trooper offices as peace officers under the public employees' retirement system; and providing for an e…
  - (2026-08-13) [Alaska HJR 23] Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
      Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
  - (2026-08-13) [Alaska HB 286] An Act relating to an optional municipal tax exemption for the homes of volunteer firefighters and volunteer providers of emergency medical services or mobile intensive care paramedic…
      An Act relating to an optional municipal tax exemption for the homes of volunteer firefighters and volunteer providers of emergency medical services or mobile intensive care paramedic services; and providing for an effec…
  - (2026-08-12) [Alaska HJR 41] Rescinding all previous requests by the Alaska State Legislature to call for a constitutional convention under art. V of the Constitution of the United States.
      Rescinding all previous requests by the Alaska State Legislature to call for a constitutional convention under art. V of the Constitution of the United States.

### Ukrainian Internal News (national + local Kyiv) — 72 new of 125 total
  - (2026-08-14) У Румунії вчетверте за день знайшли уламки дрона | LEDE: Міністерство оборони Румунії повідомило про виявлення уламків ще одного безпілотника в селі Плауру, що у прикордонному повіті Тулча.] (uk: У Ру…
      Міністерство оборони Румунії повідомило про виявлення уламків ще одного безпілотника в селі Плауру, що у прикордонному повіті Тулча.
  - (2026-08-14) Директора CEO Club, затриманого у Польщі "за крадіжку велосипедів", звільнили | LEDE: Засновник і президент CEO Club Ukraine Сергій Гайдачук заявив, що Німеччина відкликала Європейський ордер н] (uk:…
      Засновник і президент CEO Club Ukraine Сергій Гайдачук заявив, що Німеччина відкликала Європейський ордер на арешт директора бізнес-спільноти CEO Club Ukraine Дмитра Карчука, якого утримували в Польщі нібито за "крадіжку…
  - (2026-08-14) У "Хартії" повідомили про приєднання до адвокатської програми Єрмака | LEDE: Корпус "Хартія" заявив, що 8 підрозділів долучилися до програми "Адвокат+", яку започаткував екскерівник Офісу прези] (uk:…
      Корпус "Хартія" заявив, що 8 підрозділів долучилися до програми "Адвокат+", яку започаткував екскерівник Офісу президента Андрій Єрмак.
  - (2026-08-14) Були агресивні і били українців – у Польщі затримали двох жінок | LEDE: 14 серпня у польському місті Познань поліція затримала двох жінок, які поводилися агресивно щодо громадян України біля ре] (uk:…
      14 серпня у польському місті Познань поліція затримала двох жінок, які поводилися агресивно щодо громадян України біля ресторану.
  - (2026-08-14) Президент заслухав доповідь головкома: говорили про посилення напрямків Слов’янська та Костянтинівки | LEDE: Президент Володимир Зеленський 14 серпня визначив із головнокомандувачем ЗСУ Михайло] (uk:…
      Президент Володимир Зеленський 14 серпня визначив із головнокомандувачем ЗСУ Михайлом Драпатим кроки, щоб посилити напрямки Слов'янська та Костянтинівки.
  - (2026-08-14) У США кажуть, що Канада має скасувати торговельні обмеження, щоб уникнути нових мит | LEDE: Торговий представник США Джеймісон Грір заявив, що Канада повинна скасувати свої торговельні заходи у] (uk:…
      Торговий представник США Джеймісон Грір заявив, що Канада повинна скасувати свої торговельні заходи у відповідь проти американських товарів, щоб уникнути нових мит з боку Білого дому, які мають набути чинності наступного…

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 58 total
  - (2026-08-14) [Krebs on Security] Who’s Tracking You? Use This New Service to Find Out
      It can be daunting to determine who's responsible for showing ads on the websites we visit, or who's harvesting data from the mobile apps we use every day. That information is already semi-public, but it is not easily pa…
  - (2026-08-14) [BleepingComputer] Hackers arrested over €30M bank fraud exploiting service provider flaw
      Four cybercriminals were arrested in Brazil, and three others were charged in Europe over allegations that they exploited a vulnerability at a service provider, allowing them to withdraw funds from Commerzbank customers'…
  - (2026-08-14) [BleepingComputer] Hackers exploit macOS Screen Sharing flaw to deploy Monero miner
      The Netherlands' National Cyber Security Centre (NCSC) is warning that hackers are actively exploiting a macOS authentication bypass vulnerability after public exploit code emerged. [...]
  - (2026-08-14) [BleepingComputer] The Modern Attack Chain: Rethinking Google Workspace Security in the Age of AI
      Google Workspace attacks do not always begin with phishing. Stolen OAuth tokens can provide another path into Gmail, Drive, and connected systems. Material Security explains why organizations need defenses that cover the…
  - (2026-08-14) [BleepingComputer] Max severity SAP Commerce Cloud flaw now targeted in attacks
      A maximum-severity SAP Commerce Cloud remote code execution vulnerability patched three days ago is already being targeted in attacks, according to threat intelligence company Defused. [...]
  - (2026-08-14) [BleepingComputer] Shell investigates 'potential incident' after Clop data theft claims
      Oil giant Shell has confirmed it is investigating a potential security incident after the Clop ransomware gang claimed it stole 89GB of data. [...]

### Court opinions of consequence (federal & state) — 42 new of 60 total
  - (2026-08-18) Connecticut Supreme Court: Greenwich Retail, LLC v. Greenwich
  - (2026-08-14) U.S. Court of International Trade: Camel Group Co., Ltd. v. United States
  - (2026-08-14) U.S. Court of International Trade: Tianjin Magnesium Int'l Co. v. United States
  - (2026-08-14) Alaska Supreme Court: DONALD EDWARD BLOOM, DEBORAH JANE BLOOM, and JOHN W. MOORE and v. JIGLIOTTI FAMILY TRUST And
  - (2026-08-14) Alaska Supreme Court: DOT LAKE VILLAGE v. DENÁ NENÁ HENASH, D/B/A Tanana Chiefs Conference
  - (2026-08-14) U.S. Court of Appeals, 8th Cir.: Astrid Matias-Pablo v. Todd Blanche

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-14) [Moeller Philip D] Form 4 (Reporting)
      filed 2026-08-14 20:14 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001630805-26-000074 Size: 4 KB
  - (2026-08-14) [Babcock & Wilcox Enterprises, Inc.] Form 4 (Issuer)
      filed 2026-08-14 20:14 UTC · role: Issuer — Filed: 2026-08-14 AccNo: 0001630805-26-000074 Size: 4 KB
  - (2026-08-14) [Villanueva Rodriguez Alfonso] Form 4 (Reporting)
      filed 2026-08-14 20:14 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0002111103-26-000033 Size: 6 KB
  - (2026-08-14) [VERIZON COMMUNICATIONS INC] Form 4 (Issuer)
      filed 2026-08-14 20:14 UTC · role: Issuer — Filed: 2026-08-14 AccNo: 0002111103-26-000033 Size: 6 KB
  - (2026-08-14) 497 - iSHARES TRUST (0001100663) (Filer)
      filed 2026-08-14 20:14 UTC — Filed: 2026-08-14 AccNo: 0001193125-26-352275 Size: 7 KB
  - (2026-08-14) 40-17G - Brightwood Capital Corp I (0001895316) (Filer)
      filed 2026-08-14 20:13 UTC — Filed: 2026-08-14 AccNo: 0001104659-26-097155 Size: 936 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-14) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (39.2456, -4.4762) · alt: 11277m · 835km/h
  - (2026-08-14) PAT820 (United States)
      icao24: adfecf · position: (39.5151, -119.7638) · on ground
  - (2026-08-14) PAT795 (United States)
      icao24: adfecb · position: (33.6625, -87.4674) · alt: 7620m · 507km/h
  - (2026-08-14) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (37.9431, -2.2951) · alt: 11292m · 815km/h
  - (2026-08-14) CFC3874 (Canada)
      icao24: c2b35f · position: (64.0059, -145.19) · alt: 10614m · 899km/h
  - (2026-08-14) CFC3872 (Canada)
      icao24: c2b369 · position: (46.5371, -87.5211) · alt: 11887m · 1050km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-14) [Israel-Iran-Hezbollah axis · keywords] Kushner to travel to Israel , Egypt to discuss Gaza plan , sources say
      clevelandjewishnews.com · English · tone NA
  - (2026-08-14) [Israel-Iran-Hezbollah axis · keywords] Netanyahu rejects Trump Gaza plan , pursues Greater Israel agenda
      wsws.org · English · tone NA
  - (2026-08-14) [Israel-Iran-Hezbollah axis · keywords] US Engaged in Shuttle Diplomacy between Lebanon , Israel to Salvage the Negotiations
      english.aawsat.com · English · tone NA
  - (2026-08-14) [Israel-Iran-Hezbollah axis · keywords] Tel Aviv Public Relations Firms 2026
      everything-pr.com · English · tone NA
  - (2026-08-14) [Israel-Iran-Hezbollah axis · keywords] Hezbollah Chief Slams Lebanon - Israel Talks
      english.aawsat.com · English · tone NA
  - (2026-08-14) [Israel-Iran-Hezbollah axis · keywords] BARKAT DENIES PLOT : Minister Says He Never Planned To Oust Netanyahu
      theyeshivaworld.com · English · tone NA

### U.S. Federal Action — 23 new of 23 total
  - (2026-08-14) Continuation of the National Emergency With Respect to Export Control Regulations
  - (2026-08-14) Delivering Gold Standard Childhood Vaccine Recommendations for Americans
  - (2026-08-14) Differential Pay for Prescribed Wildland Fire Activities
      The Office of Personnel Management is issuing a final rule to add prescribed (planned) wildland fire duties as covered activities triggering payment of Hazardous Duty Pay (HDP) for General Schedule (GS) employees and Env…
  - (2026-08-14) Airworthiness Directives; Air Tractor, Inc. Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-16- 06, which applied to all Air Tractor, Inc. (Air Tractor) Model AT-802 and AT-802A airplanes with Wipaire, Inc. Supplemental Type Certificate (STC) No. SA01795C…
  - (2026-08-14) Proposed Establishment of the Rancho Santa Fe Viticultural Area
      The Alcohol and Tobacco Tax and Trade Bureau (TTB) proposes to establish the 15,827-acre "Rancho Santa Fe" American viticultural area (AVA) in San Diego County, California. The proposed AVA is located entirely within the…
  - (2026-08-14) Proposed Establishment of the Llano Uplift and Hickory Sands District Viticultural Areas
      The Alcohol and Tobacco Tax and Trade Bureau (TTB) proposes to establish the 2,096-square mile "Llano Uplift" American viticultural area (AVA) in portions of Blanco, Burnet, Gillespie, Llano, Mason, McCulloch, and San Sa…

### Paper Trading Scorecard — 20 new of 139 total
  - (2026-08-14) [Polymarket] NATO x Russia military clash by October 31, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between market creation and October 31, 2026, 11:59 PM ET. Otherwise, this market will resolve t…
  - (2026-08-14) [Polymarket] Will MicroStrategy be margin called in 2026?
      This market will resolve to "Yes" if MicroStrategy incorporated is margin called on any of its Bitcoin-backed loans by December 31, 2026, 11:59 PM ET, resulting in either a forced liquidation of Bitcoin by a lender or Mi…
  - (2026-08-14) [Polymarket] Will Yabloko gain the most seats in the next Russian parliamentary election?
      Parliamentary elections are to be scheduled to be held in Russia in September 2026. This market will resolve according to the political party that gains the greatest number of seats in the next Russian State Duma electio…
  - (2026-08-14) [Manifold] Will something happen in AI the week of Aug 21, 2026?
  - (2026-08-14) [Manifold] Daily Coinflip
  - (2026-08-14) [Manifold] Will Islam Makhachev still be the ufc welterweight champion at the end of 2026

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-14) LoL: GIANTX vs Team Vitality (BO3) - LEC Regular Season
      yes price: 0% · 24h volume: $1,034,283 · resolves 2026-08-14
  - (2026-08-14) Counter-Strike: PARIVISION vs 100 Thieves (BO3) - Esports World Cup Group C
      yes price: 100% · 24h volume: $801,353 · resolves 2026-08-14
  - (2026-08-14) Will Wolverhampton Wanderers FC win on 2026-08-14?
      yes price: 16% · 24h volume: $778,779 · resolves 2026-08-14
  - (2026-08-14) LoL: GIANTX vs Team Vitality - Game 2 Winner
      yes price: 100% · 24h volume: $612,950 · resolves 2026-08-14
  - (2026-08-14) The Hundred: Manchester Super Giants vs Sunrisers Leeds
      yes price: 100% · 24h volume: $532,966 · resolves 2026-08-21
  - (2026-08-14) Cincinnati Open: Lilli Tagger vs Talia Gibson
      yes price: 42% · 24h volume: $530,520 · resolves 2026-08-21

### Government Action: Sanctions + Procurement + Foreign Agents — 10 new of 97 total
  - (2026-08-14) [BIS Entity List] page checksum 5399e2d9c7b0
      Page content hash: 5399e2d9c7b0. Compare with prior day's hash to detect updates.
  - (2026-08-14) [USASpending] $1,366,609,929 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B
  - (2026-08-14) [USASpending] $684,257,622 → LEIDOS, INC.: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
      Agency: Department of Transportation. Description: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
  - (2026-08-14) [USASpending] $670,147,981 → AT&T ENTERPRISES, LLC: CO: TELLY RENFROE AWARD OF NEW TASK ORDER BASE YEAR INITIAL
      Agency: Department of Justice. Description: CO: TELLY RENFROE AWARD OF NEW TASK ORDER BASE YEAR INITIAL FUNDING
  - (2026-08-14) [USASpending] $601,495,890 → CACI, INC. - FEDERAL: ENTERPRISE LEVEL IT EXPERTISE ELITE
      Agency: General Services Administration. Description: ENTERPRISE LEVEL IT EXPERTISE ELITE
  - (2026-08-14) [USASpending] $574,356,346 → PARSONS GOVERNMENT SERVICES INC.: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERA
      Agency: General Services Administration. Description: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERATIONS, AND INFORMATION SERVICES (CEOIS) TASK ORDER IS TO PROVIDE NEAR REAL-TIME SITUATIONAL AWARENESS AND…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 40 total
  - (2026-08-14) MOVER ▼ Elon Musk — $863.45B ($-6.49B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-14) MOVER ▼ Larry Ellison — $192.41B ($-6.11B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-14) MOVER ▼ Michael Dell — $255.23B ($-5.50B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-14) MOVER ▼ Jeff Bezos — $270.17B ($-2.21B since yesterday)
      United States · Technology · source: Amazon
  - (2026-08-14) MOVER ▼ Mark Zuckerberg — $202.49B ($-1.77B since yesterday)
      United States · Technology · source: Facebook
  - (2026-08-14) MOVER ▼ Warren Buffett — $143.27B ($-1.06B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### USGS earthquakes (M4.5+, past day) — 7 new of 7 total
  - (2026-08-14) M 4.9 - 19 km WSW of Divichibazar, Azerbaijan
      M4.9 · 19 km WSW of Divichibazar, Azerbaijan · depth 10 km
  - (2026-08-14) M 4.9 - 29 km SW of Balangonan, Philippines
      M4.9 · 29 km SW of Balangonan, Philippines · depth 92.559 km
  - (2026-08-14) M 4.8 - 207 km SE of Katsuura, Japan
      M4.8 · 207 km SE of Katsuura, Japan · depth 10 km
  - (2026-08-14) M 4.8 - Bonin Islands, Japan region
      M4.8 · Bonin Islands, Japan region · depth 516.445 km
  - (2026-08-14) M 4.7 - 283 km N of Tobelo, Indonesia
      M4.7 · 283 km N of Tobelo, Indonesia · depth 10 km
  - (2026-08-14) M 4.5 - 165 km N of Sola, Vanuatu
      M4.5 · 165 km N of Sola, Vanuatu · depth 369.326 km

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-08-14) [Marginal Revolution] Friday assorted links
      1. What sort of maths are LLMs good at? 2. “People think the superrich are unhappy,” she said. “They’re not.” (NYT) 3. Trailer for a Celibadache biopic. 4. Good Joshua Saxe post on the need for a better cybersecurity pol…
  - (2026-08-14) [Marginal Revolution] Adding to the barrel of finance fallacies
      “I should note also that many (most? almost all?) of the bad scenarios have intermediate points of great worry and catastrophe” Not on my model. By the time any humans start worrying about a takeover or dying, AIs alread…
  - (2026-08-14) [Marginal Revolution] Regulated Markets Are Slow to Handle Change
      Gowrisankaran, Langer and Reguant have an excellent paper, Energy Transitions in Regulated Markets (WP), in the latest AER. The basic idea is that regulation designed to prevent utilities from building useless power plan…
  - (2026-08-14) [Conversable Economist] Orwell: “It is possible to be a normal decent person and yet be fully alive.”
      There’s a common script about about artists who live hard and die young. It says that the combination of a self-destructive lifestyle and art means that they were in some way fully alive, in a way that would be impossibl…
  - (2026-08-13) [Conversable Economist] “To Write Well is to Think Clearly”: David McCullough
      The great historian David McCullough (1933-2022) won the Pulitzer prize for biography twice, for his books on Truman and John Adams, but he also wrote best-selling books on the Panama Canal, the Johnstown Flood, the Broo…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-08-14) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo is in a phase of intense transmission. It is the largest Ebola outbreak ever reported in the country and expanding faster than any previ…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-14) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=23, 7d-median=20, 14d-median=20; carrying terms: provide, proposed, program, rulemaking, special, remove, proposes, commission, final, service, proposing, certain
- state_bills: today=129, 7d-median=118, 14d-median=118; carrying terms: forth, violation, actions, provided, every, program, amending, relating, businesses, environmental, human, implement
- state_news: today=813, 7d-median=681, 14d-median=686; carrying terms: changes, agriculture, actions, rates, every, better, because, transportation, change, since, photo, environmental
- local_news: today=255, 7d-median=230, 14d-median=234; carrying terms: since, nearly, shooting, according, sheriff, state, former, family, taxes, house, scene, three
- foreign_news: today=1076, 7d-median=1011, 14d-median=1022; carrying terms: orders, stunt, maverick, civilian, highlighting, suspected, cabinet, destination, growth, escalating, resolve, every
- chinese_internal: today=286, 7d-median=261, 14d-median=265; carrying terms: cbmibkfvx, cbmiakfvx, cbmia, cbmiyefvx, chinese, cbmix, cbmidefvx, cbmickfvx, blank, cbmiaefvx, politics, global
- russian_internal: today=1249, 7d-median=1063, 14d-median=1060; carrying terms: title, times, guardian, error, patriot, russian, https, telegram, istories, street, laquo, axios
- ukrainian_internal: today=125, 7d-median=107, 14d-median=111; carrying terms: warehouses, times, civilian, cabinet, efforts, announced, since, combat, russian, minister, nearly, several
- ukraine_theater: today=1487, 7d-median=840, 14d-median=778; carrying terms: cuxnbdfgvud, vulqrgetug, lwytlarmfwz, thhqrkcwaeozsvpbb, rkszenjbovexmk, cuxrrutdmfaxzgnrmldtdxrfzee, cuxnm, female, token, cnvytghqmvbuq, lrxrlcnd, adfwemd
- paper_bets: today=139, 7d-median=129, 14d-median=138; carrying terms: fusion, koivun, pennsylvania, decrease, manifold, succeed, degrees, performing, mbappe, arizona, visit, experience
- weather: today=198, 7d-median=182, 14d-median=180; carrying terms: changes, front, times, baltimore, winds, holly, afdsew, tuesday, greater, mountains, levels, watch
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: balance, effective, sheet, cpiaucsl, funds, inflation, headline, treasury, assets, dexjpus, jolts, dexuseu
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, natural, close, proxy, treasury, yield, china, bitcoin, nasdaq, silver, corporate, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=97, 7d-median=99, 14d-median=99; carrying terms: bissau, square, amended, lebanon, transactions, rights, application, actions, engineering, congo, palestinian, active
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, httperror, client, quiver, congresstrading, https, unauthorized, quiverquant, error
- billionaires: today=40, 7d-median=34, 14d-median=36; carrying terms: devasini, buffett, walmart, microsoft, adani, tiktok, julia, telecom, france, bloomberg, paris, ballmer
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, appeals, state, delaware, court, connecticut, blanche, international, group, company, trade, trust
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, michael, holdings, group, financial, robert, curtis
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, pinkston, cortez, elect, senate, james, johnson, krishnamoorthi, jonathan, david, filing, angels
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, japan
- gdelt_gkg: today=25, 7d-median=25, 14d-median=42; carrying terms: english, israel, trump, hezbollah, keywords, south, attacks, warns, israeli, netanyahu, lebanon, talks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=28; carrying terms: position, ground, belgium, canada, bulgaria, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: monkeypox, avian, focus, ethiopia, bivalent, symptoms, cereulide, seasonal, index, products, exposure, suspected
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: vendor, vulnerability, central, deserialization, remediation, authentication, langflow, product, injection, channel, alternate, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=244; carrying terms: czech, belize, indonesia, bosnia, france, forest, russia, ethiopia, monaco, drought, macedonia, japan
- usgs_quakes: today=7, 7d-median=13, 14d-median=13; carrying terms: depth, islands, russia, indonesia, region, japan, philippines, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: hormuz, price, resolves, september, traffic, normal, volume, meeting, interest, rates, strait, winner
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, economist, marginal, class, https, conversableeconomist, marginalrevolution, believe, future, impossible, young
- tech_news: today=58, 7d-median=56, 14d-median=56; carrying terms: going, program, review, complex, access, spectrum, weekly, hackers, world, daily, download, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: burchett, crane, ritchie, kaptur, suzanne, defense, ambassador, elena, bradley, tracey, rouzer, grothman
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, paper, either, unavailable, placed, converges, identify, today, module, markets, placement, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*