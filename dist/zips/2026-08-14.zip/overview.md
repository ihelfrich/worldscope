# WORLDSCOPE morning brief — 2026-08-14

## Headline
3719 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (735) · Russian Internal News (state + in-exile) (683) · Ukraine Theater (total-war monitoring) (561) · World leaders & government officials (324) · State-Level News (305) · Local News: St. Louis + Atlanta (214) · Chinese Internal News (212) · U.S. Weather + Severe / Climate Outlooks (189) · State Legislative Action (118) · Ukrainian Internal News (national + local Kyiv) (58) · GDELT GKG — themes / entities / watch areas (49) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 735 new of 1027 total
  - (2026-08-14) [Global] NATO jets shoot down drone flying over eastern Latvia
      Fighter jets ​on a NATO air defence mission shot down ​a drone that entered the airspace of Latvia, a NATO and European Union member, early Friday, Latvia's armed forces ​said.
  - (2026-08-14) [Global] France evacuates hundreds as new wildfire threatens southwestern Landes region
      Authorities evacuated 525 people from the village of Luglon Friday as a new wildfire tore through southwestern France, burning 1,100 hectares and advancing to within a few kilometres of the village centre amid an unprece…
  - (2026-08-14) [Global] Nigel Farage beats Count Binface to regain UK parliamentary seat in widely mocked by-election
      The anti-immigrant Reform UK party leader Nigel Farage beat comic opponent Count Binface on Friday as was expected, regaining the seat in Parliament he quit a month ago to trigger the widely mocked by-election in the sea…
  - (2026-08-14) [Global] Spain's World Cup final hero Ferran Torres closes in on PSG transfer
      Paris Saint-Germain have reached an agreement with Barcelona to sign Ferran Torres, according to reports in French and Spanish outlets on Thursday evening. The forward, who scored the match-winner for Spain in the World…
  - (2026-08-14) [Global] US sailors report dire conditions as replacement carrier heads to Middle East
      Reports of declining mental health and supply issues have been flagged by US sailors aboard the aircraft carrier USS Lincoln deployed to the Middle East, with some attempting to throw themselves into the sea. The ship ha…
  - (2026-08-14) [Global] Live: US sailors report dire conditions as replacement carrier heads to Middle East
      Reports of declining mental health and supply issues have been flagged by US sailors aboard the aircraft carrier USS Lincoln deployed to the Middle East, with some attempting to throw themselves into the sea. The ship ha…

### Russian Internal News (state + in-exile) — 683 new of 1094 total
  - (2026-08-14) Жителя Подмосковья Георгия Пирогова, приговоренного к 23 годам, обвинили в госизмене в пользу Польши. В ФСБ утверждают, что он сам связался с польскими спецслужбами | LEDE: В ФСБ заявили, чт] (ru: Жит…
      В ФСБ заявили, что житель Подмосковья Георгий Пирогов, приговоренный к 23 годам колонии строгого режима по делу о госизмене, собирал информацию для польских спецслужб.
  - (2026-08-14) Apple создала собственную ИИ-модель для Китая. В ее разработке участвует Alibaba Group | LEDE: Apple создала собственную большую языковую модель специально для китайского рынка, пишет Reuter] (ru: App…
      Apple создала собственную большую языковую модель специально для китайского рынка, пишет Reuters, ссылаясь на три осведомленных источника. Разработкой и обучением ИИ компания занималась в партнерстве с Alibaba Group.
  - (2026-08-14) О падении Российской империи написан не один десяток книг — но что из них действительно стоит прочитать? Вот шесть рекомендаций историка Алексея Уварова | LEDE: О революции и Гражданской вой] (ru: О п…
      О революции и Гражданской войне в России написаны десятки, если не сотни тысяч книг и исследований. Они посвящены самым разным темам — от свержения монархии и «немецкого следа» в Октябрьской революции до политического на…
  - (2026-08-14) На складах Wildberries после украинских атак сгорели более 11 миллионов книг. В их числе — учебники, тираж Конституции, а также книги Симоньян и Прилепина | LEDE: На складах Wildberries, ата] (ru: На…
      На складах Wildberries, атакованных Украиной, сгорели более 11 миллионов книг, подсчитали в Российском книжном союзе (РКС), Ассоциации книгоиздателей России и Ассоциации книгораспространителей.
  - (2026-08-14) Трамп ввел пошлины в 100% на ввоз в США иностранных беспилотников и комплектующих | LEDE: Дональд Трамп подписал прокламацию, которая вводит 100-процентные пошлины на беспилотники определенн] (ru: Тра…
      Дональд Трамп подписал прокламацию, которая вводит 100-процентные пошлины на беспилотники определенного размера, представляющие особую важность для национальной безопасности, сообщил Белый дом.
  - (2026-08-14) В России планируют расширить ограничения на полеты. Запретных зон станет вдвое больше | LEDE: Минтранс планирует расширить в список запретных зон для полета, включив в него зоны над объектам] (ru: В Р…
      Минтранс планирует расширить в список запретных зон для полета, включив в него зоны над объектами топливно-энергетического и оборонно-промышленного комплекса, а также транспортной инфраструктуры. С проектом соответствующ…

### Ukraine Theater (total-war monitoring) — 561 new of 857 total
  - (2026-08-14) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-13) [FIRMS] thermal anomaly 50.894, 34.213 (FRP 16.99 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 0900Z, FRP 16.99 MW
  - (2026-08-13) [FIRMS] thermal anomaly 50.897, 34.214 (FRP 20.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 0900Z, FRP 20.41 MW
  - (2026-08-13) [FIRMS] thermal anomaly 50.892, 34.204 (FRP 12.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 0900Z, FRP 12.76 MW
  - (2026-08-13) [FIRMS] thermal anomaly 45.259, 31.673 (FRP 10.99 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 1038Z, FRP 10.99 MW
  - (2026-08-13) [FIRMS] thermal anomaly 45.354, 30.903 (FRP 3.07 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-13 1038Z, FRP 3.07 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 305 new of 661 total
  - (2026-08-13) [California] ICYMI: California takes historic action against data brokers
      <a href="https://www.gov.ca.gov/2026/08/13/icymi-california-takes-hist
  - (2026-08-13) [California] As Trump’s EPA silences youth voices, California launches new Environmental Youth Council to shape our climate future
      Source
  - (2026-08-13) [California] Mientras la EPA de Trump silencia las voces de los jóvenes, California lanza un nuevo Consejo Asesor Juvenil Ambiental para ayudar a definir nuestro futuro climático
      Source
  - (2026-08-13) [California] She pleaded guilty to a drug charge. Then she visited Mexico not knowing she couldn’t return
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/01/010720_CA-Supreme-Court_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-08-13) [California] California lawmakers kill grizzly bear reintroduction bill
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072326-Grizzly-Bear-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-08-13) [California] Federal judge poised to restrict immigration arrest tactics in Los Angeles raids
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/08/081525_Immigration-Detain_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### Local News: St. Louis + Atlanta — 214 new of 247 total
  - (2026-08-14) [St. Louis] What’s True in the Lou? – 8/14/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-08-13) [St. Louis] Saint Louis Club contemplates closure over financial woes
      For nearly six decades, the private Saint Louis Club enjoyed one of the best views in the town—and cuisine to match. But the venerable club is facing mounting financial pressure after what some members say was an ill-adv…
  - (2026-08-13) [St. Louis] Where to hear live jazz in St. Louis
      Looking for a taste of jazz this weekend? This weekend marks the third annual CWE Jazz & Blues Festival on Saturday, August 15, from 1–7 p.m. The free, outdoor celebration brings together music, culture, and community. A…
  - (2026-08-13) [St. Louis] Lillian Stephen brings abstractly beautiful printmaking to the Kranzberg Gallery with ‘A Hum Beneath the Surface’
      The Kranzberg Gallery (501 N. Grand) is welcoming Lillian Stephen, printmaker and owner of L.C.Q.K.S., a shop specializing in beautifully designed fabric products, to host her first solo exhibition, A Hum Beneath the Sur…
  - (2026-08-13) [St. Louis] Elected official’s text message sends St. Louis data center vote into disarray
      Another dose of disarray was injected into the City of St. Louis’ effort to regulate data centers Wednesday. A city planning commission meeting abruptly went into recess after Don Roe, the executive director of planning…
  - (2026-08-13) [St. Louis] See the other side of Route 66 with ‘City 66: The Other Road’ at the National Building Arts Center
      When you think of Route 66, you think of the bright neon lights, the wind whipping through your hair, and the freedom of the open road as you cruise through the west in your cotton-candy pink Thunderbird. Route 66’s hist…

### Chinese Internal News — 212 new of 266 total
  - (2026-08-13) 改革者图鉴： 历史镜头里的朱镕基 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1YSGJ0OEoybm5OMTdESm4wWEVKT3kySDVoeExFU3R0aXEtaGs3YmY1bzhfRGJxTnJsY2VKR0p1aHp0ZzB0Y2k1cWhPWjNGTlJfdkMtT] (zh:…
      改革者图鉴： 历史镜头里的朱镕基 财新
  - (2026-08-12) 富途老虎期权内幕交易案锁定45人 共获利1.55亿美元(含视频) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5JZm94ZnV4SHVYVjIxa25nR0JDeHdXMzNCaGxsS1VfenZsRkdMbW9CZ0hlTEVYWjNHaXRrbW1WbHFuMnNTaHZRS] (zh:…
      富途老虎期权内幕交易案锁定45人 共获利1.55亿美元(含视频) 财新
  - (2026-08-14) 今日开盘：小幅高开 沪指涨幅0.08% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1Lckt0NjhGY3BVcldBRy1oSnNhNXc0S3pYTDlYdEpDUjQtbFR5TGFQTXZnekpMZ3oxaFlUVW1JRnFVa0JUVExuczNSRWdSTWdXTX] (zh:…
      今日开盘：小幅高开 沪指涨幅0.08% 财新
  - (2026-08-13) 财经早知道｜长鑫科技赶超腾讯，成中国大陆市值最高上市公司 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBTcnRuSWplcldXcUUtUHNhd2NOQXJCX1pHVWFRS0tXQkdwckMtU0NYOHdEVXNkRlZlcmlOMDZJTUZJSGFxZ1g5Y2Q1V] (zh:…
      财经早知道｜长鑫科技赶超腾讯，成中国大陆市值最高上市公司 财新
  - (2026-08-13) MSCI中国指数“换血” 纳入科技新贵剔除万科 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5tUHdCMmNWZlQ2Qng2X0lhZlU4ZVVfWW4yalVSMTFBbV9uUnFWSTJkbDVaZ2Iwak1RVUpzemNyZEV4Wmd6d2VGcTFwVnNWTi] (zh:…
      MSCI中国指数“换血” 纳入科技新贵剔除万科 财新
  - (2026-08-14) 主权基金集中现身SpaceX股东名单 持仓规模首次曝光 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBheTctWWRBT2JPR0dpaVJ4STk3MC16WmxYYnV3bldHUWFEOUhyQ3BzMFZlR05xVk1hdXNFakhWQUdBTEpLaGF4N1hMZG] (zh:…
      主权基金集中现身SpaceX股东名单 持仓规模首次曝光 财新

### U.S. Weather + Severe / Climate Outlooks — 189 new of 190 total
  - (2026-08-14) [Severe] Flood Watch: Flood Watch issued August 14 at 4:08AM EDT until August 14 at 11:00PM EDT by NWS Charleston WV
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of northeast Kentucky, including the following counties, Boyd, Carter, Greenup and Lawrence, southeast Ohio, including the…
  - (2026-08-14) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 14 at 3:08AM CDT until August 14 at 3:30AM CDT by NWS Lincoln IL
      At 308 AM CDT, a severe thunderstorm was located near Allerton, or 17 miles southeast of Urbana, moving southeast at 40 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, siding,…
  - (2026-08-14) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-14) [Severe] Flash Flood Warning: Flash Flood Warning issued August 14 at 2:59AM CDT until August 14 at 6:00AM CDT by NWS Lincoln IL
      FFWILX The National Weather Service in Lincoln has issued a * Flash Flood Warning for... Southern Champaign County in east central Illinois... Southern Vermilion County in east central Illinois... * Until 600 AM CDT. * A…
  - (2026-08-14) [Moderate] Special Weather Statement: Special Weather Statement issued August 14 at 5:58PM ChST by NWS Tiyan GU
      An unsettled monsoon pattern, associated with Invest 92W continues to intensify across Pohnpei and Kosrae. Invest 92W is currently rated sub-low by the Joint Typhoon Warning Center, which means development into a signifi…
  - (2026-08-14) [Moderate] Special Weather Statement: Special Weather Statement issued August 14 at 5:58PM ChST by NWS Tiyan GU
      An unsettled monsoon pattern, associated with Invest 92W continues to intensify across eastern Micronesia. Invest 92W is currently rated sub-low by the Joint Typhoon Warning Center, which means development into a signifi…

### State Legislative Action — 118 new of 120 total
  - (2026-08-13) [Alaska HB 309] An Act relating to the boundaries of the Jonesville Public Use Area; and providing for an effective date.
      An Act relating to the boundaries of the Jonesville Public Use Area; and providing for an effective date.
  - (2026-08-13) [Alaska HB 367] An Act relating to the privacy of consumer personal information; establishing the Consumer Personal Information Privacy Act; establishing data broker registration requirements; relatin…
      An Act relating to the privacy of consumer personal information; establishing the Consumer Personal Information Privacy Act; establishing data broker registration requirements; relating to social security numbers; making…
  - (2026-08-13) [Alaska HB 234] An Act relating to emergency medical dispatchers; classifying dispatchers in police or fire departments and in state trooper offices as peace officers under the public employees' retir…
      An Act relating to emergency medical dispatchers; classifying dispatchers in police or fire departments and in state trooper offices as peace officers under the public employees' retirement system; and providing for an e…
  - (2026-08-13) [Alaska HJR 23] Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
      Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
  - (2026-08-13) [Alaska HB 286] An Act relating to an optional municipal tax exemption for the homes of volunteer firefighters and volunteer providers of emergency medical services or mobile intensive care paramedic…
      An Act relating to an optional municipal tax exemption for the homes of volunteer firefighters and volunteer providers of emergency medical services or mobile intensive care paramedic services; and providing for an effec…
  - (2026-08-12) [Alaska HJR 41] Rescinding all previous requests by the Alaska State Legislature to call for a constitutional convention under art. V of the Constitution of the United States.
      Rescinding all previous requests by the Alaska State Legislature to call for a constitutional convention under art. V of the Constitution of the United States.

### Ukrainian Internal News (national + local Kyiv) — 58 new of 111 total
  - (2026-08-14) ФСБ РФ планує скасувати прикордонні зони з окупованими територіями України | LEDE: ФСБ РФ пропонує скасувати прикордонні зони на кордоні з окупованими територіями України та Кримом.] (uk: ФСБ РФ плану…
      ФСБ РФ пропонує скасувати прикордонні зони на кордоні з окупованими територіями України та Кримом.
  - (2026-08-14) Ексміністр оборони Польщі виступив проти передачі Україні ракет до Patriot | LEDE: Колишній міністр оборони Польщі Маріуш Блащак вважає неприйнятними наміри уряду передати Україні ракети до зен] (uk:…
      Колишній міністр оборони Польщі Маріуш Блащак вважає неприйнятними наміри уряду передати Україні ракети до зенітних ракетних комплексів Patriot.
  - (2026-08-14) Молдовські експортери "аграрки" побачили загрозу для себе у знижках на транзит для України | LEDE: ] (uk: Молдовські експортери "аграрки" побачили загрозу для себе у знижках на транзит д)
  - (2026-08-14) У Хорватії гасять велику лісову пожежу впритул до міста, є постраждалі | LEDE: ] (uk: У Хорватії гасять велику лісову пожежу впритул до міста, є постраждалі)
  - (2026-08-14) Молдова видала Україні організатора незаконного переправлення чоловіків через кордон | LEDE: В Україну екстрадували 30-річного жителя Вінниччини, якого підозрюють у незаконному переправленні чо] (uk:…
      В Україну екстрадували 30-річного жителя Вінниччини, якого підозрюють у незаконному переправленні чоловіків мобілізаційного віку через державний кордон.
  - (2026-08-14) Генштаб: Минулої доби на фронті відбулося 222 боєзіткнення, з них 29 – на Костянтинівському напрямку | LEDE: 13 серпня на фронті відбулося 222 бої, найбільше атак росіян відбили на Костянтинівс] (uk:…
      13 серпня на фронті відбулося 222 бої, найбільше атак росіян відбили на Костянтинівському напрямку — 29 штурмів.

### GDELT GKG — themes / entities / watch areas — 49 new of 49 total
  - (2026-08-14) [Russia oil sanctions perimeter · themes] « Первый пошел »: вице - адмирал Франции погиб после удара баллистики в Одессе
      mk.ru · Russian · tone NA
  - (2026-08-14) [Russia oil sanctions perimeter · themes] 熬夜暗沉能用什么泥膜改善 ？ 哪款泥膜能提亮 ？ 4款泥膜实测
      baijiahao.baidu.com · Chinese · tone NA
  - (2026-08-14) [Russia oil sanctions perimeter · themes] Після завершення першої хвилі вступної кампанії ІФНТУНГ вже обрало на 30 % більше абітурієнтів , а ніж торік
      pravda.if.ua · Ukrainian · tone NA
  - (2026-08-14) [Russia oil sanctions perimeter · themes] Recalculan el valor de Vaca Muerta : estiman más de 30 . 000 millones de barriles
      elcordillerano.com.ar · Spanish · tone NA
  - (2026-08-14) [Russia oil sanctions perimeter · themes] מבחני רכב - לפאס L8 ( נהיגה ראשונה ) – מתכון מוכר , רק משופר
      icar.co.il · Hebrew · tone NA
  - (2026-08-14) [Russia oil sanctions perimeter · themes] Deutsche Bank verhoogt koersdoel Fastned
      beursduivel.be · Dutch · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-14) [Attovia Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-08-14 01:52 UTC · role: Issuer — Filed: 2026-08-13 AccNo: 0001866174-26-000009 Size: 55 KB
  - (2026-08-14) [WALSH COLIN] Form 4 (Reporting)
      filed 2026-08-14 01:52 UTC · role: Reporting — Filed: 2026-08-13 AccNo: 0001866174-26-000009 Size: 55 KB
  - (2026-08-14) [WSLS EMP ONSHORE INVESTMENTS, L.P.] Form 4 (Reporting)
      filed 2026-08-14 01:51 UTC · role: Reporting — Filed: 2026-08-13 AccNo: 0000886982-26-000495 Size: 66 KB
  - (2026-08-14) [WSLS OFFSHORE INVESTMENTS, SLP] Form 4 (Reporting)
      filed 2026-08-14 01:51 UTC · role: Reporting — Filed: 2026-08-13 AccNo: 0000886982-26-000495 Size: 66 KB
  - (2026-08-14) [WSLS EMP OFFSHORE INVESTMENTS, L.P.] Form 4 (Reporting)
      filed 2026-08-14 01:51 UTC · role: Reporting — Filed: 2026-08-13 AccNo: 0000886982-26-000495 Size: 66 KB
  - (2026-08-14) [Attovia Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-08-14 01:51 UTC · role: Issuer — Filed: 2026-08-13 AccNo: 0000886982-26-000495 Size: 66 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-14) [Azerbaijan] Russian drone strike kills woman and 9 - year - old child in Ukraine Sumy region
      domain: en.apa.az · language: English · tone:
  - (2026-08-14) [Austria] Murder of 87 - Year - Old in Vienna Senior Residence : Life Sentence
      domain: vol.at · language: English · tone:
  - (2026-08-14) [United States] Fall events coming : Parade of 1 , 000 Flags , Veterans Stand Down , astronaut
      domain: ridgecrestca.com · language: English · tone:
  - (2026-08-14) [Australia] John Hinckley Jr has message for Jodie Foster 45 years after attempting to kill Ronald Reagan
      domain: perthnow.com.au · language: English · tone:
  - (2026-08-14) [China] How a northern Philippine town learned to live with the world rarest crocodile – Asia News Network
      domain: asianews.network · language: English · tone:
  - (2026-08-14) [] All My Loving : nation mourns music legend Johnny Young
      domain: newcastleherald.com.au · language: English · tone:

### Court opinions of consequence (federal & state) — 39 new of 60 total
  - (2026-08-18) Connecticut Supreme Court: Greenwich Retail, LLC v. Greenwich
  - (2026-08-13) U.S. Court of Appeals, 3rd Cir.: Gersen Gabriel v. DSM Biomedical Inc
  - (2026-08-13) Supreme Court of California: People v. Hernandez
  - (2026-08-13) Supreme Court of California: People v. Shove
  - (2026-08-13) U.S. Court of Appeals, 2nd Cir.: Umb
  - (2026-08-13) U.S. Court of Appeals, 2nd Cir.: United States v. Leeper

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 57 total
  - (2026-08-14) [BleepingComputer] Apple sends new ‘Threat Notification’ alerts over mercenary spyware attacks
      You're not alone if you just received an "Apple Threat Notification" saying it detected a "mercenary spyware attack targeted at your iPhone." [...]
  - (2026-08-14) [The Register] Claude Code returns blank thinking blocks, but reasoning still costs you
      Developers report model thinking blocks being returned empty or truncated
  - (2026-08-14) [The Register] Five years after quitting a job, developer’s former boss asked for rapid tech support
      Connecting a single power cord turned into a lucrative all-nighter
  - (2026-08-14) [The Register] New Zealand says China tried using space investments to spy on local affairs
      Intelligence Service says finding domestic threats is harder due to proliferation of toxic content online
  - (2026-08-14) [The Register] OpenAI ditches Recall-style screenshot surveillance for friendly keylogging
      'Computer History' records clicks and typing to build ChatGPT memories
  - (2026-08-13) [BleepingComputer] Ukraine shuts down 94 fraudulent call centers, seize millions in cash
      Authorities in Ukraine shut down 94 fraudulent call centers across the country that lured people into investment scams or tried to obtain access to bank accounts. [...]

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-14) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (36.346, -6.0879) · alt: 10965m · 866km/h
  - (2026-08-14) JAF76T (Bulgaria)
      icao24: 4520aa · position: (47.9911, 1.4068) · alt: 4297m · 671km/h
  - (2026-08-14) GAF172 (Germany)
      icao24: 3ea653 · position: (54.4318, 23.368) · alt: 4533m · 612km/h
  - (2026-08-14) SAM365 (United States)
      icao24: adfeb8 · position: (56.4213, -7.6284) · alt: 8610m · 931km/h
  - (2026-08-14) SAMU05 (France)
      icao24: 39ca81 · position: (44.5353, 6.1639) · alt: 1226m · 219km/h
  - (2026-08-14) JEDI27 (France)
      icao24: 39a842 · position: (45.5669, 0.2609) · alt: 1600m · 234km/h

### Paper Trading Scorecard — 14 new of 134 total
  - (2026-08-14) [Polymarket] Israel closes its airspace by August 31?
      This market will resolve to “Yes” if Israel initiates a major closure of its airspace by the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No”. A “major closure” is defined as a broad closure, canc…
  - (2026-08-14) [Polymarket] Will Alphabet be the second-largest company in the world by market cap on August 31?
      This market will resolve to the second-largest company in the world by market cap on August 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-08-14) [Polymarket] Will the price of Bitcoin be above $70,000 on August 14?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-08-14) [Polymarket] Will MicroStrategy be margin called in 2026?
      This market will resolve to "Yes" if MicroStrategy incorporated is margin called on any of its Bitcoin-backed loans by December 31, 2026, 11:59 PM ET, resulting in either a forced liquidation of Bitcoin by a lender or Mi…
  - (2026-08-14) [Polymarket] NATO x Russia military clash by October 31, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between market creation and October 31, 2026, 11:59 PM ET. Otherwise, this market will resolve t…
  - (2026-08-14) [Manifold] Will a US presidential candidate make an anti data center remark during their campaign for 2028?

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-14) Dota 2: BoomBoys vs TEAM VISION - Game 2 Winner
      yes price: 0% · 24h volume: $1,045,016 · resolves 2026-08-14
  - (2026-08-14) LoL: EDward Gaming vs LGD Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $1,012,404 · resolves 2026-08-14
  - (2026-08-14) Dota 2: LGD Gaming vs Nigma Galaxy - Game 2 Winner
      yes price: 0% · 24h volume: $670,927 · resolves 2026-08-14
  - (2026-08-14) Dota 2: Iron Wing vs Team Falcons - Game 1 Winner
      yes price: 100% · 24h volume: $621,303 · resolves 2026-08-14
  - (2026-08-14) Will Nigel Farage win at least 80% of votes in the Clacton parliamentary by-election?
      yes price: 0% · 24h volume: $560,549 · resolves 2027-06-30
  - (2026-08-14) Will Nigel Farage win 60–70% of votes in the Clacton parliamentary by-election?
      yes price: 99% · 24h volume: $554,924 · resolves 2027-06-30

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 98 total
  - (2026-08-14) [USASpending] $1,366,609,929 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B
  - (2026-08-14) [USASpending] $684,257,622 → LEIDOS, INC.: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
      Agency: Department of Transportation. Description: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
  - (2026-08-14) [USASpending] $670,147,981 → AT&T ENTERPRISES, LLC: CO: TELLY RENFROE AWARD OF NEW TASK ORDER BASE YEAR INITIAL
      Agency: Department of Justice. Description: CO: TELLY RENFROE AWARD OF NEW TASK ORDER BASE YEAR INITIAL FUNDING
  - (2026-08-14) [USASpending] $601,495,890 → CACI, INC. - FEDERAL: ENTERPRISE LEVEL IT EXPERTISE ELITE
      Agency: General Services Administration. Description: ENTERPRISE LEVEL IT EXPERTISE ELITE
  - (2026-08-14) [USASpending] $574,356,346 → PARSONS GOVERNMENT SERVICES INC.: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERA
      Agency: General Services Administration. Description: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERATIONS, AND INFORMATION SERVICES (CEOIS) TASK ORDER IS TO PROVIDE NEAR REAL-TIME SITUATIONAL AWARENESS AND…
  - (2026-08-14) [USASpending] $483,573,076 → NATIONAL GOVERNMENT SERVICES, INC.: PART A/PART B MEDICARE ADMINISTRATIVE CONTRACTOR (MAC) JURIS
      Agency: Department of Health and Human Services. Description: PART A/PART B MEDICARE ADMINISTRATIVE CONTRACTOR (MAC) JURISDICTION K (JK)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 40 total
  - (2026-08-14) MOVER ▼ Elon Musk — $869.93B ($-19.94B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-14) MOVER ▲ Mark Zuckerberg — $204.26B (+$5.47B since yesterday)
      United States · Technology · source: Facebook
  - (2026-08-14) MOVER ▲ Larry Ellison — $198.53B (+$3.76B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-14) MOVER ▲ Michael Dell — $260.72B (+$3.27B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-14) MOVER ▼ Jeff Bezos — $272.38B ($-1.90B since yesterday)
      United States · Technology · source: Amazon
  - (2026-08-14) MOVER ▲ Masayoshi Son — $68.74B (+$1.82B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-08-13) M 5.6 - Kermadec Islands region
      M5.6 · Kermadec Islands region · depth 10 km
  - (2026-08-13) M 5.3 - 11 km S of Sarangani, Philippines
      M5.3 · 11 km S of Sarangani, Philippines · depth 66.312 km
  - (2026-08-13) M 5.1 - west of Macquarie Island
      M5.1 · west of Macquarie Island · depth 10 km
  - (2026-08-13) M 5.1 - 22 km ENE of Lapuan, Philippines
      M5.1 · 22 km ENE of Lapuan, Philippines · depth 91.206 km
  - (2026-08-13) M 5.0 - 45 km SSW of Angoram, Papua New Guinea
      M5.0 · 45 km SSW of Angoram, Papua New Guinea · depth 134.025 km
  - (2026-08-14) M 4.9 - 29 km SW of Balangonan, Philippines
      M4.9 · 29 km SW of Balangonan, Philippines · depth 92.559 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-14) [Marginal Revolution] The Economics of a Shrinking World
      From Jesus Fernandez-Villaverde and Patrick Norrick: As of 2026, humanity is likely below replacement fertility. That has never happened before, not in wars or pandemics. But the real surprise is that the fall has been c…
  - (2026-08-14) [Marginal Revolution] Intergenerational mobility of immigrants in 15 destination countries
      We estimate intergenerational mobility of children of immigrants in fifteen receiving countries. Children of immigrants have somewhat lower income than children of local-born parents. Around half of this gap can be expla…
  - (2026-08-13) [Marginal Revolution] Those old (new?) service sector jobs
      An ability to mimic the shrieks of langur monkeys may not seem like a bankable skill, but for some Indians it has become a job, if not a calling. These vocal professionals specialise in pest control and are being employe…
  - (2026-08-13) [Conversable Economist] “To Write Well is to Think Clearly”: David McCullough
      The great historian David McCullough (1933-2022) won the Pulitzer prize for biography twice, for his books on Truman and John Adams, but he also wrote best-selling books on the Panama Canal, the Johnstown Flood, the Broo…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-14) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=20, 14d-median=20; carrying terms: proposing, remove, provide, final, certain, august, special, airspace, program, rulemaking, action, proposes
- state_bills: today=120, 7d-median=118, 14d-median=113; carrying terms: initiate, project, programs, utilities, administration, necessary, ordinances, prohibit, notice, office, order, provide
- state_news: today=661, 7d-median=661, 14d-median=661; carrying terms: major, history, office, records, launches, provide, serious, illustration, police, collins, david, gathered
- local_news: today=247, 7d-median=230, 14d-median=230; carrying terms: police, cbmirgfbvv, content, center, height, following, alert, president, figure, color, blank, another
- foreign_news: today=1027, 7d-median=1011, 14d-median=1011; carrying terms: locals, wardens, history, currently, office, migration, assessment, launches, probe, quarterly, computer, civilians
- chinese_internal: today=266, 7d-median=261, 14d-median=266; carrying terms: global, color, politics, blank, cbmixkfvx, title, cbmia, cbmiw, lxtfa, chinese, cbmizefvx, caixin
- russian_internal: today=1094, 7d-median=1063, 14d-median=1056; carrying terms: russian, gazeta, bloomberg, httperror, patriot, title, journal, laquo, found, https, times, telegram
- ukrainian_internal: today=111, 7d-median=107, 14d-median=111; carrying terms: russian, target, drone, killed, allies, intelligence, httperror, civilians, court, ministers, additional, error
- ukraine_theater: today=857, 7d-median=840, 14d-median=780; carrying terms: nywlbet, cuxpemdtsgfoou, vjnmzuqnq, russian, history, ymhwa, ntuejdulfxr, judkdnz, assessment, cuxqamv, pazznz, jdqzvasurmyvvnt
- paper_bets: today=134, 7d-median=129, 14d-median=134; carrying terms: caribbean, republican, goldman, leader, office, kalshi, named, carolina, inflation, successor, midterms, specified
- weather: today=190, 7d-median=182, 14d-median=177; carrying terms: caribbean, aviation, lower, showers, effect, chance, water, exhaustion, winds, little, outlook, atlantic
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpilfesl, payrolls, jtsjol, dcoilwtico, rates, unemployment, labor, crude, assets, total, personal, supply
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, credit, equities, corporate, rates, crude, bitcoin, crypto, futures, yield, large, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=98, 7d-median=99, 14d-median=99; carrying terms: programs, yemen, administration, russian, target, drilling, office, order, stability, science, serious, haitian
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quantitative, unauthorized, quiverquant, quiver, client, httperror, https, congresstrading
- billionaires: today=40, 7d-median=34, 14d-median=36; carrying terms: finance, meyers, jensen, oracle, walton, bezos, exchange, diversified, adani, berkshire, canada, mexico
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, supreme, appeals, court, blanche, connecticut, state, california, company, international, trade, energy
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, therapeutics, group, robert, walsh, steven, investments, attovia
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: david, committee, sherrod, james, booker, cortez, cycle, raised, ossoff, cooper, warner, senate
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, japan
- gdelt_gkg: today=49, 7d-median=37, 14d-median=48; carrying terms: english, russian, themes, spanish, trump, chinese, russia, keywords, perimeter, german, sanctions, turkish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: iheart, attack, kingdom, domain, court, india, english, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=26; carrying terms: position, france, ground, belgium, canada, kingdom, germany, slovenia, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: recommendations, young, being, uganda, fifth, andes, resulting, fatality, history, government, containing, cvdpv
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: vulnerability, authentication, sensitive, injection, secure, remediation, vendor, firewall, cisco, deserialization, command, untrusted
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=236; carrying terms: belize, venezuela, impact, philippines, uganda, thailand, belarus, cambodia, macedonia, australia, croatia, hurricane
- usgs_quakes: today=8, 7d-median=13, 14d-median=13; carrying terms: depth, indonesia, islands, japan, philippines, region, sarangani, guinea, papua, kermadec
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: september, strait, resolves, august, normal, winner, hormuz, volume, traffic, price, returns, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, marginal, class, https, revolution, conversable, conversableeconomist, marginalrevolution, future, believe, having, economics
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: weekly, history, target, newsletter, water, computer, hackers, intelligence, google, bleepingcomputer, technology, software
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: vance, daines, hudson, weber, chellie, zeldin, white, moylan, turner, victoria, administration, whitehouse
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, paper, converges, markets, consensus, unavailable, claude, identify, placement, evidence, decision, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*