# WORLDSCOPE morning brief — 2026-10-28

## Headline
3482 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (824) · Russian Internal News (state + in-exile) (735) · State-Level News (369) · World leaders & government officials (324) · Chinese Internal News (243) · Ukraine Theater (total-war monitoring) (235) · Local News: St. Louis + Atlanta (222) · U.S. Weather + Severe / Climate Outlooks (116) · State Legislative Action (70) · Ukrainian Internal News (national + local Kyiv) (63) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (44)

## What changed today
### International News + Multilateral Institutions — 824 new of 1006 total
  - (2026-10-28) [Global] Africa’s ‘unprecedented’ Ebola outbreak could reach UK, says top health official
  - (2026-10-28) [Global] Flávio Bolsonaro on flight to Miami after fleeing Brazil amid election defeat
  - (2026-10-28) [Global] A US woman feared dead was reported alive in Mexico. But cops now say that isn’t true
  - (2026-10-28) [Global] King Charles to discuss legacy of slavery with Commonwealth leaders at summit
  - (2026-10-28) [Global] Flávio Bolsonaro flees Brazil after presidential election loss, reports say
  - (2026-10-27) [Global] Trump shows off tanker with ‘1m barrels of oil’ and floats Venezuela as 51st state

### Russian Internal News (state + in-exile) — 735 new of 1110 total
  - (2026-10-28) Какие книги читают в России на пятый год большой войны? И почему у государства не получилось сделать популярной пропаганду? Объясняет литературный критик Галина Юзефович (Carnegie Politika) | L] (ru:…
      Книжная индустрия в России переживает не лучшие времена. Падение продаж, рост цен, цензура, ушедшие западные писатели и издательства, а также засилье пропагандистских книг не могли не повлиять на то, что сейчас читают ро…
  - (2026-10-28) Война. 1708-й день. Путин читает европейским политикам лекцию об истории славян. Трамп надеется, что встреча президентов США, России и Украины состоится «очень скоро» | LEDE: «Медуза» с 24 ф] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-28) Как думаете, бывают ли РАЗРЕШЕННЫЕ в России террористические организации? Мы тоже удивились, но да! | LEDE: Мы обнаружили, что в марте 2026 года Национальный антитеррористический комитет опу] (ru: Как…
      Мы обнаружили, что в марте 2026 года Национальный антитеррористический комитет опубликовал «Сборник информационных материалов о деятельности организаций, признанных на территории РФ террористическими». Его подготовили со…
  - (2026-10-28) Катастрофа на железной дороге в Испании. Погибли не менее 50 человек. Фотографии | LEDE: В испанской провинции Толедо столкнулись два скоростных поезда. В результате погибли по меньшей мере ] (ru: Кат…
      В испанской провинции Толедо столкнулись два скоростных поезда. В результате погибли по меньшей мере 50 человек, сообщили в службе гражданской обороны. Движение поездов между Мадридом и Андалусией остановлено, на вокзала…
  - (2026-10-28) Роскомнадзор заблокировал ИИ-трек «Ты моя мразота» | LEDE: Вирусную нейропесню музыканта DJ NARODNII «Ты моя…» заблокировали на российских стриминговых сервисах, сообщают «Осторожно, новости] (ru: Рос…
      Вирусную нейропесню музыканта DJ NARODNII «Ты моя…» заблокировали на российских стриминговых сервисах, сообщают «Осторожно, новости».
  - (2026-10-28) На этом месте находился материал, который сейчас удален | LEDE: Дорогие читатели! На этой странице находился материал, посвященный эвакуации мирных жителей из города Алешки в Херсонской обла] (ru: На…
      Дорогие читатели! На этой странице находился материал, посвященный эвакуации мирных жителей из города Алешки в Херсонской области, оккупированного российскими войсками. При публикации была допущена ошибка: в материал поп…

### State-Level News — 369 new of 724 total
  - (2026-10-28) [Alabama] First Responders Day
      Download
  - (2026-10-27) [Alabama] First-Generation College Celebration Day
      Download
  - (2026-10-27) [Alabama] Governor Ivey Announces Helix Electric to Build $45.3 Million Facility in Jackson County, Create 160 Jobs
      Governor Kay Ivey on Tuesday announced electrical contractor Helix Electric broke ground on a $45.3 million facility in Jackson County that will create 160 jobs. “Helix Electric’s major investment in Jackson County is ex…
  - (2026-10-27) [Alabama] Governor Ivey Honors Final Trooper Class of Her Administration, Highlights Years of Crime Crackdowns and Public Safety Gains
      MONTGOMERY – Governor Kay Ivey on Tuesday hosted a graduation reception honoring 44 Alabama Law Enforcement Agency (ALEA) trooper trainees, the final trooper class of her Administration. She also highlighted the investme…
  - (2026-10-28) [California] Governor Newsom announces appointments 10.27.2026
      Source
  - (2026-10-27) [California] Governor Newsom doubles down on methane tracking as Trump moves to weaken pollution protections
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 243 new of 307 total
  - (2026-10-28) 今日开盘：两市双双高开 沪指涨幅0.78% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5qbjRJUkh3NlJTT1ltX0paWkRWVDhLNWZzOVdBc25ZeXA3U3RFUV8yVjlwSmlYMG1mQjhGNHVPYmxuS3dZdmh6LWZtdWZSc0JX] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.78% 财新
  - (2026-10-28) 靳羽西：从电视到口红，一个人的闯荡与中国开放年代｜人物 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1CcVVhaWc1OFRBaXdPNXBQWDloNXVwT1JPaHZxOWFMY1VLVUk0WTNtM0xkMmpHa0VfT09BWllBekNQOG84UjNVb0NuOV] (zh:…
      靳羽西：从电视到口红，一个人的闯荡与中国开放年代｜人物 财新
  - (2026-10-27) 华尔街重估AI融资热潮 巨额资本开支面临回报考验 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1UY1RlOUNUUWFXWU1QSEd6bEI5RTNoLVYxT0FkUWV6YkdYd1NBVV81WEhVRXRkd0oxaFJrV2hXOVhHdVpVLVhtSWZCblQyV] (zh:…
      华尔街重估AI融资热潮 巨额资本开支面临回报考验 财新
  - (2026-10-26) 【基金观察】那些上半年收益翻倍的基金 如今怎么样了？ - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9zMk5xUGsyNFdRTzEwMDU0TFNfdmNpMUZaR1VBNVl3TEx3UVY2VGt1OE1oUDBsVXNRa1ltMkhiVDQ5UERyZHhzbzVmW] (zh:…
      【基金观察】那些上半年收益翻倍的基金 如今怎么样了？ 财新数据
  - (2026-10-28) 当逝者的数据持续累积，谁将继承他们的数字遗产？｜带着问题去读书 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Ld0Z5M2ZBUUQzcVlYQTNoZ0VFUEdMdmdwWC1lRHBDTzFobXhYZ0F5T3Z4bVRRbDJydEhReHAyQXR5dkV6Z2J3Uz] (zh:…
      当逝者的数据持续累积，谁将继承他们的数字遗产？｜带着问题去读书 财新
  - (2026-10-27) 财经早知道｜张一鸣，中国首富！6700亿元刷新财富纪录 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBkUVhLai1qSFA0SkRhcUR3Y1drejBVUzNKSEFmWHROS21seVJ5UnljRW9qcGxGSzZfVFdsN0k5SzZYV3BlZEdKNWJKZG] (zh:…
      财经早知道｜张一鸣，中国首富！6700亿元刷新财富纪录 财新

### Ukraine Theater (total-war monitoring) — 235 new of 401 total
  - (2026-10-27) [FIRMS] thermal anomaly 44.255, 23.156 (FRP 3.07 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 1214Z, FRP 3.07 MW
  - (2026-10-27) [FIRMS] thermal anomaly 49.274, 34.317 (FRP 4.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 1034Z, FRP 4.61 MW
  - (2026-10-27) [FIRMS] thermal anomaly 49.440, 31.820 (FRP 3.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 1034Z, FRP 3.86 MW
  - (2026-10-27) [FIRMS] thermal anomaly 49.775, 32.626 (FRP 2.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 1034Z, FRP 2.18 MW
  - (2026-10-27) [FIRMS] thermal anomaly 49.781, 32.635 (FRP 3.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 1034Z, FRP 3.42 MW
  - (2026-10-27) [FIRMS] thermal anomaly 50.051, 34.051 (FRP 3.4 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 1034Z, FRP 3.4 MW

### Local News: St. Louis + Atlanta — 222 new of 274 total
  - (2026-10-28) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-10-28) [St. Louis] A home in Clayton hits the market
      Old Town ClaytonNestled in Old Town’s Bemiston neighborhood, this property is within walking distance to downtown Clayton and boasts quick access to major highways and St. Louis’ Forest Park. Artisan Craftmanship A black…
  - (2026-10-28) [St. Louis] A South City man dreamed of plummeting to earth in a pumpkin. He got his wish
      Last weekend, the late Louis Tacchi Jr. finally got what he’d wanted: for his ashes to be placed into a pumpkin and dropped out of a B-25 bomber. It happened at St. Charles County Regional Airport–Smartt Field. Every Oct…
  - (2026-10-28) [St. Louis] Where in Chesterfield 10/28/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-10-27) [St. Louis] Café Paradise brings coffee, wine, and neighborhood charm to Lindenwood Park
      Husband and wife Stephen Lindemann and Susannah Haddad have a sweet inside joke for any time they create something lovely together. “It’s paradise,” they say, which is why there was no question what they would name their…
  - (2026-10-27) [St. Louis] Police officer who escalated Bar:PM incident takes the stand—and offers no apologies
      It was good cop, bad cop on the first day of testimony in the trial pitting the owner of a South City gay bar against the St. Louis police officer who handcuffed him shortly after a police SUV smashed into his business.…

### U.S. Weather + Severe / Climate Outlooks — 116 new of 118 total
  - (2026-10-28) [Severe] Flood Watch: Flood Watch issued October 28 at 2:56AM HST until October 29 at 5:00AM HST by NWS Honolulu HI
      A trough moving over the state is bringing abundant tropical moisture expected to last though this evening. Heavy rain and isolated thunderstorms are expected to produce flash flooding, and while the greatest flood threa…
  - (2026-10-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-28) [Severe] Special Marine Warning: Special Marine Warning issued October 28 at 2:40AM HST until October 28 at 3:45AM HST by NWS Honolulu HI
      SMWHFO The National Weather Service in Honolulu has issued a * Special Marine Warning for... Maui County Leeward Waters... * Until 345 AM HST. * At 237 AM HST, a strong thunderstorm was located 14 nm southeast of FAD Buo…
  - (2026-10-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 28 at 7:24AM CDT until October 28 at 11:00AM CDT by NWS Fort Worth TX
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Falls, Freestone, Limestone, and Navarro Counties. * WHEN...Until 11 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions haza…
  - (2026-10-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 28 at 7:24AM CDT until October 28 at 11:00AM CDT by NWS Fort Worth TX
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Leon, Milam, and Robertson Counties. * WHEN...Until 11 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-10-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 28 at 7:16AM CDT until October 28 at 10:00AM CDT by NWS New Orleans LA
      * WHAT...Visibility of one quarter mile or less in dense fog. * WHERE...Lower St. Charles, St. James, St. John The Baptist, and Upper Lafourche Parishes. * WHEN...Until 10 AM CDT this morning. * IMPACTS...Low visibility…

### State Legislative Action — 70 new of 115 total
  - (2026-10-28) [Alaska SB 26] An Act petitioning the United States Department of Transportation to change the time zones of Alaska; exempting the state from daylight saving time; and providing for an effective date.
      An Act petitioning the United States Department of Transportation to change the time zones of Alaska; exempting the state from daylight saving time; and providing for an effective date.
  - (2026-10-28) [Alaska SB 237] An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Departm…
      An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Department of Administration; relating to e…
  - (2026-10-28) [Alaska SB 64] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating t…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-10-28) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-10-28) [Alaska HB 280] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and tele…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and telecommunications service providers; an…
  - (2026-10-28) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 63 new of 129 total
  - (2026-10-28) Єврокомісію заздалегідь попередили про дзвінок лідерів Фінляндії та Норвегії Путіну | LEDE: У Європейській комісії заявили, що знали про заплановану розмову президента Фінляндії Александра Стуб] (uk:…
      У Європейській комісії заявили, що знали про заплановану розмову президента Фінляндії Александра Стубба та прем'єра Норвегії Йонаса Гара Стьоре з Володимиром Путіним ще до дзвінка, який відбувся 27 жовтня.
  - (2026-10-28) Литва передасть Україні медичні засоби на суму 84,5 тис. євро | LEDE: ] (uk: Литва передасть Україні медичні засоби на суму 84,5 тис. євро)
  - (2026-10-28) Умєров попередив партнерів про фальшиві повідомлення від його імені: Вивідують інформацію про переговори | LEDE: Голова Служби зовнішньої розвідки України Рустем Умєров повідомив, що дипломатам] (uk:…
      Голова Служби зовнішньої розвідки України Рустем Умєров повідомив, що дипломатам і партнерам у різних країнах надсилають повідомлення від його імені, намагаючись отримати інформацію про переговори.
  - (2026-10-28) Зеленський прибув у Нідерланди | LEDE: Президент Володимир Зеленський у середу, 28 жовтня, прибув у Нідерланди для зустрічі з прем'єр-міністром країни Робом Єттеном.] (uk: Зеленський прибув у Нідерлан…
      Президент Володимир Зеленський у середу, 28 жовтня, прибув у Нідерланди для зустрічі з прем'єр-міністром країни Робом Єттеном.
  - (2026-10-28) Сікорський підлив масла у вогонь щодо скандалу довкола "сутенерського" минулого Навроцького | LEDE: У Варшаві відбулося засідання щодо позову Кароля Навроцького проти Onet через статтю про ніби] (uk:…
      У Варшаві відбулося засідання щодо позову Кароля Навроцького проти Onet через статтю про нібито організацію послуг повій.
  - (2026-10-28) У четвер частину України накриють дощі, у п’ятницю буде переважно сухо | LEDE: 29 жовтня у частині областей України пройдуть дощі, а вже 30 жовтня істотних опадів переважно не очікують. Денна т] (uk:…
      29 жовтня у частині областей України пройдуть дощі, а вже 30 жовтня істотних опадів переважно не очікують. Денна температура на більшості території становитиме 7-12° тепла.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-10-27) U.S. Court of Appeals, 2nd Cir.: Barberan v. Town of Eastchester
  - (2026-10-27) U.S. Court of Appeals, 2nd Cir.: Leos v. MUFG
  - (2026-10-27) Connecticut Supreme Court: Greenstein v. Thomas
  - (2026-10-27) U.S. Court of Appeals, 10th Cir.: United States v. Barrett
  - (2026-10-27) U.S. Court of Appeals, 10th Cir.: United States v. Koch
  - (2026-10-27) U.S. Court of Appeals, 6th Cir.: Susan Anne Wasserman v. Robert Beggs

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 57 total
  - (2026-10-28) [BleepingComputer] Hackers now scanning systems for recently-patched Oracle flaw
      Attackers have begun probing the Internet for systems unpatched against a recently disclosed critical Oracle E-Business Suite (EBS) vulnerability. [...]
  - (2026-10-28) [BleepingComputer] CISA warns of hackers now exploiting critical Node2Shell flaw
      On Tuesday, the US Cybersecurity and Infrastructure Security Agency (CISA) confirmed that hackers have begun exploiting a critical Brotli vulnerability known as Node2Shell, Broccoli2Shell, and HTTP2Shell. [...]
  - (2026-10-28) [BleepingComputer] Nefilim and Hive ransomware affiliate gets 70 months in prison
      A Ukrainian national was sentenced to 70 months in prison for his role in ransomware attacks targeting hospitals, government entities, and high-revenue businesses worldwide between 2018 and 2021. [...]
  - (2026-10-28) [The Hacker News] Adobe Fixes 8 Critical Campaign Classic Flaws Allowing Code Execution and Security Bypass
      Adobe has released patches to address multiple critical security flaws in Campaign Classic that, if successfully exploited, could result in arbitrary code execution, security feature bypass, and privilege escalation. The…
  - (2026-10-28) [The Hacker News] American Organizations Under Attack: Skyw4lker Device Code Phishing Campaign Exposed
      Modern phishing campaigns can compromise American businesses without relying on traditional credential theft. Attackers can abuse legitimate cloud services, authentication mechanisms, and trusted business workflows to ga…
  - (2026-10-28) [The Hacker News] Anthropic's Unreleased AI Model Chains Flaws Into Working Chrome, Safari, Windows and Linux Exploits
      An unreleased Anthropic AI model found security flaws in Chrome, Safari, Android, Windows, and Linux and chained them into working proof-of-concept exploits, the company said in its latest report. The exploits were built…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-28) 425 - FIRST COMMUNITY BANKSHARES INC /VA/ (0000859070) (Subject)
      filed 2026-10-28 12:54 UTC — Filed: 2026-10-28 AccNo: 0001437749-26-033708 Size: 3 MB
  - (2026-10-28) 425 - LCI INDUSTRIES (0000763744) (Subject)
      filed 2026-10-28 12:36 UTC — Filed: 2026-10-28 AccNo: 0000763744-26-000096 Size: 39 KB
  - (2026-10-28) [Fitzgerald Margaret Boles] Form 4 (Reporting)
      filed 2026-10-28 12:33 UTC · role: Reporting — Filed: 2026-10-28 AccNo: 0001628280-26-067740 Size: 5 KB
  - (2026-10-28) [Beacon Financial Corp] Form 4 (Issuer)
      filed 2026-10-28 12:33 UTC · role: Issuer — Filed: 2026-10-28 AccNo: 0001628280-26-067740 Size: 5 KB
  - (2026-10-28) 497 - Virtus Strategy Trust (0001423227) (Filer)
      filed 2026-10-28 12:30 UTC — Filed: 2026-10-28 AccNo: 0000930413-26-003163 Size: 7 KB
  - (2026-10-28) 497K - Tidal Trust III (0001722388) (Filer)
      filed 2026-10-28 12:28 UTC — Filed: 2026-10-28 AccNo: 0001999371-26-023673 Size: 929 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-28) PAT710 (United States)
      icao24: adfe54 · position: (37.2287, -78.9733) · alt: 6705m · 456km/h
  - (2026-10-28) PAT647 (United States)
      icao24: adfe95 · position: (34.623, -85.5398) · alt: 7620m · 434km/h
  - (2026-10-28) JEDI19 (United States)
      icao24: ae1ea9 · position: (30.488, -87.4002) · alt: 2362m · 437km/h
  - (2026-10-28) JEDI07 (United States)
      icao24: ae1eac · position: (30.7662, -88.028) · alt: 2484m · 429km/h
  - (2026-10-28) PAT865 (United States)
      icao24: adfebc · position: (30.971, -97.2549) · alt: 6705m · 705km/h
  - (2026-10-28) EAGLE09 (United States)
      icao24: adff72 · position: (33.8379, -88.2973) · alt: 1737m · 607km/h

### USGS earthquakes (M4.5+, past day) — 23 new of 23 total
  - (2026-10-28) M 6.0 - 214 km NW of Port-Olry, Vanuatu
      M6.0 · 214 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-28) M 5.6 - 174 km NW of Port-Olry, Vanuatu
      M5.6 · 174 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-28) M 5.5 - Reykjanes Ridge
      M5.5 · Reykjanes Ridge · depth 10 km
  - (2026-10-28) M 5.5 - 221 km NW of Port-Olry, Vanuatu
      M5.5 · 221 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-27) M 5.4 - 193 km WSW of Merizo Village, Guam
      M5.4 · 193 km WSW of Merizo Village, Guam · depth 100.998 km
  - (2026-10-27) M 5.4 - 210 km ENE of Nagqu, China
      M5.4 · 210 km ENE of Nagqu, China · depth 10 km

### U.S. Federal Action — 17 new of 17 total
  - (2026-10-28) Presidential Determination Pursuant to Section 303 of the Defense Production Act of 1950, as Amended, on Domestic Petroleum Production, Refining, and Logistics Capacity
  - (2026-10-28) Decreasing Housing Costs for the American People
  - (2026-10-28) National Seafood Month, 2026
  - (2026-10-28) Adjusting Imports of Wind Turbines and Their Parts and Components Into the United States
  - (2026-10-28) Television Broadcasting Services Elko, Nevada
      This document amends the Table of TV Allotments (table) of the Federal Communications Commission's (Commission) rules by substituting VHF channel 10 for UHF channel 20 at Elko, Nevada in response to a petition for rulema…
  - (2026-10-28) Fisheries of the Northeastern United States; Atlantic Bluefish Fishery; Quota Transfer From New York to North Carolina
      NMFS announces that the State of New York is transferring a portion of their 2026 commercial bluefish quota to the State of North Carolina. This quota adjustment is necessary to comply with the Atlantic Bluefish Fishery…

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 104 total
  - (2026-10-27) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Extreme Networks, Inc. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Extreme Networks, Inc. Office of Foreign Assets Control (.gov)
  - (2026-10-28) [USASpending] $399,660,463 → SOUTHERN OHIO CLEANUP COMPANY LLC: PORTSMOUTH (PORTS) DECONTAMINATION & DECOMMISSIONING (D&D) -
      Agency: Department of Energy. Description: PORTSMOUTH (PORTS) DECONTAMINATION & DECOMMISSIONING (D&D) - TASK ORDER 3 FISCAL YEARS 2026 THROUGH 2031
  - (2026-10-28) [USASpending] $397,858,199 → CALIFORNIA INSTITUTE OF TECHNOLOGY: WIDE FIELD INFRARED SURVEY TELESCOPE (WFIRST) CORONAGRAPH T
      Agency: National Aeronautics and Space Administration. Description: WIDE FIELD INFRARED SURVEY TELESCOPE (WFIRST) CORONAGRAPH THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRA…
  - (2026-10-28) [USASpending] $369,247,719 → ACCENTURE FEDERAL SERVICES LLC: USDA ENTERPRISE-SCALE FEDRAMP CERTIFIED CLOUD HOSTING SERVIC
      Agency: Department of Agriculture. Description: USDA ENTERPRISE-SCALE FEDRAMP CERTIFIED CLOUD HOSTING SERVICES. IGF::OT::IGF
  - (2026-10-28) [USASpending] $277,857,783 → ACCENTURE FEDERAL SERVICES LLC: CBP'S DATA CENTER SUPPORT SERVICES (DCSS).
      Agency: Department of Homeland Security. Description: CBP'S DATA CENTER SUPPORT SERVICES (DCSS).
  - (2026-10-28) [USASpending] $277,476,499 → TELEDYNE BROWN ENGINEERING, INC.: MARSHALL OPERATIONS SYSTEMS, SERVICES, AND INTEGRATION II (M
      Agency: National Aeronautics and Space Administration. Description: MARSHALL OPERATIONS SYSTEMS, SERVICES, AND INTEGRATION II (MOSSI II)

### Paper Trading Scorecard — 10 new of 64 total
  - (2026-10-28) [Manifold] Will gold (XAU/USD) close higher on Wednesday, October 28, 2026 than on Tuesday, October 27, 2026?
  - (2026-10-28) [Manifold] Will the Fed cut its target rate at the October 27-28, 2026 FOMC meeting?
  - (2026-10-28) [Manifold] Will Paris-Montsouris record at least 1 mm of rain on Thursday, October 29, 2026?
  - (2026-10-28) [Manifold] Will the first human walk on Venus before the first human walks on the Challenger Deep?
  - (2026-10-28) [Manifold] Will the Riemann Hypothesis be solved before December 2026
  - (2026-10-28) [Manifold] Will the first on-page dialogue of the Worm IDW comic book be 'Take that, you worm'?

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-10-28) Dota 2: PARIVISION vs Team Liquid (BO3) - PARI Universe Playoffs
      yes price: 100% · 24h volume: $1,540,414 · resolves 2026-10-28
  - (2026-10-28) Counter-Strike: TheMongolz vs Nemiga (BO3) - PGL Masters Bucharest Group Stage
      yes price: 30% · 24h volume: $1,398,359 · resolves 2026-10-28
  - (2026-10-28) Will Likud win 25-29 seats in the 2026 Israeli legislative election?
      yes price: 97% · 24h volume: $1,093,459 · resolves 2026-10-28
  - (2026-10-28) Will Naftali Bennett be the next Prime Minister of Israel?
      yes price: 5% · 24h volume: $886,987 · resolves 2026-10-28
  - (2026-10-28) Will Elon Musk win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $690,830 · resolves 2028-11-08
  - (2026-10-28) Will Avigdor Lieberman be the next Prime Minister of Israel?
      yes price: 2% · 24h volume: $653,876 · resolves 2026-10-28

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-28) [Marginal Revolution] Inequality in Equal Land
      Adam Nash has a good post on wealth inequality: …Every year, we pull the most recent data from the US Census on household wealth, cut by age. …invariably, the students’ initial response is a reaction to the apparent disp…
  - (2026-10-28) [Marginal Revolution] AI hacking risks
      That is the topic of my latest Free Press column (now there are gift links!), here is one excerpt, noting this is a worst-case scenario not a prediction: Yet current systems are likely to prove more robust than that sugg…
  - (2026-10-27) [Marginal Revolution] Tuesday assorted links
      1. Which musical styles do smart people prefer? 2. U. of Austin job ads. 3. Walter Koenig, RIP (NYT). Chekov. 4. One take on the new computational result. And one (overstated) Chinese interpretation. And another extreme…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 19 total
  - (2026-10-27) CVE-2026-48356 · Adobe Commerce and Magento: Adobe Commerce and Magento Unrestricted Upload of File with Dangerous Type Vulnerability
      vendor: Adobe · product: Commerce and Magento · CISA remediation by 2026-11-10
  - (2026-10-27) CVE-2026-111497 · Google Brotli: Google Brotli Unchecked Return Value Vulnerability
      vendor: Google · product: Brotli · CISA remediation by 2026-11-10

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=16, 14d-median=17; carrying terms: final, published, proposed, action, protection, proposing, certain, regulatory, control, safety, rulemaking, national
- state_bills: today=115, 7d-median=70, 14d-median=109; carrying terms: provides, state, california, requiring, emergency, local, procedures, public, persons, district, facilities, relating
- state_news: today=724, 7d-median=678, 14d-median=688; carrying terms: control, https, residents, seats, request, among, think, senator, michigan, figure, flgov, appeared
- local_news: today=274, 7d-median=248, 14d-median=239; carrying terms: https, appeared, years, brings, voters, missing, georgia, around, child, finals, target, trump
- foreign_news: today=1006, 7d-median=999, 14d-median=1006; carrying terms: spread, https, residents, publications, diario, protests, questions, netanyahu, opposition, final, begin, working
- chinese_internal: today=307, 7d-median=270, 14d-median=278; carrying terms: https, cbmibkfvx, target, cbmib, lxtfa, cbmizefvx, color, cbmiy, cbmia, title, market, lxtfb
- russian_internal: today=1110, 7d-median=1010, 14d-median=1019; carrying terms: reuters, error, https, politico, found, novayagazeta, telegram, media, spacex, httperror, raquo, title
- ukrainian_internal: today=129, 7d-median=130, 14d-median=130; carrying terms: control, https, partners, european, month, institute, cabinet, washington, agreement, attack, comes, moscow
- ukraine_theater: today=401, 7d-median=392, 14d-median=397; carrying terms: control, https, hewljiugrgx, ohzybwpxyurfcvrzy, mxrudhc, ulfltl, dataroom, lbtzdwxruru, vjbkl, among, zufyymt, hfagtodhm
- paper_bets: today=64, 7d-median=64, 14d-median=66; carrying terms: goals, drought, problems, named, passing, inflation, millennium, openai, allen, force, evans, fusion
- weather: today=118, 7d-median=136, 14d-median=138; carrying terms: roads, watch, baltimore, difficult, chance, flood, strong, coastal, seattle, river, severe, counties
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: effective, jolts, consumption, spread, inflation, cpiaucsl, funds, balance, payrolls, headline, implied, jtsjol
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, silver, russell, crypto, futures, nasdaq, yield, proxy, crude, rates, commodities, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=104, 7d-median=102, 14d-median=104; carrying terms: control, engineering, https, prohibiting, attacks, systems, mission, aggression, russia, protests, detect, terrorism
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, error, unauthorized, congresstrading, https, quiverquant, httperror, quantitative, quiver
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, appeals, supreme, court, state, board, delaware, blanche, trade, arkansas, alabama, company
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, filed, issuer, filer, trust, financial, subject, funds, investment, acquisition
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, booker, congress, committee, shawn, sherrod, angels, cooper, raised, receipts, alexandria, robert
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, japanherald, china
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, keywords, sanctions, israel, themes, russia, perimeter, chinese, spanish, russian, ukrainian, netanyahu
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=28; carrying terms: belgium, ground, position, france, kingdom, germany, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: control, saudi, young, indicating, spread, however, focal, regio, influenza, institut, siberia, measures
- cisa_kev: today=19, 7d-median=17, 14d-median=15; carrying terms: control, remediation, secure, product, vendor, traversal, spoofing, authentication, bypass, cisco, improper, server
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=100, 14d-median=100; carrying terms: wildfire, hurricane, earthquake, maximum, magnitude, alert, typhoon, depth, guinea, cyclone, nigeria, tropical
- usgs_quakes: today=23, 7d-median=22, 14d-median=20; carrying terms: depth, vanuatu, russia, philippines, indonesia, islands, tonga, china, panama, south, vilyuchinsk, nagqu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: meeting, price, resolves, interest, october, volume, rates, election, presidential, change, increase, decrease
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, https, class, revolution, marginal, economist, marginalrevolution, world, economic, government, example, money
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: control, https, attacks, systems, computer, service, already, websites, technology, schneier, bleepingcomputer, attack
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: charles, yassamin, ralph, mannion, jeanne, sonderling, abraham, capito, bernie, cisneros, clyde, tillis
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, identify, today, either, evidence, markets, placed, sufficient, unavailable, placement, paper, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks
- [2026-10-23] ECB press: ECB Consumer Expectations Survey results – September 2026
- [2026-10-24] ECB press: Piero Cipollone: Interview with Milano Finanza
- [2026-10-26] ECB press: Frank Elderson: Taking action for nature – investing in economic resilience and prosperity
- [2026-10-26] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-10-27] ECB press: October 2026 euro area bank lending survey

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*