# WORLDSCOPE morning brief — 2026-10-30

## Headline
3412 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (837) · Russian Internal News (state + in-exile) (689) · State-Level News (396) · World leaders & government officials (324) · Chinese Internal News (236) · Local News: St. Louis + Atlanta (234) · U.S. Weather + Severe / Climate Outlooks (148) · Ukraine Theater (total-war monitoring) (136) · Ukrainian Internal News (national + local Kyiv) (68) · GDACS — global disaster alerts (56) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (39)

## What changed today
### International News + Multilateral Institutions — 837 new of 1065 total
  - (2026-10-30) [Global] From Levi's to Primark - the fashion chains selling mended clothes
      A new generation is embracing eye-catching patching and visible mends.
  - (2026-10-30) [Global] Yorkshire Water boss resigns after firm downgraded
      Nicola Shaw, who has led the company since 2022, will step down in January, it is announced.
  - (2026-10-30) [Global] Streeting denies 'kicking can down the road' in defence spending row
      The government is under pressure to set out a path to greater defence spending, as ministers unveil plans to boost UK firms.
  - (2026-10-30) [Global] Google value plunges by $500bn as its own AI search hits ad sales
      Google spooked investors so badly that its stock hit a six-month low, after it revealed its AI own search summaries were affecting ad revenue.
  - (2026-10-30) [Global] How video game remakes tap the power of nostalgia
      Video games are good at triggering nostalgia, a key reason why classic games keep getting remade.
  - (2026-10-29) [Global] Burnham 'ready to support' Poundland staff as retailer faces collapse
      Poundland's bosses are filing a notice of intention to appoint administrators to the business.

### Russian Internal News (state + in-exile) — 689 new of 1114 total
  - (2026-10-30) Хегсет уволил генерала, которого заподозрили в утечке информации о войнах в Иране и в Украине. Он трижды не прошел проверку на полиграфе | LEDE: Министр обороны США Пит Хегсет уволил генерал] (ru: Хег…
      Министр обороны США Пит Хегсет уволил генерал-лейтенанта армии Бретта Сильвию, занимавшего должность главы управления стратегии, планирования и политики в Объединенном комитете начальников штабов, пишут The Hill, NBC New…
  - (2026-10-30) В Загребе угнали автомобиль главы Bugatti за 2,4 миллиона евро. Он оставил ключи от машины в салоне, потому что всегда так делал. Больше не делает | LEDE: Недалеко от Загреба угнали автомоби] (ru: В З…
      Недалеко от Загреба угнали автомобиль генерального директора Bugatti Мате Римаца, это произошло из-за того, что он оставил ключи зажигания в салоне машины. Об этом сам Римац рассказал в инстаграме.
  - (2026-10-30) Во взломе криптобиржи Binance заподозрили северокорейских хакеров, связанных с Россией | LEDE: За кражей более шести миллиардов долларов с криптобиржи Binance может стоять северокорейская ха] (ru: Во…
      За кражей более шести миллиардов долларов с криптобиржи Binance может стоять северокорейская хакерская группировка TraderTraitor, которая также известна как Lazarus Group. К такому выводу пришли аналитические компании TR…
  - (2026-10-30) Несгибаемые. Заявление редакции «Медузы» и других журналистов — в поддержку «Новой газеты» | LEDE: «Новая газета» объявила, что закрывается. Мы никогда не думали, что нам доведется написать ] (ru: Нес…
      «Новая газета» объявила, что закрывается. Мы никогда не думали, что нам доведется написать такие слова — и тем не менее, это реальность. История важнейшего независимого издания в современной России подошла к концу.
  - (2026-10-30) В Польше задержали россиянина, который фотографировал поезда. Его арестовали по делу о шпионаже | LEDE: В городе Свидница в Нижнесилезском воеводстве Польши задержали 55-летнего россиянина, ] (ru: В П…
      В городе Свидница в Нижнесилезском воеводстве Польши задержали 55-летнего россиянина, который фотографировал поезда и железнодорожную инфраструктуру, сообщает газета Rzeczpospolita.
  - (2026-10-30) Самый мощный ударный корабль российского флота — атомный крейсер «Петр Великий» — решили не восстанавливать из-за износа | LEDE: Специальная комиссия признала нецелесообразным ремонт и модер] (ru: Сам…
      Специальная комиссия признала нецелесообразным ремонт и модернизацию тяжелого атомного ракетного крейсера «Петр Великий». Об этом сообщил глава Общероссийского движения поддержки флота Владимир Мальцев.

### State-Level News — 396 new of 797 total
  - (2026-10-30) [California] California can’t afford to keep Prop 13 loopholes open when billions of dollars are on the line
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/06/021023-CANNABIS-CRASH-MHN-46-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-10-30) [California] How Prop 45 could reshape California’s fight over data centers
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/083126_DATA-CENTERS_AHK_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-10-30) [California] Google and Meta spent big this election cycle. Is Big Tech trying to ‘buy the legislature’?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/091225_End-Of-Session_FG_CM_30.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-10-30) [California] Candidates are giving lowkey instructions on how to attack their opponents. Here’s how it works
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/063025-Budget-Assembly-MG-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-10-30) [California] Has the Trump administration doomed Newsom’s water plan?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/051123_Banks-Delat-Pumps_DWR_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-10-30) [California] For the record: Fresno man deported by ICE had previous illegal crossings
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/102126-ArreguinDeportation-DR-CM-07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 236 new of 278 total
  - (2026-10-28) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE1TNFlrSXNROFcwWlFPNjM4eGxJYlMtWHZkLUFhZnF5d3ZvblRFUndUakdjaGtYaWs2bUJaa3FlN2h6MEZ2RXVpTHZ1WjNSM1pURW1sNFBKXzJKTjRj?oc=5"] (zh:…
      财新
  - (2026-10-28) 弗拉维奥被曝逃离巴西流亡美国迈阿密 美方称已发放签证 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE83RE9ibXNHSnZrYXJ3alRLVW9PNVpYMEFYb1AxRVB1REVIRnZocHJVUU1GN2VDcDFOLVkwdjV0a3p3RW90cVI0amY3dDh] (zh:…
      弗拉维奥被曝逃离巴西流亡美国迈阿密 美方称已发放签证 财新
  - (2026-10-28) 美国人退休后为何不愿动用退休账户储蓄 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFAwcFUzcTJmcTlkNmZ4SnFSZ0RlaVk5VXVtOUZ0V29GZXVuSjVhMVFtVXhHMU50NFlqdUx5OWU1eXV1LTdaSUdqaVdqTXV5Ujh4U2p] (zh:…
      美国人退休后为何不愿动用退休账户储蓄 财新
  - (2026-10-30) 【华尔街原声】《大空头》原型人物：Anthropic收入增速明显放缓 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE4zVHpYbTlHa3RmdmxQZ3FDbXByX0QzN3RZUEUtdDV3aDFzU014bHJxM25UVmwxSXZCZGFoeVhOYlM0ZmJGa] (zh:…
      【华尔街原声】《大空头》原型人物：Anthropic收入增速明显放缓 财新数据
  - (2026-10-30) 【市场动态】英特尔季度营收展望逊于预期 受PC需求疲软和零部件供应短缺拖累 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE5Sd0ZzLUlnWE9GWmRvRTVoSFRENEs3THVPTlNuR3NLQkg4dnpLUFp1UmdJRk9tLVdINlZHXzM3WlBVX2] (zh:…
      【市场动态】英特尔季度营收展望逊于预期 受PC需求疲软和零部件供应短缺拖累 财新数据
  - (2026-10-30) 【市场动态】微软250亿美元发债获热捧 科技巨头未必都能获得同等待遇 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9YRWl0djVobFJ2SUpaSDNSSngzWWJGemU5ZWxJdnJraTRSc2tQOXZSXzdsbEFXWDdnbWw3cWwyLWQ4VGp3N] (zh:…
      【市场动态】微软250亿美元发债获热捧 科技巨头未必都能获得同等待遇 财新数据

### Local News: St. Louis + Atlanta — 234 new of 266 total
  - (2026-10-30) [St. Louis] Ask George: Are restaurants seeing an increase in bogus complaints from diners seeking freebies?
      Eight years ago, an “Ask George” column posed the question, “How common are restaurant scams?” My answer then: “Not that common, but nevertheless it’s a subject that restaurant chefs and owners love to grouse about.” (It…
  - (2026-10-30) [St. Louis] Meet the new companies Arch Grants is betting on to grow quickly in St. Louis
      Arch Grants has unveiled the 16 startups making up its 2026 cohort, which the nonprofit is supporting with grants totalling $1.35 million. It’s the 15th year the nonprofit has awarded nondilutive grants of $75,000 each t…
  - (2026-10-30) [St. Louis] Prop B tax hike could mean more money for an unrelated cause: St. Louis Police
      Backers of Prop B want St. Louis voters to say yes to a sales tax hike aimed at raising $22.4 million for early childhood education. But City Counselor Michael Garvin warns that they’re looking, at best, at more like $16…
  - (2026-10-30) [St. Louis] St. Louis court rolls out counseling for jurors struggling with their service
      When Tamra Thorsen was summoned to jury duty in St. Louis in the summer of 2025, she had no idea of the human suffering she’d be called to witness. It began even before she was selected for the panel: While lawyers probe…
  - (2026-10-30) [St. Louis] What’s True in the Lou? – 10/30/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-10-29) [St. Louis] Lorenzoz Restaurant & Lounge brings a modern steakhouse concept to Downtown West
      Lorenzoz Restaurant & Lounge (2005 Locust) offers a new modern American steakhouse concept in the former Pepper Lounge space. The menu features dry-aged USDA Prime cuts, seafood, and craft cocktails. Here’s what to know…

### U.S. Weather + Severe / Climate Outlooks — 148 new of 150 total
  - (2026-10-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-30) [Moderate] Special Weather Statement: Special Weather Statement issued October 30 at 4:50AM AKDT by NWS Fairbanks AK
      Snowfall is expected through Atigun Pass beginning Friday morning through Saturday night. 4 to 8 inches are expected during this time and may make travel difficult. Wind gusts up to 25 mph may reduce visibility to below…
  - (2026-10-30) [Severe] Flash Flood Warning: Flash Flood Warning issued October 30 at 7:44AM CDT until October 30 at 10:45AM CDT by NWS Midland/Odessa TX
      FFWMAF The National Weather Service in Midland/Odessa has issued a * Flash Flood Warning for... Central Martin County in western Texas... * Until 1045 AM CDT. * At 744 AM CDT, trained weather spotters reported showers pr…
  - (2026-10-30) [Moderate] Special Weather Statement: Special Weather Statement issued October 30 at 4:37AM AKDT by NWS Fairbanks AK
      Heavy snow is expected along the Dalton Highway through Saturday morning. Total snow accumulations could range between 5 and 10 inches during this time frame. Travel could become difficult during periods of heavier snowf…
  - (2026-10-30) [Severe] Flood Warning: Flood Warning issued October 30 at 7:36AM CDT until October 31 at 5:57AM CDT by NWS Topeka KS
      ...The Flood Warning continues for the following rivers in Kansas... Big Blue River near Blue Rapids affecting Marshall County. * WHAT...Minor flooding is occurring and minor flooding is forecast. * WHERE...Big Blue Rive…
  - (2026-10-30) [Severe] High Wind Warning: High Wind Warning issued October 30 at 4:29AM AKDT until October 30 at 4:00PM AKDT by NWS Fairbanks AK
      * WHAT...Southeast winds 30 to 45 mph with gusts up to 70 mph expected. * WHERE...Windy Pass. * WHEN...Until 4 PM AKDT this afternoon. * IMPACTS...Gusty winds will blow around unsecured objects. Tree limbs could be blown…

### Ukraine Theater (total-war monitoring) — 136 new of 342 total
  - (2026-10-30) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-29) [FIRMS] thermal anomaly 51.257, 34.991 (FRP 2.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-29 0956Z, FRP 2.41 MW
  - (2026-10-29) [FIRMS] thermal anomaly 51.258, 34.977 (FRP 5.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-29 0956Z, FRP 5.71 MW
  - (2026-10-29) [FIRMS] thermal anomaly 51.262, 34.975 (FRP 5.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-29 0956Z, FRP 5.71 MW
  - (2026-10-29) [FIRMS] thermal anomaly 51.261, 34.969 (FRP 5.43 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-29 0956Z, FRP 5.43 MW
  - (2026-10-29) [FIRMS] thermal anomaly 51.256, 34.990 (FRP 5.65 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-29 0956Z, FRP 5.65 MW

### Ukrainian Internal News (national + local Kyiv) — 68 new of 134 total
  - (2026-10-30) Zelensky Ready to Discuss Territory With Putin, Sybiha Says
      President Volodymyr Zelensky is ready to discuss territorial issues directly with Vladimir Putin, Foreign Minister Andrii Sybiha said. Kyiv backed the Finnish and Norwegian leaders’ call with Putin to advance ceasefire e…
  - (2026-10-30) Kyiv Builds Backup Crossings as Russia Targets Bridges
      Construction of backup river crossings has begun in Kyiv as part of a nationwide plan for 21 alternative routes amid Russian attacks on bridges. The first crossings in the capital are expected to open in early 2027, Infr…
  - (2026-10-30) ‘Inner Need to Engage With Heritage’ – Ukrainian Singer Khrystyna Soloviy on Stories Through Music
      In an exclusive interview with Kyiv Post, Khrystyna Soloviy discusses reimagining Ukrainian music from the 1990s, artists’ responsibility toward their cultural heritage, and challenging Soviet-era stereotypes. She also r…
  - (2026-10-30) ‘Get Them There Alive’: Ukraine’s Railways Under Russian Barrage
      Russia’s escalating attacks on Ukraine’s railway infrastructure have made train travel increasingly dangerous, forcing Ukrainian Railways to evacuate passengers whenever drone strikes threaten trains and stations. With h…
  - (2026-10-30) ‘Dark Days for Ukraine and Europe’: Nahaylo Warns Ahead of US Midterms | Bohdan Nahaylo
      Bohdan Nahaylo, editor-in-chief of the Kyiv Post, says the upcoming peace talks in Abu Dhabi have almost no chance of ending Russia’s war against Ukraine, giving their prospects just two out of ten.
  - (2026-10-30) Europe Launches $24 Billion Round of SAFE Funding, Focus on Ukraine
      The European Commission announced the second funding round under the Security Action for Europe (SAFE) program on Thursday. All 27 EU Member States are eligible to apply for a share of the €21.3 billion ($24 billion) ava…

### GDACS — global disaster alerts — 56 new of 100 total
  - (2026-10-30) [Green] Earthquake in Greece
      Earthquake · Green alert · Greece · Magnitude 4.7M, Depth:10km
  - (2026-10-30) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 4.5M, Depth:10km
  - (2026-10-30) [Green] Earthquake in Balleny Islands Region
      Earthquake · Green alert · Balleny Islands Region · Magnitude 5.1M, Depth:10km
  - (2026-10-30) [Green] Earthquake in Russia
      Earthquake · Green alert · Russia · Magnitude 4.6M, Depth:43.625km
  - (2026-10-30) [Green] Earthquake in Fiji Islands Region
      Earthquake · Green alert · Fiji Islands Region · Magnitude 4.8M, Depth:371.793km
  - (2026-10-30) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 4.6M, Depth:56.598km

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-30) 497VPU - FIDELITY INVESTMENTS VARIABLE ANNUITY ACCOUNT I (0000821051) (Filer)
      filed 2026-10-30 12:58 UTC — Filed: 2026-10-30 AccNo: 0001193125-26-439989 Size: 31 KB
  - (2026-10-30) 497VPI - FIDELITY INVESTMENTS VARIABLE ANNUITY ACCOUNT I (0000821051) (Filer)
      filed 2026-10-30 12:57 UTC — Filed: 2026-10-30 AccNo: 0001193125-26-439984 Size: 31 KB
  - (2026-10-30) 497 - FIDELITY INVESTMENTS VARIABLE ANNUITY ACCOUNT I (0000821051) (Filer)
      filed 2026-10-30 12:55 UTC — Filed: 2026-10-30 AccNo: 0001193125-26-439982 Size: 624 KB
  - (2026-10-30) 425 - LCI INDUSTRIES (0000763744) (Subject)
      filed 2026-10-30 12:55 UTC — Filed: 2026-10-30 AccNo: 0000763744-26-000105 Size: 1 MB
  - (2026-10-30) [Ostfeld Scott] Form 4 (Reporting)
      filed 2026-10-30 12:54 UTC · role: Reporting — Filed: 2026-10-30 AccNo: 0000902664-26-004313 Size: 5 KB
  - (2026-10-30) [MERCURY SYSTEMS INC] Form 4 (Issuer)
      filed 2026-10-30 12:54 UTC · role: Issuer — Filed: 2026-10-30 AccNo: 0000902664-26-004313 Size: 5 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 55 total
  - (2026-10-30) [BleepingComputer] CISA says max severity GitLab flaw now exploited in the wild
      Attackers have started exploiting a maximum-severity GitLab vulnerability patched earlier this month, according to the US Cybersecurity and Infrastructure Security Agency (CISA). [...]
  - (2026-10-30) [BleepingComputer] Microsoft finally fixes VPN issues caused by September updates
      Microsoft has resolved Always On VPN connection failures triggered after installing the September 2026 Windows 11 security updates. [...]
  - (2026-10-30) [BleepingComputer] Drupal warns of critical Commerce Core flaw exploited in attacks
      Drupal warned admins to patch a critical access bypass vulnerability in the Commerce Core module that attackers are exploiting in the wild. [...]
  - (2026-10-30) [BleepingComputer] Binance links $6.3 billion crypto theft to compromised DevOps laptop
      Binance, the world's largest crypto exchange, has linked the theft of about $6.3 billion in cryptocurrency to a DevOps engineer's compromised laptop. [...]
  - (2026-10-30) [The Hacker News] Trezor Warns of Suspected Hardware Implant in One of Its Wallets Sold by CryptoBilis
      A Trezor Safe 5 hardware wallet bought from the reseller CryptoBilis has an extra circuit board that sends out the recovery phrase over a mobile network, a customer has reported. Trezor has not yet examined the device. I…
  - (2026-10-30) [The Hacker News] Why Urgent Security Fixes Aren't Fixed. Observe, Prove, Act, Confirm Gets Them Moving
      The alert is critical. The fix is known. And the ticket sits in a queue for days. Security teams understand the risk, but the people who keep applications available need proof that the change won’t break anything. Their…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-10-30) #1 Elon Musk — $916.79B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-10-30) #2 Jeff Bezos — $364.35B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-10-30) #3 Michael Dell — $246.66B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-10-30) #4 Larry Page — $235.89B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-10-30) #5 Sergey Brin — $217.17B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-10-30) #6 Mark Zuckerberg — $214.61B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-10-30) PAT880 (United States)
      icao24: adfe47 · position: (39.8714, -76.098) · alt: 4709m · 295km/h
  - (2026-10-30) JEDI18 (United States)
      icao24: ae1ea9 · position: (30.3027, -87.8014) · alt: 2301m · 422km/h
  - (2026-10-30) CNA22 (Spain)
      icao24: 3475cb · position: (28.5453, -16.4156) · alt: 670m · 106km/h
  - (2026-10-30) PAT22 (United States)
      icao24: ae77cb · position: (38.8094, -76.0775) · alt: 22m · 53km/h
  - (2026-10-30) PAT13 (United States)
      icao24: ae77ed · position: (38.7186, -77.3721) · alt: 617m · 237km/h
  - (2026-10-30) FNY55B3 (France)
      icao24: 39a407 · position: (48.5082, -3.8637) · alt: 6263m · 628km/h

### Court opinions of consequence (federal & state) — 19 new of 60 total
  - (2026-10-29) U.S. Court of Appeals, 8th Cir.: Donald Stephens v. Harcros Chemicals
  - (2026-10-29) U.S. Court of Appeals, 8th Cir.: United States v. Steville Burns
  - (2026-10-29) Arkansas Supreme Court: Arkansas Department of Finance and Administration v. Randall Risor and Tia Risor
  - (2026-10-29) Arkansas Supreme Court: BERNICE RUTLAND v. TODD C. STEWART, INDIVIDUALLY; TODD C. STEWART D.D.S., P.A.; AND ROCK DENTAL ARKANSAS, PLLC, D/B/A HELENA FAMILY DENTAL
  - (2026-10-29) Arkansas Supreme Court: Cooper Wesley v. State of Arkansas
  - (2026-10-29) Arkansas Supreme Court: Darius Burnett v. Lona McCastlain; Dexter Payne, Director, Arkansas Division of Correction; And Arkansas Post-Prison Transfer Board

### U.S. Federal Action — 18 new of 18 total
  - (2026-10-30) Further Modifying the Scope of Products of Canada Subject to the Additional Duties Imposed To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Motor Vehicles
  - (2026-10-30) Safety Zone; M/T KALAHARI, Gulf of America, Pascagoula, MS
      The Coast Guard is establishing a temporary safety zone for navigable waters of the Gulf of America. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards associated w…
  - (2026-10-30) Safety Zone; S.S. UNITED STATES Dead Ship Tow, Sector Mobile Captain of the Port Zone, Mobile, AL
      The Coast Guard is establishing a temporary moving safety zone around the S.S. UNITED STATES and all vessels involved in its towage through the Mobile River Channel, Mobile Bay, and the Gulf of America. The safety zone i…
  - (2026-10-30) Standard Instrument Approach Procedures, and Takeoff Minimums and Obstacle Departure Procedures; Miscellaneous Amendments
      This rule amends, suspends, or removes Standard Instrument Approach Procedures (SIAPs) and associated Takeoff Minimums and Obstacle Departure Procedures for operations at certain airports. These regulatory actions are ne…
  - (2026-10-30) Standard Instrument Approach Procedures, and Takeoff Minimums and Obstacle Departure Procedures; Miscellaneous Amendments
      This rule establishes, amends, suspends, or removes Standard Instrument Approach Procedures (SIAPS) and associated Takeoff Minimums and Obstacle Departure procedures (ODPs) for operations at certain airports. These regul…
  - (2026-10-30) Fisheries of the Exclusive Economic Zone off Alaska; Pollock in Statistical Area 630 in the Gulf of Alaska
      NMFS is prohibiting directed fishing for pollock in Statistical Area 630 in the Gulf of Alaska (GOA). This action is necessary to prevent exceeding the annual 2026 total allowable catch (TAC) of pollock in Statistical Ar…

### Paper Trading Scorecard — 17 new of 70 total
  - (2026-10-30) [Polymarket] Will Ethereum dip to $1,250 by December 31, 2026?
      This market will resolve to "Yes" if any Binance 1 minute candle for Ethereum (ETH/USDT) between the creation of this market through 11:59 PM ET on the last day of the year specified in the title has a final “Low” price…
  - (2026-10-30) [Manifold] NFL Week 8: Will Seattle Seahawks beat Chicago Bears by 4 or more points?
  - (2026-10-30) [Manifold] Will Binance officially announce the resumption of crypto withdrawals before November 1, 2026, 12:36 UTC?
  - (2026-10-30) [Manifold] Will bitcoin reach 81000 by 10/31/2026 11:59pm
  - (2026-10-30) [Manifold] Catholic Church change it's publicly known name to the Synodal Church before Christmas Eve 2031!
  - (2026-10-30) [Manifold] Will Daniela Amodei stop being Anthropic's president by the end of 2027?

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 105 total
  - (2026-10-29) [OFAC] Issuance of Amended Iran-related General License - Office of Foreign Assets Control (.gov)
      Issuance of Amended Iran-related General License Office of Foreign Assets Control (.gov)
  - (2026-10-29) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE FF-1 Authorizin - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE FF-1 Authorizin Office of Foreign Assets Control (.gov)
  - (2026-10-26) [OFAC] 10 - Office of Foreign Assets Control (.gov)
      10 Office of Foreign Assets Control (.gov)
  - (2026-10-26) [OFAC] 49 - Office of Foreign Assets Control (.gov)
      49 Office of Foreign Assets Control (.gov)
  - (2026-10-30) [USASpending] $36,289,094,015 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-10-30) [USASpending] $20,172,513,578 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-10-29) M 6.2 - 43 km ESE of Port-Olry, Vanuatu
      M6.2 · 43 km ESE of Port-Olry, Vanuatu · depth 142.833 km
  - (2026-10-30) M 5.1 - Balleny Islands region
      M5.1 · Balleny Islands region · depth 10 km
  - (2026-10-30) M 5.1 - 97 km NNE of Finschhafen, Papua New Guinea
      M5.1 · 97 km NNE of Finschhafen, Papua New Guinea · depth 116.297 km
  - (2026-10-29) M 5.0 - 131 km NNW of Tual, Indonesia
      M5.0 · 131 km NNW of Tual, Indonesia · depth 10 km
  - (2026-10-29) M 5.0 - 143 km S of False Pass, Alaska
      M5.0 · 143 km S of False Pass, Alaska · depth 15.602 km
  - (2026-10-30) M 4.8 - Fiji region
      M4.8 · Fiji region · depth 371.793 km

### State Legislative Action — 13 new of 82 total
  - (2026-10-29) [Alabama SB 271] Lieutenant Governor, vacancy in office, require the office be filled by election in certain circumstances, constitutional amendment
      Constitutional Amendments Statewide
  - (2026-10-30) [Alaska HB 260] An Act relating to penalties for violating a requirement for a certificate of fitness; relating to joint and several liability for unpaid construction wages; and relating to the jurisd…
      An Act relating to penalties for violating a requirement for a certificate of fitness; relating to joint and several liability for unpaid construction wages; and relating to the jurisdiction of the office of administrati…
  - (2026-10-30) [Alaska HB 267] An Act relating to employer contributions to the unemployment compensation fund; establishing an employer contribution for the state training and employment program; and providing for…
      An Act relating to employer contributions to the unemployment compensation fund; establishing an employer contribution for the state training and employment program; and providing for an effective date.
  - (2026-10-30) [Alaska HB 16] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits for state and local office; direct…
  - (2026-10-30) [Alaska HB 25] An Act relating to disposable food service ware and containers provided by customers; and providing for an effective date.
      An Act relating to disposable food service ware and containers provided by customers; and providing for an effective date.
  - (2026-10-29) [Alaska SB 259] An Act relating to an optional municipal limit to increases of the full and true value of property owned and occupied as a permanent place of abode by a resident.
      An Act relating to an optional municipal limit to increases of the full and true value of property owned and occupied as a permanent place of abode by a resident.

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-10-30) Will the Republican Party control the Senate after the 2026 Midterm elections?
      yes price: 28% · 24h volume: $1,329,719 · resolves 2026-11-04
  - (2026-10-30) US x Iran ceasefire continues through October 31?
      yes price: 93% · 24h volume: $838,714 · resolves 2026-10-31
  - (2026-10-30) Will JD Vance win the 2028 US Presidential Election?
      yes price: 19% · 24h volume: $761,031 · resolves 2028-11-08
  - (2026-10-30) Dota 2: Team Spirit vs PARIVISION (BO3) - PARI Universe Playoffs
      yes price: 84% · 24h volume: $750,954 · resolves 2026-10-30
  - (2026-10-30) Counter-Strike: Nemiga vs Vitality (BO3) - PGL Masters Bucharest Playoffs
      yes price: 42% · 24h volume: $711,876 · resolves 2026-10-30
  - (2026-10-30) 2026 Balance of Power: R Senate, D House
      yes price: 24% · 24h volume: $692,092 · resolves 2026-11-04

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-30) [Marginal Revolution] Better Incentives, More Kidneys, More Lives
      The organ procurement system has long been a miasma of inefficient monopoly providers. In 2024 I quoted some shocking facts from a great Statecraft interview with Jennifer Erickson and Greg Segal: “Organs are literally l…
  - (2026-10-30) [Marginal Revolution] Are there too many misdemeanor convictions?
      Maybe so: Misdemeanors account for three-quarters of criminal cases filed annually in the United States, yet causal evidence on the impacts of misdemeanor conviction is scarce. We combine administrative and survey data t…
  - (2026-10-30) [Marginal Revolution] Chronicle of Higher Education interviews me on AI and education
      Scott Carlson did the work (gated, but free with registration), here is one excerpt: Cowen: …Another proposal I’ve made is that schools should let people do one class, only one class, AI-only — no professor, except a pro…
  - (2026-10-29) [Conversable Economist] A Primer on Health Care Systems Across Countries
      Discussions with the US about the American health care system often counterpose the well-known issues of the US health care system (high costs, lack of health insurance, unequal access to care, lower health outcomes than…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-10-29) CVE-2026-97229 · GitLab Community Edition and Enterprise Edition: GitLab Community Edition and Enterprise Edition Integer Overflow or Wraparound Vulnerability
      vendor: GitLab · product: Community Edition and Enterprise Edition · CISA remediation by 2026-11-01
  - (2026-10-29) CVE-2026-76418 · Cisco Secure Firewall ASA Software and Cisco Secure FTD Software: Cisco Secure Firewall ASA Software and Cisco Secure FTD Software Unchecked Return Value to NULL Pointer Dereference V…
      vendor: Cisco · product: Secure Firewall ASA Software and Cisco Secure FTD Software · CISA remediation by 2026-11-01

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=15, 14d-median=16; carrying terms: regulatory, certain, action, vessels, protection, final, procedures, public, enforcement, establishing, specifically, authorized
- state_bills: today=82, 7d-median=70, 14d-median=109; carrying terms: specified, school, vehicle, establishes, community, vehicles, certain, relating, property, election, providing, emergency
- state_news: today=797, 7d-median=678, 14d-median=688; carrying terms: never, decision, received, money, october, behind, house, inside, reporting, medical, democratic, early
- local_news: today=266, 7d-median=253, 14d-median=241; carrying terms: october, house, early, accused, constitution, safety, senate, still, charges, journal, arrested, missouri
- foreign_news: today=1065, 7d-median=999, 14d-median=1006; carrying terms: never, money, behind, house, manipur, inside, incident, medical, tensions, early, level, deputy
- chinese_internal: today=278, 7d-median=278, 14d-median=278; carrying terms: market, cbmiy, cbmizefvx, cbmia, cbmibkfvx, chinese, google, cbmiykfvx, cbmidefvx, cbmiw, color, target
- russian_internal: today=1114, 7d-median=1010, 14d-median=1019; carrying terms: media, blank, novayagazeta, telegram, title, street, reuters, gazeta, https, ukraina, forbidden, found
- ukrainian_internal: today=134, 7d-median=130, 14d-median=131; carrying terms: october, inside, infrastructure, according, winter, early, european, title, recent, earlier, residential, kyivindependent
- ukraine_theater: today=342, 7d-median=390, 14d-median=393; carrying terms: kcjjlbvjpttfvdffqde, hrzjv, ttbssnh, cbmimajbvv, october, hymzjcu, untrnbkjvnli, cuxpvejrwklmvdnlq, uljsytlcsef, vvqkvsz, mission, cuxontjgzzzvtgleagrsnevlwe
- paper_bets: today=70, 7d-median=63, 14d-median=65; carrying terms: patrick, mbappe, kylian, russell, earthquake, supervolcano, chair, nuclear, jpmorgan, unemployment, receiving, force
- weather: today=150, 7d-median=134, 14d-median=136; carrying terms: possible, southwest, afdokx, october, current, significant, hazardous, eastern, twoat, temperatures, roads, persist
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexjpus, openings, implied, spread, inflation, cpiaucsl, pcepilfe, supply, effective, commodities, total, cpilfesl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: large, futures, crypto, silver, commodities, credit, equities, russell, range, natural, proxy, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=105, 7d-median=102, 14d-median=104; carrying terms: description, legislation, latinscript, integrity, measures, transnistria, events, misappropriation, protecting, chemical, updates, compare
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, https, unauthorized, quiverquant, congresstrading, quiver, httperror, quantitative, error
- billionaires: today=30, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, board, supreme, trade, state, delaware, appeals, blanche, court, alabama, services, alaska
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, accno, reporting, holdings, filer, subject, trust, investment, finance, tidal, acquisition
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: receipts, brown, david, cycle, pinkston, robert, congress, elect, ossoff, booker, jonathan, disbursements
- gdelt_regions: today=0, 7d-median=12, 14d-median=12
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, keywords, israel, themes, sanctions, perimeter, chinese, hezbollah, spanish, russian, attack, elections
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: ground, belgium, position, kingdom, france, germany, canada, spain, samuidf
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: death, investigations, rwampara, seasonal, november, clade, announcing, africa, point, public, cases, international
- cisa_kev: today=18, 7d-median=17, 14d-median=17; carrying terms: injection, products, improper, bypass, server, control, vulnerability, authentication, secure, spoofing, external, multiple
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: maximum, vanuatu, forest, tropical, earthquake, wildfire, speed, islands, hurricane, cyclone, indonesia, papua
- usgs_quakes: today=15, 7d-median=23, 14d-median=21; carrying terms: depth, vanuatu, indonesia, philippines, islands, russia, papua, guinea, japan, region, alaska, panama
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: meeting, interest, october, rates, price, resolves, volume, election, decrease, league, shakhtar, donetsk
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, economist, revolution, https, conversable, class, marginalrevolution, world, example, economic, great, trump
- tech_news: today=55, 7d-median=57, 14d-median=57; carrying terms: hacker, already, infrastructure, updates, according, government, software, group, attacks, model, intelligence, weekly
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: carter, tlaib, kustoff, frederica, himes, jamie, jefferson, emilia, sotomayor, pocan, cuellar, perry
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, consensus, either, markets, paper, decision, sufficient, unavailable, converges, placed, evidence, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-26] ECB press: Frank Elderson: Taking action for nature – investing in economic resilience and prosperity
- [2026-10-26] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-10-27] ECB press: October 2026 euro area bank lending survey
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] ECB press: ECB President Lagarde to step down on 7 February 2027
- [2026-10-29] ECB press: Monetary policy decisions
- [2026-10-29] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-10-29] ECB press: Piero Cipollone: Next-day securities settlement, tokenisation and the transformation of Europe’s financial infrastructure
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*