# WORLDSCOPE morning brief — 2026-08-08

## Headline
2746 new items across 24 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (643) · International News + Multilateral Institutions (447) · Russian Internal News (state + in-exile) (341) · World leaders & government officials (324) · State Legislative Action (261) · U.S. Weather + Severe / Climate Outlooks (163) · Chinese Internal News (118) · State-Level News (115) · Local News: St. Louis + Atlanta (78) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (39)

## What changed today
### Ukraine Theater (total-war monitoring) — 643 new of 840 total
  - (2026-08-08) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-07) [FIRMS] thermal anomaly 44.078, 23.464 (FRP 5.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-07 0105Z, FRP 5.41 MW
  - (2026-08-07) [FIRMS] thermal anomaly 52.307, 34.284 (FRP 0.27 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-07 0105Z, FRP 0.27 MW
  - (2026-08-07) [FIRMS] thermal anomaly 52.306, 34.281 (FRP 0.58 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-07 0105Z, FRP 0.58 MW
  - (2026-08-07) [FIRMS] thermal anomaly 51.685, 34.359 (FRP 0.31 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-07 0105Z, FRP 0.31 MW
  - (2026-08-07) [FIRMS] thermal anomaly 51.679, 33.912 (FRP 3.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-07 0105Z, FRP 3.95 MW

### International News + Multilateral Institutions — 447 new of 1016 total
  - (2026-08-08) [Global] From Tehran’s walls to the world: Iran’s visual propaganda as an art of war (2/2)
      Tehran at War (Part 2/2). In Iran, the war with the United States is also fought through enormous, state-sponsored posters. Murals transform walls into billboards advertising the official narrative, designed to carry the…
  - (2026-08-08) [Global] Russian strikes kill three near Kyiv, Zelensky makes landmark visit to Serbia
      Russian missile strikes killed three people, including a child, ​in ‌the Kyiv region on Saturday, said local authorities. The attack came hours after Ukrainian President Volodymyr Zelensky arrived in Belgrade on a landma…
  - (2026-08-08) [Global] US pledges $1 billion security aid to Colombia as Trump-endorsed president takes office
      The US State Department announced late Friday that President Donald Trump's ​administration plans toprovide $1 billion in security assistance to Colombia as the country's new right-wing President Abelardo De La Espriella…
  - (2026-08-08) [Global] Russian strikes kill three near Kyiv, Zelensky makes landmark visit to Serbia
      Russian missile strikes killed three people, including a child, ​in ‌the Kyiv region on Saturday, said local authorities, as an air raid alert was declared in and around the Ukrainian capital. The attack came hours after…
  - (2026-08-07) [Global] Houthi attacks kill at least 10 in Yemen as rebels target oil-rich Marib
      At least eight members of Yemeni government forces and two civilians were killed Friday in new attacks by Houthi rebels in an oil-rich province.
  - (2026-08-07) [Global] Ebola cases surpasses 4000 cases
      In tonight's program, a grim new milestone in the fast-growing Ebola outbreak in the Democratic Republic of Congo as cases surpass 4,000. Also low rainfall and failing pipes leave taps dry in the Gabon capital. Finally r…

### Russian Internal News (state + in-exile) — 341 new of 1048 total
  - (2026-08-08) Испания ввела пограничный контроль с Италией. Ранее Рим ввел аналогичные меры из-за миграционного кризиса в Сеуте | LEDE: Правительство Испании объявило, что в ночь на 8 августа ввело погран] (ru: Исп…
      Правительство Испании объявило, что в ночь на 8 августа ввело пограничный контроль для путешественников, прибывающих из Италии воздушным и морским путем, сообщает Reuters.
  - (2026-08-08) Россия второй раз за неделю нанесла удар по Киевской области. Погибли три человека, в том числе ребенок | LEDE: Вооруженные силы РФ в ночь на 8 августа нанесли удар ракетами и беспилотниками] (ru: Рос…
      Вооруженные силы РФ в ночь на 8 августа нанесли удар ракетами и беспилотниками по Украине, сообщило командование Воздушных сил ВСУ. Всего войска РФ запустили шесть ракет и 151 дрон разного типа. Украинские ПВО сбили 135…
  - (2026-08-08) Итог «дела книгоиздателей» о продаже квир-литературы — три условных приговора. За этим процессом мог стоять Аркадий Ротенберг, а избежать новых обвинений помог Владимир Мединский, выяснила «Рус] (ru:…
      Суд в Москве 7 августа назначил четыре года условно бывшему директору издательств Popcorn Books и Individuum Дмитрию Протопопову по уголовному делу об «ЛГБТ-экстремизме». Он стал третьим фигурантом «дела книгоиздателей»,…
  - (2026-08-08) Юрфирма Budovnits Family Law Agency заявила, что ее сайт взломали. Ранее «Медуза» обнаружила там информацию о том, что она помогает уклоняться от мобилизации — и этим занимается дочь генерала |] (ru:…
      Юридическая фирма Budovnits Family Law Agency, основанная семьей юристов Владиславом, Натаном и Артемом Будовницами, удалила со своего сайта информацию о том, что помогает уклоняться от мобилизации.
  - (2026-08-08) К чему может привести кризис в Сеуте? И коснется ли он россиян, которые живут в Испании? Рассказываем о возможных последствиях и причинах миграционного конфликта | LEDE: 30 июля толпы марокк] (ru: К ч…
      30 июля толпы марокканцев прорвались в испанский анклав Сеута, расположенный на берегу Северной Африки. Оценки их количества сильно варьируются: власти Марокко говорят о 40 тысячах человек, тогда как испанские власти счи…
  - (2026-08-08) Почти 400 украинских беспилотников атаковали регионы России и Крым. В Самарской области и Краснодарском крае горят НПЗ | LEDE: Минобороны России отчиталось, что российские ПВО в ночь на 8 ав] (ru: Поч…
      Минобороны России отчиталось, что российские ПВО в ночь на 8 августа перехватили и уничтожили 397 украинских беспилотников над регионами России, аннексированным Крымом и Азовским морем. Сколько всего дронов запустила Укр…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State Legislative Action — 261 new of 368 total
  - (2026-08-08) [Alaska HB 16] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits for state and local office; direct…
  - (2026-08-07) [Alaska HB 285] An Act relating to the electronic health information exchange system; and providing for an effective date.
      An Act relating to the electronic health information exchange system; and providing for an effective date.
  - (2026-08-07) [Alaska HB 232] An Act relating to the examination and treatment of minors; relating to consent for behavioral and mental health treatment for minors 16 years of age or older; and providing for an eff…
      An Act relating to the examination and treatment of minors; relating to consent for behavioral and mental health treatment for minors 16 years of age or older; and providing for an effective date.
  - (2026-08-07) [Alaska HJR 32] Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor a…
      Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor and the Alaska delegation in Congress…
  - (2026-08-07) [Alaska HB 292] An Act relating to insurance coverage for pediatric autoimmune neuropsychiatric disorders; and providing for an effective date.
      An Act relating to insurance coverage for pediatric autoimmune neuropsychiatric disorders; and providing for an effective date.
  - (2026-08-06) [Connecticut SB 1] AN ACT MAKING ADJUSTMENTS TO THE STATE BUDGET FOR THE BIENNIUM ENDING JUNE 30, 2027, MAKING DEFICIENCY APPROPRIATIONS FOR THE FISCAL YEAR ENDING JUNE 30, 2026, AUTHORIZING AND ADJUS…
      AN ACT MAKING ADJUSTMENTS TO THE STATE BUDGET FOR THE BIENNIUM ENDING JUNE 30, 2027, MAKING DEFICIENCY APPROPRIATIONS FOR THE FISCAL YEAR ENDING JUNE 30, 2026, AUTHORIZING AND ADJUSTING BONDS OF THE STATE AND CONCERNING…

### U.S. Weather + Severe / Climate Outlooks — 163 new of 212 total
  - (2026-08-08) [Moderate] Special Weather Statement: Special Weather Statement issued August 8 at 1:43AM MDT by NWS El Paso Tx/Santa Teresa NM
      At 141 AM MDT, Doppler radar was tracking a strong thunderstorm just west of Hueco Tanks, moving west at 20 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could kn…
  - (2026-08-08) [Moderate] Heat Advisory: Heat Advisory issued August 8 at 12:23AM PDT until August 9 at 10:00PM PDT by NWS Eureka CA
      * WHAT...Temperatures of 90 to 101 will produce moderate HeatRisk. * WHERE...Southwestern Interior Mendocino. * WHEN...From 10 AM this morning to 10 PM PDT Sunday. * IMPACTS...Hot temperatures may cause heat illnesses. *…
  - (2026-08-08) [Moderate] Heat Advisory: Heat Advisory issued August 8 at 12:23AM PDT until August 9 at 10:00PM PDT by NWS Eureka CA
      * WHAT...Temperatures of 100 to 110 will produce moderate to major HeatRisk. * WHERE...Trinity County. * WHEN...Until 10 PM PDT Sunday. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-08-08) [Moderate] Heat Advisory: Heat Advisory issued August 8 at 12:23AM PDT until August 8 at 11:00PM PDT by NWS Eureka CA
      * WHAT...Temperatures of 100 to 105 will produce moderate to major HeatRisk. * WHERE...Humboldt Interior. * WHEN...From 11 AM this morning to 11 PM PDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.…
  - (2026-08-08) [Moderate] Heat Advisory: Heat Advisory issued August 8 at 12:23AM PDT until August 9 at 10:00PM PDT by NWS Eureka CA
      * WHAT...Temperatures of 100 to 110 will produce moderate to major HeatRisk. * WHERE...Northern Mendocino Interior, Lake County, and Southeastern Interior Mendocino. * WHEN...Until 10 PM PDT Sunday. * IMPACTS...Hot tempe…
  - (2026-08-08) [Moderate] Dust Advisory: Dust Advisory issued August 8 at 1:18AM MDT until August 8 at 2:45AM MDT by NWS El Paso Tx/Santa Teresa NM
      The National Weather Service in El Paso has issued a * Dust Advisory for... Northwestern Hidalgo County in southwestern New Mexico... * Until 245 AM MDT. * At 116 AM MDT, sustained outflow winds from earlier thunderstorm…

### Chinese Internal News — 118 new of 259 total
  - (2026-08-07) 市场动态 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE5aT1pNNWV3bGVtczJXdjhPVG5CYUU4WHFHb18zQVFBNVRoQXcyc2JXaDl1Um5sWFVzazBjWnFDNnk5UEVoWjZmVXE3X1NjeGtL] (zh:…
      市场动态 deepview.caixin.com
  - (2026-08-08) 为什么悬疑刑侦剧偏爱东北？｜影视 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5GNGNOM0lVcTY4R21VaTVrQ3FtbnFPVG1CQ3lVNmlQM0k5TDRuMUx0X0ZBTTlGZlNXQVVmOGsxNHIxbUx2T0xGck1B] (zh:…
      为什么悬疑刑侦剧偏爱东北？｜影视 mini.caixin.com
  - (2026-08-08) 火器的革命｜猎读 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5CbVM5RGlrZklVOERoWU0tc01iYXdBOEJ5OVBvcXcwbl9MZlQ1S3RKQU9pcDJjREJEUzJmckIzd253bkVfQWpMZV82cnZEUUYy] (zh:…
      火器的革命｜猎读 mini.caixin.com
  - (2026-08-08) 青少年乒乓球赛事中出现严重赛风赛纪问题，乒协发文 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE45YnA5bEZrbi0wcl9BQTF0MUQtQld4OFVGRE5pUnZsZVpfYUowM1RwTVJTNS1aSEZ1OVlZa1Y5d0VQNUFS] (zh:…
      青少年乒乓球赛事中出现严重赛风赛纪问题，乒协发文 mini.caixin.com
  - (2026-08-08) “90后”农民工讨薪涉刑案发回重审 因部分事实不清 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1qa0JGdmFLekppQkx1WFZpSGVOY0V6SUI4bnhXcHhxV0RDX1ZHWDQ5YTNEMWk1QVVJQVZobTdBbHdHQ3] (zh:…
      “90后”农民工讨薪涉刑案发回重审 因部分事实不清 china.caixin.com
  - (2026-08-08) 全国人大常委会：六名将领涉嫌严重违纪违法 被罢免全国人大代表 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBmMUZjVXh6bFVPdEx2R2xNZUpYZm5kMVBuT3paZ19zZzBwQTFkQUZvOVI3alJFME16anpjQUcxZ] (zh:…
      全国人大常委会：六名将领涉嫌严重违纪违法 被罢免全国人大代表 china.caixin.com

### State-Level News — 115 new of 714 total
  - (2026-08-08) [California] Governor Newsom announces appointments 8.7.26
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/SEO-Thumbnail-Template-2.0-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="Blue background with a white ci…
  - (2026-08-07) [California] Governor Newsom announces judicial appointments
      Source
  - (2026-08-08) [Alabama] Governor Kay Ivey’s 2026 Back to School Message
      Governor Ivey welcomes Alabama students back to school and encourages them to embrace the opportunities a new school year brings. She also expresses her gratitude for Alabama’s teachers, school leaders and parents, thank…
  - (2026-08-07) [Connecticut] Historic site defaced, senator’s populist pitch and tourists abound: CT politics news
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/FORTUNE-EARLY-VOTING-0803-0803-SG-02-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decod…
  - (2026-08-07) [Connecticut] GOP Congressional hopefuls focus on issues, and campaign styles
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/CTPublic_Westportvoting2-1024x683.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcs…
  - (2026-08-07) [Arkansas] US Senate struggles to wrap up work before August recess
      WASHINGTON — The U.S. Senate continued work Friday night without an indication as to when senators would vote on several key legislative priorities. In a rare Friday session that stretched from morning until night, senat…

### Local News: St. Louis + Atlanta — 78 new of 232 total
  - (2026-08-08) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-08-08) [St. Louis] Car show celebrates Collier Brothers Auto Body's 80 years
      On Aug. 8, Delmar Boulevard will be closed from Walton Avenue to Taylor Avenue for a free-to-attend community car show from 4 p.m. to 9 p.m. celebrating Collier Brothers Auto Body’s 80 years of service to the community.
  - (2026-08-08) [St. Louis] Herrera homers in the Cardinals' 3-2 win over the Rockies
      Iván Herrera hit a solo home run, Kyle Leahy pitched five innings and the St. Louis Cardinals beat the Colorado Rockies 3-2 on Friday night.
  - (2026-08-08) [St. Louis] Teens charged for shooting at St. Louis Police, ATF agents
      Two 19-year-old men have been charged for their role in an ambush on St. Louis police officers and federal agents during a traffic stop last month.
  - (2026-08-08) [St. Louis] Community gathers for Michael Brown legacy weekend
      Michael Brown Sr. and his wife, Cal D. Brown, launched the three-day Michael Brown Legacy Weekend Friday night to commemorate 12 years since the death of Michael Brown Jr.
  - (2026-08-08) [St. Louis] Woman injured during failed escape from St. Louis Police car
      A woman is facing additional charges after police said she tried to escape custody while being taken to a St. Louis police station on Friday.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-08) [Russia oil sanctions perimeter · keywords] Ukraine promises to end attacks on US - linked oil terminal Bloomberg
      arabherald.com · English · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · keywords] Ukraine promised to end attacks on US - linked oil terminal Bloomberg
      middleeaststar.com · English · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · keywords] India faces tariff risk as US Senate passes sweeping Russia sanctions bill
      morungexpress.com · English · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · keywords] Ukraine promises to end attacks on US - linked oil terminal Bloomberg
      middleeaststar.com · English · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · keywords] Ukraine promised to end attacks on US - linked oil terminal Bloomberg
      afghanistannews.net · English · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · keywords] Ukraine promised to end attacks on US - linked oil terminal Bloomberg
      azerbaijannews.net · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-08) [FRIEDMAN BRIAN P] Form 4 (Reporting)
      filed 2026-08-08 01:53 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001214659-26-009794 Size: 8 KB
  - (2026-08-08) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-08 01:53 UTC · role: Issuer — Filed: 2026-08-07 AccNo: 0001214659-26-009794 Size: 8 KB
  - (2026-08-08) [Attovia Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-08-08 01:47 UTC · role: Issuer — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB
  - (2026-08-08) [Redmile Biopharma Investments III, L.P.] Form 4 (Reporting)
      filed 2026-08-08 01:47 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB
  - (2026-08-08) [Green Jeremy] Form 4 (Reporting)
      filed 2026-08-08 01:47 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB
  - (2026-08-08) [Redmile Group, LLC] Form 4 (Reporting)
      filed 2026-08-08 01:47 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB

### Ukrainian Internal News (national + local Kyiv) — 39 new of 104 total
  - (2026-08-08) Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балістиці | LEDE: ] (uk: Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балісти)
  - (2026-08-08) У Києві після російської атаки виявили тіло людини – КМВА | LEDE: Під час ліквідації наслідків атаки на Київ 8 серпня рятувальники виявили тіло загиблого.] (uk: У Києві після російської атаки виявили…
      Під час ліквідації наслідків атаки на Київ 8 серпня рятувальники виявили тіло загиблого.
  - (2026-08-08) ЗМІ: У Німеччині фіксували дрони над базою, де ремонтують Patriot | LEDE: У місті Мехерніх біля секретної бази Бундесверу виявили шість підозрілих польотів дронів – ведеться розслідування] (uk: ЗМІ: У…
      У місті Мехерніх біля секретної бази Бундесверу виявили шість підозрілих польотів дронів – ведеться розслідування
  - (2026-08-08) Іспанія запровадила прикордонний контроль для мандрівників з Італії | LEDE: ] (uk: Іспанія запровадила прикордонний контроль для мандрівників з Італії)
  - (2026-08-08) Росіяни атакували пасажирський поїзд "Суми – Київ" | LEDE: 8 серпня російський дрон атакував поїзд «Суми – Київ». Пошкоджено локомотив, виникла пожежа, обійшлося без постраждалих.] (uk: Росіяни атакув…
      8 серпня російський дрон атакував поїзд «Суми – Київ». Пошкоджено локомотив, виникла пожежа, обійшлося без постраждалих.
  - (2026-08-08) Уночі РФ атакувала 6 балістичними ракетами, їх не вдалося збити – дані ПС | LEDE: У ніч на 8 серпня російські війська атакували Україну шістьма ракетами та 151 безпілотником різних типів.] (uk: Уночі…
      У ніч на 8 серпня російські війська атакували Україну шістьма ракетами та 151 безпілотником різних типів.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 97 total
  - (2026-08-08) [USASpending] $2,744,085,731 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-08-08) [USASpending] $1,608,568,595 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
      Agency: Department of State. Description: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
  - (2026-08-08) [USASpending] $877,300,916 → PERATON INC.: OPERATIONAL PLANNING IMPLEMENTATION AND ASSESSMENT SERVICES
      Agency: General Services Administration. Description: OPERATIONAL PLANNING IMPLEMENTATION AND ASSESSMENT SERVICES (OPIAS) BASE AWARD.
  - (2026-08-08) [USASpending] $859,669,886 → BOOZ ALLEN HAMILTON INC: NEW TO - EHRM PMO IO SUPPORT
      Agency: Department of Veterans Affairs. Description: NEW TO - EHRM PMO IO SUPPORT
  - (2026-08-08) [USASpending] $837,225,881 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-08-08) [USASpending] $786,689,591 → AMENTUM SERVICES, INC.: AIRCRAFT MAINTENANCE AND LOGISTICS SUPPORT SERVICES
      Agency: Department of Homeland Security. Description: AIRCRAFT MAINTENANCE AND LOGISTICS SUPPORT SERVICES

### Government & military aircraft airborne (OpenSky) — 14 new of 14 total
  - (2026-08-08) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (47.4261, 0.9855) · alt: 7612m · 807km/h
  - (2026-08-08) JAF56C (Bulgaria)
      icao24: 4520aa · position: (45.7287, -0.381) · alt: 10972m · 916km/h
  - (2026-08-08) KAF3228 (Kuwait)
      icao24: 7061f6 · position: (24.2013, 49.134) · alt: 7620m · 603km/h
  - (2026-08-08) JAF1NL (Belgium)
      icao24: 44d1c2 · position: (38.3957, -3.574) · alt: 11582m · 892km/h
  - (2026-08-08) SAMU42 (France)
      icao24: 39ac4d · position: (45.7852, 3.8912) · alt: 1104m · 266km/h
  - (2026-08-08) NCR829 (United States)
      icao24: a9c52e · position: (-35.3253, 154.1888) · alt: 10972m · 808km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 14 new of 56 total
  - (2026-08-08) [The Hacker News] Metabase Zero-Day Exploited in Wild Allows Admin Access Without Authentication
      Metabase has warned that a maximum-severity security flaw impacting its business intelligence and data visualization software package has been exploited in the wild as a zero-day. The vulnerability (CVSS score: 10.0), wh…
  - (2026-08-08) [The Hacker News] N-able Issues N-central Hotfix 2 as Attackers Reach Managed Systems and Persist
      N-able has released a fresh round of hotfixes for N‑central as part of its investigation into ongoing exploitation of a recently disclosed security flaw in the Remote Monitoring and Management (RMM) product. "We are proa…
  - (2026-08-08) [The Hacker News] Progress Kemp LoadMaster Flaw Hits CISA KEV After 792 Reported Exploit Attempts
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Friday added a critical-severity security flaw impacting Progress Kemp LoadMaster to its Known Exploited Vulnerabilities (KEV) catalog, following report…
  - (2026-08-07) [Cybersecurity Dive] Experts say healthcare faces cybersecurity crisis: ‘These are patient safety issues’
      Regulatory failures, funding constraints and industry consolidation have created serious hacking risks.
  - (2026-08-07) [Schneier on Security] Friday Squid Blogging: Arctic Bobtail Squid Video
      Nice video of the Arctic bobtail squid. As usual, you can also use this squid post to talk about the security stories in the news that I haven’t covered. Blog moderation policy.
  - (2026-08-07) [The Register] OpenAI pledges to add Astra security as Anthropic loosens Fable's leash
      Or how I learned to stop worrying and love dangerous AI

### Paper Trading Scorecard — 13 new of 143 total
  - (2026-08-08) [Polymarket] Will Bitcoin dip to $42,500 in August?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa…
  - (2026-08-08) [Manifold] Will the next George R. R. Martin "Not a Blog" post mention "The Winds of Winter"?
  - (2026-08-08) [Manifold] will i get expert in codeforces by end of 2026
  - (2026-08-08) [Manifold] Will Buzzy2 make AIME
  - (2026-08-08) [Manifold] Will Google publicly release Gemini 3.5 Pro before September 1, 2026?
  - (2026-08-08) [Manifold] Daily Coinflip

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-08-07) Alaska Supreme Court: City of Nome Equalization Board v. Norton Sound Health Corporation
  - (2026-08-07) Alaska Supreme Court: Lora Reinbold v. State of Alaska and Alaska Legislature Select Committee on Legislative Ethics
  - (2026-08-07) Alaska Supreme Court: SARAH RACHEL MALLETTE and v. GARFIELD TAU ADAMS And
  - (2026-08-07) Alaska Supreme Court: State of Alaska v. Steven Ridenour
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Guzman v. Blanche
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Woonasquatucket River Watershed Council v. USDA

### USGS earthquakes (M4.5+, past day) — 11 new of 15 total
  - (2026-08-08) M 5.6 - 57 km WNW of Skwentna, Alaska
      M5.6 · 57 km WNW of Skwentna, Alaska · depth 10 km
  - (2026-08-08) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 10 km
  - (2026-08-08) M 4.8 - 95 km SSW of Severo-Kuril’sk, Russia
      M4.8 · 95 km SSW of Severo-Kuril’sk, Russia · depth 82.521 km
  - (2026-08-08) M 4.8 - 158 km NNE of Darya Boyi, China
      M4.8 · 158 km NNE of Darya Boyi, China · depth 10 km
  - (2026-08-07) M 4.8 - southern East Pacific Rise
      M4.8 · southern East Pacific Rise · depth 10 km
  - (2026-08-07) M 4.7 - 17 km WNW of Yanacancha, Peru
      M4.7 · 17 km WNW of Yanacancha, Peru · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-08-08) LoL: T1 vs Hanwha Life Esports (BO3) - LCK Round 3-4 Legend Group
      yes price: 46% · 24h volume: $726,659 · resolves 2026-08-08
  - (2026-08-08) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $426,257 · resolves 2026-06-01
  - (2026-08-08) Will Yabloko gain the most seats in the next Russian parliamentary election?
      yes price: 1% · 24h volume: $292,973 · resolves 2026-09-30
  - (2026-08-08) LoL: Weibo Gaming vs LNG Esports - Game 1 Winner
      yes price: 90% · 24h volume: $273,354 · resolves 2026-08-08
  - (2026-08-08) Israel x Iran ceasefire continues through August 9?
      yes price: 99% · 24h volume: $222,997 · resolves 2026-08-09
  - (2026-08-08) LoL: Weibo Gaming vs LNG Esports (BO3) - LPL Group Nirvana
      yes price: 81% · 24h volume: $210,587 · resolves 2026-08-08

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-08) [Japan] First measurement of antineutrinos from spent nuclear fuel confirms emissions persist after reactor shutdown
      nuclear-news.net · English
  - (2026-08-08) [Japan] Time to build a Scotland without nuclear weapons
      nuclear-news.net · English
  - (2026-08-08) [Japan] Gaza Peace Plan Is Written in Blood « nuclear - news
      nuclear-news.net · English
  - (2026-08-08) [Japan] Having Been Exploited , I Decided To Abandon Both My Husband And My Best Friend Manga By Ikezumi & Bessho Akari Launches
      fandompost.com · English
  - (2026-08-08) [Japan] The Next Weapons Frontier : New Mexico Expanding Military Industrial Ecosystem « nuclear - news
      nuclear-news.net · English
  - (2026-08-08) [Japan] Japan cannot avoid nuclear weapons debate , defense chief Koizumi says « nuclear - news
      nuclear-news.net · English

### GDACS — global disaster alerts — 2 new of 228 total
  - (2026-08-08) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.6M, Depth:10km
  - (2026-08-08) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.6M, Depth:10km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-08-08) [Marginal Revolution] *Restoring Childhood: How to Set Kids Free in the Age of Anxiety*
      That is the new book by Peter Gray, and it is very much a whole philosophy of child-rearing and also antidote to the current panic over social media. Excerpt: In preparation for this chapter, I spent weeks poring over th…
  - (2026-08-08) [Marginal Revolution] What I’ve been reading
      1. Mike Jay, Wireheads: An Unnatural History of Technology in the Brain. Much of this story is told through the lens of the accompanying science fiction and non-neuro trends in other parts of science. An excellent book,…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-08) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=21, 14d-median=21; carrying terms: final, rulemaking, notice, provide, proposes, safety, order, certain, program, action, proposing, proposed
- state_bills: today=368, 7d-median=118, 14d-median=124; carrying terms: housing, include, administration, health, programs, service, subject, local, community, district, financial, another
- state_news: today=714, 7d-median=714, 14d-median=758; carrying terms: taken, organization, districts, billion, challenges, include, facing, facilities, massachusetts, smoke, young, eastern
- local_news: today=232, 7d-median=232, 14d-median=230; carrying terms: georgia, executive, class, another, events, world, charges, according, around, neighborhood, image, known
- foreign_news: today=1016, 7d-median=1016, 14d-median=1022; carrying terms: graduates, protests, staying, naughty, challenges, facing, killing, resulted, mimetype, lhasa, tinubu, story
- chinese_internal: today=259, 7d-median=266, 14d-median=266; carrying terms: caixin, chinese, stock, china, google, global, people, https, record, market, price, cbmickfvx
- russian_internal: today=1048, 7d-median=1048, 14d-median=943; carrying terms: insider, title, https, variety, axios, times, media, novaya, telegram, patriot, istories, client
- ukrainian_internal: today=104, 7d-median=122, 14d-median=129; carrying terms: nearly, soldiers, combat, districts, title, killing, facilities, support, including, reported, former, region
- ukraine_theater: today=840, 7d-median=639, 14d-median=639; carrying terms: client, known, httperror, viirs, maintained, polygons, extra, snapshot, google, liveuamap, cartography, https
- paper_bets: today=143, 7d-median=140, 14d-median=138; carrying terms: michigan, supreme, house, listed, baker, title, resolution, jackson, rippling, virginia, nomination, north
- weather: today=212, 7d-median=177, 14d-median=175; carrying terms: moving, index, normal, monday, statement, corridor, detroit, include, heatrisk, watch, sensitive, message
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, commodities, energy, personal, dcoilwtico, pcepilfe, sheet, supply, treasury, jtsjol, total, dexjpus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, large, commodities, equities, bitcoin, nasdaq, treasury, rates, silver, china, yield, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=97, 7d-median=102, 14d-median=102; carrying terms: moldova, entity, protests, university, guinea, active, combat, venezuela, oblasts, enable, maintenance, drilling
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiver, error, https, httperror, quiverquant, congresstrading, quantitative, unauthorized
- billionaires: today=30, 7d-median=40, 14d-median=40; carrying terms: yiming, berkshire, devasini, microsoft, nasdaq, amancio, diversified, thomas, gautam, zhang, paris, arnault
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, california, county, court, johnson, appeals, delaware, blanche, association, arizona, international, group
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, michael, therapeutics, richard, william, group, daniel
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, elect, angels, congress, johnson, talarico, brown, jonathan, house, senate, cooper, shawn
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan
- gdelt_gkg: today=50, 7d-median=50, 14d-median=38; carrying terms: english, hezbollah, israel, trump, keywords, spanish, themes, russian, russia, attacks, strikes, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=14, 7d-median=14, 14d-median=16; carrying terms: position, belgium, france, ground, kingdom, china
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: strain, index, nigeria, analysis, mainly, guinea, organization, remaining, active, patient, bloody, incubation
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: fortios, command, deserialization, unauthorized, vendor, information, orchestrator, untrusted, product, fortinet, velocloud, exposure
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=228, 7d-median=233, 14d-median=250; carrying terms: liechtenstein, germany, panama, philippines, forestfire, ecuador, kazakhstan, indonesia, guinea, marshall, cyclone, kenya
- usgs_quakes: today=15, 7d-median=14, 14d-median=17; carrying terms: depth, islands, region, russia, philippines, indonesia, china, severo, kuril, kermadec, sarangani, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, normal, returns, hormuz, ceasefire, strait, traffic, august, prime, effective
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: economist, revolution, marginal, https, conversable, class, conversableeconomist, marginalrevolution, college, strong, future, economic
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: edition, health, going, schneier, cloud, model, google, government, cyber, internet, campaign, against
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: kathy, filings, fitzgerald, casar, tammy, jacobs, jason, housing, blackburn, administrator, advisers, brett
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, sufficient, converges, unavailable, placed, markets, decision, paper, module, market, identify, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*