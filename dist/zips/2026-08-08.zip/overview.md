# WORLDSCOPE morning brief — 2026-08-08

## Headline
2748 new items across 25 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (629) · International News + Multilateral Institutions (506) · Russian Internal News (state + in-exile) (383) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (172) · Chinese Internal News (127) · State-Level News (126) · State Legislative Action (95) · Local News: St. Louis + Atlanta (89) · GDELT GKG — themes / entities / watch areas (48) · Ukrainian Internal News (national + local Kyiv) (44) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Ukraine Theater (total-war monitoring) — 629 new of 840 total
  - (2026-08-08) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-08) [Liveuamap] 1 person killed, 2 wounded as result of explosion of naval mine near Kobleve - Liveuamap
      1 person killed, 2 wounded as result of explosion of naval mine near Kobleve Liveuamap</fo
  - (2026-08-07) [Liveuamap] 2 people killed, 4 wounded as result of Russian bombardment in Izyum - Liveuamap
      2 people killed, 4 wounded as result of Russian bombardment in Izyum Liveuamap
  - (2026-08-06) [Liveuamap] 12 people wounded as result of Russian strikes in Sumy - Liveuamap
      12 people wounded as result of Russian strikes in Sumy Liveuamap
  - (2026-08-05) [Liveuamap] Ukraine - Liveuamap
      Ukraine Liveuamap
  - (2026-08-06) [Liveuamap] At Kupyansk direction clashes yesterday near Kupyansk, Kindrashivka, Novoosynove, Shyykivka, - General Staff of Armed Forces of Ukraine reports Kharkiv Oblast, Ukraine - Ukraine Interactiv…
      At Kupyansk direction clashes yesterday near Kupyansk, Kindrashivka, Novoosynove, Shyykivka, - General Staff of Armed Forces of Ukrai

### International News + Multilateral Institutions — 506 new of 1034 total
  - (2026-08-08) [Global] Child among three killed in Russian missile attacks near Kyiv
      Russia continued its overnight attacks after President Volodymyr Zelensky warned of Ukraine's dwindling supplies of missile interceptors.
  - (2026-08-07) [Global] The phone book that led us to Assad's spy chief in hiding
      How we tracked down "The Spider" who was once one of the most-feared men in Syria.
  - (2026-08-07) [Global] Spain imposes border controls against Italy as row over Ceuta migrant influx intensifies
      Italy introduced border controls following an influx of about 78,000 migrants from Morocco into the neighbouring Spanish exclave of Ceuta.
  - (2026-08-07) [Global] Thai PM vows to introduce stricter gun laws after eight killed in shooting
      Eight people were killed when a 14-year-old opened fire at his home and school before shooting himself dead.
  - (2026-08-07) [Global] I was standing in front of my teacher when she was shot, Thai pupil says
      The student says she feared never seeing her mother again after the attack killed five teachers.
  - (2026-08-08) [Global] 'I ran because I knew I would die': Russian drones target medics in Ukraine
      Ukrainian emergency workers warn of growing Russian attacks on hospitals and ambulances.

### Russian Internal News (state + in-exile) — 383 new of 1063 total
  - (2026-08-08) «Яблоко» требуют снять с выборов в Госдуму. Но это не должно помешать тем, кто идет от партии в региональные парламенты. В Петербурге в заксобрание баллотируется 21-летняя Марина Песляк. Она «и] (ru:…
      «Яблоко» — единственная партия с антивоенной позицией, допущенная до выборов в Госдуму. Против этого выступили ее конкуренты, которые стали писать доносы и требовать, чтобы Верховный суд отменил регистрацию федерального…
  - (2026-08-08) В Москве по делу о шпионаже арестовали аспиранта РУДН из Китая | LEDE: Лефортовский суд Москвы арестовал 42-летнего студента-аспиранта РУДН из Китая Чэнь Юн Та по обвинению в шпионаже, выясн] (ru: В М…
      Лефортовский суд Москвы арестовал 42-летнего студента-аспиранта РУДН из Китая Чэнь Юн Та по обвинению в шпионаже, выяснила «Медиазона». Заседание прошло еще в апреле.
  - (2026-08-08) «Россия-24» обратилась в прокуратуру и Следственный комитет из-за травли создателей фильма о Колобке | LEDE: Правовая редакция телеканала «Россия-24» пожаловалась в прокуратуру и Следственны] (ru: «Ро…
      Правовая редакция телеканала «Россия-24» пожаловалась в прокуратуру и Следственный комитет по Москве из-за критики фильма «Последний богатырь. Колобок» и угроз в адрес его создателей, сообщил начальник службы выпуска пра…
  - (2026-08-08) Испания ввела пограничный контроль с Италией. Ранее Рим ввел аналогичные меры из-за миграционного кризиса в Сеуте | LEDE: Правительство Испании объявило, что в ночь на 8 августа ввело погран] (ru: Исп…
      Правительство Испании объявило, что в ночь на 8 августа ввело пограничный контроль для путешественников, прибывающих из Италии воздушным и морским путем, сообщает Reuters.
  - (2026-08-08) Россия второй раз за неделю нанесла удар по Киевской области. Погибли три человека, в том числе ребенок | LEDE: Вооруженные силы РФ в ночь на 8 августа нанесли удар ракетами и беспилотниками] (ru: Рос…
      Вооруженные силы РФ в ночь на 8 августа нанесли удар ракетами и беспилотниками по Украине, сообщило командование Воздушных сил ВСУ. Всего войска РФ запустили шесть ракет и 151 дрон разного типа. Украинские ПВО сбили 135…
  - (2026-08-08) Итог «дела книгоиздателей» о продаже квир-литературы — три условных приговора. За этим процессом мог стоять Аркадий Ротенберг, а избежать новых обвинений помог Владимир Мединский, выяснила «Рус] (ru:…
      Суд в Москве 7 августа назначил четыре года условно бывшему директору издательств Popcorn Books и Individuum Дмитрию Протопопову по уголовному делу об «ЛГБТ-экстремизме». Он стал третьим фигурантом «дела книгоиздателей»,…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 172 new of 212 total
  - (2026-08-08) [Moderate] Heat Advisory: Heat Advisory issued August 8 at 3:27AM MDT until August 8 at 8:00PM MDT by NWS Albuquerque NM
      * WHAT...Temperatures from 99 to 103 expected. * WHERE...Middle Rio Grande Valley including the Albuquerque Metro Area, Sandia and Manzano Mountains including Edgewood, Northwest Plateau, and Espanola Valley. * WHEN...Fr…
  - (2026-08-08) [Moderate] Gale Warning: Gale Warning issued August 8 at 2:27AM PDT until August 10 at 8:00PM PDT by NWS Medford OR
      * WHAT...For the Small Craft Advisory, north winds 20 to 30 kt with gusts up to 35 kt and steep short period seas 6 to 9 ft. For the Gale Warning, north winds 25 to 35 kt with gusts up to 45 kt and very steep hazardous s…
  - (2026-08-08) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-08) [Severe] Red Flag Warning: Red Flag Warning issued August 8 at 2:21AM PDT until August 8 at 11:00PM PDT by NWS Spokane WA
      A dry cold front will push through the area Saturday, bringing breezy west to southwesterly winds. Winds will be strongest near the Cascades and Western Columbia Basin Saturday evening. Combined with low afternoon relati…
  - (2026-08-08) [Severe] Red Flag Warning: Red Flag Warning issued August 8 at 2:21AM PDT until August 8 at 11:00PM PDT by NWS Spokane WA
      A dry cold front will push through the area Saturday, bringing breezy west to southwesterly winds. Winds will be strongest near the Cascades and Western Columbia Basin Saturday evening. Combined with low afternoon relati…
  - (2026-08-08) [Moderate] Special Weather Statement: Special Weather Statement issued August 8 at 5:20AM EDT by NWS Binghamton NY
      Patchy dense fog is possible across areas in Central NY and Northeast Pennsylvania through early this morning. Visibilities could drop down to or below one quarter mile at times. Be cautious of rapid drops in visibilitie…

### Chinese Internal News — 127 new of 261 total
  - (2026-08-07) 互联网金融 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE0xNDA3RFRWVjA0Vnl4bExvNlVyWWFHVFctcmJrM3hTN0xVYUJBRkdxS0Z4VjVBWmNIcjJYbkZ3X1dTYzk1WUF1ZXN4M2k2TEJ] (zh:…
      互联网金融 deepview.caixin.com
  - (2026-08-07) 新能源车 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE1yUS1SVllMSzc2X19vTnFaRGFhQ0xtckk0R0lzb2VHUlVQcDZMZVF1bUltOFJfS1gwMnljTy14YUVZUmhENmszZkJ0MmhVdVBL] (zh:…
      新能源车 deepview.caixin.com
  - (2026-08-07) 上汽 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1Ta0ZHOEFlaU92Ulp1S2ROek1LSHFxV2RWODFGaHVxUTRCNXFrc0xDRDI2OXZCMkNxLWlsdEtJdEdWNWxzODVobVkwWG1fVy1MQn] (zh:…
      上汽 deepview.caixin.com
  - (2026-08-08) 为什么悬疑刑侦剧偏爱东北？｜影视 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5GNGNOM0lVcTY4R21VaTVrQ3FtbnFPVG1CQ3lVNmlQM0k5TDRuMUx0X0ZBTTlGZlNXQVVmOGsxNHIxbUx2T0xGck1BWkw4NldzcnREZ] (zh:…
      为什么悬疑刑侦剧偏爱东北？｜影视 财新
  - (2026-08-08) 火器的革命｜猎读 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5CbVM5RGlrZklVOERoWU0tc01iYXdBOEJ5OVBvcXcwbl9MZlQ1S3RKQU9pcDJjREJEUzJmckIzd253bkVfQWpMZV82cnZEUUYybE5EWVNSeFp3Y] (zh:…
      火器的革命｜猎读 财新
  - (2026-08-08) 青少年乒乓球赛事中出现严重赛风赛纪问题，乒协发文 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE45YnA5bEZrbi0wcl9BQTF0MUQtQld4OFVGRE5pUnZsZVpfYUowM1RwTVJTNS1aSEZ1OVlZa1Y5d0VQNUFSanZhS1pjZnNEU] (zh:…
      青少年乒乓球赛事中出现严重赛风赛纪问题，乒协发文 财新

### State-Level News — 126 new of 717 total
  - (2026-08-08) [California] Governor Newsom announces appointments 8.7.26
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/SEO-Thumbnail-Template-2.0-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="Blue background with a white ci…
  - (2026-08-07) [California] Governor Newsom announces judicial appointments
      Source
  - (2026-08-08) [Alabama] Governor Kay Ivey’s 2026 Back to School Message
      Governor Ivey welcomes Alabama students back to school and encourages them to embrace the opportunities a new school year brings. She also expresses her gratitude for Alabama’s teachers, school leaders and parents, thank…
  - (2026-08-07) [Connecticut] Historic site defaced, senator’s populist pitch and tourists abound: CT politics news
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/FORTUNE-EARLY-VOTING-0803-0803-SG-02-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decod…
  - (2026-08-07) [Connecticut] GOP Congressional hopefuls focus on issues, and campaign styles
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/CTPublic_Westportvoting2-1024x683.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcs…
  - (2026-08-08) [Hawaii] Office of the Governor — News Release — Governor, Mayor Bissen Announce Wildfires DCMP Move From State to County
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA GOVERNOR GREEN, MAYOR BISSEN ANNOUNCE WILDFIRES DISASTER CASE MANAGEMENT PROGRAM MOVE FROM STATE TO […]

### State Legislative Action — 95 new of 202 total
  - (2026-08-08) [Alaska HB 16] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits for state and local office; direct…
  - (2026-08-07) [Alaska HB 285] An Act relating to the electronic health information exchange system; and providing for an effective date.
      An Act relating to the electronic health information exchange system; and providing for an effective date.
  - (2026-08-07) [Alaska HB 232] An Act relating to the examination and treatment of minors; relating to consent for behavioral and mental health treatment for minors 16 years of age or older; and providing for an eff…
      An Act relating to the examination and treatment of minors; relating to consent for behavioral and mental health treatment for minors 16 years of age or older; and providing for an effective date.
  - (2026-08-07) [Alaska HJR 32] Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor a…
      Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor and the Alaska delegation in Congress…
  - (2026-08-07) [Alaska HB 292] An Act relating to insurance coverage for pediatric autoimmune neuropsychiatric disorders; and providing for an effective date.
      An Act relating to insurance coverage for pediatric autoimmune neuropsychiatric disorders; and providing for an effective date.
  - (2026-08-06) [Connecticut SB 1] AN ACT MAKING ADJUSTMENTS TO THE STATE BUDGET FOR THE BIENNIUM ENDING JUNE 30, 2027, MAKING DEFICIENCY APPROPRIATIONS FOR THE FISCAL YEAR ENDING JUNE 30, 2026, AUTHORIZING AND ADJUS…
      AN ACT MAKING ADJUSTMENTS TO THE STATE BUDGET FOR THE BIENNIUM ENDING JUNE 30, 2027, MAKING DEFICIENCY APPROPRIATIONS FOR THE FISCAL YEAR ENDING JUNE 30, 2026, AUTHORIZING AND ADJUSTING BONDS OF THE STATE AND CONCERNING…

### Local News: St. Louis + Atlanta — 89 new of 241 total
  - (2026-08-08) [St. Louis] 12 years after Michael Brown's death, community gathers to reflect and heal
      Brown's death changed Ferguson. Local leaders and families are now uniting to focus on trauma, mental health, and moving forward.
  - (2026-08-08) [St. Louis] A woman found a ball python in her toilet. Now she has answers on how it got there.
      A ball python found in an Orangevale, California, toilet appears to have been a lost pet.
  - (2026-08-08) [St. Louis] Disney animator meets first responders who rescued him from Arizona mountain
      Glen Keane, 72, was hiking Mummy Mountain with his family on July 29 when he reached a section of the trail he realized he could not safely cross.
  - (2026-08-08) [St. Louis] Minnie Driver injured in car crash while driving through France: 'So grateful to be alive'
      The actor said she suffered a sprained neck and is "in shock" after a car accident in rural France left the vehicle totaled.
  - (2026-08-08) [St. Louis] Helicopter helping battle Utah wildfire crashes with 2 aboard
      There was no immediate word on the conditions of the two aboard.
  - (2026-08-07) [St. Louis] Remains of 56 people found improperly stored and decomposing at Chicago funeral home
      The remains were discovered Thursday in various states of decomposition at South Chicago Chapel.

### GDELT GKG — themes / entities / watch areas — 48 new of 48 total
  - (2026-08-08) [Russia oil sanctions perimeter · themes] Congress MP Manickam Tagore urges Jaishankar to secure release of 11 fishermen detained by Sri Lanka
      aninews.in · English · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · themes] У регіонах росії , куди приїжджає путін , раптово падають ціни на бензин медіа
      podrobnosti.ua · Ukrainian · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · themes] Malaxparet älskar att rädda gamla hus – här är deras bästa råd
      yle.fi · Swedish · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · themes] Ulet çmimi i naftës për 3 centë , benzina dhe gazi mbeten të pandryshuara
      zeri.info · Albanian · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · themes] Iran leaders think they have Trump cornered , but their strategy carries great risks
      yankton.net · English · tone NA
  - (2026-08-08) [Russia oil sanctions perimeter · themes] Tuga u Apatinu , sahranjen putar poginuo u nesreći : U petak je trebalo da se vrati sa terena , jedva je čekao
      naslovi.net · Serbian · tone NA

### Ukrainian Internal News (national + local Kyiv) — 44 new of 107 total
  - (2026-08-08) Польща назвала популізмом заяви опозиції щодо депортації українців | LEDE: Польське МВС назвало заяви PiS про депортацію українців популізмом. 95% працюють легально.] (uk: Польща назвала популізмом за…
      Польське МВС назвало заяви PiS про депортацію українців популізмом. 95% працюють легально.
  - (2026-08-08) Посольство РФ вважає інцидент у Лейпцигу сфабрикованою провокацією | LEDE: ] (uk: Посольство РФ вважає інцидент у Лейпцигу сфабрикованою провокацією)
  - (2026-08-08) Україна уразила ще два НПЗ у Росії – Генштаб | LEDE: У ніч на 8 серпня ЗСУ уразили Ільський і Сизранський НПЗ у РФ та об'єкт у Чорному морі. Є підтверджені пожежі.] (uk: Україна уразила ще два НПЗ у Р…
      У ніч на 8 серпня ЗСУ уразили Ільський і Сизранський НПЗ у РФ та об'єкт у Чорному морі. Є підтверджені пожежі.
  - (2026-08-08) Зеленський: На Київщині загинули 3-річний хлопчик, його бабуся та дідусь, а батьки поранені | LEDE: У Пухівці Київської області внаслідок російської атаки загинуло троє, четверо поранені. Зелен] (uk:…
      У Пухівці Київської області внаслідок російської атаки загинуло троє, четверо поранені. Зеленський закликає посилити санкції.
  - (2026-08-08) В Єврокомісії дорікнули Іспанії за перевірки італійських мандрівників | LEDE: ] (uk: В Єврокомісії дорікнули Іспанії за перевірки італійських мандрівників)
  - (2026-08-08) Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балістиці | LEDE: ] (uk: Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балісти)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-08) [FRIEDMAN BRIAN P] Form 4 (Reporting)
      filed 2026-08-08 01:53 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001214659-26-009794 Size: 8 KB
  - (2026-08-08) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-08 01:53 UTC · role: Issuer — Filed: 2026-08-07 AccNo: 0001214659-26-009794 Size: 8 KB
  - (2026-08-08) [Attovia Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-08-08 01:47 UTC · role: Issuer — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB
  - (2026-08-08) [Redmile Biopharma Investments III, L.P.] Form 4 (Reporting)
      filed 2026-08-08 01:47 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB
  - (2026-08-08) [Green Jeremy] Form 4 (Reporting)
      filed 2026-08-08 01:47 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB
  - (2026-08-08) [Redmile Group, LLC] Form 4 (Reporting)
      filed 2026-08-08 01:47 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001104659-26-092867 Size: 16 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-08-08) CFC2510 (Canada)
      icao24: c2b5a3 · position: (54.8689, 10.1864) · alt: 8839m · 654km/h
  - (2026-08-08) JAF3NE (Belgium)
      icao24: 44d1ba · position: (44.6013, -1.221) · alt: 10363m · 937km/h
  - (2026-08-08) JAF74C (Belgium)
      icao24: 44d1a7 · position: (38.2539, 22.1632) · alt: 11582m · 794km/h
  - (2026-08-08) JAF5KH (Belgium)
      icao24: 44d1a5 · position: (37.8558, 26.3425) · alt: 6705m · 779km/h
  - (2026-08-08) JAF9WL (Belgium)
      icao24: 44d1b3 · position: (46.8498, 1.189) · alt: 10972m · 887km/h
  - (2026-08-08) JAF3LV (Belgium)
      icao24: 44d1b4 · position: (40.1179, 7.5764) · alt: 11582m · 830km/h

### U.S. Federal Action — 17 new of 20 total
  - (2026-08-10) Continuation of U.S. Drug Interdiction Assistance to the Government of Colombia
  - (2026-08-10) English Language Proficiency; Out of Service Criteria
      FMCSA proposes to codify the English language proficiency (ELP) driver qualification requirement as an out-of-service (OOS) violation. The rulemaking would ensure uniform enforcement by aligning the Federal Motor Carrier…
  - (2026-08-10) Establishment of Class E Airspace; Coleman, TX
      This action proposes to establish Class E airspace at Ranch at Double Gates Airport, Coleman, TX. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-08-10) Removal of FAA Third-Class Medical Certificate Requirement for Military Pilot Trainees
      FAA proposes to amend regulations to extend the existing exception for U.S. military pilots from the requirement to hold an FAA third-class medical certificate to military pilot trainees who already meet U.S. military pi…
  - (2026-08-10) Backup Withholding on Third Party Network Transactions
      This document contains final regulations governing backup withholding on reportable payments with respect to third party network transactions. The final regulations reflect recent changes to the statutory law that affect…
  - (2026-08-10) Television Broadcasting Services Elko, Nevada
      This document proposes to amend the Table of TV Allotments (Table) of the Federal Communications Commission's (Commission) rules in response to a petition for rulemaking filed by Reno (KENV-TV) Licensee, Inc. (Licensee),…

### Paper Trading Scorecard — 16 new of 144 total
  - (2026-08-08) [Polymarket] Will Bitcoin dip to $42,500 in August?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa…
  - (2026-08-08) [Manifold] Will an AI company be valued at $1 trillion+ before January 1, 2027?
  - (2026-08-08) [Manifold] Will any AI model released before 2028 reach an Epoch general ECI of at least 200?
  - (2026-08-08) [Manifold] Will the next George R. R. Martin "Not a Blog" post mention "The Winds of Winter"?
  - (2026-08-08) [Manifold] will i get expert in codeforces by end of 2026
  - (2026-08-08) [Manifold] Will Buzzy2 make AIME

### IT, InfoSys & cybersecurity news (last 7 days) — 16 new of 56 total
  - (2026-08-08) [The Hacker News] Atlassian Rovo Can Be Tricked Into Sending Jira and Confluence Data to Attackers
      Attacker-controlled instructions can make Atlassian's Rovo assistant collect Jira or Confluence data that a signed-in user can access, then send it to an outside server. Two security firms found that behavior independent…
  - (2026-08-08) [The Hacker News] New CSS Attacks Can Break Webmail Defenses to Steal Passwords and Tokens
      New research shows content inside an email can escape its message boundary and interfere with the webmail interface. Across attack chains spanning Outlook, Gmail, Fastmail, Proton Mail, Yahoo Mail, and AOL Mail, the tech…
  - (2026-08-08) [The Hacker News] Metabase Zero-Day Exploited in Wild Allows Admin Access Without Authentication
      Metabase has warned that a maximum-severity security flaw impacting its business intelligence and data visualization software package has been exploited in the wild as a zero-day. The vulnerability (CVSS score: 10.0), wh…
  - (2026-08-08) [The Hacker News] N-able Issues N-central Hotfix 2 as Attackers Reach Managed Systems and Persist
      N-able has released a fresh round of hotfixes for N‑central as part of its investigation into ongoing exploitation of a recently disclosed security flaw in the Remote Monitoring and Management (RMM) product. "We are proa…
  - (2026-08-08) [The Hacker News] Progress Kemp LoadMaster Flaw Hits CISA KEV After 792 Reported Exploit Attempts
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Friday added a critical-severity security flaw impacting Progress Kemp LoadMaster to its Known Exploited Vulnerabilities (KEV) catalog, following report…
  - (2026-08-07) [Cybersecurity Dive] Experts say healthcare faces cybersecurity crisis: ‘These are patient safety issues’
      Regulatory failures, funding constraints and industry consolidation have created serious hacking risks.

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 97 total
  - (2026-08-08) [USASpending] $2,744,085,731 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-08-08) [USASpending] $1,608,568,595 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
      Agency: Department of State. Description: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
  - (2026-08-08) [USASpending] $877,300,916 → PERATON INC.: OPERATIONAL PLANNING IMPLEMENTATION AND ASSESSMENT SERVICES
      Agency: General Services Administration. Description: OPERATIONAL PLANNING IMPLEMENTATION AND ASSESSMENT SERVICES (OPIAS) BASE AWARD.
  - (2026-08-08) [USASpending] $859,669,886 → BOOZ ALLEN HAMILTON INC: NEW TO - EHRM PMO IO SUPPORT
      Agency: Department of Veterans Affairs. Description: NEW TO - EHRM PMO IO SUPPORT
  - (2026-08-08) [USASpending] $837,225,881 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-08-08) [USASpending] $786,689,591 → AMENTUM SERVICES, INC.: AIRCRAFT MAINTENANCE AND LOGISTICS SUPPORT SERVICES
      Agency: Department of Homeland Security. Description: AIRCRAFT MAINTENANCE AND LOGISTICS SUPPORT SERVICES

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Guzman v. Blanche
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Woonasquatucket River Watershed Council v. USDA
  - (2026-08-07) U.S. Court of Appeals, 5th Cir.: United States v. Mendoza
  - (2026-08-07) U.S. Court of Appeals, 5th Cir.: United States v. Williams
  - (2026-08-07) Alaska Supreme Court: City of Nome Equalization Board v. Norton Sound Health Corporation
  - (2026-08-07) Alaska Supreme Court: Lora Reinbold v. State of Alaska and Alaska Legislature Select Committee on Legislative Ethics

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-08) [Japan] US court pauses Pentagon blacklisting of China WuXi AppTec
      asia.nikkei.com · English
  - (2026-08-08) [Japan] Hong Kong - based rice ball chain prepares supplies for US push
      asia.nikkei.com · English
  - (2026-08-08) [Japan] Trails in the Sky 2nd Chapter Promotional Trailer Released
      operationrainfall.com · English
  - (2026-08-08) [Japan] DMK to boycott CM Vijay all - party MPs meet on delimitation : DMK MP Kanimozhi
      japanherald.com · English
  - (2026-08-08) [Japan] GI - tagged Mithila Makhana makes first sea shipment from Bihar to Australia
      japanherald.com · English
  - (2026-08-08) [Japan] 31 - year - old man sentenced to 15 years for sexually assaulting 19 children at home
      japantoday.com · English

### USGS earthquakes (M4.5+, past day) — 11 new of 14 total
  - (2026-08-08) M 5.6 - 57 km WNW of Skwentna, Alaska
      M5.6 · 57 km WNW of Skwentna, Alaska · depth 10 km
  - (2026-08-08) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 10 km
  - (2026-08-08) M 4.8 - 95 km SSW of Severo-Kuril’sk, Russia
      M4.8 · 95 km SSW of Severo-Kuril’sk, Russia · depth 82.521 km
  - (2026-08-08) M 4.8 - 158 km NNE of Darya Boyi, China
      M4.8 · 158 km NNE of Darya Boyi, China · depth 10 km
  - (2026-08-07) M 4.8 - southern East Pacific Rise
      M4.8 · southern East Pacific Rise · depth 10 km
  - (2026-08-07) M 4.7 - 17 km WNW of Yanacancha, Peru
      M4.7 · 17 km WNW of Yanacancha, Peru · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-08-08) LoL: T1 vs Hanwha Life Esports (BO3) - LCK Round 3-4 Legend Group
      yes price: 66% · 24h volume: $1,525,551 · resolves 2026-08-08
  - (2026-08-08) LoL: T1 vs Hanwha Life Esports - Game 2 Winner
      yes price: 38% · 24h volume: $1,282,155 · resolves 2026-08-08
  - (2026-08-08) Will Tom Cotton win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,096,197 · resolves 2028-11-07
  - (2026-08-08) LoL: T1 vs Hanwha Life Esports - Game 1 Winner
      yes price: 100% · 24h volume: $921,335 · resolves 2026-08-08
  - (2026-08-08) LoL: Weibo Gaming vs LNG Esports - Game 1 Winner
      yes price: 100% · 24h volume: $727,620 · resolves 2026-08-08
  - (2026-08-08) LoL: Weibo Gaming vs LNG Esports - Game 2 Winner
      yes price: 100% · 24h volume: $607,023 · resolves 2026-08-08

### GDACS — global disaster alerts — 5 new of 233 total
  - (2026-07-15) [Green] Flood in Vietnam
      Flood · Green alert · Vietnam · Magnitude 0
  - (2026-07-15) [Green] Flood in Vietnam
      Flood · Green alert · Vietnam · Magnitude 0
  - (2026-07-15) [Green] Flood in Vietnam
      Flood · Green alert · Vietnam · Magnitude 0
  - (2026-08-08) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.6M, Depth:10km
  - (2026-08-08) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.6M, Depth:10km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-08-08) [Marginal Revolution] *Restoring Childhood: How to Set Kids Free in the Age of Anxiety*
      That is the new book by Peter Gray, and it is very much a whole philosophy of child-rearing and also antidote to the current panic over social media. Excerpt: In preparation for this chapter, I spent weeks poring over th…
  - (2026-08-08) [Marginal Revolution] What I’ve been reading
      1. Mike Jay, Wireheads: An Unnatural History of Technology in the Brain. Much of this story is told through the lens of the accompanying science fiction and non-neuro trends in other parts of science. An excellent book,…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-08) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: proposing, operations, final, rulemaking, notice, safety, proposes, certain, proposed, action, provide, standards
- state_bills: today=202, 7d-median=118, 14d-median=129; carrying terms: consumer, appropriation, transportation, crime, establishes, mental, housing, provider, violation, county, materials, provided
- state_news: today=717, 7d-median=717, 14d-median=766; carrying terms: american, feather, sought, transportation, never, staff, average, story, mental, housing, talks, attorneys
- local_news: today=241, 7d-median=239, 14d-median=234; carrying terms: county, including, georgia, figure, scene, based, former, children, width, since, articles, three
- foreign_news: today=1034, 7d-median=1034, 14d-median=1038; carrying terms: moves, broken, ecological, drivers, principle, ceremony, companies, prize, never, instruction, breathtaking, saudi
- chinese_internal: today=261, 7d-median=266, 14d-median=271; carrying terms: global, google, china, caixin, stock, record, people, chinese, https, price, market, investors
- russian_internal: today=1063, 7d-median=1056, 14d-median=972; carrying terms: press, variety, street, title, found, axios, client, journal, istories, httperror, bloomberg, times
- ukrainian_internal: today=107, 7d-median=122, 14d-median=127; carrying terms: updates, killed, title, across, financial, additional, staff, combat, snapshot, overnight, stories, talks
- ukraine_theater: today=840, 7d-median=639, 14d-median=633; carrying terms: frontline, firms, maintained, known, liveuamap, daily, deepstatemap, token, polygon, snapshot, alerts, community
- paper_bets: today=144, 7d-median=140, 14d-median=139; carrying terms: netanyahu, verve, james, player, baker, title, determined, california, award, johnny, jinping, majors
- weather: today=212, 7d-median=177, 14d-median=174; carrying terms: afdlox, great, basin, memphis, remains, watch, across, details, conditions, continues, transportation, springs
- macro: today=20, 7d-median=21, 14d-median=21; carrying terms: money, nonfarm, payems, vixcls, inflation, payrolls, jolts, assets, pcepilfe, dexuseu, total, growth
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, credit, large, silver, corporate, yield, commodities, russell, agriculture, futures, range, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=97, 7d-median=102, 14d-median=102; carrying terms: updates, eastern, moldova, violations, award, federation, prior, operation, accellerator, square, destruction, guatemala
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, quiverquant, unauthorized, congresstrading, httperror, quantitative, https, client, error
- billionaires: today=30, 7d-median=40, 14d-median=38; carrying terms: exchange, china, gcarsoa, mukesh, fashion, nasdaq, adani, warren, walmart, gates, ellison, huang
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, johnson, appeals, county, court, supreme, blanche, arizona, corporation, state, association, international
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, michael, richard, therapeutics, group, william, daniel
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: david, disbursements, ossoff, angels, senate, sherrod, booker, pinkston, talarico, cortez, james, trone
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, south, japan, korea, koreaherald
- gdelt_gkg: today=48, 7d-median=50, 14d-median=48; carrying terms: english, israel, hezbollah, spanish, trump, themes, russian, italian, chinese, russia, turkish, baijiahao
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=19, 14d-median=18; carrying terms: position, canada, belgium, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: animals, caused, challenge, social, above, great, respiratory, affected, posting, point, alerted, remains
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: information, product, remediation, deserialization, management, actor, arista, authentication, vendor, sensitive, orchestrator, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=233, 7d-median=233, 14d-median=236; carrying terms: china, macedonia, serbia, medium, minor, congo, gabon, costa, hungary, forestfire, france, guinea
- usgs_quakes: today=14, 7d-median=14, 14d-median=16; carrying terms: depth, islands, russia, region, china, philippines, indonesia, severo, kuril, kermadec, sarangani, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, september, normal, traffic, strait, effective, hormuz, august, prime, ceasefire
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: marginal, economist, conversable, class, revolution, https, conversableeconomist, marginalrevolution, strong, college, economic, future
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: across, mythos, companies, information, researchers, access, breach, security, bleepingcomputer, cloud, hacked, autonomous
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: hagerty, tonko, harold, babin, burlison, kamlager, fitzgerald, cassidy, morgan, james, nathaniel, kathy
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, unavailable, converges, evidence, markets, either, claude, sufficient, identify, decision, placed, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*