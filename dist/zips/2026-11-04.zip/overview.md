# WORLDSCOPE morning brief — 2026-11-04

## Headline
3453 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (814) · State-Level News (596) · Russian Internal News (state + in-exile) (559) · World leaders & government officials (324) · Chinese Internal News (257) · Local News: St. Louis + Atlanta (214) · Ukraine Theater (total-war monitoring) (108) · U.S. Weather + Severe / Climate Outlooks (92) · Ukrainian Internal News (national + local Kyiv) (80) · State Legislative Action (68) · GDELT GKG — themes / entities / watch areas (68) · GDACS — global disaster alerts (43)

## What changed today
### International News + Multilateral Institutions — 814 new of 1013 total
  - (2026-11-04) [Global] ANC faces anger over poor services as South Africans vote in local elections
  - (2026-11-03) [Global] One dead and another missing in suspected grizzly bear attack in Canada
  - (2026-11-04) [Global] Endangered giant burrowing frog returns to wild after tadpoles rescued from ashes of black summer fires
  - (2026-11-04) [Global] Albanese government warned it’s ‘sleepwalking into another robodebt scenario’ over use of algorithms and AI
  - (2026-11-04) [Global] Australia has an especially bad inflation problem. So why are we only middle-of-the pack on the misery index?
  - (2026-11-04) [Global] ‘Discontent and distrust’: annual social cohesion checkup shows exactly what’s making Australia angry

### State-Level News — 596 new of 1008 total
  - (2026-11-03) [Alabama] Alabama Retail Day
      Download
  - (2026-11-04) [Alabama] Tuberville escapes blue wave to clinch victory in governor's race
  - (2026-11-04) [Alabama] Democrats flip two Alabama Senate seats as District 10 remains close
  - (2026-11-04) [Alabama] Washington County Public Fishing Lake lowered to combat giant salvinia
  - (2026-11-04) [Alabama] Sewell wins another House term, pledges focus on affordability
  - (2026-11-04) [Alabama] Alabama man alleges prison officials punished him for speaking to press

### Russian Internal News (state + in-exile) — 559 new of 952 total
  - (2026-11-04) «Рокки — это я» — художественный фильм об истории создания американской классики, боксерской драмы «Рокки». Внушает оптимизм! А еще актер Энтони Ипполито ужасно хорош в роли Сталлоне | LEDE: <p] (ru:…
      19 ноября в российский прокат выходит фильм «Рокки — это я» (I Play Rocky) режиссера Питера Фаррелли, снявшего оскароносный фильм «Зеленая книга». Это история создания самого влиятельного боксерского фильма в истории — «…
  - (2026-11-04) Умер режиссер эротического кино Тинто Брасс | LEDE: Умер итальянский режиссер Тинто Брасс, сообщает ANSA. ] (ru: Умер режиссер эротического кино Тинто Брасс)
      Умер итальянский режиссер Тинто Брасс, сообщает ANSA.
  - (2026-11-04) «Мы искренне рассчитываем, что Трамп продолжит свои миротворческие усилия». Кремль — о результатах промежуточных выборов в США | LEDE: Россия рассчитывает на продолжение посредничества США в] (ru: «Мы…
      Россия рассчитывает на продолжение посредничества США в вопросе завершения российско-украинской войны, несмотря на поражение Республиканской партии на выборах в США. Об этом заявил пресс-секретарь президента РФ Дмитрий П…
  - (2026-11-04) Российское правительство почти в два раза повысило пошлины на крепкий алкоголь из «недружественных» стран | LEDE: Правительство России почти вдвое повысило ввозные пошлины на крепкий алкогол] (ru: Рос…
      Правительство России почти вдвое повысило ввозные пошлины на крепкий алкоголь из «недружественных» стран. Соответствующее постановление размещено на официальном интернет-портале правовой информации.
  - (2026-11-04) В ночных клубах Анкары задержали более 30 россиянок. Их обвиняют в «нарушении морали и общественной безопасности» | LEDE: В Анкаре в ходе рейдов в ночных клубах задержаны 34 гражданки России] (ru: В н…
      В Анкаре в ходе рейдов в ночных клубах задержаны 34 гражданки России, сообщило посольство РФ в Турции.
  - (2026-11-04) Китай впервые подтвердил переговоры о встрече Трампа, Си и Путина. Она может состояться уже через две недели | LEDE: Китай впервые подтвердил, что ведет переговоры о возможной трехсторонней ] (ru: Кит…
      Китай впервые подтвердил, что ведет переговоры о возможной трехсторонней встрече Си Цзиньпина, Дональда Трампа и Владимира Путина.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 257 new of 338 total
  - (2026-11-03) China to Raise Forex Deposit Reserve Requirement to Curb Yuan’s Rally - Caixin Global
      China to Raise Forex Deposit Reserve Requirement to Curb Yuan’s Rally Caixin Global
  - (2026-11-02) Tencent, Visa Expand Partnership in Cross-Border Payments and AI - Caixin Global
      Tencent, Visa Expand Partnership in Cross-Border Payments and AI Caixin Global
  - (2026-11-04) China to Accelerate Work on Comprehensive AI Legislation - Caixin Global
      China to Accelerate Work on Comprehensive AI Legislation Caixin Global
  - (2026-11-03) China’s Self-Driving Firms Turn to Heavy Trucks for New Growth - Caixin Global
      China’s Self-Driving Firms Turn to Heavy Trucks for New Growth Caixin Global
  - (2026-11-02) China’s Manufacturing Activity Returns to Contraction - Caixin Global
      China’s Manufacturing Activity Returns to Contraction Caixin Global
  - (2026-11-03) China Prosecutors Detail Data-Sale Networks Linked to Overseas Scams - Caixin Global
      China Prosecutors Detail Data-Sale Networks Linked to Overseas Scams Caixin Global

### Local News: St. Louis + Atlanta — 214 new of 246 total
  - (2026-11-04) [St. Louis] A home in Sunset Hills hits the market
      Nature EscapeTucked into the woods near the Powder Valley Conservation and Nature Center, this property is surrounded by scenic views and miles of hiking trails. Its location in the Lindbergh School District is another r…
  - (2026-11-04) [St. Louis] Edward Jones Ventures’ Innovation Summit puts St. Louis at the center of new financial ideas
      Hundreds of people in the financial services and investment industry descended on St. Louis this week for Edward Jones Ventures’ Innovation Summit, eager to hear about the new ideas and offerings that could soon filter i…
  - (2026-11-04) [St. Louis] Jake Zimmerman wins St. Louis County executive race
      Democratic candidate Jake Zimmerman has been elected St. Louis County executive, earning support from 65 percent of voters, according to final but unofficial results on Tuesday. Republican Dennis Hancock earned 32 percen…
  - (2026-11-04) [St. Louis] Missouri voters reject abortion ban and Trump-backed map, and say yes to Amendment 6
      Missouri’s left flank won a trio of major ballot initiatives in Tuesday’s midterms, ensuring continued protection of abortion access (voting down Amendment 3), protection of initiative petitions (approving Amendment 6) a…
  - (2026-11-04) [St. Louis] Wellman beats Wagner, upsetting longtime GOP incumbent in St. Louis’ suburbs
      Military veteran Fred Wellman pulled off the upset of the night in Missouri, defeating incumbent U.S. Rep. Ann Wagner (R-Ballwin) to represent the state’s 2nd District in Congress. At 10:13 p.m., with 96 percent of the v…
  - (2026-11-03) [St. Louis] 5 things to know as St. Louis CITY SC faces Houston on Decision Day
      St. Louis CITY SC has one final dress rehearsal before its second trip to the MLS Cup Playoffs. Decision Day kicks off Saturday, November 7, at 6 p.m. for the Western Conference. For the first time in club history, CITY…

### Ukraine Theater (total-war monitoring) — 108 new of 328 total
  - (2026-11-04) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-03) [Liveuamap] Russia targeted a substation critical to the stable operation of the Khmelnytskyi Nuclear Power Plant with three drones, Energy Minister Shmyhal said. According to him, energy facilities w…
      Russia targeted a substation critical to the stable operation of the Khmelnytskyi Nuclear Power Plant with three drones, Energy M
  - (2026-11-03) [Liveuamap] British Maritime Authority: Report of a tanker being struck by unknown projectiles in the engine room northeast of Lima in Oman – Strait of Hormuz - Liveuamap
      British Maritime Authority: Report of a tanker being struck by unknown projectiles in the engine room northeast of Lima
  - (2026-11-02) [Liveuamap] A center for the return of civilian citizens will be established in Ukraine, according to Ukrainian Human Rights Commissioner Dmytro Lubinets – Kyiv, Kyiv city - Liveuamap
      A center for the return of civilian citizens will be established in Ukraine, according to Ukrainian Human Rights Commissioner Dmy
  - (2026-11-04) [Liveuamap] At Pokrovsk direction clashes yesterday near Vilne, Bilytske, Molodetske, Dobropillya, Hulive, Serhiyivka, Novopavlivka, - General Staff of Armed Forces of Ukraine reports – Dnipropetrovsk…
      At Pokrovsk direction clashes yesterday near Vilne, Bilytske, Molodetske, Dobropillya, Hulive, Serhiyivka, Novopavlivka, - Genera
  - (2016-05-01) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - Liveuamap
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com Liveuamap

### U.S. Weather + Severe / Climate Outlooks — 92 new of 94 total
  - (2026-11-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-04) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 4 at 5:33AM AKST until November 4 at 6:00AM AKST by NWS Juneau AK
      The snow has ended.
  - (2026-11-04) [Moderate] Rip Current Statement: Rip Current Statement issued November 4 at 9:23AM EST until November 5 at 4:00AM EST by NWS Jacksonville FL
      * WHAT...Dangerous rip currents. * WHERE...Coastal Duval County. * WHEN...Through late tonight. * IMPACTS...Rip currents can sweep even the best swimmers away from shore into deeper water.
  - (2026-11-04) [Moderate] Rip Current Statement: Rip Current Statement issued November 4 at 9:23AM EST until November 5 at 4:00AM EST by NWS Jacksonville FL
      * WHAT...Dangerous rip currents. * WHERE...Coastal Nassau, Coastal Flagler, Northeast Coastal St. Johns and Southeast Coastal St. Johns Counties. * WHEN...Through late tonight. * IMPACTS...Rip currents can sweep even the…
  - (2026-11-04) [Severe] Flood Warning: Flood Warning issued November 4 at 7:21AM MST until November 4 at 2:00PM MST by NWS Phoenix AZ
      * WHAT...Flooding caused by upstream dam release continues. * WHERE...Maricopa County in south central Arizona... * WHEN...Until 200 PM MST Wednesday. * IMPACTS...Flooding of rivers, creeks, streams, and other low-lying…
  - (2026-11-04) [Severe] Flood Warning: Flood Warning issued November 4 at 7:21AM MST until November 7 at 2:00PM MST by NWS Phoenix AZ
      * WHAT...Flooding caused by upstream dam release continues. * WHERE...Maricopa County in south central Arizona... * WHEN...Until 200 PM MST Saturday. * IMPACTS...Flooding of rivers, creeks, streams, and other low-lying a…

### Ukrainian Internal News (national + local Kyiv) — 80 new of 139 total
  - (2026-11-04) Чи врятує нас морозна зима від російських реактивних дронів? | LEDE: Росія у 2026 використовує реактивні дрони для ударів по Україні. Морози ускладнюють атаки, але не зупиняють їх. Деталі про н] (uk:…
      Росія у 2026 використовує реактивні дрони для ударів по Україні. Морози ускладнюють атаки, але не зупиняють їх. Деталі про нові типи БпЛА у матеріалі.
  - (2026-11-04) Девʼять авіабомб по школі в Комишувасі: вже відомо про 40 загиблих | LEDE: Президент Володимир Зеленський повідомив, що внаслідок російського удару по школі в селищі Комишуваха Запорізької обла] (uk:…
      Президент Володимир Зеленський повідомив, що внаслідок російського удару по школі в селищі Комишуваха Запорізької області загинуло 40 людей, ще понад 30 можуть бути під завалами.
  - (2026-11-04) Росіяни атакували Одещину: 2 постраждалих, зруйновано склад взуття та пошкоджено поштовий термінал | LEDE: Внаслідок обстрілу в Одеській області пошкоджено склад із взуттям, поштовий термінал т] (uk:…
      Внаслідок обстрілу в Одеській області пошкоджено склад із взуттям, поштовий термінал та автівки. Пожежу ліквідували рятувальники.
  - (2026-11-04) НАБУ затримало генерала СБУ Дуку | LEDE: Працівники Національного антикорупційного бюро затримали першого заступника начальника департаменту захисту національної державності СБУ генерала Сергія] (uk:…
      Працівники Національного антикорупційного бюро затримали першого заступника начальника департаменту захисту національної державності СБУ генерала Сергія Дуку.
  - (2026-11-04) ЄС показав звіт про розширення-2026: Україна – серед лідерів євроінтеграції | LEDE: 4 листопада Європейська комісія оприлюднила щорічний пакет документів щодо розширення Європейського Союзу, у ] (uk:…
      4 листопада Європейська комісія оприлюднила щорічний пакет документів щодо розширення Європейського Союзу, у якому оцінила поступ десяти країн-кандидатів на вступ до ЄС, помістивши Україну до четвірки держав з найбільшим…
  - (2026-11-04) Україна та Польща повідомили про початок пошукових досліджень на Тернопільщині | LEDE: ] (uk: Україна та Польща повідомили про початок пошукових досліджень на Тернопільщині)

### State Legislative Action — 68 new of 72 total
  - (2026-11-04) [Alaska HB 346] An Act relating to municipal zoning around airports; and relating to buffers between airports and nonindustrial property.
      An Act relating to municipal zoning around airports; and relating to buffers between airports and nonindustrial property.
  - (2026-11-04) [Alaska HB 53] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental a…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-11-04) [Alaska HB 55] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-11-04) [Alaska HJR 42] Supporting the Northern Continental Corridor concept; and urging the United States Department of Defense to fund further analysis for the Northern Continental Corridor.
      Supporting the Northern Continental Corridor concept; and urging the United States Department of Defense to fund further analysis for the Northern Continental Corridor.
  - (2026-11-04) [Alaska HB 125] An Act relating to membership of the Board of Fisheries.
      An Act relating to membership of the Board of Fisheries.
  - (2026-11-04) [Alaska HB 64] An Act relating to the surrender of infants; and providing for an effective date.
      An Act relating to the surrender of infants; and providing for an effective date.

### GDELT GKG — themes / entities / watch areas — 68 new of 68 total
  - (2026-11-04) [Russia oil sanctions perimeter · themes] 亡きあの人や未来の自分に思いを 御浜町に 「 こころの電話 」 設置
      isenp.co.jp · Japanese · tone NA
  - (2026-11-04) [Russia oil sanctions perimeter · themes] A股头条 ： 接盘资金来了 ， 数百亿级别券商资金已集结 ； 中际旭创 小作文 被澄清 ， 英伟达产业链利空发酵 ， 两融余额降至冰点 - A股头条 - 金融界
      stock.jrj.com.cn · Chinese · tone NA
  - (2026-11-04) [Russia oil sanctions perimeter · themes] Óscar Puente se deja caer
      elmundo.es · Spanish · tone NA
  - (2026-11-04) [Russia oil sanctions perimeter · themes] Number _ i岸優太 、 家の大掃除に奮闘 犬と遊ぶ姿も
      oricon.co.jp · Japanese · tone NA
  - (2026-11-04) [Russia oil sanctions perimeter · themes] I was swallowed by a whale . The
      thecorsaironline.com · English · tone NA
  - (2026-11-04) [Russia oil sanctions perimeter · themes] 社区食堂 代加工 炒热邻里情
      hznews.hangzhou.com.cn · Chinese · tone NA

### GDACS — global disaster alerts — 43 new of 100 total
  - (2026-11-04) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5M, Depth:49.074km
  - (2026-10-20) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-10-24) [Green] Flood in Indonesia
      Flood · Green alert · Indonesia · Magnitude 0
  - (2026-11-04) [Green] Earthquake in Fiji
      Earthquake · Green alert · Fiji · Magnitude 4.6M, Depth:556.459km
  - (2026-11-03) [Green] Forest fires in South Sudan
      Wildfire · Green alert · South Sudan · Green impact for forestfire in 5341 ha
  - (2026-11-03) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 6484 ha

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 60 total
  - (2026-11-04) [BleepingComputer] US charges two Canadians accused of hacking US universities
      A federal grand jury indicted two Canadians suspected of hacking multiple US universities and using the compromised systems to mine for cryptocurrency. [...]
  - (2026-11-04) [BleepingComputer] CISA flags WordPress RCE flaw as actively exploited in attacks
      The US Cybersecurity and Infrastructure Security Agency (CISA) warned federal agencies that attackers have started exploiting a recently patched high-severity WordPress vulnerability in the wild. [...]
  - (2026-11-04) [BleepingComputer] Hackers use n-day exploits in zero-click attacks on iOS, Android devices
      A large-scale watering hole attack associated with Russian hackers has been targeting iOS and Android users visiting compromised sites or fake ones impersonating legitimate portals. [...]
  - (2026-11-04) [The Hacker News] Critical Rails Flaw Lets Attackers Write Server Files via Crafted ImageMagick Uploads
      A critical flaw in Ruby on Rails could allow an unauthenticated attacker to write arbitrary files on an app's server by uploading a crafted file if the app processes uploads using ImageMagick. The Rails project disclosed…
  - (2026-11-04) [The Hacker News] Xen Hypervisor Flaws Let One Malicious VM Read and Write Any Other VM's Memory
      Two flaws in the Xen hypervisor allow a malicious guest virtual machine (VM) to read and write the memory of other VMs on the same host, including dom0. Dom0 is the VM that, by default, has full permissions and manages t…
  - (2026-11-04) [The Hacker News] Radio With No Radar: Why Agent Runtime Security Fails Without the Layers Beneath It
      Nearly every agent security pitch now ends on the same promise: the product stops the bad action in real time. The promise holds for one kind of agent, the kind whose traffic passes through a gateway the enterprise owns.…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-04) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-04 14:33 UTC — Filed: 2026-11-04 AccNo: 0001918704-26-034465 Size: 614 KB
  - (2026-11-04) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-11-04 14:33 UTC — Filed: 2026-11-04 AccNo: 0001918704-26-034465 Size: 614 KB
  - (2026-11-04) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-04 14:30 UTC — Filed: 2026-11-04 AccNo: 0001918704-26-034464 Size: 529 KB
  - (2026-11-04) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-11-04 14:30 UTC — Filed: 2026-11-04 AccNo: 0001918704-26-034464 Size: 529 KB
  - (2026-11-04) 497AD - Eagle Point Enhanced Income Trust (0001992148) (Filer)
      filed 2026-11-04 14:30 UTC — Filed: 2026-11-04 AccNo: 0001104659-26-122423 Size: 219 KB
  - (2026-11-04) 497J - Tidal Trust V (0002081107) (Filer)
      filed 2026-11-04 14:30 UTC — Filed: 2026-11-04 AccNo: 0001999371-26-024414 Size: 7 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-11-04) JAF62Y (Bulgaria)
      icao24: 4520ce · position: (35.599, -6.3381) · alt: 9723m · 771km/h
  - (2026-11-04) PAT251A (United States)
      icao24: adfee0 · position: (35.9352, -101.7) · alt: 6697m · 384km/h
  - (2026-11-04) PAT322 (United States)
      icao24: adfe51 · position: (37.1706, -78.2441) · alt: 4198m · 378km/h
  - (2026-11-04) PAT326 (United States)
      icao24: adfe55 · position: (37.1162, -76.5017) · alt: 22m · 216km/h
  - (2026-11-04) PAT054 (United States)
      icao24: adfe54 · position: (41.2265, -75.7137) · alt: 4800m · 454km/h
  - (2026-11-04) CFC3121 (Canada)
      icao24: c2c1fb · position: (40.6362, -2.3765) · alt: 5448m · 656km/h

### Court opinions of consequence (federal & state) — 18 new of 60 total
  - (2026-11-10) Connecticut Supreme Court: Order on Motion - State v. Miller
  - (2026-11-03) U.S. Court of Appeals, 1st Cir.: Codan Forsikring A/S v. Bogus
  - (2026-11-03) U.S. Court of Appeals, 1st Cir.: Ortiz-Resto v. Rivera-Schatz
  - (2026-11-03) U.S. Court of Appeals, 9th Cir.: Service Employees International Union v. DOJ - United States Department of Justice
  - (2026-11-03) U.S. Court of Appeals, 9th Cir.: Service Employees International Union v. DOJ - United States Department of Justice
  - (2026-11-03) U.S. Court of Appeals, 9th Cir.: National Tps Alliance v. Mullin

### Paper Trading Scorecard — 17 new of 67 total
  - (2026-11-04) [Polymarket] Israel Election: Arab party disqualified?
      Elections to the 26th Knesset were held in Israel on October 27, 2026. This market will resolve to "Yes" if an Arab party is effectively disqualified from taking the seats it won in the 2026 Knesset election by the swear…
  - (2026-11-04) [Manifold] Will Dan Sullivan lose because of Dan Sullivan? [Short fuse]
  - (2026-11-04) [Manifold] Florida learjet crash was intentional.
  - (2026-11-04) [Manifold] Will Hakeem Jeffries become the next Speaker of the House?
  - (2026-11-04) [Manifold] Next WH Press Secretary a Woman?
  - (2026-11-04) [Manifold] will i create a better market than this one?

### U.S. Federal Action — 15 new of 16 total
  - (2026-11-04) Treatment of Emergency Amendments: Paycheck Protection Program Liquidity Facility and Paycheck Protection Program Loans
      The NCUA Board (Board) is issuing a final rule adopting as final the revisions to the capital adequacy rule and the member business lending rule made under an interim final rule (IFR) published in the Federal Register on…
  - (2026-11-04) Member Business Loans; Commercial Lending
      The NCUA Board (Board) is amending its regulations governing member business loans and commercial lending. This interim final rule eliminates an outdated, transitional provision that is no longer necessary. This action i…
  - (2026-11-04) Statutory Lien
      On February 25, 2026, NCUA (or `agency') published a proposed rule to solicit comments on the removal of a provision of NCUA regulations regarding federal credit unions' (FCUs) statutory lien authority. Upon further cons…
  - (2026-11-04) Guidance on Eligible Investments for Trump Accounts; Hearing
      This document provides a notice of proposed rulemaking (CC- 00349938-26) published in the Federal Register on August 21, 2026. The proposed regulations provided guidance regarding eligible investments, which are the only…
  - (2026-11-04) International Mail Manual; Incorporation by Reference
      The Postal Service announces the issuance of the Mailing Standards of the United States Postal Service, International Mail Manual (IMM[supreg]), issued November 2, 2026, and its incorporation by reference in the Code of…
  - (2026-11-04) Domestic Mail Manual; Incorporation by Reference
      The Postal Service announces the issuance of the Mailing Standards of the United States Postal Service, Domestic Mail Manual (DMM[supreg]), updated November 2, 2026, and its incorporation by reference in the Code of Fede…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-11-04) 2026 Balance of Power: R Senate, D House
      yes price: 0% · 24h volume: $2,788,579 · resolves 2026-11-04
  - (2026-11-04) Will the Republicans win the Mississippi Senate race in 2026?
      yes price: 17% · 24h volume: $1,832,590 · resolves 2026-11-04
  - (2026-11-04) Will Mary Peltola win the Alaska Senate race in 2026?
      yes price: 87% · 24h volume: $1,373,285 · resolves 2026-11-04
  - (2026-11-04) Will the Democrats win the Mississippi Senate race in 2026?
      yes price: 83% · 24h volume: $1,318,663 · resolves 2026-11-04
  - (2026-11-04) Rolex Paris Masters: Alexander Zverev vs Lorenzo Musetti
      yes price: 0% · 24h volume: $1,226,234 · resolves 2026-11-11
  - (2026-11-04) Will the US confirm that aliens exist before 2027?
      yes price: 2% · 24h volume: $1,195,009 · resolves 2027-01-01

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 97 total
  - (2026-11-04) [USASpending] $3,279,484,507 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation. Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM
  - (2026-11-04) [USASpending] $1,886,485,775 → HANFORD TANK WASTE OPERATIONS & CLOSURE, LLC: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITI
      Agency: Department of Energy. Description: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITION CONTRACT VIA THE IMPLEMENTATION TASK ORDER, TO-02.
  - (2026-11-04) [USASpending] $1,151,643,464 → LEIDOS, INC.: MILITARY AND FAMILY LIFE COUNSELING. REQUIREMENT FOR WORLDWI
      Agency: General Services Administration. Description: MILITARY AND FAMILY LIFE COUNSELING. REQUIREMENT FOR WORLDWIDE NON MEDICAL CONFIDENTIAL COUNSELING SERVICES.
  - (2026-11-04) [USASpending] $977,933,615 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-11-04) [USASpending] $920,668,088 → SALIENT CRGT, INC.: THE PURPOSE OF THIS MODIFICATION IS TO AWARD THE TASK ORDER
      Agency: General Services Administration. Description: THE PURPOSE OF THIS MODIFICATION IS TO AWARD THE TASK ORDER MAVERICK, AND PROVIDE INCREMENTAL FUNDING.
  - (2026-11-04) [USASpending] $897,676,816 → HII MISSION TECHNOLOGIES CORP: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT
      Agency: General Services Administration. Description: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT NETWORK OF ENGINEERING AND EMERGING OPERATIONS (JNEEO)

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-11-03) M 5.2 - 91 km ESE of Kyzyl-Eshme, Kyrgyzstan
      M5.2 · 91 km ESE of Kyzyl-Eshme, Kyrgyzstan · depth 10 km
  - (2026-11-03) M 5.2 - Mid-Indian Ridge
      M5.2 · Mid-Indian Ridge · depth 10 km
  - (2026-11-03) M 5.2 - Volcano Islands, Japan region
      M5.2 · Volcano Islands, Japan region · depth 139.456 km
  - (2026-11-04) M 5.0 - 207 km ESE of Sarangani, Philippines
      M5.0 · 207 km ESE of Sarangani, Philippines · depth 49.074 km
  - (2026-11-03) M 4.9 - 9 km N of Delta, B.C., MX
      M4.8869503562808 · 9 km N of Delta, B.C., MX · depth 15.59 km
  - (2026-11-03) M 4.8 - 85 km S of Gorontalo, Indonesia
      M4.8 · 85 km S of Gorontalo, Indonesia · depth 136.685 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-04) [Marginal Revolution] The election
      Procedurally it seems to have gone just fine, and the people predicting “the end of democracy in America” now look foolish. They have been suffering under fundamental misunderstandings of how this country works. During t…
  - (2026-11-04) [Marginal Revolution] Trade and the end of antiquity, or did Islam serve to deglobalize the world?
      How did trade and economic activity evolve at the End of Antiquity, when political power shifts away from the Mediterranean towards the Middle East and northern Europe? No records of ancient production, consumption, and…
  - (2026-11-03) [Marginal Revolution] Ireland fact of the day
      Almost half of Ireland’s corporation tax haul comes from just three companies: Apple, Eli Lilly and Microsoft. Here is much more from Jude Webber at the FT, on why Ireland does not always feel or operate like a wealthy c…
  - (2026-11-03) [Conversable Economist] The Challenges of Laissez-Faire Democracy
      Economists are frequently accused of being advocates for unfettered and unregulated laissez-faire markets, but anyone who has ever taken a basic introductory economics class knows that this caricature is untrue. The basi…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-11-03) CVE-2026-119977 · WordPress WordPress Core: WordPress WordPress Core Time-of-check Time-of-use (TOCTOU) Race Condition Vulnerability
      vendor: WordPress · product: WordPress Core · CISA remediation by 2026-11-06

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=16, 7d-median=15, 14d-median=15; carrying terms: certain, safety, regulatory, final, action, commission, published, rulemaking, persons, document, necessary, proposing
- state_bills: today=72, 7d-median=100, 14d-median=100; carrying terms: vehicle, emergency, insurance, relating, alaska, review, providing, certain, duties, training, commission, district
- state_news: today=1008, 7d-median=752, 14d-median=724; carrying terms: toomanyredirects, spotlightdelaware, issues, fetchpriority, height, nation, business, carolina, columbia, raised, district, appeared
- local_news: today=246, 7d-median=253, 14d-median=248; carrying terms: illinois, wednesday, hawks, business, appeared, football, south, target, county, death, plans, found
- foreign_news: today=1013, 7d-median=1013, 14d-median=1006; carrying terms: others, files, allegations, monitoring, involved, nation, deputy, business, until, nationwide, suspected, football
- chinese_internal: today=338, 7d-median=281, 14d-median=278; carrying terms: cbmix, cbmickfvx, articles, blank, cbmibefvx, color, cbmidefvx, cbmiakfvx, chinese, market, cbmib, cbmic
- russian_internal: today=952, 7d-median=952, 14d-median=990; carrying terms: journal, found, raquo, server, client, gazeta, group, street, https, laquo, blank, media
- ukrainian_internal: today=139, 7d-median=131, 14d-median=131; carrying terms: russia, continues, zelensky, ukraine, vechirniy, reports, patriot, ending, president, calls, independent, civilian
- ukraine_theater: today=328, 7d-median=369, 14d-median=382; carrying terms: bvlfctc, plakx, cbmikgfbvv, rxehe, tezxmg, anllzgziwnoxou, goudhrk, awtbdtleuhrxnnv, south, systems, pjqlbmc, vehicles
- paper_bets: today=67, 7d-median=67, 14d-median=65; carrying terms: goldman, miles, jinping, growth, fuentes, kalshi, successor, total, minister, leader, hypothesis, least
- weather: today=94, 7d-median=134, 14d-median=134; carrying terms: continues, difficult, locations, until, houston, accumulations, discussion, message, memphis, afdtbw, reduce, across
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, personal, latest, energy, recession, dexjpus, growth, treasury, jolts, walcl, pcepilfe, funds
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, yield, equities, agriculture, treasury, proxy, china, range, russell, crude, large, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=97, 7d-median=103, 14d-median=103; carrying terms: energy, entity, paeez, representative, contract, management, activities, ambassador, award, security, amended, comments
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, unauthorized, quiver, quiverquant, httperror, https, client, quantitative
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, court, supreme, state, blanche, services, trade, appeals, company, board, secretary, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, filer, subject, financial, trust, finance, america, tidal, jpmorgan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, congress, cortez, abdul, trone, talarico, robert, sayed, receipts, ossoff, raised
- gdelt_regions: today=0, 7d-median=6, 14d-median=9
- gdelt_gkg: today=68, 7d-median=50, 14d-median=50; carrying terms: keywords, english, sanctions, israel, russia, trump, themes, election, middle, spanish, aljazeera, israeli
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, germany, canada, ground, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: contamination, cumulative, mechanical, returning, barasat, experiencing, healthcare, implicated, continues, bengal, epidemiological, etiology
- cisa_kev: today=13, 7d-median=18, 14d-median=18; carrying terms: product, injection, command, software, remediation, server, vulnerability, authentication, secure, request, vendor, edition
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forest, nigeria, islands, japan, papua, magnitude, china, depth, australia, fires, guinea, cyclone
- usgs_quakes: today=8, 7d-median=15, 14d-median=18; carrying terms: depth, japan, islands, philippines, indonesia, region, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, election, volume, resolves, october, balance, senate, presidential, house, power, seats, minister
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, class, https, marginal, conversable, revolution, world, economic, being, activity, economists, thoughts
- tech_news: today=60, 7d-median=56, 14d-median=57; carrying terms: compromised, download, agents, today, researchers, bleepingcomputer, infrastructure, systems, record, vulnerability, state, models
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jerome, goldman, moolenaar, auchincloss, christopher, cuellar, mcgarvey, derek, kristen, mcconnell, mcgovern, alford
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, sufficient, today, module, placed, identify, placement, market, paper, markets, claude, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] ECB press: Monetary policy decisions
- [2026-10-29] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-10-29] ECB press: Piero Cipollone: Next-day securities settlement, tokenisation and the transformation of Europe’s financial infrastructure
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*