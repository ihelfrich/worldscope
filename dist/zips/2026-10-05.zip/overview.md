# WORLDSCOPE morning brief — 2026-10-05

## Headline
3268 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (801) · Russian Internal News (state + in-exile) (724) · Ukraine Theater (total-war monitoring) (430) · World leaders & government officials (324) · Chinese Internal News (197) · State-Level News (174) · Local News: St. Louis + Atlanta (174) · U.S. Weather + Severe / Climate Outlooks (90) · State Legislative Action (85) · Ukrainian Internal News (national + local Kyiv) (63) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (40)

## What changed today
### International News + Multilateral Institutions — 801 new of 948 total
  - (2026-10-05) [Global] Latest US military strike on alleged drug boat kills four in Caribbean
      UN warns US boat strikes in the Caribbean counter-drug war may violate international law and human rights principles.
  - (2026-10-05) [Global] Murder in Okinawa: The US military’s history of alleged crime in Japan
      The murder of 39-year-old Anna Yagi is the latest in a string of crimes involving US personnel on Okinawa.
  - (2026-10-05) [Global] US pulls bombers from UK base: Is Iran manoeuvring Trump’s war plans?
      The withdrawal means the US lost a convenient launchpad, not its underlying strike capability, said an expert.
  - (2026-10-05) [Global] Nobel medicine prize honours US and German scientists for optogenetics work
      The winners of the Nobel Prizes in physics, chemistry, literature, peace and ‌economics will be announced in the week.
  - (2026-10-05) [Global] Samoa prime minister apologises after Nazi salute video surfaces
      Samoa PM has apologised after a video of him resurfaced, showing him leading a Nazi salute and saying ‘Heil Hitler'.
  - (2026-10-05) [Global] Is Iran charging a toll to allow oil traffic through Hormuz?
      Crude exports bypassing Hormuz surged in September, yet oil prices remain high. Could a secret fee be the reason?

### Russian Internal News (state + in-exile) — 724 new of 909 total
  - (2026-10-05) В Нижегородской области дезертировавший военный убил и расчленил трех женщин | LEDE: В Нижегородской области местный житель, ранее дезертировавший из воинской части, убил трех женщин. ] (ru: В Нижегор…
      В Нижегородской области местный житель, ранее дезертировавший из воинской части, убил трех женщин.
  - (2026-10-05) Чума легко передается от человека к человеку? Нет. Она очень опасна? Да. Может ли произойти очередная пандемия? Нет. Коротко отвечаем на важные вопросы о чуме | LEDE: 1 октября 2026 года в Ш] (ru: Чум…
      1 октября 2026 года в Шелехове Иркутской области закрыли стационарное отделение районной больницы из-за подозрений на «особо опасную инфекцию». Впоследствии СМИ сообщили, что там от легочной чумы умерла 28-летняя Дарья Ш…
  - (2026-10-05) Евросоюз хочет ограничить доступ Украины к агрорынку при вступлении в блок | LEDE: Брюссель может ограничить для Украины доступ к сельскохозяйственным субсидиям и продовольственному рынку в ] (ru: Евр…
      Брюссель может ограничить для Украины доступ к сельскохозяйственным субсидиям и продовольственному рынку в случае вступления в Евросоюз. Такое предложение изложено во внутреннем документе Еврокомиссии, пишет Financial Ti…
  - (2026-10-05) Ижевского активиста, пытавшегося провести митинг за честные выборы, арестовали по делу о наркотиках | LEDE: Суд в Ижевске отправил местного активиста Дмитрия Морозова под арест на два месяца] (ru: Иже…
      Суд в Ижевске отправил местного активиста Дмитрия Морозова под арест на два месяца по делу о хранении наркотиков в крупном размере. Его обвиняют в том, что он хранил 0,38 грамма мефедрона, сообщает «Коммерсант — Удмуртия…
  - (2026-10-05) Теннисиста Даниила Медведева дисквалифицировали на турнире в Пекине. В матче с Джоковичем он мячом попал в зрителя на трибуне | LEDE: Даниил Медведев и Новак Джокович не доиграли полуфинальн] (ru: Тен…
      Даниил Медведев и Новак Джокович не доиграли полуфинальный матч турнира ATP 500 в Пекине из-за дисквалификации россиянина. Такое решение судьи приняли при счете 7:5, 5:3 в пользу серба после того, как Медведев попал мячо…
  - (2026-10-05) Россия нанесла удар по Харькову. Погибли три человека, более 30 ранены | LEDE: Вооруженные силы РФ днем 5 октября нанесли удар корректируемыми авиабомбами по Харькову, сообщил глава областно] (ru: Рос…
      Вооруженные силы РФ днем 5 октября нанесли удар корректируемыми авиабомбами по Харькову, сообщил глава областной военной администрации Олег Синегубов.

### Ukraine Theater (total-war monitoring) — 430 new of 717 total
  - (2026-10-05) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-04) [FIRMS] thermal anomaly 46.913, 34.643 (FRP 5.66 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-04 0924Z, FRP 5.66 MW
  - (2026-10-04) [FIRMS] thermal anomaly 46.912, 34.648 (FRP 6.49 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-04 0924Z, FRP 6.49 MW
  - (2026-10-04) [FIRMS] thermal anomaly 51.253, 34.896 (FRP 8.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-04 0926Z, FRP 8.86 MW
  - (2026-10-04) [FIRMS] thermal anomaly 51.254, 34.879 (FRP 8.13 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-04 0926Z, FRP 8.13 MW
  - (2026-10-04) [FIRMS] thermal anomaly 51.264, 34.903 (FRP 49.45 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-04 0926Z, FRP 49.45 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 197 new of 233 total
  - (2026-10-04) 会员尊享积分汇 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMigAFBVV95cUxOczVUMEd6aVRDLWVnLWxJaVY1eXZYM2ctdUJkYkFMQU9tNWp1bW5NSGdURV8wVzVVTVFFQ0ZfTWQxZlVQanZ1VDdRQ2ZFSnNlWk1XWFRQa0tr] (zh:…
      会员尊享积分汇 财新商城
  - (2026-10-03) 恒大清盘人追讨许家印资产 向张松桥蒋大龙索偿191.5亿港元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9QbUZoT2NDcC15VnBON2gwdndERTNrVzdEeGMwcl8wZk9OZ25RanVGY3JMSG9TRUVZUHhuSldJQ1NUTHptLTBEMjZ] (zh:…
      恒大清盘人追讨许家印资产 向张松桥蒋大龙索偿191.5亿港元 财新
  - (2026-10-04) 焦土之上，东线战场的几个片段｜画志·2026年第三季 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFAxZlBfNXlYbEFqdFpwZVlxdG5EWWo1ZldvNmxZQ2lGS1NsZkZLSnVPaTd3MW1DZDlSdlZvT3Jac1ZqblhieDlvRTVRY0F] (zh:…
      焦土之上，东线战场的几个片段｜画志·2026年第三季 财新
  - (2026-10-05) 大西洋观察｜法律与秩序：新时代的选战话术 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1tVHRUazZZMHo2YTRSbjVRUDQyR3l0TVVEekdKVThNb2xONXdvQzVNSEJSMW1pWm1maEl4ZS1Bb3M1bGVUdTJRdzF0YUpLSi0tU] (zh:…
      大西洋观察｜法律与秩序：新时代的选战话术 财新
  - (2026-10-05) 美德三位科学家荣获2026年诺贝尔生理学或医学奖 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBLZ2NadmFIdlVwOWphSFRqcFVfUDd1UTBTd2t2Mm5wQmNXN1pHNzlLOHpCMUhrT1FlUE5SamoyVjlkYVFVOWdqaTFCN25CY] (zh:…
      美德三位科学家荣获2026年诺贝尔生理学或医学奖 财新
  - (2026-10-05) 开创光遗传学革新大脑研究 美德三位科学家获诺贝尔生理学或医学奖 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBUVnNKZEVLOU9ReVNtREZ0LWRjNE9sV3RreHhJUjJCZDVCY3BxZ05CQmFLNHh4bkxUZ2NDRDFXYnFTaXpZTzRhVk] (zh:…
      开创光遗传学革新大脑研究 美德三位科学家获诺贝尔生理学或医学奖 财新

### State-Level News — 174 new of 284 total
  - (2026-10-05) [California] California’s economy continues to dominate — topping $4.5 T in economic output, and remains the world’s fourth largest economy
      Source
  - (2026-10-05) [Alabama] Governor Ivey Proclaims Alabama Girls in Sports Day
      MONTGOMERY – Governor Kay Ivey on Monday proclaimed Saturday, October 10, 2026, as Alabama Girls in Sports Day, recognizing the female athletes throughout the state and reaffirming Alabama’s commitment to ensuring women…
  - (2026-10-05) [California] What’s with all the taxes on the California ballot?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/060226_Sac-Ballot-Count_FG_CM_12.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-10-05) [California] Tech billionaires are spending millions to reshape California’s Legislature
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/06/102821-Facebook-Meta-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-10-05) [California] 5 tax measures are on the California ballot. Here’s how to make sense of them all
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/052219-California-Teachers-Association-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-si…
  - (2026-10-05) [California] Will Democrats’ midterm wave reach California’s Central Valley? Bernie Sanders rallies the vote
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/100426-Villegas-and-Bernie-Rally-LV-CM-07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-…

### Local News: St. Louis + Atlanta — 174 new of 199 total
  - (2026-10-05) [St. Louis] Top family-friendly events this week in St. Louis
      See Also: Fall Family Fun Guide Silhouettes by Erik at Urban Fort | October 7Third-generation silhouette artist Erik Johnson returns to Urban Fort for a day of custom keepsakes. Families can reserve individual time slots…
  - (2026-10-05) [St. Louis] St. Louis restaurant openings, closings, and coming soons
      The following information is accurate as of an early-October press date. Last month, there were seven restaurant closures and 21 openings, a clear sign that the sky is not falling. Plus, several of the closed establishme…
  - (2026-10-05) [St. Louis] Lou’s Clues – 10/5/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-10-05) [St. Louis] A free pass offers a new way to explore Kansas City’s Northland one drink at a time
      When Friday night rolls around, you may often end up at the same happy hour ordering the same drink at the same familiar bar. Go North KC, however, has a way to mix up the routine—and your next pint might even be free. T…
  - (2026-10-05) [St. Louis] Could a small school be a big advantage for a serious athlete?
      By the time the final bell rings, a serious high school athlete may already be thinking about an upcoming test, a paper that’s due on Friday, or practice that afternoon. With weekend tournaments and college athletics on…
  - (2026-10-05) [St. Louis] Arzola’s Tacos y Más joins Wash Ave Food Hall lineup
      Arzola’s Tacos y Más is the latest founding vendor announced for the Wash Ave Food Hall, slated to open this fall at 1122 Washington Ave. The new fast-casual concept joins a lineup that includes Steve’s Smash, Little BAO…

### U.S. Weather + Severe / Climate Outlooks — 90 new of 92 total
  - (2026-10-05) [Severe] Flood Warning: Flood Warning issued October 5 at 11:24AM EDT until October 5 at 2:30PM EDT by NWS Tallahassee FL
      * WHAT...Flooding caused by excessive rainfall is occurring. * WHERE...Southwestern Franklin County in Big Bend Florida... * WHEN...Until 230 PM EDT. * IMPACTS...Expect many areas of slow moving or standing water. * ADDI…
  - (2026-10-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-05) [Moderate] Special Weather Statement: Special Weather Statement issued October 5 at 11:08AM EDT by NWS Albany NY
      At 1108 AM EDT, Doppler radar was tracking gusty showers along a line extending from near Gloversville to near St. Johnsville to near Cedarville. Movement was east at 50 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Ra…
  - (2026-10-05) [Severe] Special Marine Warning: Special Marine Warning issued October 5 at 11:08AM EDT until October 5 at 1:15PM EDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Apalachee Bay or Coastal Waters From Keaton Beach to Ochlockonee River Fl out to 20 Nm... Coastal Waters From Ochlockonee Ri…
  - (2026-10-05) [Moderate] Gale Watch: Gale Watch issued October 5 at 11:01AM EDT until October 6 at 11:00PM EDT by NWS Grand Rapids MI
      * WHAT...South winds 20 to 30 knots with gusts up to 40 knots and waves 5 to 8 feet possible. * WHERE...Pentwater to Manistee MI. * WHEN...From Tuesday afternoon through Tuesday evening. * IMPACTS...Strong winds can caus…
  - (2026-10-05) [Severe] Flood Warning: Flood Warning issued October 5 at 9:53AM CDT until October 6 at 1:00AM CDT by NWS Des Moines IA
      ...The Flood Warning continues for the following rivers in Iowa... Iowa River near Tama Hwy E49 affecting Tama and Poweshiek Counties. Raccoon River at Des Moines Fleur Dr affecting Polk County. * WHAT...Minor flooding i…

### State Legislative Action — 85 new of 111 total
  - (2026-10-05) [Alaska HB 235] An Act relating to perfluoroalkyl and polyfluoroalkyl substances; relating to thermal remediation of perfluoroalkyl and polyfluoroalkyl substance contamination; and providing for an ef…
      An Act relating to perfluoroalkyl and polyfluoroalkyl substances; relating to thermal remediation of perfluoroalkyl and polyfluoroalkyl substance contamination; and providing for an effective date.
  - (2026-10-05) [Alaska HB 303] An Act relating to the registration and titling of legally imported motor vehicles; and providing for an effective date.
      An Act relating to the registration and titling of legally imported motor vehicles; and providing for an effective date.
  - (2026-10-05) [Alaska HB 218] An Act expanding the Tanana Valley State Forest; and providing for an effective date.
      An Act expanding the Tanana Valley State Forest; and providing for an effective date.
  - (2026-10-05) [Alaska HB 371] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution discl…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution disclosure requirements; requiring the di…
  - (2026-10-05) [Alaska HB 377] An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alask…
      An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alaska Public Records Act.
  - (2026-10-05) [Alaska HB 315] An Act relating to the qualifications and confirmation of appointees to the Board of Trustees of the Alaska Permanent Fund Corporation; and providing for an effective date.
      An Act relating to the qualifications and confirmation of appointees to the Board of Trustees of the Alaska Permanent Fund Corporation; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 63 new of 130 total
  - (2026-10-05) Одна загибла і троє поранених через три російські авіаудари по Слов’янській громаді | LEDE: Армія РФ здійснила три авіаудари по Слов'янській громаді. Загинула жінка, поранено троє людей, серед ] (uk:…
      Армія РФ здійснила три авіаудари по Слов'янській громаді. Загинула жінка, поранено троє людей, серед них 13-річний хлопчик. Пошкоджено понад 50 будинків.
  - (2026-10-05) Норми ЄС як виклик: які перехідні періоди потрібні бізнесу в Україні, щоб вистояти після вступу | LEDE: ] (uk: Норми ЄС як виклик: які перехідні періоди потрібні бізнесу в Україні, щоб вистоя)
  - (2026-10-05) Суддя ВАКС заблокувала донат в 3 млн грн для фонду "Повернись живим" | LEDE: Волонтер Сергій Стерненко заявив, що суддя ВАКС Ірина Тесленко відмовила в укладанні угоди між нардепом забороненої ] (uk:…
      Волонтер Сергій Стерненко заявив, що суддя ВАКС Ірина Тесленко відмовила в укладанні угоди між нардепом забороненої ОПЗЖ і САП. Депутат мав перерахувати фонду "ПЖ" 3 млн грн, але суддя вирішила, що такий внесок "не відпо…
  - (2026-10-05) Єврокомісія стежить за ймовірним спалахом чуми в Росії | LEDE: Європейська комісія "дуже уважно" стежить за ймовірним спалахом легеневої чуми в Сибіру і готова, у разі необхідності, координуват] (uk:…
      Європейська комісія "дуже уважно" стежить за ймовірним спалахом легеневої чуми в Сибіру і готова, у разі необхідності, координувати заходи реагування серед держав-членів.
  - (2026-10-05) Російські дрони атакували турецьке судно, загинув капітан – Зеленський | LEDE: У нейтральних водах російські дрони вдарили по турецькому судну з кукурудзою. Загинув капітан, долю одного члена е] (uk:…
      У нейтральних водах російські дрони вдарили по турецькому судну з кукурудзою. Загинув капітан, долю одного члена екіпажу з'ясовують.
  - (2026-10-05) Каллас: Російських олігархів Усманова і Фрідмана наразі не планують повертати під санкції ЄС | LEDE: Європейський Союз найближчим часом не порушуватиме питання про повернення під санкції ЄС рос] (uk:…
      Європейський Союз найближчим часом не порушуватиме питання про повернення під санкції ЄС російських олігархів Алішера Усманова та Михаїла Фрідмана, виключених нещодавно з санкційного списку під тиском Франції та Словаччи…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-05) 497 - Wilton Reassurance Life Co of New York Variable Life Separate Account A (0001034438) (Filer)
      filed 2026-10-05 15:26 UTC — Filed: 2026-10-05 AccNo: 0001193125-26-413668 Size: 10 KB
  - (2026-10-05) 424B2 - BANK OF NOVA SCOTIA (0000009631) (Filer)
      filed 2026-10-05 15:26 UTC — Filed: 2026-10-05 AccNo: 0001839882-26-049572 Size: 428 KB
  - (2026-10-05) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-10-05 15:26 UTC — Filed: 2026-10-05 AccNo: 0001918704-26-030541 Size: 935 KB
  - (2026-10-05) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-10-05 15:26 UTC — Filed: 2026-10-05 AccNo: 0001918704-26-030541 Size: 935 KB
  - (2026-10-05) 424B2 - ROYAL BANK OF CANADA (0001000275) (Filer)
      filed 2026-10-05 15:26 UTC — Filed: 2026-10-05 AccNo: 0000950103-26-015186 Size: 227 KB
  - (2026-10-05) 497VPU - Wilton Reassurance Life Co of New York Variable Life Separate Account A (0001034438) (Filer)
      filed 2026-10-05 15:25 UTC — Filed: 2026-10-05 AccNo: 0001193125-26-413665 Size: 9 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 40 new of 55 total
  - (2026-10-05) [BleepingComputer] Denmark population registry data breach affects 8.8 million people
      Denmark's Central Population Register (CPR) is warning of a data breach that exposed the personal information of approximately 8.8 million registered individuals. [...]
  - (2026-10-05) [BleepingComputer] New Dell System Update flaw lets hackers gain root privileges
      Dell warned customers to patch a critical vulnerability in the System Update (DSU) command-line interface (CLI) deployment tool as soon as possible. [...]
  - (2026-10-05) [BleepingComputer] South Korea probes bank breaches amid suspected AI-powered attacks
      South Korea's Financial Services Commission (FSC) held an emergency meeting following a series of cyberattacks targeting financial institutions in the country. [...]
  - (2026-10-05) [BleepingComputer] tenfold CE: Our free Identity Governance tool just got 2 new features
      tenfold has added shared content governance and real-time event auditing to its free Community Edition for organizations with under 150 users. The new features help teams manage Microsoft 365 sharing and investigate susp…
  - (2026-10-05) [BleepingComputer] Alleged dev of Ploutus ATM malware appears in US court after arrest
      The U.S. Department of Justice has announced the arrest of the alleged developer of Ploutus malware, used to steal millions of dollars in ATM jackpotting attacks across the United States. [...]
  - (2026-10-05) [The Hacker News] ⚡ Weekly Recap: NetScaler and FortiMail 0-Days, AI Coding Leaks, Spectre v2 and Ransomware Arrests
      A blank field. A public repo. One reply to an email. A box left exposed. None of this sounds dramatic, which is partly the problem. This week’s threats keep finding leverage in small things that were easy to overlook. Th…

### Paper Trading Scorecard — 30 new of 131 total
  - (2026-10-05) [Manifold] Hegseth, Patel, or RFK is out within the next 90 days
  - (2026-10-05) [Manifold] Manifold gets new name in 2027?
  - (2026-10-05) [Manifold] Will the address for math.eg.rego.re receive more than $100 before Oct 8 UTC-12?
  - (2026-10-05) [Manifold] OpenAI renamed to OpenSI by EOY?
  - (2026-10-05) [Manifold] Will Russia invade Greece in 2027?
  - (2026-10-05) [Manifold] Will The Boring Company's Vegas Loop have 50+ operational stations before 2030?

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-10-05) JAF1TA (Bulgaria)
      icao24: 4520ce · position: (45.5878, -0.304) · alt: 10355m · 843km/h
  - (2026-10-05) CFC517 (Canada)
      icao24: c2b03f · position: (48.4793, -116.7598) · alt: 5143m · 617km/h
  - (2026-10-05) SAMU71 (France)
      icao24: 398c4e · position: (47.0292, 4.9936) · alt: 487m · 235km/h
  - (2026-10-05) CFC0536 (Canada)
      icao24: c02045 · position: (47.2641, -93.1826) · alt: 6431m · 503km/h
  - (2026-10-05) PAT662 (United States)
      icao24: adfe8d · position: (30.897, -97.883) · alt: 1143m · 390km/h
  - (2026-10-05) SAM2A (United States)
      icao24: adfeb8 · position: (39.8976, -78.1886) · alt: 7924m · 774km/h

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-10-05) Counter-Strike: M80 vs TYLOO (BO3) - ESL Pro League Group Stage
      yes price: 42% · 24h volume: $1,445,882 · resolves 2026-10-05
  - (2026-10-05) Counter-Strike: Spirit vs MOUZ (BO3) - ESL Pro League Group Stage
      yes price: 14% · 24h volume: $1,213,473 · resolves 2026-10-05
  - (2026-10-05) Falcons vs. Saints
      yes price: 48% · 24h volume: $1,013,001 · resolves 2026-10-06
  - (2026-10-05) China Open: Coco Gauff vs Xinran Sun
      yes price: 98% · 24h volume: $635,414 · resolves 2026-10-12
  - (2026-10-05) Spread: Saints (-2.5)
      yes price: 46% · 24h volume: $453,136 · resolves 2026-10-06
  - (2026-10-05) Counter-Strike: Spirit vs MOUZ - Map 1 Winner
      yes price: 0% · 24h volume: $414,677 · resolves 2026-10-05

### USGS earthquakes (M4.5+, past day) — 9 new of 9 total
  - (2026-10-05) M 5.3 - central Mid-Atlantic Ridge
      M5.3 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-10-05) M 5.0 - 187 km ENE of Saipan, Northern Mariana Islands
      M5.0 · 187 km ENE of Saipan, Northern Mariana Islands · depth 10 km
  - (2026-10-05) M 5.0 - 71 km E of ‘Ohonua, Tonga
      M5.0 · 71 km E of ‘Ohonua, Tonga · depth 10 km
  - (2026-10-05) M 4.9 - Volcano Islands, Japan region
      M4.9 · Volcano Islands, Japan region · depth 35 km
  - (2026-10-05) M 4.8 - 191 km ESE of Sarangani, Philippines
      M4.8 · 191 km ESE of Sarangani, Philippines · depth 51.291 km
  - (2026-10-04) M 4.8 - 32 km SSE of Jurm, Afghanistan
      M4.8 · 32 km SSE of Jurm, Afghanistan · depth 248.906 km

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-05) [Marginal Revolution] The Greg Clark Symposium
      Earlier I wrote “Greg Clark may well be the most important social scientist of the 21st century.” Thus, the symposium in Econ Journal Watch on Clark’s new but perhaps not forthcoming book is very welcome. The symposium i…
  - (2026-10-05) [Marginal Revolution] China fact of the day
      With surrogacy illegal in China, an industry of agencies, consultants and fertility clinics has emerged to connect clients with women overseas willing to carry their children. While there is no data on the number of chil…
  - (2026-10-05) [Marginal Revolution] Crime in Covid Times
      What caused the historically unique volatility in American homicides since 2019, driven by gun homicides? While there is no shortage of candidate explanations, a coherent understanding has been elusive because of the wid…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 122 total
  - (2026-10-05) [BIS Entity List] page checksum ecf4738334c8
      Page content hash: ecf4738334c8. Compare with prior day's hash to detect updates.
  - (2026-10-05) [UN Sanctions] page checksum 5bf218f2ca8b
      Active UN Security Council sanctions committees page snapshot

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 18 total
  - (2026-10-04) CVE-2026-88779 · Citrix NetScaler: Citrix NetScaler Improper Restriction of Operations within the Bounds of a Memory Buffer Vulnerability
      vendor: Citrix · product: NetScaler · CISA remediation by 2026-10-07

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=26, 14d-median=21; carrying terms: procedures, final, rulemaking, regulatory, action, state, program, information, proposed, certain, model, changes
- state_bills: today=111, 7d-median=82, 14d-median=106; carrying terms: specified, personal, local, procedures, transportation, related, regulates, defined, government, person, policies, water
- state_news: today=284, 7d-median=698, 14d-median=604; carrying terms: abortion, schools, often, agree, thumbnail, history, rural, medicaid, support, policies, centers, photo
- local_news: today=199, 7d-median=225, 14d-median=225; carrying terms: officials, woman, dining, three, investigation, hospital, arrested, according, killed, state, articles, officer
- foreign_news: today=948, 7d-median=1018, 14d-median=1012; carrying terms: financiero, schools, council, russian, arrest, allegations, tackle, thumbnail, watch, history, operation, prevent
- chinese_internal: today=233, 7d-median=265, 14d-median=267; carrying terms: cbmizefvx, cbmigwfbvv, cbmix, cbmiy, cbmibkfvx, articles, blank, cbmiykfvx, target, cbmib, https, cbmiakfvx
- russian_internal: today=909, 7d-median=1022, 14d-median=1022; carrying terms: novaya, russian, financial, target, client, httperror, server, https, gazeta, europe, istories, novayagazeta
- ukrainian_internal: today=130, 7d-median=131, 14d-median=131; carrying terms: russian, missiles, attacks, officials, support, moscow, vladimir, babel, powered, million, assessment, killing
- ukraine_theater: today=717, 7d-median=579, 14d-median=502; carrying terms: rustfmqmzdwf, pjzgzrq, council, russian, classification, lwnue, learned, modern, fdmlmc, muvevxhgmkc, cuxoeulwwvlvbgzhzetbtkflvmdszfzun, adfwemd
- paper_bets: today=131, 7d-median=123, 14d-median=123; carrying terms: participation, growth, washington, pennsylvania, nebraska, arizona, december, presidential, president, remain, achieved, earthquake
- weather: today=92, 7d-median=144, 14d-median=144; carrying terms: montgomery, hours, currents, watch, capsize, winds, illinois, aviation, afdilx, twoat, forecast, water
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: walcl, dexuseu, growth, supply, crude, cpiaucsl, pcepilfe, funds, payrolls, jtsjol, dcoilwtico, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, nasdaq, close, corporate, crude, crypto, agriculture, bitcoin, rates, large, equities, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=122, 7d-median=121, 14d-median=106; carrying terms: representative, schools, council, recognition, sanctions, russian, annexation, somalia, terrorist, operation, attacks, oblasts
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quiver, error, httperror, quantitative, https, quiverquant, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, financial, filer, finance, america, chase, jpmorgan, investment, james
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, angels, james, lindsey, graham, ossoff, warner, disbursements, cooper, talarico, krishnamoorthi, robert
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=49, 14d-median=50; carrying terms: english, sanctions, trump, russian, themes, russia, chinese, perimeter, ukraine, spanish, german, vietnamese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, ground, france, kingdom, canada, germany, bulgaria, kuwait, samuidf
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: derived, deteriorate, confined, toxin, fever, mauritania, parganas, accordance, comprising, phase, interconnected, generation
- cisa_kev: today=18, 7d-median=18, 14d-median=18; carrying terms: vulnerability, buffer, vendor, authorization, incorrect, overflow, traversal, check, products, product, improper, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=9, 7d-median=16, 14d-median=16; carrying terms: depth, islands, philippines, japan, region, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: shakhtar, league, volume, price, donetsk, championship, resolves, champions, group, october, meeting, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, https, economist, marginal, conversableeconomist, class, conversable, basic, economic, markets, because, since
- tech_news: today=55, 7d-median=57, 14d-median=57; carrying terms: research, critical, attacks, government, computerweekly, using, weekday, newsletter, schneier, vulnerability, technica, spectrum
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: fischer, stanton, gregory, conaway, mazie, scholten, representative, aderholt, moody, lizzie, council, hamadeh
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, decision, either, placement, paper, sufficient, unavailable, placed, consensus, market, module, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-28] Fed speeches: Cook, An Update on AI and the Economy
- [2026-09-29] Fed speeches: Bowman, Opening Remarks
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-29] Fed press (events + announcements): Agencies publish resolution plan feedback letters for 15 banking organizations
- [2026-09-30] ECB press: Frank Elderson: Supervisory risk appetite, efficiency and effectiveness
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] ECB press: Isabel Schnabel: Monetary policy in a world of overlapping shocks
- [2026-09-30] ECB press: Christine Lagarde: Interview with La Croix
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] ECB press: Christine Lagarde: Where AI risks meet
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*