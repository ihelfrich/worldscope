# WORLDSCOPE morning brief — 2026-07-24

## Headline
2552 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (636) · Russian Internal News (state + in-exile) (557) · World leaders & government officials (324) · Chinese Internal News (210) · U.S. Weather + Severe / Climate Outlooks (148) · State-Level News (127) · GDELT GKG — themes / entities / watch areas (94) · Local News: St. Louis + Atlanta (92) · Ukraine Theater (total-war monitoring) (65) · Ukrainian Internal News (national + local Kyiv) (45) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 636 new of 1021 total
  - (2026-07-24) [Global] Tens of thousands evacuated from French tourist spot and near Madrid as wildfires spread
      The fire has raged in the region for several days with officials now ordering the evacuation of the entire Cap Ferret peninsula.
  - (2026-07-24) [Global] US hits dozens of countries with new wave of tariffs
      Imposed citing forced labour concerns, the levies replace a temporary global duty brought in after the US Supreme Court struck down tariffs in February.
  - (2026-07-24) [Global] US and Iran trade more strikes in Gulf as fears of escalation mount
      It comes as Iran condemned the US plan to use frozen Iranian assets to pay for war damages.
  - (2026-07-23) [Global] Indonesian babies were trafficked to Singapore. What happens to them now?
      At least 12 babies have been trafficked from Indonesia to Singapore, but what will happen to them remains unclear.
  - (2026-07-24) [Global] South Africa's president wins bid to temporarily halt impeachment inquiry over 'Farmgate'
      Ramaphosa has faced scrutiny following the theft of large sums of cash from his private farm in 2020.
  - (2026-07-24) [Global] Tech titan ordered to pay ex-wife $644m in divorce settlement
      The divorce, involving the chairman of one of South Korea's biggest companies, has gripped the nation.

### Russian Internal News (state + in-exile) — 557 new of 1138 total
  - (2026-07-24) Россия атаковала частный полигон под Киевом. Десять человек погибли, около 100 ранены | LEDE: Россия днем 24 июля нанесла ракетный удар по Киеву и Киевской области. Украинские СМИ со ссылкой] (ru: Рос…
      Россия днем 24 июля нанесла ракетный удар по Киеву и Киевской области. Украинские СМИ со ссылкой на основателя компании — производителя оборонной продукции First Contact Валерия Боровика пишут, что российские военные нан…
  - (2026-07-24) ВСУ бьют по складам Wildberries почти каждый день. Вот к каким последствиям это уже привело. Список | LEDE: 18 июля. Электросталь, Московская область. Один человек погиб, 57 получили ранения] (ru: ВСУ…
      18 июля. Электросталь, Московская область. Один человек погиб, 57 получили ранения. Пожар на складе продолжался четыре дня. Сейчас склад не работает, Wildberries занимается «оценкой последствий».
  - (2026-07-24) Потребление электричества в Крыму в июле сократилось почти вдвое на фоне блэкаутов из-за ударов ВСУ | LEDE: Потребление электроэнергии в аннексированном Крыму в первые 20 дней июля 2026 года] (ru: Пот…
      Потребление электроэнергии в аннексированном Крыму в первые 20 дней июля 2026 года снизилось на 42% по сравнению с аналогичным периодом в прошлом году. По сравнению с первыми 20 днями июня потребление электроэнергии сокр…
  - (2026-07-24) ЦБ России десятый раз подряд снизил ключевую ставку — до 14% | LEDE: Банк России снизил ключевую ставку на 25 базисных пунктов, до 14%. ] (ru: ЦБ России десятый раз подряд снизил ключевую ставку — до…
      Банк России снизил ключевую ставку на 25 базисных пунктов, до 14%.
  - (2026-07-24) Путин приехал в Иркутск. С начала года он выезжал из Москвы лишь в три города | LEDE: Владимир Путин приехал на авиационный завод в Иркутске. Поездка заранее не анонсировалась. Государственн] (ru: Пут…
      Владимир Путин приехал на авиационный завод в Иркутске. Поездка заранее не анонсировалась. Государственные СМИ, включая ТАСС, сообщили о визите только днем 24 июля.
  - (2026-07-24) Звезда «Лучше звоните Солу» Боб Оденкерк повторил роль Томми Вайсо из эталонно плохого фильма «Комната». Это эксперимент: может ли блестящий актер вытянуть худший в истории сценарий? | LEDE: <p] (ru:…
      В июне благотворительный проект «Acting For a Cause» выложил в сеть фильм «Комната возвращается!» — трибьют картине «Комната» 2003 года. Оригинальную драму Томми Вайсо называют худшей в истории кино, «„Гражданином Кейном…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 210 new of 306 total
  - (2026-07-24) 卡尼：针对美关税威胁将“不惜一切代价”维护利益--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1DV2ZoZzJCcUh0RFBEa29NcmRqRXhmOHpDWm9TbGlJNms5QzJMVEpnZEpXZzR2Q3RNd1A5Uk5yQy1wc29jdGl4SFltL] (zh:…
      卡尼：针对美关税威胁将“不惜一切代价”维护利益--国际 人民网
  - (2026-07-24) 关于推荐白光迪等5名同志参加第十三届“好记者讲好故事”活动的公示--传媒 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTFBtSWxiOFMyR1dyR2hVamhHWl9yTVpLM1JOdXZOVWVHUGJuM1JWNndkUFktdmYzRG9seThGcy1TQjlteFRR] (zh:…
      关于推荐白光迪等5名同志参加第十三届“好记者讲好故事”活动的公示--传媒 人民网
  - (2026-07-23) 江西南昌：昌九高铁全线接触网挂网完成 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTFAtZWxRU2ZpV0JJdGk1QzhQSDN6ZFFaazRJQjgwT0owWUFwem5tT1h2M21SelI1WlNoMXBRUHJkSUpkZldka25VTHJoT3U3e] (zh:…
      江西南昌：昌九高铁全线接触网挂网完成 人民网-图片频道
  - (2026-07-24) 京津冀消协联合约谈15家航司及售票平台 应8月底前完成整改 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1GWkZFY3NBemlYcjBSWlRaWGhLMXpxdkotd3QyNTZaT184MF83YXphVHhMM011ZkY5d19HcWszNjhGSXBuc0VNbFl] (zh:…
      京津冀消协联合约谈15家航司及售票平台 应8月底前完成整改 人民网
  - (2026-07-24) 这座机场藏着“智慧大脑” - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE0taTJLTjBpQ3JCcU9ha2NFdkZVcGQ4OS1CeUtTcXFzck0yazVUdFluS3BHN0x1MHluWXBMZDk2WmdqWlJRWWFTelA5M1BSRFRqUEFfS0J4] (zh:…
      这座机场藏着“智慧大脑” 人民网
  - (2026-07-24) 闯入一座会呼吸的博物馆 做一回百年前的“隐形宾客” - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1CTFN5V3ZJZFcxX1hWLVZLMHBRTWljVXM1TzVHSnotMWNwSER0eElyZkluWllfTno4LWU2RmVkQTEyX0U1ZmFBdG0wc0t] (zh:…
      闯入一座会呼吸的博物馆 做一回百年前的“隐形宾客” 人民网

### U.S. Weather + Severe / Climate Outlooks — 148 new of 157 total
  - (2026-07-24) [Moderate] Special Weather Statement: Special Weather Statement issued July 24 at 7:20AM CDT by NWS Hastings NE
      Areas of fog will continue affecting much of south central/central Nebraska and north central Kansas early this morning. Visibility as low as 1 to 1/2 mile will be fairly widespread across much of the area, with embedded…
  - (2026-07-24) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-24) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued July 24 at 5:12AM PDT until July 28 at 5:00PM PDT by NWS San Francisco CA
      * WHAT...Long period SW swell will bring an increased risk of sneaker waves and strong rip currents. Breaking waves will reach up to 10 feet along some south and southwest facing beaches and break points. * WHERE...Beach…
  - (2026-07-24) [Severe] Flood Watch: Flood Watch issued July 24 at 7:10AM CDT until July 25 at 7:00AM CDT by NWS Birmingham AL
      * WHAT...Persistent showers may result in excessive rainfall and localized flooding. * WHERE...A portion of central Alabama, including the following counties, Blount, Cherokee and Etowah. * WHEN...Through Saturday mornin…
  - (2026-07-24) [Severe] Flood Watch: Flood Watch issued July 24 at 7:10AM CDT until July 25 at 7:00AM CDT by NWS Birmingham AL
      * WHAT...Persistent showers may result in excessive rainfall and localized flooding. * WHERE...A portion of central Alabama, including the following counties, Calhoun, Cleburne, Jefferson, St. Clair, Walker and Winston.…
  - (2026-07-24) [Severe] Flood Watch: Flood Watch issued July 24 at 8:06AM EDT until July 25 at 12:00AM EDT by NWS Peachtree City GA
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of north central, northeast, and northwest Georgia, including the following counties, in north central Georgia, Cherokee, Dawson…

### State-Level News — 127 new of 858 total
  - (2026-07-24) [Connecticut] Larson, Bronin waging an ad war in waning weeks before primary
      <img width="1024" height="831" src="https://ctmirror.org/wp-content/uploads/2026/03/5C565132-17A4-4CAE-A8C9-A0BCD07C6412-1024x831.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="…
  - (2026-07-24) [Connecticut] Without Olmstead rule protection, God help the disabled
      <img width="775" height="451" src="https://ctmirror.org/wp-content/uploads/2026/07/I-am-olmstead.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="htt…
  - (2026-07-24) [Connecticut] Congress has given states new housing tools. CT is ready to make them work
      <img width="600" height="336" src="https://ctmirror.org/wp-content/uploads/2026/06/Housing-image-copy.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset…
  - (2026-07-24) [Arizona] Doctors warn Andy Biggs’ record on healthcare, abortion should alarm Arizona voters
      Arizona doctors and progressive organizations are warning voters that Republican gubernatorial nominee Andy Biggs has a long record as an elected official of attacking access to healthcare and abortion care. Biggs will f…
  - (2026-07-24) [Arizona] Cyclosporiasis outbreak surges to over 4,173 confirmed cases
      The number of cases of cyclosporiasis — a parasitic infection linked to contaminated water or food that causes severe intestinal issues — has more than doubled to over 4,173 cases across 41 states this week, up from the…
  - (2026-07-24) [Arizona] Mayes tells federal court it’s too early to block Prop. 314, says no one has been arrested yet
      Arizona Attorney General Kris Mayes says it’s too soon for a lawsuit to be filed against a 2024 law that would allow local police officers to arrest unauthorized immigrants because no one has been arrested under it yet.…

### GDELT GKG — themes / entities / watch areas — 94 new of 94 total
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Ázsiai tőzsde Július 24 . – Pirosban a Távol - Kelet az olaj 99 dollár
      tozsdeforum.hu · Hungarian · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Sticker shock at the pumps forces Albertans to rethink summer road trips
      calgary.citynews.ca · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Zeker 63 . 000 evacuaties om bosbranden Frankrijk , ook mensen per boot weggebracht
      nos.nl · Dutch · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Children and teens roundup – the best new picture books and novels
      aol.co.uk · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Weak marketing margins drag down BPCL and HPCL Q1 earnings
      indiagazette.com · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Tropical Storm Bertha weakens after bringing strong winds and heavy surf to Louisiana and Texas – KTBB News , Weather , Talk
      ktbb.com · English · tone NA

### Local News: St. Louis + Atlanta — 92 new of 243 total
  - (2026-07-24) [St. Louis] Ask George: What summertime dish would you drive across St. Louis for?
      This may be a first: When I asked SLM’s dining team to weigh in, two people picked the same dish—and make that three if you include me. Denise Mueller-Peterson, Madi Lee, and I all chose Louie‘s prosciutto and shaved Par…
  - (2026-07-24) [St. Louis] St. Louis’ 70 Grand bus route is letting riders down, transit group says
      The 70 Grand bus route running from Broadway to Loughborough Commons services an average of 5,000 riders each weekday. However, the route boasting the highest ridership in the city is also frequently plagued by reliabili…
  - (2026-07-24) [St. Louis] Union Pacific’s Big Boy tour fun concealed a serious purpose
      This past weekend, thousands of St. Louisans sweated it out at Union Station to see the 1.2-million pound steam locomotive Big Boy stop by on its cross-country tour. It was a surprisingly emotional experience: Wherever t…
  - (2026-07-24) [St. Louis] Assault case against bedridden 85-year-old gets dismissed—for now
      Last November, 85-year-old Norman Fishel of Olivette suffered a massive hemorrhagic stroke, which left his entire left side paralyzed. Three days after that stroke, while in the intensive care unit at Mercy Hospital, the…
  - (2026-07-24) [St. Louis] 'Utterly disappointed' | Students say they were unexpectedly unenrolled from Howard University
      The university says students missed a tuition deadline, while some affected students say they were waiting on scholarship money and had made payment plans.
  - (2026-07-24) [St. Louis] Drones target northern Iraqi city where US forces are based as US-Iran fighting escalates
      An Associated Press journalist heard at least seven blasts Friday morning local time in the city of Irbil, the capital of Iraq’s semi-autonomous Kurdish region.

### Ukraine Theater (total-war monitoring) — 65 new of 290 total
  - (2026-07-24) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-23) [FIRMS] thermal anomaly 49.184, 33.457 (FRP 1.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-23 2246Z, FRP 1.12 MW
  - (2026-07-24) [FIRMS] thermal anomaly 52.847, 29.992 (FRP 0.67 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0026Z, FRP 0.67 MW
  - (2026-07-24) [FIRMS] thermal anomaly 52.113, 32.201 (FRP 0.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0026Z, FRP 0.39 MW
  - (2026-07-24) [FIRMS] thermal anomaly 47.786, 29.016 (FRP 1.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0026Z, FRP 1.08 MW
  - (2026-07-24) [FIRMS] thermal anomaly 46.521, 30.696 (FRP 1.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0028Z, FRP 1.37 MW

### Ukrainian Internal News (national + local Kyiv) — 45 new of 125 total
  - (2026-07-24) Качинський заявив про вихід понад 30 депутатів із партії "Право і справедливість" | LEDE: У Польщі понад 30 членів "ПіС" покинули партію через конфлікт навколо декларації та створення об'єднанн] (uk:…
      У Польщі понад 30 членів "ПіС" покинули партію через конфлікт навколо декларації та створення об'єднання Моравецьким.
  - (2026-07-24) Єврокомісія попередньо встановила порушення TikTok вимог цифрового законодавства ЄС | LEDE: ] (uk: Єврокомісія попередньо встановила порушення TikTok вимог цифрового законодавства)
  - (2026-07-24) Дрон РФ влучив в автомобіль у Харкові: водій загинув | LEDE: Вдень 24 липня російський ударний безпілотник влучив у легковий автомобіль у Київському районі Харкова, водій загинув.] (uk: Дрон РФ влучив…
      Вдень 24 липня російський ударний безпілотник влучив у легковий автомобіль у Київському районі Харкова, водій загинув.
  - (2026-07-24) 10 загиблих і до 100 поранених через російський удар по полігону на Київщині; відкрито 2 провадження | LEDE: Ракетний удар РФ по полігону Київщини: 10 загиблих, близько 100 поранених. Порушено ] (uk:…
      Ракетний удар РФ по полігону Київщини: 10 загиблих, близько 100 поранених. Порушено два кримінальні провадження.
  - (2026-07-24) У Литві чоловіка запідозрили у зборі даних про військові об’єкти для Росії | LEDE: Литовська прокуратура розслідує ймовірний шпигунство громадянина країни, який, за даними слідства, передавав о] (uk:…
      Литовська прокуратура розслідує ймовірний шпигунство громадянина країни, який, за даними слідства, передавав особам, пов'язаним із російською розвідкою, інформацію про військову інфраструктуру, техніку та переміщення вій…
  - (2026-07-24) СБУ заявила про удари по НПЗ, РЛС і військових аеродромах у РФ та Криму | LEDE: Служба безпеки України повідомила, що в ніч на 24 липня завдала серії далекобійних ударів по нафтопереробних підп] (uk:…
      Служба безпеки України повідомила, що в ніч на 24 липня завдала серії далекобійних ударів по нафтопереробних підприємствах, паливній інфраструктурі та радіолокаційній станції на території Росії й тимчасово окупованого Кр…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-24) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-07-24 12:22 UTC — Filed: 2026-07-24 AccNo: 0001213900-26-081131 Size: 24 KB
  - (2026-07-24) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-07-24 12:22 UTC — Filed: 2026-07-24 AccNo: 0001213900-26-081131 Size: 24 KB
  - (2026-07-24) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-07-24 12:21 UTC — Filed: 2026-07-24 AccNo: 0001213900-26-081130 Size: 24 KB
  - (2026-07-24) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-07-24 12:21 UTC — Filed: 2026-07-24 AccNo: 0001213900-26-081130 Size: 24 KB
  - (2026-07-24) 424B2 - DEUTSCHE BANK AKTIENGESELLSCHAFT (0001159508) (Filer)
      filed 2026-07-24 12:20 UTC — Filed: 2026-07-24 AccNo: 0000950103-26-011128 Size: 105 KB
  - (2026-07-24) 425 - Warehouses De Pauw (0002145819) (Subject)
      filed 2026-07-24 12:15 UTC — Filed: 2026-07-23 AccNo: 0001208646-26-000033 Size: 519 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-24) [United Kingdom] Amy Winehouse mum shares painful truth of star addiction on death anniversary
      domain: mirror.co.uk · language: English · tone:
  - (2026-07-24) [United States] Peter Lassally , longtime late - night TV Producer , dies at 93
      domain: texarkanagazette.com · language: English · tone:
  - (2026-07-24) [United States] Fort Collins settles $500K wrongful DUI lawsuit , other cases pending
      domain: yahoo.com · language: English · tone:
  - (2026-07-24) [United Kingdom] Intel makes Q2 loss of $11bn ⋆ Electronics Weekly
      domain: electronicsweekly.com · language: English · tone:
  - (2026-07-24) [] Sticker shock at the pumps forces Albertans to rethink summer road trips
      domain: calgary.citynews.ca · language: English · tone:
  - (2026-07-24) [Israel] Palestinian stabbed and injured by Israeli colonists near Jericho
      domain: english.wafa.ps · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-24) JAF50T (Bulgaria)
      icao24: 4520d0 · position: (40.9651, -3.1588) · alt: 11285m · 718km/h
  - (2026-07-24) PAT097 (United States)
      icao24: adfecb · position: (38.1297, -85.1049) · alt: 3162m · 291km/h
  - (2026-07-24) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (33.2957, -6.8767) · alt: 11041m · 822km/h
  - (2026-07-24) PAT053 (United States)
      icao24: adfe4a · position: (32.8709, -88.1182) · alt: 8229m · 482km/h
  - (2026-07-24) SAMU691 (France)
      icao24: 39c994 · position: (45.5219, 4.4501) · alt: 876m · 230km/h
  - (2026-07-24) CFC2967 (Canada)
      icao24: c2b585 · position: (48.5118, 0.9947) · alt: 3063m · 540km/h

### U.S. Federal Action — 23 new of 32 total
  - (2026-07-24) Amendment of Class D Airspace and Class E Airspace Over Westfield, MA
      This action amends Class D and Class E airspace over Westfield, MA. This action updates the airport name and geographic coordinates in both Westfield, MA Class D and Class E airspace legal descriptions. This action also…
  - (2026-07-24) Establishment of Class E Airspace; Ottawa, IL
      This action proposes to establish Class E airspace at OSF St Francis Medical Center Heliport, Ottawa, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-07-24) Proposed Amendment to the Definition of Huione Group, a Financial Institution Operating Outside the United States of Primary Money Laundering Concern; Extension of Comment Period
      FinCEN is extending the comment period for the referenced notice of proposed rulemaking (NPRM) it published to amend the existing definition of Huione Group to include, within the definition of that group, H-Pay Service…
  - (2026-07-24) Amendment of Class E Airspace; Alma, MI; correction
      This action corrects an NPRM published by the FAA in the Federal Register on July 10, 2026, amending the Class E airspace at Alma, MI. Specifically, this action corrects the title of the document erroneously published as…
  - (2026-07-24) Loan Performance Categories and Financial Reporting
      The Farm Credit Administration (FCA, we, or our) amends our regulatory high-risk loan performance categories by removing "Formally restructured loans (TDR)," also known as troubled debt restructurings. In 2022, changes i…
  - (2026-07-24) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a safety zone on the main branch of the Chicago River between Michigan Avenue Bridge (Mile Marker 326.5) and the Columbus Drive Bridge (Mile Marker 326.7) for the Annual Chicago Ducky Derby m…

### IT, InfoSys & cybersecurity news (last 7 days) — 20 new of 57 total
  - (2026-07-24) [BleepingComputer] Man gets six years for hacking 750 women's Snapchat accounts
      An Illinois man was sentenced on Tuesday to 76 months in prison and three years of supervised release for hacking the Snapchat accounts of over 750 women to steal nude photos. [...]
  - (2026-07-24) [BleepingComputer] Clop ransomware targets Windchill, FlexPLM in data theft attacks
      The Clop ransomware gang (also tracked as Cl0p) is targeting Internet-exposed PTC Windchill and FlexPLM instances in a new data theft extortion campaign. [...]
  - (2026-07-24) [The Hacker News] Seeing AI Agents Is Not Enough. Security Teams Must Enforce What They Can Do
      AI agent security is moving through a familiar maturity curve: adoption, then visibility, and finally, control. But what we've collectively discovered is that enforcing least privilege for AI agents is harder than we eve…
  - (2026-07-24) [The Hacker News] Hacker Runs Hermes AI Agent Unattended for Post-Exploitation at Thai Finance Ministry
      Someone installed a popular AI assistant on a rented server, switched off the setting that makes it ask permission before running risky commands, and pointed it at Thailand's Ministry of Finance, which runs the country's…
  - (2026-07-24) [The Hacker News] Golden Chickens Resurfaces With Four New Malware Families and Modular Implants
      The threat actors behind the Golden Chickens malware-as-a-service (MaaS) ecosystem have resurfaced with four new malware families, indicating that the operators are showing no signs of stopping despite extensive public d…
  - (2026-07-24) [The Hacker News] NodeBB Patches Eight AI-Found Flaws Exposing Admin Access and Private Chats
      Eight security flaws in NodeBB went public on Wednesday, along with the code to exploit them. Aikido Security rates all eight as high severity and says its AI pentest agents found them in a six-hour review of the forum s…

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-07-24) LoL: Team WE vs JD Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $1,796,902 · resolves 2026-07-24
  - (2026-07-24) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,107,688 · resolves 2026-06-01
  - (2026-07-24) LoL: Team WE vs JD Gaming - Game 2 Winner
      yes price: 0% · 24h volume: $1,013,937 · resolves 2026-07-24
  - (2026-07-24) Counter-Strike: magic vs 3DMAX (BO3) - BLAST Bounty Qualifier
      yes price: 0% · 24h volume: $737,324 · resolves 2026-07-24
  - (2026-07-24) Generali Open: Yannick Hanfmann vs Quentin Halys
      yes price: 0% · 24h volume: $525,110 · resolves 2026-07-31
  - (2026-07-24) Counter-Strike: magic vs 3DMAX - Map 2 Winner
      yes price: 0% · 24h volume: $446,815 · resolves 2026-07-24

### GDACS — global disaster alerts — 10 new of 246 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0

### Paper Trading Scorecard — 9 new of 146 total
  - (2026-07-24) [Polymarket] Will John N. Kennedy win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-07-24) [Polymarket] Will there be between 0 and 20 average daily transits of the Strait of Hormuz on July 31?
      This market will resolve according to the finalized 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for July 31, 2026. If the reported value falls exactly b…
  - (2026-07-24) [Polymarket] Will Dune: Messiah have the best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses more domestically on its opening weekend than any other movie in 2026. The “Weekend Box Office Performance” table on the page for the relevant mo…
  - (2026-07-24) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-24) [Manifold] Will a soccer final between Spain and Argentina be repeated before 2027?
  - (2026-07-24) [Manifold] Will a Mythos-tier-at-cybersecurity open-source model be released before end of 2027?

### USGS earthquakes (M4.5+, past day) — 9 new of 17 total
  - (2026-07-24) M 5.3 - 197 km W of Abepura, Indonesia
      M5.3 · 197 km W of Abepura, Indonesia · depth 10 km
  - (2026-07-24) M 5.0 - 94 km SSE of Adak, Alaska
      M5.0 · 94 km SSE of Adak, Alaska · depth 10 km
  - (2026-07-24) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 35 km
  - (2026-07-24) M 4.8 - Mid-Indian Ridge
      M4.8 · Mid-Indian Ridge · depth 10 km
  - (2026-07-24) M 4.8 - 54 km NNW of San Antonio, Puerto Rico
      M4.8 · 54 km NNW of San Antonio, Puerto Rico · depth 9 km
  - (2026-07-23) M 4.7 - 56 km NW of Santa Domenica, Italy
      M4.7 · 56 km NW of Santa Domenica, Italy · depth 243.071 km

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 126 total
  - (2026-07-24) [USASpending] $22,440,930,497 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-07-24) [USASpending] $3,055,729,526 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-07-24) [USASpending] $1,605,134,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-24) [USASpending] $1,313,227,200 → SLS FEDERAL SERVICES LLC: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
      Agency: Department of Homeland Security. Description: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
  - (2026-07-24) [USASpending] $1,036,291,804 → L3HARRIS TECHNOLOGIES, INC.: TAS::80 0122::TAS DEVELOPMENT, MANUFACTURING AND SUPPORT TO
      Agency: National Aeronautics and Space Administration. Description: TAS::80 0122::TAS DEVELOPMENT, MANUFACTURING AND SUPPORT TO WEATHER OBSERVING INSTRUMENT
  - (2026-07-24) [USASpending] $1,027,192,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-24) [China] Women to Watch 2026 extends deadline for entries
      campaignasia.com · English
  - (2026-07-24) [China] Explainer : What to know about U . S .- Saudi nuclear deal
      chinanationalnews.com · English
  - (2026-07-24) [China] China imports from Africa rise 23 . 5 % following zero - tariff expansion
      china.org.cn · English
  - (2026-07-24) [China] People Moves : ADIC appoints real assets CIO | Moves
      asianinvestor.net · English
  - (2026-07-24) [China] China consumer market continues to expand and improve
      china.org.cn · English
  - (2026-07-24) [China] Lotte Duty Free unveils Glenmorangie Signet Reserve dessert bar at Incheon Airport
      dfnionline.com · English

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-07-23) U.S. Court of Appeals, 5th Cir.: United States v. Debrow
  - (2026-07-23) U.S. Court of Appeals, 1st Cir.: Rana v. Blanche
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: United States v. Palomares
  - (2026-07-21) U.S. Court of Appeals, 1st Cir.: Recchia v. Campbell
  - (2026-07-21) Florida Supreme Court: Dominick A. Occhicone v. State of Florida

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### State Legislative Action — 3 new of 107 total
  - (2026-07-24) [California SB 820] Inmates: mental health.
      Existing law prohibits a person from being tried or adjudged to punishment while that person is mentally incompetent. Existing law establishes a process by which a defendant's mental competency is evaluated. Existing law…
  - (2026-07-24) [California SB 809] Employees and independent contractors: construction trucking.
      (1) Existing law, as established in the case of Dynamex Operations W. v. Superior Court (2018) 4 Cal.5th 903 (Dynamex) , creates a presumption that a worker who performs services for a hirer is an employee for purposes o…
  - (2026-07-24) [Colorado HB 1298] Background Checks for Child Welfare Placements
      The act gives county departments of human or social services and the Colorado department of human services (department) the statutory authority needed to conduct the required fingerprint-based criminal history record che…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 34 total
  - (2026-07-24) MOVER ▲ Gautam Adani — $85.36B (+$0.16B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-24) MOVER ▼ Francoise Bettencourt Meyers & family — $91.34B ($-0.09B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-24) MOVER ▲ Mukesh Ambani — $86.50B (+$0.09B since yesterday)
      India · Diversified · source: Diversified

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-24) [Marginal Revolution] Talk Therapy is Speech
      IJ: On Wednesday, the United States District Court for the District of Columbia struck down a D.C. law that barred therapists from other jurisdictions from doing online teletherapy visits with clients in D.C. The decisio…
  - (2026-07-24) [Marginal Revolution] European Fact of the Day, Again
      This year, like last year, “the European Union will again make more money from fining US tech companies Than from the total tax income from Europe’s own public tech companies!” The post European Fact of the Day, Again ap…
  - (2026-07-24) [Marginal Revolution] The optimal Bayesian update?
      I see at least three updates one might make from the recent OAI/Hugging Face hacking incident: 1. “This happened sooner than I expected, and the story is more dramatic than I expected,” therefore I am more worried than b…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=32, 7d-median=22, 14d-median=21; carrying terms: amendment, regulatory, proposing, published, unless, certain, service, action, public, provide, safety, guard
- state_bills: today=107, 7d-median=121, 14d-median=118; carrying terms: funding, powers, units, physical, makes, reimbursement, pursuant, promote, having, general, provisions, generally
- state_news: today=858, 7d-median=747, 14d-median=782; carrying terms: hours, funding, providence, following, biddeford, circuit, fellow, cutting, formerly, indigenous, speaker, always
- local_news: today=243, 7d-median=227, 14d-median=235; carrying terms: hours, following, residents, srcset, visit, tuesday, content, https, morning, august, early, woman
- foreign_news: today=1021, 7d-median=1021, 14d-median=1022; carrying terms: hours, timesofisrael, draft, heads, speaker, around, decades, promote, called, updating, struck, statistics
- chinese_internal: today=306, 7d-median=303, 14d-median=304; carrying terms: https, google, global, cbmizefvx, cbmibkfvx, capital, cbmiaefvx, cbmidefvx, china, cbmix, market, cbmiw
- russian_internal: today=1138, 7d-median=982, 14d-median=945; carrying terms: gazeta, street, social, laquo, novaya, istories, times, found, title, google, media, wildberries
- ukrainian_internal: today=125, 7d-median=125, 14d-median=126; carrying terms: following, babel, civilians, injuring, logistics, called, offered, network, general, struck, several, aerial
- ukraine_theater: today=290, 7d-median=443, 14d-median=422; carrying terms: kytupucnjrdwdhowf, neuzakjlqnryyvj, hralpvne, pszvnnnbhvxdrv, dcwtu, zlsfrhyk, syria, cwzggxvwf, logistics, pbrgd, eytlztmvrtdujn, uwgzduvjcdnxugsxb
- paper_bets: today=146, 7d-median=144, 14d-median=144; carrying terms: transferable, impossible, levels, jpmorgan, current, series, sachs, humanoid, officially, nominee, playoffs, number
- weather: today=157, 7d-median=167, 14d-median=166; carrying terms: following, chances, scattered, tropical, around, state, afternoon, monitoring, rainfall, portions, weather, hazardous
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, rates, payems, payrolls, dexuseu, indicator, total, jolts, headline, pcepilfe, inflation, unemployment
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, commodities, nasdaq, natural, yield, rates, equities, credit, large, crypto, agriculture, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=126, 7d-median=117, 14d-median=118; carrying terms: dfbfehlhafb, tkxym, mufswgh, events, qjrqy, syria, logistics, frequently, restrictive, state, target, zmlvhjbjhxrjbvsmxhahnores
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, httperror, error, unauthorized, quiver, quiverquant, https, client, congresstrading
- billionaires: today=34, 7d-median=36, 14d-median=35; carrying terms: diversified, tesla, changpeng, facebook, steve, peterffy, infrastructure, ambani, tiktok, jensen, source, bernard
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, state, trade, charles, insurance, blanche, court, supreme, district, international, board, alliance
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, david, graham, alexandria, brown, johnson, senate, disbursements, house, trone, congress, filing
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=94, 7d-median=45, 14d-median=46; carrying terms: english, hezbollah, israel, trump, spanish, chinese, themes, russia, perimeter, action, latest, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: police, english, military, trump, domain, killed, language, kingdom, house, against, death, health
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=9, 14d-median=9; carrying terms: position, canada, belgium, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: trends, exposure, following, welfare, member, cvdpv, watery, discharged, levels, current, increases, regio
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: injection, mechanism, access, untrusted, sharepoint, insufficient, critical, lockout, missing, vendor, server, langflow
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=246, 7d-median=196, 14d-median=180; carrying terms: sweden, north, kenya, belarus, thailand, depth, vietnam, liechtenstein, minor, elida, tropical, montenegro
- usgs_quakes: today=17, 7d-median=17, 14d-median=18; carrying terms: puerto, depth, islands, indonesia, mexico, ridge, south, madero, abepura, region, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, resolves, interest, price, meeting, prime, minister, volume, ethiopia, demeke, change, mekonnen
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: interlocutor, revolution, marginal, useful, conversable, effects, interview, https, caught, perhaps, class, economist
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: computer, around, encryption, technology, artificial, hacker, accessed, fields, recent, cyber, entered, million
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: merkley, darin, warnock, yakym, garcia, minneapolis, barrasso, shelley, board, miller, dusty, degette
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, placed, unavailable, paper, placement, converges, today, evidence, identify, decision, either, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: Monetary policy decisions
- [2026-07-23] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*