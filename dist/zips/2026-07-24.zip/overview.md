# WORLDSCOPE morning brief — 2026-07-24

## Headline
3153 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (773) · Russian Internal News (state + in-exile) (682) · World leaders & government officials (324) · State-Level News (303) · Chinese Internal News (218) · U.S. Weather + Severe / Climate Outlooks (189) · Local News: St. Louis + Atlanta (170) · Ukraine Theater (total-war monitoring) (112) · Ukrainian Internal News (national + local Kyiv) (59) · SEC Form 4 insider transactions (recent) (40) · GDACS — global disaster alerts (38) · IT, InfoSys & cybersecurity news (last 7 days) (38)

## What changed today
### International News + Multilateral Institutions — 773 new of 1057 total
  - (2026-07-24) [Global] Thousands of lightning strikes trigger fresh wildfires in western Canada
  - (2026-07-24) [Global] Guyanese authorities confirm death of 72 people in sinking of coastal ferry
  - (2026-07-24) [Global] Canadian government urged to block Thomson Reuters data deal with US ICE
  - (2026-07-24) [Global] Masked men invading and taking Amazon communities ‘hostage’ in organised crime surge, say local leaders
  - (2026-07-24) [Global] Weather tracker: More than 900 wildfires rage across Canada
  - (2026-07-24) [Global] Australian households face prospect of interest rate hike and petrol prices rising above $2 a litre

### Russian Internal News (state + in-exile) — 682 new of 1226 total
  - (2026-07-24) Трамп пригрозил Европе «значительными пошлинами» из-за штрафов, наложенных на американские бигтех-компании | LEDE: Дональд Трамп пообещал, что его администрация начнет расследование в отноше] (ru: Тра…
      Дональд Трамп пообещал, что его администрация начнет расследование в отношении Евросоюза в связи с практикой «ограбления» американских компаний, которым ЕС назначает многомиллиардные штрафы.
  - (2026-07-24) Прокурора Международного уголовного суда Карима Хана (это он выдал ордер на арест Путина) отстранили от должности по обвинению в домогательствах | LEDE: Страны-участницы Международного уголо] (ru: Про…
      Страны-участницы Международного уголовного суда (МУС) проголосовали за отстранение Карима Хана от должности главного прокурора, пишет Reuters со ссылкой на два дипломатических источника.
  - (2026-07-24) Неделю назад ВСУ начали бить по складам Wildberries. Вспоминаем, что произошло с тех пор. Девять атакованных объектов, десятки пострадавших, миллиарды рублей ущерба. В соцсетях спорят о справед] (ru:…
      Wildberries — крупнейший российский маркетплейс. В 2025 году его оборот превысил шесть триллионов рублей, а чистая прибыль достигла 175 миллиардов рублей. По оценке исследовательского агентства Data Insight, на Wildberri…
  - (2026-07-24) Зеленский заявил, что в следующем году у Украины будут дроны дальностью до 10 тысяч километров | LEDE: Украина планирует в 2027 году получить дроны с дальностью до 10 тысяч километров, заяви] (ru: Зел…
      Украина планирует в 2027 году получить дроны с дальностью до 10 тысяч километров, заявил Владимир Зеленский в интервью американской журналистке Лоре Лумер, приехавшей в Киев.
  - (2026-07-24) Энди Бернэм — новый премьер-министр Великобритании. Что о нем известно? И почему его уже сравнивают с Мамдани, а также называют «королем Севера» | LEDE: 17 июля Энди Бернэм официально сменил] (ru: Энд…
      17 июля Энди Бернэм официально сменил Кира Стармера на посту лидера Лейбористской партии. Три дня спустя он вступил в должность премьер-министра Великобритании. До этого Бернэм 16 лет был членом парламента, занимал посты…
  - (2026-07-24) Российская сеть «Шторм-1516» развернула кампанию дезинформации против кандидата в президенты Франции Эдуара Филиппа | LEDE: Российская дезинформационная сеть «Шторм-1516» попыталась вмешатьс] (ru: Рос…
      Российская дезинформационная сеть «Шторм-1516» попыталась вмешаться в президентские выборы во Франции. Источник во французских службах безопасности рассказал AFP, что группа развернула кампанию против бывшего премьер-мин…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 303 new of 984 total
  - (2026-07-24) [Alabama] Alabama Health Literacy Month
      Download
  - (2026-07-24) [California] California’s economy isn’t just bigger than Texas and Florida — it’s growing faster, too
      Source
  - (2026-07-24) [California] CA landlord fights law meant to help low-income renters
      Should California landlords be required to rent to tenants with federal housing vouchers? They are under state law, but a Sacramento-based property manager is contest
  - (2026-07-24) [California] Public funding cuts, lost grants, stagnant wages: How economic woes are dimming a vibrant art scene
      <img width="1024" height="681" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072226-SD-Arts-AP-CM.jpg?fit=1024%2C681&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="An a…
  - (2026-07-24) [California] Aging oil refineries don’t need more public dollars. California should let them retire
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092925-Refinery-Workers-SK-10-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-24) [California] California can’t replant its forests fast enough to keep up with wildfires
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526_Reforestation_AHK_CM_75.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### Chinese Internal News — 218 new of 313 total
  - (2026-07-23) 韩国电竞明星Faker获封“警长” 名誉警衔兼任反网赌宣传大使 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1PcEk4dmQtV0ppUmNSb0g0RGN0Z3EtUmFVQTFxbUdBZ0NmOUxheU0zcGNPRzJBYUYzQ01jbDREQVNGS216RGZVRG] (zh:…
      韩国电竞明星Faker获封“警长” 名誉警衔兼任反网赌宣传大使 财新
  - (2026-07-24) 今日开盘：两市双双低开 沪指跌幅0.60% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBwSTQtSXF6WURFeGh4aG1rMXNpRXdWTE1zSmROLWNsR1B4Z2dPRFJxQkNsaS1obmpFYWUxeDg0NUNYSWh1Zkk3SXZqbi1uaXM5] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.60% 财新
  - (2026-07-24) 伊朗被曝已拒绝美方停火提议 特朗普“接近”决定是否扩大对伊行动 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE53eDJHMnNnWTBjblQ2Y2RINFBCdF94d0lHX0ZYeGJNOHBLMDVTZTk4V2hwemRfZjFPWDFHQ2pha2t6VG9vVXNtVF] (zh:…
      伊朗被曝已拒绝美方停火提议 特朗普“接近”决定是否扩大对伊行动 财新
  - (2026-07-24) 人事观察｜福建高层联动调整 58岁厦门市长伍斌任福建副省长 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBzNV9LdXZTLTBNZXhsRXFfdkJyUjc0R2dzNXlsWG9RLVgxV3FQQUZRdzM0bGFZSndzZ3g0eW9iZn] (zh:…
      人事观察｜福建高层联动调整 58岁厦门市长伍斌任福建副省长 china.caixin.com
  - (2026-07-24) 中国绿证价格指数正式发布 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5xSU4wMXVzaWg0aVlVYmNNMnZ4dUJZNWFkcTdNR0R0TnlrN0xYa1dUVXY1eFhoZUp0WktYVlpNdmVSd1pxc29KMVJYME40TmhCSDVia0JQN] (zh:…
      中国绿证价格指数正式发布 财新
  - (2026-07-24) 朱学东：尖椒豇豆｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9PQ2hHZFBFMFhoZmxPemFOS0R4d1doRjZXWS12ZjNLMEhPTXV3UnVvZ2had3NzTG1HTWpNRExUWVFjSTdzS2FnZGxmZGh6emtqZ1FYWlJGd2] (zh:…
      朱学东：尖椒豇豆｜饮食 财新

### U.S. Weather + Severe / Climate Outlooks — 189 new of 193 total
  - (2026-07-24) [Severe] Flash Flood Warning: Flash Flood Warning issued July 24 at 2:13PM MDT until July 24 at 5:15PM MDT by NWS Albuquerque NM
      FFWABQ The National Weather Service in Albuquerque has issued a * Flash Flood Warning for... The Hermits Peak Calf Canyon Burn Scar in... North Central Mora County in northeastern New Mexico... * Until 515 PM MDT. * At 2…
  - (2026-07-24) [Moderate] Gale Warning: Gale Warning issued July 24 at 1:12PM PDT until July 25 at 3:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 35 kt and combined seas 7 to 9 ft when conditions are worst. * WHERE...Point Piedras Blancas to Point Sal from 10 to 60 NM. * WHEN...Until 3 AM PDT Saturday. * IMPACT…
  - (2026-07-24) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 24 at 3:10PM CDT until July 24 at 4:15PM CDT by NWS Grand Forks ND
      SVRFGF The National Weather Service in Grand Forks has issued a * Severe Thunderstorm Warning for... Central Kittson County in northwestern Minnesota... Southwestern Roseau County in northwestern Minnesota... East centra…
  - (2026-07-24) [Moderate] Special Weather Statement: Special Weather Statement issued July 24 at 4:10PM EDT by NWS Charleston SC
      At 410 PM EDT, Doppler radar was tracking a strong thunderstorm near McClellanville, moving east at 20 mph. HAZARD...Wind gusts of 50 to 55 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs…
  - (2026-07-24) [Severe] Fire Weather Watch: Fire Weather Watch issued July 24 at 1:10PM PDT until July 26 at 7:00PM PDT by NWS Medford OR
      ...Critical fire weather conditions continue through the weekend... .Hot, dry and windy conditions will peak this afternoon and Saturday east of the Cascades and potions of northern California. Humidities nudge higher on…
  - (2026-07-24) [Severe] Red Flag Warning: Red Flag Warning issued July 24 at 1:10PM PDT until July 25 at 9:00PM PDT by NWS Medford OR
      ...Critical fire weather conditions continue through the weekend... .Hot, dry and windy conditions will peak this afternoon and Saturday east of the Cascades and potions of northern California. Humidities nudge higher on…

### Local News: St. Louis + Atlanta — 170 new of 250 total
  - (2026-07-24) [St. Louis] Photos: St. Louis Family Playdate at TotSpot Social
      On July 23, St. Louis Magazine celebrated one year of Family Playdates with a special birthday celebration at TotSpot Social, presented by Royal Banks of Missouri and sponsored by Ryan Lawn & Tree. Returning to the venue…
  - (2026-07-24) [St. Louis] Ask George: What summertime dish would you drive across St. Louis for?
      This may be a first: When I asked SLM’s dining team to weigh in, two people picked the same dish—and make that three if you include me. Denise Mueller-Peterson, Madi Lee, and I all chose Louie‘s prosciutto and shaved Par…
  - (2026-07-24) [St. Louis] St. Louis’ 70 Grand bus route is letting riders down, transit group says
      The 70 Grand bus route running from Broadway to Loughborough Commons services an average of 5,000 riders each weekday. However, the route boasting the highest ridership in the city is also frequently plagued by reliabili…
  - (2026-07-24) [St. Louis] Union Pacific’s Big Boy tour fun concealed a serious purpose
      This past weekend, thousands of St. Louisans sweated it out at Union Station to see the 1.2-million pound steam locomotive Big Boy stop by on its cross-country tour. It was a surprisingly emotional experience: Wherever t…
  - (2026-07-24) [St. Louis] Assault case against bedridden 85-year-old gets dismissed—for now
      Last November, 85-year-old Norman Fishel of Olivette suffered a massive hemorrhagic stroke, which left his entire left side paralyzed. Three days after that stroke, while in the intensive care unit at Mercy Hospital, the…
  - (2026-07-24) [St. Louis] General Motors announces $157 million investment in Wentzville plant's paint shop
      GM is investing $157 million to modernize the Wentzville Assembly Plant's paint shop, adding a new 28,000-square-foot building over the next year and a half

### Ukraine Theater (total-war monitoring) — 112 new of 324 total
  - (2026-07-24) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-23) [Liveuamap] The EU will include the Moscow Stock Exchange in the 21st package of sanctions against Russia – Reuters - Liveuamap
      The EU will include the Moscow Stock Exchange in the 21st package of sanctions against Russia – Reuters <font color="#
  - (2026-07-24) [Liveuamap] At Orikhiv direction clashes yesterday near Scherbaky, Stepove and Prymorske, - General Staff of Armed Forces of Ukraine reports Zaporizhia Oblast, Ukraine - Ukraine Interactive map - Ukra…
      At Orikhiv direction clashes yesterday near Scherbaky, Stepove and Prymorske, - General Staff of Armed Forces of Ukrain
  - (2026-07-22) [Liveuamap] Explosions were reported in Armavir, Krasnodar Krai - Liveuamap
      Explosions were reported in Armavir, Krasnodar Krai Liveuamap
  - (2026-07-24) [Liveuamap] Smoke columns rising over St. Petersburg after drones strikes - Liveuamap
      Smoke columns rising over St. Petersburg after drones strikes Liveuamap
  - (2026-07-23) [Liveuamap] Fresh satellite imagery confirms new strike damage at Ali Al Salem Air Base in Kuwait after today&039;s Iranian attacks. Multiple structures, likely troop billets, were destroyed, with smo…
      Fresh satellite imagery confirms new strike damage at Ali Al Salem Air Base in Kuwait after today&039;s Iranian atta

### Ukrainian Internal News (national + local Kyiv) — 59 new of 139 total
  - (2026-07-24) Трамп каже, що довіряє заявам Сі і Путіна щодо продажу зброї Ірану | LEDE: Президент США Дональд Трамп заявив, що довіряє заявам лідера Китаю Сі Цзіньпіна та правителя РФ Владіміра Путіна щодо ] (uk:…
      Президент США Дональд Трамп заявив, що довіряє заявам лідера Китаю Сі Цзіньпіна та правителя РФ Владіміра Путіна щодо торгівлі зброєю з Іраном.
  - (2026-07-24) Від російського удару на полігоні в Київській області загинула комунікаційниця УДО | LEDE: Від ракетного удару Росії по Київщині 24 липня загинула керівниця центру міжнародного співробітництва ] (uk:…
      Від ракетного удару Росії по Київщині 24 липня загинула керівниця центру міжнародного співробітництва та стратегічних комунікацій Управління державної охорони України Валентина Савіцька.
  - (2026-07-24) Генштаб повідомляє про 192 бойових зіткнення на фронті з початку доби | LEDE: Від початку доби 24 липня на фронті відбулось 192 бойових зіткнення, з них 24 на Покровському напрямку.] (uk: Генштаб пові…
      Від початку доби 24 липня на фронті відбулось 192 бойових зіткнення, з них 24 на Покровському напрямку.
  - (2026-07-24) Трамп виправдовується перед РФ, що продає зброю не Україні, а країнам НАТО | LEDE: Президент США Дональд Трамп заявив, що російський лідер Володимир Путін нібито розуміє його, коли йдеться про ] (uk:…
      Президент США Дональд Трамп заявив, що російський лідер Володимир Путін нібито розуміє його, коли йдеться про питання продажу зброї країнам НАТО.
  - (2026-07-24) ЗМІ: Під час атаки РФ на Київ загинув співробітник польської оборонної компанії | LEDE: Внаслідок російського ракетного удару по Києву загинув співробітник польської компанії, що працює в оборо] (uk:…
      Внаслідок російського ракетного удару по Києву загинув співробітник польської компанії, що працює в оборонному секторі.
  - (2026-07-24) Каллас запропонує нові санкції проти РФ через удари по Слов'янську і Київській області | LEDE: ] (uk: Каллас запропонує нові санкції проти РФ через удари по Слов'янську і Київській о)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-24) 425 - TRICO BANCSHARES / (0000356171) (Subject)
      filed 2026-07-24 20:15 UTC — Filed: 2026-07-24 AccNo: 0001104659-26-086650 Size: 27 KB
  - (2026-07-24) 425 - FIRST HAWAIIAN, INC. (0000036377) (Filed by)
      filed 2026-07-24 20:15 UTC — Filed: 2026-07-24 AccNo: 0001104659-26-086650 Size: 27 KB
  - (2026-07-24) [Blackstone Infrastructure Strategies L.P.] Form 4 (Issuer)
      filed 2026-07-24 20:15 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001193125-26-316115 Size: 4 KB
  - (2026-07-24) [Hershey John D.] Form 4 (Reporting)
      filed 2026-07-24 20:15 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001193125-26-316115 Size: 4 KB
  - (2026-07-24) [Blackstone Infrastructure Strategies L.P.] Form 4 (Issuer)
      filed 2026-07-24 20:15 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001193125-26-316114 Size: 4 KB
  - (2026-07-24) [SULLIVAN OWEN J] Form 4 (Reporting)
      filed 2026-07-24 20:15 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001193125-26-316114 Size: 4 KB

### GDACS — global disaster alerts — 38 new of 215 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0

### IT, InfoSys & cybersecurity news (last 7 days) — 38 new of 57 total
  - (2026-07-24) [BleepingComputer] OnTrac notifies customers of data breach after network hack
      OnTrac parcel delivery company is informing that hackers breached its corporate network and may have accessed personal details belonging to its customers. [...]
  - (2026-07-24) [BleepingComputer] Hermes AI agent used to automate attack on Thai Finance Ministry
      A threat actor used the open-source Hermes AI agent in unattended "YOLO" mode to automate post-exploitation activity during an alleged breach of Thailand's Ministry of Finance. [...]
  - (2026-07-24) [BleepingComputer] Hackers hijack hotel Wi-Fi DNS to steal Microsoft 365 accounts
      Hackers are changing the DNS settings on Wi-Fi devices at hotels and conference centers to redirect users to fake Microsoft 365 login pages. [...]
  - (2026-07-24) [BleepingComputer] Microsoft blames massive Microsoft 365 outage on maintenance bug
      Microsoft says a bug in its automated network maintenance request system caused Thursday's massive outage by mistakenly removing IP routes from more devices than intended, disrupting Azure and Microsoft 365 services. [..…
  - (2026-07-24) [BleepingComputer] Chick-fil-A data breach affects more than 13,000 customers
      Chick-fil-A has confirmed that over 13,000 customers had their accounts breached in a wave of credential stuffing attacks targeting its website and mobile app between June 17 and June 19. [...]
  - (2026-07-24) [The Hacker News] BlueNoroff Zoom Phishing Kit Profiles Crypto Wallets Before Malware Delivery
      The North Korean threat actors behind the ClickFix-style campaigns that employ typosquatted Zoom and Microsoft Teams domains have been found to operate an active phishing kit to impersonate the videoconferencing platform…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-24) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (39.8023, -2.9443) · alt: 10668m · 742km/h
  - (2026-07-24) PAT087 (United States)
      icao24: adfedd · position: (21.143, -157.954) · alt: 1783m · 372km/h
  - (2026-07-24) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (38.6252, -1.8806) · alt: 10675m · 707km/h
  - (2026-07-24) PAT143 (United States)
      icao24: adfe4b · position: (43.5742, -116.2548) · alt: 929m · 248km/h
  - (2026-07-24) PAT120 (United States)
      icao24: adfdd0 · position: (35.6079, -79.1215) · alt: 7315m · 519km/h
  - (2026-07-24) CFC515 (Canada)
      icao24: c2b099 · position: (44.0277, -106.3595) · alt: 7048m · 543km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-24) [Russia oil sanctions perimeter · keywords] EU Targets Georgian Oil Refinery Over Russian Crude Processing
      occrp.org · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · keywords] Why the Latest Oil Rally May Be Far From Over
      oilprice.com · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · keywords] EU Targets Russian Shadow Fleet , Banks and Crypto in Sweeping 21st Sanctions Package
      gcaptain.com · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · keywords] EU adopts 21st package of sanctions against Russia
      globalsecurity.org · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · keywords] Foreign Minister Tsahkna : 21st sanctions package keeps the oil price cap painful for Russia and paves the way for a visa ban on combatants
      globalsecurity.org · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · keywords] 21st package of sanctions : EU hits Russian energy , financial services and crypto hard
      globalsecurity.org · English · tone NA

### U.S. Federal Action — 23 new of 32 total
  - (2026-07-24) Amendment of Class D Airspace and Class E Airspace Over Westfield, MA
      This action amends Class D and Class E airspace over Westfield, MA. This action updates the airport name and geographic coordinates in both Westfield, MA Class D and Class E airspace legal descriptions. This action also…
  - (2026-07-24) Establishment of Class E Airspace; Ottawa, IL
      This action proposes to establish Class E airspace at OSF St Francis Medical Center Heliport, Ottawa, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-07-24) Proposed Amendment to the Definition of Huione Group, a Financial Institution Operating Outside the United States of Primary Money Laundering Concern; Extension of Comment Period
      FinCEN is extending the comment period for the referenced notice of proposed rulemaking (NPRM) it published to amend the existing definition of Huione Group to include, within the definition of that group, H-Pay Service…
  - (2026-07-24) Amendment of Class E Airspace; Alma, MI; correction
      This action corrects an NPRM published by the FAA in the Federal Register on July 10, 2026, amending the Class E airspace at Alma, MI. Specifically, this action corrects the title of the document erroneously published as…
  - (2026-07-24) Loan Performance Categories and Financial Reporting
      The Farm Credit Administration (FCA, we, or our) amends our regulatory high-risk loan performance categories by removing "Formally restructured loans (TDR)," also known as troubled debt restructurings. In 2022, changes i…
  - (2026-07-24) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a safety zone on the main branch of the Chicago River between Michigan Avenue Bridge (Mile Marker 326.5) and the Columbus Drive Bridge (Mile Marker 326.7) for the Annual Chicago Ducky Derby m…

### Court opinions of consequence (federal & state) — 21 new of 60 total
  - (2026-07-24) U.S. Court of International Trade: Galvasid S.A. de C.V. v. United States
  - (2026-07-24) Arizona Supreme Court: A & P RANCH LTD v. COCHISE COUNTY
  - (2026-07-24) U.S. Court of Appeals, 11th Cir.: Bay United Holdings, LLC. v. INXS VII, LLC
  - (2026-07-24) U.S. Court of Appeals, 5th Cir.: Students Engaged in Advancing Texas v. Ken Paxton
  - (2026-07-24) Alaska Supreme Court: Darren M. v. Destiny D
  - (2026-07-24) U.S. Court of Appeals, D.C. Cir.: Adsync Technologies, Inc. v. FAA

### USGS earthquakes (M4.5+, past day) — 18 new of 20 total
  - (2026-07-24) M 5.7 - 49 km W of Turangi, New Zealand
      M5.7 · 49 km W of Turangi, New Zealand · depth 10 km
  - (2026-07-24) M 5.4 - 47 km WNW of San Antonio de los Cobres, Argentina
      M5.4 · 47 km WNW of San Antonio de los Cobres, Argentina · depth 197.18 km
  - (2026-07-24) M 5.4 - 202 km W of Abepura, Indonesia
      M5.4 · 202 km W of Abepura, Indonesia · depth 10 km
  - (2026-07-24) M 5.3 - 197 km W of Abepura, Indonesia
      M5.3 · 197 km W of Abepura, Indonesia · depth 10 km
  - (2026-07-24) M 5.1 - 115 km ENE of Ozernovskiy, Russia
      M5.1 · 115 km ENE of Ozernovskiy, Russia · depth 69.804 km
  - (2026-07-24) M 5.1 - 194 km W of Abepura, Indonesia
      M5.1 · 194 km W of Abepura, Indonesia · depth 10 km

### Paper Trading Scorecard — 14 new of 142 total
  - (2026-07-24) [Polymarket] Iran leadership change by June 30, 2027?
      This market will resolve to "Yes" if the Supreme Leader of Iran, Mojtaba Khamenei, ceases to be the de facto leader of Iran at any point between market creation and the listed date (ET). Otherwise, this market will resol…
  - (2026-07-24) [Polymarket] Will Dune: Messiah have the best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses more domestically on its opening weekend than any other movie in 2026. The “Weekend Box Office Performance” table on the page for the relevant mo…
  - (2026-07-24) [Polymarket] Will Bitcoin reach $75,000 by December 31, 2026?
      This market will resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between the creation of this market through 11:59 PM ET on the last day of the year specified in the title has a final "High" price…
  - (2026-07-24) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-24) [Manifold] 2 of the top 5 AI's are open source at eoy 2027? (ECI)
  - (2026-07-24) [Manifold] Will AI contribute novel theorywork to agent foundations before 2028?

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-07-24) LoL: G2 Esports vs Movistar KOI (BO3) - LEC Regular Season
      yes price: 100% · 24h volume: $2,086,038 · resolves 2026-07-24
  - (2026-07-24) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,964,488 · resolves 2026-06-01
  - (2026-07-24) LoL: G2 Esports vs Movistar KOI - Game 2 Winner
      yes price: 100% · 24h volume: $936,453 · resolves 2026-07-24
  - (2026-07-24) Palermo: Alevtina Ibragimova vs Clara Burel
      yes price: 100% · 24h volume: $856,557 · resolves 2026-07-31
  - (2026-07-24) LoL: Team Vitality vs Karmine Corp - Game 2 Winner
      yes price: 0% · 24h volume: $845,309 · resolves 2026-07-25
  - (2026-07-24) Will LeBron James play for the Philadelphia 76ers in 2026-27?
      yes price: 100% · 24h volume: $778,767 · resolves 2026-10-31

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 128 total
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Reg…
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Regulatory Amendments Office o…
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-07-24) [USASpending] $22,440,930,497 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-07-24) [USASpending] $3,055,729,526 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-07-24) [USASpending] $1,605,134,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-24) [USASpending] $1,313,227,200 → SLS FEDERAL SERVICES LLC: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
      Agency: Department of Homeland Security. Description: BORDER WALL CONSTRUCTION FOR TCA-5 TON.

### State Legislative Action — 8 new of 112 total
  - (2026-07-24) [California SB 820] Inmates: mental health.
      Existing law prohibits a person from being tried or adjudged to punishment while that person is mentally incompetent. Existing law establishes a process by which a defendant's mental competency is evaluated. Existing law…
  - (2026-07-24) [California SB 809] Employees and independent contractors: construction trucking.
      (1) Existing law, as established in the case of Dynamex Operations W. v. Superior Court (2018) 4 Cal.5th 903 (Dynamex) , creates a presumption that a worker who performs services for a hirer is an employee for purposes o…
  - (2026-07-24) [Colorado HB 1347] Federal Disability Benefits for Foster Care Youth
      Beginning on or before July 1, 2028, the act extends certain application, accounting, and notice provisions already in place for federal survivor benefits awarded to a child or youth who is in foster care (child or youth…
  - (2026-07-24) [Colorado HB 1349] Funding for Prevention Services Programs Colorado Department of Early Childhood
      The existing nurse home visitor program (program) provides regular in-home visiting nurse services to low-income first-time mothers during their pregnancies and through their children's second birthday. The nurse home vi…
  - (2026-07-24) [Colorado HB 1427] Uniform Antitrust Pre-Merger Notification Update
      The act updates the 'Uniform Antitrust Pre-Merger Notification Act' (act) with amendments to the act adopted by the Uniform Law Commission by:Defining 'Uniform Antitrust Pre-Merger Notification Act' for purposes of the a…
  - (2026-07-24) [Colorado HB 1374] Kinship Care Funding Provisions
      The act eliminates financial assistance and supports and reimbursement to county departments of human or social services (county departments) for non-certified kinship care homes. The act specifies that county department…

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-24) [South Korea] BTS Leader RM Shares the Leadership Lesson That Changed His Perspective
      kpopstarz.com · English
  - (2026-07-24) [South Korea] Biggest turning point in my life : After 22 years , ex - 2NE1 member Sandara Park finally making her own music
      koreatimes.co.kr · English
  - (2026-07-24) [South Korea] Investigators detect evidence Shincheonji sect also forced memberships of DPK
      koreatimes.co.kr · English
  - (2026-07-24) [South Korea] Drones target northern Iraqi city where US forces are based as US - Iran fighting escalates
      koreatimes.co.kr · English
  - (2026-07-24) [South Korea] [ INTERVIEW ] Anua believes K - beauty is replacing French luxury
      koreatimes.co.kr · English
  - (2026-07-24) [South Korea] Defense export boom tests supply chain resilience
      koreatimes.co.kr · English

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-24) [Marginal Revolution] The Decision, the sequel
      Imagine your career were coming to a close, how would you want it to end? By earning an especially large sum of money? Publishing a final wonderful paper? With an amazing act of mentorship? When it comes to Lebron, had h…
  - (2026-07-24) [Marginal Revolution] Friday assorted links
      1. How global was “antiquity”? 2. Why the Clarity Act is mired in muck (NYT). 3. Jim Olds on the new science plan. 4. Cyber capabilities of Kimi 3? 5. “Following a standard workplace safety check, I have just received an…
  - (2026-07-24) [Marginal Revolution] Talk Therapy is Speech
      IJ: On Wednesday, the United States District Court for the District of Columbia struck down a D.C. law that barred therapists from other jurisdictions from doing online teletherapy visits with clients in D.C. The decisio…
  - (2026-07-24) [Conversable Economist] Occupational Licensing: US and International
      The potential benefit of having the government require that certain jobs require an official license is quality control and protection. Personally, I rather like knowing that my nurse or doctor or dentist has gone throug…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-07-24) MOVER ▼ Michael Dell — $237.30B ($-2.51B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-07-24) MOVER ▲ Warren Buffett — $140.66B (+$1.22B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=32, 7d-median=22, 14d-median=21; carrying terms: remove, action, special, period, proposing, regulatory, final, authorized, specifically, amendment, provide, certain
- state_bills: today=112, 7d-median=121, 14d-median=118; carrying terms: providing, comply, place, element, students, eligible, reason, certificate, required, alaska, according, delivery
- state_news: today=984, 7d-median=747, 14d-median=782; carrying terms: article, judges, tribes, homeland, staff, national, needed, circuit, louisiana, afford, fighting, cannot
- local_news: today=250, 7d-median=227, 14d-median=236; carrying terms: stlmag, visit, child, legacy, https, pitch, comes, families, google, afternoon, charged, cbmipafbvv
- foreign_news: today=1057, 7d-median=1024, 14d-median=1030; carrying terms: article, windy, nanjing, competitive, staff, austerity, diplomacy, export, boris, vaskin, civilization, fighting
- chinese_internal: today=313, 7d-median=303, 14d-median=306; carrying terms: https, capital, google, chinese, target, cbmiykfvx, politics, cbmizkfvx, people, cbmiw, cbmiyefvx, cbmiaefvx
- russian_internal: today=1226, 7d-median=982, 14d-median=945; carrying terms: wildberries, journal, error, gazeta, title, found, novayagazeta, forbidden, social, https, istories, netflix
- ukrainian_internal: today=139, 7d-median=128, 14d-median=132; carrying terms: countries, diplomacy, occupied, range, hromadske, september, politician, intensified, strikes, continue, vessels, follows
- ukraine_theater: today=324, 7d-median=443, 14d-median=422; carrying terms: jctexhsu, ykxmmtg, fhbzhsti, delegat, ylhjaljhaew, ntefmuhvjnllrmhlilxpbsq, staff, national, mlzqv, qkjbsmgwwevjqmhnzlk, nnpmm, ymdxyzk
- paper_bets: today=142, 7d-median=143, 14d-median=144; carrying terms: playoff, verve, nomination, african, payable, announces, postponed, republican, receives, statement, earthquake, erupt
- weather: today=193, 7d-median=171, 14d-median=169; carrying terms: unknown, seattle, creek, national, temperatures, boston, information, tropical, located, hazards, pressure, return
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: spread, sheet, labor, growth, implied, crude, balance, rates, payrolls, energy, total, cpilfesl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, range, natural, china, crude, proxy, agriculture, large, rates, bitcoin, russell, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=128, 7d-median=117, 14d-median=118; carrying terms: qjrqy, frequently, rebuilding, davidson, nkhzcm, homeland, oblasts, pmrlfnu, national, convene, contractor, usaspending
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quantitative, httperror, quiver, congresstrading, client, unauthorized, error, https
- billionaires: today=40, 7d-median=40, 14d-median=38; carrying terms: holdings, tesla, london, italy, india, gautam, tokyo, ortega, google, jensen, steve, charles
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, appeals, court, international, trade, supreme, district, children, state, school, delaware, board
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, holdings, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: committee, johnson, senate, trone, disbursements, michael, congress, talarico, lindsey, filing, robert, alexandria
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=25, 7d-median=25, 14d-median=35; carrying terms: english, russia, against, perimeter, russian, sanctions, latest, attacks, world
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=9, 14d-median=9; carrying terms: position, canada, ground, belgium, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: multi, italy, complications, unknown, fourth, circulation, netherlands, circulate, african, cutaneous, countries, unusual
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: access, option, upload, deserialization, missing, command, business, vendor, suite, management, critical, dangerous
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=215, 7d-median=196, 14d-median=180; carrying terms: papua, italy, herzegovina, monaco, honduras, bulgaria, costa, thailand, liechtenstein, agricultural, madagascar, nicaragua
- usgs_quakes: today=20, 7d-median=18, 14d-median=19; carrying terms: depth, puerto, indonesia, islands, mexico, ridge, south, madero, abepura, region, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, price, rates, prime, volume, meeting, resolves, ethiopia, interest, change, strait, hormuz
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: perhaps, marginal, economist, class, https, conversable, revolution, useful, marginalrevolution, paper, links, assorted
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: unknown, information, hackers, infrastructure, giant, malware, world, encryption, technica, built, breach, international
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: fletcher, frank, davidson, derek, goodlander, frost, moulton, cramer, elfreth, schneider, marco, homeland
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, paper, converges, claude, evidence, consensus, module, sufficient, placement, identify, either, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*