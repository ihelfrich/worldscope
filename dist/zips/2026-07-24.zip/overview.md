# WORLDSCOPE morning brief — 2026-07-24

## Headline
2271 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (549) · Russian Internal News (state + in-exile) (479) · World leaders & government officials (324) · Chinese Internal News (199) · U.S. Weather + Severe / Climate Outlooks (144) · State Legislative Action (130) · State-Level News (69) · Local News: St. Louis + Atlanta (66) · GDELT GKG — themes / entities / watch areas (43) · Ukraine Theater (total-war monitoring) (41) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (38)

## What changed today
### International News + Multilateral Institutions — 549 new of 1045 total
  - (2026-07-24) [Global] France orders evacuation of tourist spot as hundreds flee wildfires by boat
      The fire has raged in the region for several days with officials now ordering the evacuation of the entire Cap Ferret peninsula.
  - (2026-07-24) [Global] US hits dozens of countries with new wave of tariffs
      Imposed citing forced labour concerns, the levies replace a temporary global duty brought in after the US Supreme Court struck down tariffs in February.
  - (2026-07-23) [Global] Indonesian babies were trafficked to Singapore. What happens to them now?
      At least 12 babies have been trafficked from Indonesia to Singapore, but what will happen to them remains unclear.
  - (2026-07-24) [Global] Tech titan ordered to pay ex-wife $644m in divorce settlement
      The divorce, involving the chairman of one of South Korea's biggest companies, has gripped the nation.
  - (2026-07-24) [Global] India's 'cockroach' protesters and government to hold talks as stalemate continues
      The meeting comes hours after activist Sonam Wangchuk announced he was ending his 26-day hunger strike.
  - (2026-07-23) [Global] CJP protest: The youth movement India's Modi didn't see coming
      The CJP protest began with exam paper leaks. It became India's biggest student movement in years - why?

### Russian Internal News (state + in-exile) — 479 new of 1100 total
  - (2026-07-24) «Золотая корона» прекратила переводы в Грузию, а «Цифра банк» — в Казахстан | LEDE: Система денежных переводов «Золотая Корона» отключила возможность переводить деньги в Грузию, сообщает «Ко] (ru: «Зо…
      Система денежных переводов «Золотая Корона» отключила возможность переводить деньги в Грузию, сообщает «Код Дурова».
  - (2026-07-24) Жительницу Краснодара задержали за публикацию видео пожара на складе Wildberries после атаки украинских дронов | LEDE: Полиция задержала 19-летнюю жительницу Краснодара, которая, по версии в] (ru: Жит…
      Полиция задержала 19-летнюю жительницу Краснодара, которая, по версии ведомства, записала на видео пожар на складе Wildberries после удара украинских беспилотников 22 июля.
  - (2026-07-24) После ударов ВСУ по складам Wildberries работники жаловались на плохо организованную эвакуацию. А как она должна быть устроена на подобных объектах? Инструкция, полезная не только сотрудникам с] (ru:…
      После того как украинские дроны атаковали склады Wildberries в Подмосковье и Тамбовской области, работники компании сообщали, что при эвакуации были серьезные задержки. За следующие несколько дней ВСУ нанесли удары еще п…
  - (2026-07-24) В Петербурге и Ленинградской области горят склады Wildberries. Украинские военные нанесли новые удары по логистическим центрам компании. Фото и видео | LEDE: Украинские военные в ночь на 24 ] (ru: В П…
      Украинские военные в ночь на 24 июля вновь атаковали дронами склады российского маркетплейса Wildberries — четвертый раз за неделю. Удары нанесли по складам в Шушарах (Петербург) и промышленной зоне «Уткина заводь» (Лени…
  - (2026-07-24) ФСБ заявила, что задержала в Москве подозреваемую в работе на разведку Украины. Ее обвинили в попытке подорвать машину силовика | LEDE: Сотрудники ФСБ задержали в Москве россиянку 1996 года ] (ru: ФСБ…
      Сотрудники ФСБ задержали в Москве россиянку 1996 года рождения, подозреваемую в том, что она пыталась подорвать автомобиль сотрудника органов безопасности по заданию украинской разведки, заявили в Центре общественных свя…
  - (2026-07-24) Россия запретила ввоз молочной продукции из Армении | LEDE: Россельхознадзор с 27 июля 2026 года вводит ограничения на ввоз в Россию молочной продукции из Армении. ] (ru: Россия запретила ввоз молочно…
      Россельхознадзор с 27 июля 2026 года вводит ограничения на ввоз в Россию молочной продукции из Армении.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 199 new of 298 total
  - (2026-07-23) 韩国电竞明星Faker获封“警长” 名誉警衔兼任反网赌宣传大使 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1PcEk4dmQtV0ppUmNSb0g0RGN0Z3EtUmFVQTFxbUdBZ0NmOUxheU0zcGNPRzJBYUYzQ01jbDREQVNGS216RGZVRG] (zh:…
      韩国电竞明星Faker获封“警长” 名誉警衔兼任反网赌宣传大使 财新
  - (2026-07-24) 今日开盘：两市双双低开 沪指跌幅0.60% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBwSTQtSXF6WURFeGh4aG1rMXNpRXdWTE1zSmROLWNsR1B4Z2dPRFJxQkNsaS1obmpFYWUxeDg0NUNYSWh1Zkk3SXZqbi1uaXM5] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.60% 财新
  - (2026-07-24) 米琴：美国大片《奥德赛》的灵感来源 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBMYjhHVjdMcURRaUJ5UUVpT0dkLUp3aGgzdW1kZmpLd1pvSDRtWHMzM3R2dXN3WmtfZWpWbjRoa1gyTUtfMzJwdUgycXJLaFgxdXg3] (zh:…
      米琴：美国大片《奥德赛》的灵感来源 财新
  - (2026-07-24) 邓煜、王虹两位中国数学家首获菲尔兹奖 实现历史突破 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5ERlRvTF9nbk1LRWllZU1XcXZ6VnNQd2xvU3VuV3ZjYzI5c3VMalFQYlg0Tk5RLWw1MURwTDZXVHFFaGdPV1BObElqTnVW] (zh:…
      邓煜、王虹两位中国数学家首获菲尔兹奖 实现历史突破 财新
  - (2026-07-24) 三家银行在海南试水贷款利率定价“新锚” 为何用DR？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5rbmc5VHVqZG9Temx5WFpfeU10UUo5SWRxRzRtQ29WWjlNVTkwWW9kaE1fQlM1dl9LREE2ZjNEOHo0TU5kYXBfb2phTXA] (zh:…
      三家银行在海南试水贷款利率定价“新锚” 为何用DR？ 财新
  - (2026-07-24) 吉利汽车收购福特西班牙工厂34%股权 双方将合作开发新能源车型 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5VSXhaRXVhOXZFV1c1RVJWSUtXcnFYeElPSTBDeHhTYmhiYnN4X1hKTExhTFpGSTRlb0tiWGNHMkl6dUVvZ3NpRH] (zh:…
      吉利汽车收购福特西班牙工厂34%股权 双方将合作开发新能源车型 财新

### U.S. Weather + Severe / Climate Outlooks — 144 new of 158 total
  - (2026-07-24) [Severe] Special Marine Warning: Special Marine Warning issued July 24 at 5:29AM EDT until July 24 at 6:00AM EDT by NWS Wilmington NC
      SMWILM The National Weather Service in Wilmington has issued a * Special Marine Warning for... Coastal waters from Surf City to Cape Fear NC out 20 nm... Waters from Surf City NC to Little River Inlet SC from 20 to 60 NM…
  - (2026-07-24) [Severe] Flood Watch: Flood Watch issued July 24 at 4:28AM CDT until July 24 at 7:00PM CDT by NWS Huntsville AL
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of Alabama, including the following areas, Cullman, DeKalb, Jackson, Madison, Marshall and Morgan and southern middle Tenn…
  - (2026-07-24) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-24) [Moderate] Special Weather Statement: Special Weather Statement issued July 24 at 3:24AM MDT by NWS Billings MT
      At 324 AM MDT, Doppler radar was tracking a line of strong thunderstorms extending from 22 miles north of Roundup to 12 miles north of Joliet, moving east at 40 mph. HAZARD...Wind gusts of 40 to 55 mph. SOURCE...Radar in…
  - (2026-07-24) [Severe] Flood Warning: Flood Warning issued July 24 at 4:23AM CDT until July 25 at 2:00AM CDT by NWS Topeka KS
      ...The National Weather Service in Topeka has issued a Flood Warning for the following rivers in Kansas... Salt Creek near Ada affecting Ottawa County. * WHAT...Minor flooding is forecast. * WHERE...Salt Creek near Ada.…
  - (2026-07-24) [Moderate] Rip Current Statement: Rip Current Statement issued July 24 at 4:19AM CDT until July 24 at 6:00PM CDT by NWS Mobile AL
      * WHAT...Dangerous rip currents. * WHERE...In Alabama, Mobile Coastal and Baldwin Coastal Counties. In Florida, Escambia Coastal, Santa Rosa Coastal and Okaloosa Coastal Counties. * WHEN...Through this afternoon. * IMPAC…

### State Legislative Action — 130 new of 236 total
  - (2026-07-24) [Colorado HB 1298] Background Checks for Child Welfare Placements
      The act gives county departments of human or social services and the Colorado department of human services (department) the statutory authority needed to conduct the required fingerprint-based criminal history record che…
  - (2026-07-24) [Louisiana SB 484] COLLEGES/UNIVERSITIES: Transfers certain duties from the Board of Regents to the management boards of public colleges and universities and Louisiana Works. (8/1/26)
      COLLEGES/UNIVERSITIES: Transfers certain duties from the Board of Regents to the management boards of public colleges and universities and Louisiana Works. (8/1/26)
  - (2026-07-24) [Louisiana SB 450] SCHOOLS: Requires mandatory reporting of school threats and provides for physical security school assessments for K-12 schools. (8/1/26) (EN SEE FISC NOTE GF EX)
      SCHOOLS: Requires mandatory reporting of school threats and provides for physical security school assessments for K-12 schools. (8/1/26) (EN SEE FISC NOTE GF EX)
  - (2026-07-24) [Louisiana SB 482] SCHOOLS: Provides for career coaches to assist public middle and high school students and their parents in developing an individualized graduation plan for each student. (8/1/26)
      SCHOOLS: Provides for career coaches to assist public middle and high school students and their parents in developing an individualized graduation plan for each student. (8/1/26)
  - (2026-07-24) [Louisiana SB 488] SCHOOLS: Creates the School Safety Drone Response Pilot Program to supplement school crisis management and response plans. (8/1/26) (EN SEE FISC NOTE GF EX)
      SCHOOLS: Creates the School Safety Drone Response Pilot Program to supplement school crisis management and response plans. (8/1/26) (EN SEE FISC NOTE GF EX)
  - (2026-07-24) [Louisiana SB 441] STUDENTS: Provides relative to programs for prekindergarten-aged children. (gov sig) (EN -$6,530 GF RV See Note)
      STUDENTS: Provides relative to programs for prekindergarten-aged children. (gov sig) (EN -$6,530 GF RV See Note)

### State-Level News — 69 new of 817 total
  - (2026-07-24) [Connecticut] Larson, Bronin waging an ad war in waning weeks before primary
      <img width="1024" height="831" src="https://ctmirror.org/wp-content/uploads/2026/03/5C565132-17A4-4CAE-A8C9-A0BCD07C6412-1024x831.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="…
  - (2026-07-24) [Connecticut] Without Olmstead rule protection, God help the disabled
      <img width="775" height="451" src="https://ctmirror.org/wp-content/uploads/2026/07/I-am-olmstead.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="htt…
  - (2026-07-24) [Connecticut] Congress has given states new housing tools. CT is ready to make them work
      <img width="600" height="336" src="https://ctmirror.org/wp-content/uploads/2026/06/Housing-image-copy.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset…
  - (2026-07-24) [Arizona] Doctors warn Andy Biggs’ record on healthcare, abortion should alarm Arizona voters
      Arizona doctors and progressive organizations are warning voters that Republican gubernatorial nominee Andy Biggs has a long record as an elected official of attacking access to healthcare and abortion care. Biggs will f…
  - (2026-07-24) [Arizona] Cyclosporiasis outbreak surges to over 4,173 confirmed cases
      The number of cases of cyclosporiasis — a parasitic infection linked to contaminated water or food that causes severe intestinal issues — has more than doubled to over 4,173 cases across 41 states this week, up from the…
  - (2026-07-24) [Arizona] Mayes tells federal court it’s too early to block Prop. 314, says no one has been arrested yet
      Arizona Attorney General Kris Mayes says it’s too soon for a lawsuit to be filed against a 2024 law that would allow local police officers to arrest unauthorized immigrants because no one has been arrested under it yet.…

### Local News: St. Louis + Atlanta — 66 new of 250 total
  - (2026-07-24) [St. Louis] Explosions are heard near a US base in northern Iraq after US strikes Iran
      An Associated Press journalist heard at least seven blasts Friday morning local time in the city of Irbil, the capital of Iraq’s semi-autonomous Kurdish region.
  - (2026-07-24) [St. Louis] Kenmore Air floatplane with 11 on board catches fire after emergency landing in Washington's San Juan Islands
      All 11 people on board of a Kenmore Air floatplane that crashed in the San Juan Islands are alive, according to the company.
  - (2026-07-24) [St. Louis] Tropical Storm Bertha weakens after bringing strong winds and heavy surf to Louisiana and Texas
      The storm is unlikely to leave behind widespread damage as the heaviest rains are staying offshore.
  - (2026-07-24) [St. Louis] Two St. Louis aldermen urge school board to postpone vote on 'Future Ready' plan
      Resolution 78 calls for increased transparency, community engagement, and alignment with previously adopted citywide educational plans.
  - (2026-07-24) [St. Louis] Sweetgreen addresses customer concerns amid cyclospora outbreak
      Sweetgreen addressed concerns on Wednesday night confirming that it has not been associated with the current cyclospora outbreak.
  - (2026-07-24) [St. Louis] Gateway Pet Guardians looking for volunteers after 20 dogs rescued in St. Clair County hoarding case
      The dogs are now under the care of Gateway Pet Guardians as St. Clair County Animal Services removed 90 animals from a property.

### GDELT GKG — themes / entities / watch areas — 43 new of 43 total
  - (2026-07-24) [Israel-Iran-Hezbollah axis · themes] صحيفة المنار - البترول يعود إلى صدارة الاحتقان في الضفة الغربية
      manar.com · Arabic · tone NA
  - (2026-07-24) [Israel-Iran-Hezbollah axis · themes] SALUT | El CAP de Castelló dEmpúries consolida les activitats de rem , vela i passejades pels Aiguamolls com a eines de salut
      emporda.info · Catalan · tone NA
  - (2026-07-24) [Israel-Iran-Hezbollah axis · themes] Laura Loomer meets with Zelenskyy in Ukraine after her major reversal on the war
      nbcnews.com · English · tone NA
  - (2026-07-24) [Israel-Iran-Hezbollah axis · themes] Alpinistas desaparecidos : Por que escalar o Huascarán está se tornando cada vez mais perigoso ?
      oglobo.globo.com · Portuguese · tone NA
  - (2026-07-24) [Israel-Iran-Hezbollah axis · themes] Former Corrie star Tracy Shaw heartbreaking cancer update
      wimbledonguardian.co.uk · English · tone NA
  - (2026-07-24) [Israel-Iran-Hezbollah axis · themes] Villa Erba , doppia magia con Mannarino e Angelica Bove
      ciaocomo.it · Italian · tone NA

### Ukraine Theater (total-war monitoring) — 41 new of 290 total
  - (2026-07-24) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-24) [Liveuamap] Fire as result of drone strike in St.Petersburg - Liveuamap
      Fire as result of drone strike in St.Petersburg Liveuamap
  - (2026-07-22) [Liveuamap] Israeli Broadcasting Authority: Washington will carry out airstrikes on Iran in the coming days using heavy bombers. - Liveuamap
      Israeli Broadcasting Authority: Washington will carry out airstrikes on Iran in the coming days using heavy bombers. &nb
  - (2026-07-22) [Liveuamap] The continued operation of US air defenses at bases in Erbil province - iraq.liveuamap.com
      The continued operation of US air defenses at bases in Erbil province iraq.liveuamap.c
  - (2026-07-22) [Liveuamap] The European Union: Operation Aspidis remains fully committed to protecting freedom of navigation in the Red Sea. - Liveuamap
      The European Union: Operation Aspidis remains fully committed to protecting freedom of navigation in the Red Sea.
  - (2026-07-19) [Liveuamap] Explosion in the vicinity of the Sana'ye (Electronic Industries Complex) of Shiraz Fars Province, Iran - Liveuamap
      Explosion in the vicinity of the Sana'ye (Electronic Industries Complex) of Shiraz Fars Province, Iran &nbs

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-24) [Vanderhook Timothy] Form 4 (Reporting)
      filed 2026-07-24 01:54 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001843103-26-000014 Size: 16 KB
  - (2026-07-24) [Viant Technology Inc.] Form 4 (Issuer)
      filed 2026-07-24 01:54 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001843103-26-000014 Size: 16 KB
  - (2026-07-24) [Vanderhook Christopher] Form 4 (Reporting)
      filed 2026-07-24 01:54 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001843104-26-000014 Size: 16 KB
  - (2026-07-24) [Viant Technology Inc.] Form 4 (Issuer)
      filed 2026-07-24 01:54 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001843104-26-000014 Size: 16 KB
  - (2026-07-24) [Capital V LLC] Form 4 (Reporting)
      filed 2026-07-24 01:53 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001844767-26-000012 Size: 15 KB
  - (2026-07-24) [Viant Technology Inc.] Form 4 (Issuer)
      filed 2026-07-24 01:53 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001844767-26-000012 Size: 15 KB

### Ukrainian Internal News (national + local Kyiv) — 38 new of 120 total
  - (2026-07-24) Росіяни розстріляли полоненого українського бійця після допиту | LEDE: Прокуратура розслідує черговий злочин окупантів – розстріл українського військовополоненого на Донеччині.] (uk: Росіяни розстріля…
      Прокуратура розслідує черговий злочин окупантів – розстріл українського військовополоненого на Донеччині.
  - (2026-07-24) F-16 збив безпілотник, який залетів на територію Румунії | LEDE: Румунський винищувач F-16 24 липня збив безпілотник, який порушив повітряний простір країни.] (uk: F-16 збив безпілотник, який залетів…
      Румунський винищувач F-16 24 липня збив безпілотник, який порушив повітряний простір країни.
  - (2026-07-24) Росія потрапила до списку країн, щодо яких США ввели нові мита | LEDE: США ввели нові мита щодо 60 торговельних партнерів, у список яких, зокрема, потрапила й Росія.] (uk: Росія потрапила до списку кр…
      США ввели нові мита щодо 60 торговельних партнерів, у список яких, зокрема, потрапила й Росія.
  - (2026-07-24) Глава МЗС Литви розкритикував поступки в останньому пакеті санкцій ЄС проти Росії | LEDE: Міністр закордонних справ Литви Кястутіс Будріс розкритикував поступки, зроблені державам-членам в рамк] (uk:…
      Міністр закордонних справ Литви Кястутіс Будріс розкритикував поступки, зроблені державам-членам в рамках переговорів щодо останнього пакета санкцій Європейського Союзу проти Росії.
  - (2026-07-24) Затримали підозрювану, яка намагалась передати на блокпост вибухівку, замасковану під бургер із McDonald's | LEDE: На Чернігівщині Нацполіція спільно з СБУ та прокуратурою затримали особу, яка ] (uk:…
      На Чернігівщині Нацполіція спільно з СБУ та прокуратурою затримали особу, яка на одному із блокпостів у Чернігові намагалася передати військовослужбовцям саморобну вибухівку, замасковану під бургер із McDonald's.
  - (2026-07-24) Армія РФ вдарила по цивільній інфраструктурі Одеси: є постраждалий | LEDE: Внаслідок російської атаки на Одесу пошкоджено цивільну інфраструктуру та меблевий магазин. За попередніми даними, одн] (uk:…
      Внаслідок російської атаки на Одесу пошкоджено цивільну інфраструктуру та меблевий магазин. За попередніми даними, одна людина постраждала.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 28 total
  - (2026-07-24) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (48.7252, 2.3557) · on ground
  - (2026-07-24) SAMU49 (France)
      icao24: 39ca81 · position: (47.3274, -1.2703) · alt: 396m · 216km/h
  - (2026-07-24) PUMA52 (Slovenia)
      icao24: 506e19 · position: (45.8477, 15.2155) · alt: 1554m · 173km/h
  - (2026-07-24) SAMU59 (France)
      icao24: 39b5d1 · position: (50.8037, 2.3471) · alt: 556m · 247km/h
  - (2026-07-24) JAF97T (Belgium)
      icao24: 44d1ba · position: (45.8284, 12.7586) · alt: 12192m · 695km/h
  - (2026-07-24) JAF66L (Belgium)
      icao24: 44d1a6 · position: (50.8325, 3.9465) · alt: 3931m · 695km/h

### U.S. Federal Action — 23 new of 32 total
  - (2026-07-24) Amendment of Class D Airspace and Class E Airspace Over Westfield, MA
      This action amends Class D and Class E airspace over Westfield, MA. This action updates the airport name and geographic coordinates in both Westfield, MA Class D and Class E airspace legal descriptions. This action also…
  - (2026-07-24) Establishment of Class E Airspace; Ottawa, IL
      This action proposes to establish Class E airspace at OSF St Francis Medical Center Heliport, Ottawa, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-07-24) Proposed Amendment to the Definition of Huione Group, a Financial Institution Operating Outside the United States of Primary Money Laundering Concern; Extension of Comment Period
      FinCEN is extending the comment period for the referenced notice of proposed rulemaking (NPRM) it published to amend the existing definition of Huione Group to include, within the definition of that group, H-Pay Service…
  - (2026-07-24) Amendment of Class E Airspace; Alma, MI; correction
      This action corrects an NPRM published by the FAA in the Federal Register on July 10, 2026, amending the Class E airspace at Alma, MI. Specifically, this action corrects the title of the document erroneously published as…
  - (2026-07-24) Loan Performance Categories and Financial Reporting
      The Farm Credit Administration (FCA, we, or our) amends our regulatory high-risk loan performance categories by removing "Formally restructured loans (TDR)," also known as troubled debt restructurings. In 2022, changes i…
  - (2026-07-24) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a safety zone on the main branch of the Chicago River between Michigan Avenue Bridge (Mile Marker 326.5) and the Columbus Drive Bridge (Mile Marker 326.7) for the Annual Chicago Ducky Derby m…

### IT, InfoSys & cybersecurity news (last 7 days) — 13 new of 57 total
  - (2026-07-24) [BleepingComputer] Clop ransomware targets Windchill, FlexPLM in data theft attacks
      The Clop ransomware gang (also tracked as Cl0p) is targeting Internet-exposed PTC Windchill and FlexPLM instances in a new data theft extortion campaign. [...]
  - (2026-07-24) [The Hacker News] NodeBB Patches Eight AI-Found Flaws Exposing Admin Access and Private Chats
      Eight security flaws in NodeBB went public on Wednesday, along with the code to exploit them. Aikido Security rates all eight as high severity and says its AI pentest agents found them in a six-hour review of the forum s…
  - (2026-07-24) [The Hacker News] Kimi K3 Agents Found Redis Zero-Days and Built RCE Exploit, Researchers Say
      Redis shipped seven security releases on July 23 after researchers published authenticated RCE PoCs for stock Redis 6.2.22, 7.4.9, 8.6.4, and 8.8.0. All four chains require RESTORE. The Streams chains also need EVAL and…
  - (2026-07-24) [The Hacker News] Fake Notepad++ Plugin Delivers MATCHBOIL.V2 in UAC-0099 Attacks
      The Computer Emergency Response Team of Ukraine (CERT-UA) has warned of a new campaign that involves the use of a malicious program that's dressed up as a Notepad++ plugin to compromise Windows systems. The activity has…
  - (2026-07-24) [The Register] Burnham wants Big Ecommerce to bankroll Britain's pubs
      Online marketplaces could find themselves buying the next round as the PM looks to tax ecommerce to save the local
  - (2026-07-24) [The Register] Google meets the neighbors and gets both barrels over its new UK datacenter
      The Reg was there as locals aired grievances over poor communication, noise, and light pollution at Waltham Cross facility

### Paper Trading Scorecard — 12 new of 149 total
  - (2026-07-24) [Polymarket] Will John N. Kennedy win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-07-24) [Polymarket] Will there be between 0 and 20 average daily transits of the Strait of Hormuz on July 31?
      This market will resolve according to the finalized 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for July 31, 2026. If the reported value falls exactly b…
  - (2026-07-24) [Polymarket] Will Dune: Messiah have the best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses more domestically on its opening weekend than any other movie in 2026. The “Weekend Box Office Performance” table on the page for the relevant mo…
  - (2026-07-24) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-24) [Polymarket] Will Baker Mayfield win the 2026 NFL MVP?
      This market will resolve to the player who wins the 2026 NFL Most Valuable Player award for the 2026-27 NFL season. In the event of a tie, this market will resolve according to the official winner as determined by NFL ru…
  - (2026-07-24) [Polymarket] Will MetaMask launch a token by September 30, 2026?
      This market will resolve to "Yes" if Metamask officially launches a token by September 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". The token must be actively and publicly transferable and tradable…

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-24) LoL: Anyone's Legend vs LGD Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $784,041 · resolves 2026-07-24
  - (2026-07-24) LoL: Anyone's Legend vs LGD Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $615,406 · resolves 2026-07-24
  - (2026-07-24) LoL: Anyone's Legend vs LGD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $593,911 · resolves 2026-07-24
  - (2026-07-24) LoL: Team WE vs JD Gaming - Game 1 Winner
      yes price: 44% · 24h volume: $449,234 · resolves 2026-07-24
  - (2026-07-24) Will U.S. viewership of the 2026 FIFA World Cup Final be between 46 million and 50 million?
      yes price: 100% · 24h volume: $410,327 · resolves 2026-07-19
  - (2026-07-24) Kharg Island no longer under Iranian control by July 31?
      yes price: 3% · 24h volume: $266,211 · resolves 2026-06-30

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 126 total
  - (2026-07-24) [USASpending] $22,440,930,497 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-07-24) [USASpending] $3,055,729,526 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-07-24) [USASpending] $1,605,134,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-24) [USASpending] $1,313,227,200 → SLS FEDERAL SERVICES LLC: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
      Agency: Department of Homeland Security. Description: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
  - (2026-07-24) [USASpending] $1,036,291,804 → L3HARRIS TECHNOLOGIES, INC.: TAS::80 0122::TAS DEVELOPMENT, MANUFACTURING AND SUPPORT TO
      Agency: National Aeronautics and Space Administration. Description: TAS::80 0122::TAS DEVELOPMENT, MANUFACTURING AND SUPPORT TO WEATHER OBSERVING INSTRUMENT
  - (2026-07-24) [USASpending] $1,027,192,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### GDACS — global disaster alerts — 7 new of 243 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 10090 ha
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 10090 ha
  - (2026-07-22) [Green] Forest fires in France
      Wildfire · Green alert · France · Green impact for forestfire in 12807 ha

### USGS earthquakes (M4.5+, past day) — 7 new of 18 total
  - (2026-07-24) M 5.0 - 94 km SSE of Adak, Alaska
      M5.0 · 94 km SSE of Adak, Alaska · depth 10 km
  - (2026-07-24) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 35 km
  - (2026-07-24) M 4.8 - Mid-Indian Ridge
      M4.8 · Mid-Indian Ridge · depth 10 km
  - (2026-07-24) M 4.8 - 59 km NNW of San Antonio, Puerto Rico
      M4.8 · 59 km NNW of San Antonio, Puerto Rico · depth 10 km
  - (2026-07-23) M 4.7 - 56 km NW of Santa Domenica, Italy
      M4.7 · 56 km NW of Santa Domenica, Italy · depth 243.071 km
  - (2026-07-23) M 4.7 - southwest of Sumatra, Indonesia
      M4.7 · southwest of Sumatra, Indonesia · depth 10 km

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-07-23) U.S. Court of Appeals, 1st Cir.: Rana v. Blanche
  - (2026-07-22) Hawaii Supreme Court: Maui Tomorrow Foundation v. Maui Planning Commission
  - (2026-07-21) Florida Supreme Court: Dominick A. Occhicone v. State of Florida
  - (2026-07-21) Hawaii Supreme Court: State v. Dela Cruz
  - (2026-07-21) Hawaii Supreme Court: State v. Pavich
  - (2026-07-21) U.S. Court of Appeals, 1st Cir.: Recchia v. Campbell

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 34 total
  - (2026-07-24) MOVER ▲ Francoise Bettencourt Meyers & family — $91.43B (+$0.27B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-24) MOVER ▲ Amancio Ortega — $136.97B (+$0.13B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-24) MOVER ▼ Mukesh Ambani — $86.41B ($-0.08B since yesterday)
      India · Diversified · source: Diversified

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-24) [Marginal Revolution] The optimal Bayesian update?
      I see at least three updates one might make from the recent OAI/Hugging Face hacking incident: 1. “This happened sooner than I expected, and the story is more dramatic than I expected,” therefore I am more worried than b…
  - (2026-07-24) [Marginal Revolution] What I’ve been reading
      1. Christopher Priest and Nina Allan, The Illuminated Man: Life, Death and the Worlds of J.G. Ballard. Priest died before he finished this book, and his widow added material, including on Priest himself. This is in any c…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=32, 7d-median=22, 14d-median=21; carrying terms: public, remove, unless, certain, service, regulatory, proposing, action, period, authorized, final, published
- state_bills: today=236, 7d-median=124, 14d-median=122; carrying terms: selling, reasonable, energy, infrastructure, generally, current, training, teacher, family, actions, common, charter
- state_news: today=817, 7d-median=747, 14d-median=782; carrying terms: energy, infrastructure, quarter, training, months, family, common, figure, prices, ballots, climate, louisiana
- local_news: today=250, 7d-median=227, 14d-median=236; carrying terms: months, family, figure, blank, charges, height, crash, another, loading, hours, uploads, woman
- foreign_news: today=1045, 7d-median=1024, 14d-median=1030; carrying terms: selling, infrastructure, quarter, bilateral, months, named, india, xianghe, figure, prices, model, resignation
- chinese_internal: today=298, 7d-median=299, 14d-median=301; carrying terms: blank, chinese, cbmiw, https, lxtfa, cbmibefvx, capital, china, target, cbmiy, lxtfb, cbmixkfvx
- russian_internal: today=1100, 7d-median=982, 14d-median=945; carrying terms: found, russian, istories, client, apple, gazeta, novaya, media, google, laquo, financial, forbidden
- ukrainian_internal: today=120, 7d-median=125, 14d-median=126; carrying terms: energy, infrastructure, client, region, linked, fighter, against, resigned, support, sparked, broke, emergency
- ukraine_theater: today=290, 7d-median=443, 14d-median=422; carrying terms: zvsdrfovjpy, beeuxsnozvxftodzhewq, qzdkc, quarter, governorate, training, jtywo, prmxr, swvnrvaxtdz, ykxmmtg, cbmimwfbvv, xsfhntktxmhy
- paper_bets: today=149, 7d-median=144, 14d-median=144; carrying terms: netanyahu, payable, current, rippling, named, kansas, season, mamdani, india, earthquake, roberto, valid
- weather: today=158, 7d-median=167, 14d-median=166; carrying terms: afddtx, river, counties, inches, current, afdmeg, region, ongoing, impacted, hazards, northwestern, miami
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, energy, payrolls, walcl, labor, sheet, dexchus, dcoilwtico, spread, indicator, jolts, consumption
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, large, crude, russell, credit, commodities, silver, crypto, range, china, natural, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=126, 7d-median=117, 14d-median=118; carrying terms: tdrcrzjkow, energy, haitian, extra, bilateral, region, fridays, resolutions, actions, xskhmowz, against, program
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, congresstrading, error, client, https, quantitative, quiver, unauthorized, quiverquant
- billionaires: today=34, 7d-median=36, 14d-median=35; carrying terms: finance, ellison, spain, microsoft, masayoshi, facebook, infrastructure, francoise, gcarsoa, spacex, changpeng, giancarlo
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, trade, insurance, charles, district, appeals, children, supreme, international, court, blanche, america
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, amended, holdings, michael, capital
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jonathan, shawn, michael, graham, johnson, political, congress, warner, angels, disbursements, cycle, raised
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, japanherald
- gdelt_gkg: today=43, 7d-median=43, 14d-median=44; carrying terms: hezbollah, israel, english, spanish, chinese, themes, russian, arabic, german, italian, strike
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=28, 7d-median=9, 14d-median=9; carrying terms: position, belgium, ground, kingdom, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: kasai, spain, divisions, affecting, public, current, poliovirus, south, positivity, region, linked, infections
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: management, granularity, improper, microsoft, suite, cross, association, authentication, protocol, privilege, option, untrusted
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=243, 7d-median=196, 14d-median=180; carrying terms: spain, agricultural, panama, maximum, macedonia, canada, cambodia, depth, alert, papua, australia, ecuador
- usgs_quakes: today=18, 7d-median=18, 14d-median=18; carrying terms: puerto, depth, islands, indonesia, mexico, ridge, south, madero, region, abepura, northern
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, volume, interest, prime, meeting, rates, resolves, price, ethiopia, mekonnen, change, demeke
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, class, interview, conversable, marginal, caught, effects, useful, revolution, interlocutor, https, perhaps
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: microsoft, infrastructure, current, months, against, program, hacker, research, fields, almost, unknown, information
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: nchez, schrier, energy, marilyn, sonderling, higgins, castro, thompson, george, elena, gillibrand, doris
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, evidence, unavailable, consensus, decision, placed, either, claude, markets, converges, market, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-21] ECB press: ECB appoints Boris Kisselevsky as Director General Secretariat
- [2026-07-23] ECB press: Monetary policy decisions
- [2026-07-23] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*