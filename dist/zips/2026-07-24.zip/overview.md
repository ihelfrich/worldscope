# WORLDSCOPE morning brief — 2026-07-24

## Headline
2179 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (542) · Russian Internal News (state + in-exile) (462) · World leaders & government officials (324) · Chinese Internal News (198) · U.S. Weather + Severe / Climate Outlooks (141) · State-Level News (64) · State Legislative Action (60) · Local News: St. Louis + Atlanta (51) · Ukraine Theater (total-war monitoring) (41) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (37)

## What changed today
### International News + Multilateral Institutions — 542 new of 1045 total
  - (2026-07-24) [Global] France orders evacuation of tourist spot as hundreds flee wildfires by boat
      The fire has raged in the region for several days with officials now ordering the evacuation of the entire Cap Ferret peninsula.
  - (2026-07-24) [Global] US hits dozens of countries with new wave of tariffs
      Imposed citing forced labour concerns, the levies replace a temporary global duty brought in after the US Supreme Court struck down tariffs in February.
  - (2026-07-23) [Global] Indonesian babies were trafficked to Singapore. What happens to them now?
      At least 12 babies have been trafficked from Indonesia to Singapore, but what will happen to them remains unclear.
  - (2026-07-24) [Global] Tech titan ordered to pay ex-wife $644m in divorce settlement
      The divorce, involving the chairman of one of South Korea's biggest companies, has gripped the nation.
  - (2026-07-24) [Global] India's 'cockroach' protesters and government to hold talks as stalemate continues
      The meeting comes hours after activist Sonam Wangchuk announced he was ending his 26-day hunger strike.
  - (2026-07-23) [Global] CJP protest: The youth movement India's Modi didn't see coming
      The CJP protest began with exam paper leaks. It became India's biggest student movement in years - why?

### Russian Internal News (state + in-exile) — 462 new of 1096 total
  - (2026-07-24) После ударов ВСУ по складам Wildberries работники жаловались на плохо организованную эвакуацию. А как она должна быть устроена на подобных объектах? Инструкция, полезная не только сотрудникам с] (ru:…
      После того как украинские дроны атаковали склады Wildberries в Подмосковье и Тамбовской области, работники компании сообщали, что при эвакуации были серьезные задержки. За следующие несколько дней ВСУ нанесли удары еще п…
  - (2026-07-24) В Петербурге и Ленинградской области горят склады Wildberries. Украинские военные нанесли новые удары по логистическим центрам компании. Фото и видео | LEDE: Украинские военные в ночь на 24 ] (ru: В П…
      Украинские военные в ночь на 24 июля вновь атаковали дронами склады российского маркетплейса Wildberries — четвертый раз за неделю. Удары нанесли по складам в Шушарах (Петербург) и промышленной зоне «Уткина заводь» (Лени…
  - (2026-07-24) ФСБ заявила, что задержала в Москве подозреваемую в работе на разведку Украины. Ее обвинили в попытке подорвать машину силовика | LEDE: Сотрудники ФСБ задержали в Москве россиянку 1996 года ] (ru: ФСБ…
      Сотрудники ФСБ задержали в Москве россиянку 1996 года рождения, подозреваемую в том, что она пыталась подорвать автомобиль сотрудника органов безопасности по заданию украинской разведки, заявили в Центре общественных свя…
  - (2026-07-24) Россия запретила ввоз молочной продукции из Армении | LEDE: Россельхознадзор с 27 июля 2026 года вводит ограничения на ввоз в Россию молочной продукции из Армении. ] (ru: Россия запретила ввоз молочно…
      Россельхознадзор с 27 июля 2026 года вводит ограничения на ввоз в Россию молочной продукции из Армении.
  - (2026-07-24) Война. 1612-й день. Украина нанесла один из самых массированных ударов по России за год. Цели удара — снова склады Wildberries и производитель ракет в Кирове | LEDE: «Медуза» с 24 февраля 20] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить.
  - (2026-07-24) Аркадий Дворкович временно покинул пост главы ФИДЕ из-за санкций | LEDE: Аркадий Дворкович объявил, что из-за санкций ЕС временно покинет пост главы Международной шахматной федерации (ФИДЕ).] (ru: Арк…
      Аркадий Дворкович объявил, что из-за санкций ЕС временно покинет пост главы Международной шахматной федерации (ФИДЕ). В заявлении Дворковича, опубликованном на сайте федерации, говорится:

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 198 new of 298 total
  - (2026-07-24) 韩国爱宝乐园发布新生大熊猫幼崽照片 - 人民网韩国频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFBHbmc4VGE4RlVzMS1ESHNZUE9BVkhma1lzSmRzS2ZkbmFzRmxzVTVUMTJfbjJQMlNYZWpEeWdQZjZESmtCQlRCTXpoQm9qRHA] (zh:…
      韩国爱宝乐园发布新生大熊猫幼崽照片 人民网韩国频道
  - (2026-07-24) 卡尼：针对美关税威胁将“不惜一切代价”维护利益--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1DV2ZoZzJCcUh0RFBEa29NcmRqRXhmOHpDWm9TbGlJNms5QzJMVEpnZEpXZzR2Q3RNd1A5Uk5yQy1wc29jdGl4SFltL] (zh:…
      卡尼：针对美关税威胁将“不惜一切代价”维护利益--国际 人民网
  - (2026-07-24) 读懂中国经济的信心与底气--传媒 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE1McWVvdldPZzkydDBNTlA4Y0xPMTZuV0ZTODNDSXNFcEVyV1hNc1dESmhieENkN1dHb1hsRlNsUkZwbkRiWVZjQlBueWN5ZU5oWjFD] (zh:…
      读懂中国经济的信心与底气--传媒 人民网
  - (2026-07-23) 江西南昌：昌九高铁全线接触网挂网完成 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTFAtZWxRU2ZpV0JJdGk1QzhQSDN6ZFFaazRJQjgwT0owWUFwem5tT1h2M21SelI1WlNoMXBRUHJkSUpkZldka25VTHJoT3U3e] (zh:…
      江西南昌：昌九高铁全线接触网挂网完成 人民网-图片频道
  - (2026-07-24) 京津冀消协联合约谈15家航司及售票平台 应8月底前完成整改 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1GWkZFY3NBemlYcjBSWlRaWGhLMXpxdkotd3QyNTZaT184MF83YXphVHhMM011ZkY5d19HcWszNjhGSXBuc0VNbFl] (zh:…
      京津冀消协联合约谈15家航司及售票平台 应8月底前完成整改 人民网
  - (2026-07-24) 闯入一座会呼吸的博物馆 做一回百年前的“隐形宾客” - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1CTFN5V3ZJZFcxX1hWLVZLMHBRTWljVXM1TzVHSnotMWNwSER0eElyZkluWllfTno4LWU2RmVkQTEyX0U1ZmFBdG0wc0t] (zh:…
      闯入一座会呼吸的博物馆 做一回百年前的“隐形宾客” 人民网

### U.S. Weather + Severe / Climate Outlooks — 141 new of 157 total
  - (2026-07-24) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-24) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 24 at 2:13AM MST until July 25 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with temperatures of 105 to 113 degrees expected with Major to Extreme HeatRisk. * WHERE...Southeast Pinal County, Tohono O'odham Nation, Tucson Metro Area, Upper Gila River Valley, an…
  - (2026-07-24) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 24 at 2:13AM MST until July 25 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with temperatures of 100 to 105 expected with Major HeatRisk. * WHERE...Eastern Cochise County below 5000 feet, Upper San Pedro River Valley, and Upper Santa Cruz River Valley/Altar Va…
  - (2026-07-24) [Severe] Extreme Heat Watch: Extreme Heat Watch issued July 24 at 3:09AM MDT until July 28 at 12:00AM MDT by NWS Salt Lake City UT
      * WHAT...Dangerously hot conditions with moderate to high confidence in daytime temperatures over 100. Overnight minimum temperatures are unlikely to fall below the mid 70s limiting daily recovery. * WHERE...The Wasatch…
  - (2026-07-24) [Severe] Extreme Heat Watch: Extreme Heat Watch issued July 24 at 3:09AM MDT until July 28 at 12:00AM MDT by NWS Salt Lake City UT
      * WHAT...Hazardous conditions with moderate confidence in daytime temperatures reaching 97 to 101 across the Cache Valley. Overnight minimum temperatures are unlikely to fall below 70 limiting daily recovery. * WHERE...C…
  - (2026-07-24) [Moderate] Heat Advisory: Heat Advisory issued July 24 at 2:51AM MDT until July 25 at 9:00PM MDT by NWS Denver CO
      * WHAT...Temperatures from 99 to 103. * WHERE...Fort Collins, Boulder and the western suburbs of Denver, Denver, and Greeley. * WHEN...From 11 AM to 9 PM MDT both Saturday and Sunday. * IMPACTS...Hot temperatures may cau…

### State-Level News — 64 new of 812 total
  - (2026-07-24) [Alaska] Alaska removes thousands from state’s active voter list, erroneously flagging some citizens
      The state of Alaska has removed an estimated 3,000 to 3,500 Alaskans from the state’s active voter list, claiming they may be noncitizens. The removals leave those residents able to vote only if they provide extra identi…
  - (2026-07-24) [Arizona] Doctors warn Andy Biggs’ record on healthcare, abortion should alarm Arizona voters
      Arizona doctors and progressive organizations are warning voters that Republican gubernatorial nominee Andy Biggs has a long record as an elected official of attacking access to healthcare and abortion care. Biggs will f…
  - (2026-07-24) [Arizona] Cyclosporiasis outbreak surges to over 4,173 confirmed cases
      The number of cases of cyclosporiasis — a parasitic infection linked to contaminated water or food that causes severe intestinal issues — has more than doubled to over 4,173 cases across 41 states this week, up from the…
  - (2026-07-24) [Arizona] Mayes tells federal court it’s too early to block Prop. 314, says no one has been arrested yet
      Arizona Attorney General Kris Mayes says it’s too soon for a lawsuit to be filed against a 2024 law that would allow local police officers to arrest unauthorized immigrants because no one has been arrested under it yet.…
  - (2026-07-24) [Connecticut] Larson, Bronin waging an ad war in waning weeks before primary
      <img width="1024" height="831" src="https://ctmirror.org/wp-content/uploads/2026/03/5C565132-17A4-4CAE-A8C9-A0BCD07C6412-1024x831.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="…
  - (2026-07-24) [Connecticut] Without Olmstead rule protection, God help the disabled
      <img width="775" height="451" src="https://ctmirror.org/wp-content/uploads/2026/07/I-am-olmstead.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="htt…

### State Legislative Action — 60 new of 166 total
  - (2026-07-24) [Colorado HB 1298] Background Checks for Child Welfare Placements
      The act gives county departments of human or social services and the Colorado department of human services (department) the statutory authority needed to conduct the required fingerprint-based criminal history record che…
  - (2026-07-24) [District of Columbia B 26-0763] The Omnibus Barry Farm Redevelopment Clarification Emergency Amendment Act of 2026
      The Omnibus Barry Farm Redevelopment Clarification Emergency Amendment Act of 2026
  - (2026-07-24) [District of Columbia B 26-0765] Restoration of Covenanted Roads and Alleys by the District Government Clarification Emergency Amendment Act of 2026
      Restoration of Covenanted Roads and Alleys by the District Government Clarification Emergency Amendment Act of 2026
  - (2026-07-24) [District of Columbia B 26-0767] Net Zero Continuity Emergency Amendment Act of 2026
      Net Zero Continuity Emergency Amendment Act of 2026
  - (2026-07-23) [District of Columbia B 26-0718] Modification Nos. M0006 and M0007 to Contract No. CW119502 with Friendship Place Approval and Payment Authorization Emergency Act of 2026
      Modification Nos. M0006 and M0007 to Contract No. CW119502 with Friendship Place Approval and Payment Authorization Emergency Act of 2026
  - (2026-07-23) [District of Columbia B 26-0710] Entertainment Establishment Employee Safety Extension Emergency Amendment Act of 2026
      Entertainment Establishment Employee Safety Extension Emergency Amendment Act of 2026

### Local News: St. Louis + Atlanta — 51 new of 241 total
  - (2026-07-24) [St. Louis] Explosions are heard near a US base in northern Iraq after US strikes Iran
      An Associated Press journalist heard at least seven blasts Friday morning local time in the city of Irbil, the capital of Iraq’s semi-autonomous Kurdish region.
  - (2026-07-24) [St. Louis] Kenmore Air floatplane with 11 on board catches fire after emergency landing in Washington's San Juan Islands
      All 11 people on board of a Kenmore Air floatplane that crashed in the San Juan Islands are alive, according to the company.
  - (2026-07-24) [St. Louis] Tropical Storm Bertha weakens after bringing strong winds and heavy surf to Louisiana and Texas
      The storm is unlikely to leave behind widespread damage as the heaviest rains are staying offshore.
  - (2026-07-24) [St. Louis] Two St. Louis aldermen urge school board to postpone vote on 'Future Ready' plan
      Resolution 78 calls for increased transparency, community engagement, and alignment with previously adopted citywide educational plans.
  - (2026-07-24) [St. Louis] Sweetgreen addresses customer concerns amid cyclospora outbreak
      Sweetgreen addressed concerns on Wednesday night confirming that it has not been associated with the current cyclospora outbreak.
  - (2026-07-24) [St. Louis] Gateway Pet Guardians looking for volunteers after 20 dogs rescued in St. Clair County hoarding case
      The dogs are now under the care of Gateway Pet Guardians as St. Clair County Animal Services removed 90 animals from a property.

### Ukraine Theater (total-war monitoring) — 41 new of 290 total
  - (2026-07-24) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-23) [FIRMS] thermal anomaly 49.184, 33.457 (FRP 1.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-23 2246Z, FRP 1.12 MW
  - (2026-07-24) [FIRMS] thermal anomaly 52.847, 29.992 (FRP 0.67 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0026Z, FRP 0.67 MW
  - (2026-07-24) [FIRMS] thermal anomaly 52.113, 32.201 (FRP 0.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0026Z, FRP 0.39 MW
  - (2026-07-24) [FIRMS] thermal anomaly 47.786, 29.016 (FRP 1.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0026Z, FRP 1.08 MW
  - (2026-07-24) [FIRMS] thermal anomaly 46.521, 30.696 (FRP 1.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-24 0028Z, FRP 1.37 MW

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-24) [Vanderhook Timothy] Form 4 (Reporting)
      filed 2026-07-24 01:54 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001843103-26-000014 Size: 16 KB
  - (2026-07-24) [Viant Technology Inc.] Form 4 (Issuer)
      filed 2026-07-24 01:54 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001843103-26-000014 Size: 16 KB
  - (2026-07-24) [Vanderhook Christopher] Form 4 (Reporting)
      filed 2026-07-24 01:54 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001843104-26-000014 Size: 16 KB
  - (2026-07-24) [Viant Technology Inc.] Form 4 (Issuer)
      filed 2026-07-24 01:54 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001843104-26-000014 Size: 16 KB
  - (2026-07-24) [Capital V LLC] Form 4 (Reporting)
      filed 2026-07-24 01:53 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001844767-26-000012 Size: 15 KB
  - (2026-07-24) [Viant Technology Inc.] Form 4 (Issuer)
      filed 2026-07-24 01:53 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001844767-26-000012 Size: 15 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-24) [United States] Laura Loomer meets with Zelenskyy in Ukraine after her major reversal on the war
      domain: nbcnews.com · language: English · tone:
  - (2026-07-24) [United Kingdom] Former Corrie star Tracy Shaw heartbreaking cancer update
      domain: wimbledonguardian.co.uk · language: English · tone:
  - (2026-07-24) [Ghana] The Controversial Detention of Chairman Wontumi : Is He a Political Prisoner ? – Ghanamma . com
      domain: ghanamma.com · language: English · tone:
  - (2026-07-24) [United Kingdom] UK ready to defend itself after Iran criticises US using British bases
      domain: dudleynews.co.uk · language: English · tone:
  - (2026-07-24) [United States] Oracle wins Pentagon software deal worth up to $7bn
      domain: thenextweb.com · language: English · tone:
  - (2026-07-24) [United States] Rubio says U . S . is ready to help end war in Ukraine but no quick deal ahead
      domain: kios.org · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 37 new of 119 total
  - (2026-07-24) F-16 збив безпілотник, який залетів на територію Румунії | LEDE: Румунський винищувач F-16 24 липня збив безпілотник, який порушив повітряний простір країни.] (uk: F-16 збив безпілотник, який залетів…
      Румунський винищувач F-16 24 липня збив безпілотник, який порушив повітряний простір країни.
  - (2026-07-24) Росія потрапила до списку країн, щодо яких США ввели нові мита | LEDE: США ввели нові мита щодо 60 торговельних партнерів, у список яких, зокрема, потрапила й Росія.] (uk: Росія потрапила до списку кр…
      США ввели нові мита щодо 60 торговельних партнерів, у список яких, зокрема, потрапила й Росія.
  - (2026-07-24) Глава МЗС Литви розкритикував поступки в останньому пакеті санкцій ЄС проти Росії | LEDE: Міністр закордонних справ Литви Кястутіс Будріс розкритикував поступки, зроблені державам-членам в рамк] (uk:…
      Міністр закордонних справ Литви Кястутіс Будріс розкритикував поступки, зроблені державам-членам в рамках переговорів щодо останнього пакета санкцій Європейського Союзу проти Росії.
  - (2026-07-24) Затримали підозрювану, яка намагалась передати на блокпост вибухівку, замасковану під бургер із McDonald's | LEDE: На Чернігівщині Нацполіція спільно з СБУ та прокуратурою затримали особу, яка ] (uk:…
      На Чернігівщині Нацполіція спільно з СБУ та прокуратурою затримали особу, яка на одному із блокпостів у Чернігові намагалася передати військовослужбовцям саморобну вибухівку, замасковану під бургер із McDonald's.
  - (2026-07-24) Армія РФ вдарила по цивільній інфраструктурі Одеси: є постраждалий | LEDE: Внаслідок російської атаки на Одесу пошкоджено цивільну інфраструктуру та меблевий магазин. За попередніми даними, одн] (uk:…
      Внаслідок російської атаки на Одесу пошкоджено цивільну інфраструктуру та меблевий магазин. За попередніми даними, одна людина постраждала.
  - (2026-07-24) Зелене світло для російської "ядерки"? Як Німеччина повторює помилку "Північного потоку-2" | LEDE: ] (uk: Зелене світло для російської "ядерки"? Як Німеччина повторює помилку "Північного)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 26 total
  - (2026-07-24) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (48.6949, 2.2466) · alt: 365m · 240km/h
  - (2026-07-24) PUMA20 (Slovenia)
      icao24: 506e1f · position: (45.911, 15.4898) · alt: 396m · 161km/h
  - (2026-07-24) JAF97T (Belgium)
      icao24: 44d1ba · position: (44.85, 14.2205) · alt: 12199m · 713km/h
  - (2026-07-24) JAF66L (Belgium)
      icao24: 44d1a6 · position: (49.7649, 2.3513) · alt: 9128m · 739km/h
  - (2026-07-24) JAF3NE (Belgium)
      icao24: 44d1a5 · position: (42.1979, -2.3918) · alt: 10363m · 879km/h
  - (2026-07-24) JAF5KH (Belgium)
      icao24: 44d1a2 · position: (38.3832, 25.9198) · alt: 9806m · 814km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Rusya , 3 limana saldırı düzenledi – Güncel Haberler , Son Dakika Haberleri , Turktime Haber Portalı
      turktime.com · Turkish · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Incendie en Gironde : l évacuation de la presqu île du Cap - Ferret ordonnée , plus de 10 000 ha parcourus par les flammes
      leparisien.fr · French · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Condena de la OMI a los ataques marítimos en el mar Rojo durante el bloqueo hutí
      andaluciainformacion.es · Spanish · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] WSJ ： 伊朗戰爭看不到盡頭 川普已對外交失去耐性 | 國際
      cna.com.tw · Chinese · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] 董秘江湖之商贸零售行业 ： 市井消费与资本市场的摆渡人 ， 串联起万千人间烟火 _ 个股资讯 _ 市场 _ 中金在线
      sc.stock.cnfol.com · Chinese · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] 中国AI为全球网络安全架桥铺路
      china.com.cn · Chinese · tone NA

### U.S. Federal Action — 23 new of 32 total
  - (2026-07-24) Amendment of Class D Airspace and Class E Airspace Over Westfield, MA
      This action amends Class D and Class E airspace over Westfield, MA. This action updates the airport name and geographic coordinates in both Westfield, MA Class D and Class E airspace legal descriptions. This action also…
  - (2026-07-24) Establishment of Class E Airspace; Ottawa, IL
      This action proposes to establish Class E airspace at OSF St Francis Medical Center Heliport, Ottawa, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-07-24) Proposed Amendment to the Definition of Huione Group, a Financial Institution Operating Outside the United States of Primary Money Laundering Concern; Extension of Comment Period
      FinCEN is extending the comment period for the referenced notice of proposed rulemaking (NPRM) it published to amend the existing definition of Huione Group to include, within the definition of that group, H-Pay Service…
  - (2026-07-24) Amendment of Class E Airspace; Alma, MI; correction
      This action corrects an NPRM published by the FAA in the Federal Register on July 10, 2026, amending the Class E airspace at Alma, MI. Specifically, this action corrects the title of the document erroneously published as…
  - (2026-07-24) Loan Performance Categories and Financial Reporting
      The Farm Credit Administration (FCA, we, or our) amends our regulatory high-risk loan performance categories by removing "Formally restructured loans (TDR)," also known as troubled debt restructurings. In 2022, changes i…
  - (2026-07-24) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a safety zone on the main branch of the Chicago River between Michigan Avenue Bridge (Mile Marker 326.5) and the Columbus Drive Bridge (Mile Marker 326.7) for the Annual Chicago Ducky Derby m…

### IT, InfoSys & cybersecurity news (last 7 days) — 13 new of 57 total
  - (2026-07-24) [BleepingComputer] Clop ransomware targets Windchill, FlexPLM in data theft attacks
      The Clop ransomware gang (also tracked as Cl0p) is targeting Internet-exposed PTC Windchill and FlexPLM instances in a new data theft extortion campaign. [...]
  - (2026-07-24) [The Hacker News] NodeBB Patches Eight AI-Found Flaws Exposing Admin Access and Private Chats
      Eight security flaws in NodeBB went public on Wednesday, along with the code to exploit them. Aikido Security rates all eight as high severity and says its AI pentest agents found them in a six-hour review of the forum s…
  - (2026-07-24) [The Hacker News] Kimi K3 Agents Found Redis Zero-Days and Built RCE Exploit, Researchers Say
      Redis shipped seven security releases on July 23 after researchers published authenticated RCE PoCs for stock Redis 6.2.22, 7.4.9, 8.6.4, and 8.8.0. All four chains require RESTORE. The Streams chains also need EVAL and…
  - (2026-07-24) [The Hacker News] Fake Notepad++ Plugin Delivers MATCHBOIL.V2 in UAC-0099 Attacks
      The Computer Emergency Response Team of Ukraine (CERT-UA) has warned of a new campaign that involves the use of a malicious program that's dressed up as a Notepad++ plugin to compromise Windows systems. The activity has…
  - (2026-07-24) [The Register] Burnham wants Big Ecommerce to bankroll Britain's pubs
      Online marketplaces could find themselves buying the next round as the PM looks to tax ecommerce to save the local
  - (2026-07-24) [The Register] Google meets the neighbors and gets both barrels over its new UK datacenter
      The Reg was there as locals aired grievances over poor communication, noise, and light pollution at Waltham Cross facility

### Paper Trading Scorecard — 12 new of 150 total
  - (2026-07-24) [Polymarket] Will John N. Kennedy win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-07-24) [Polymarket] Will there be between 0 and 20 average daily transits of the Strait of Hormuz on July 31?
      This market will resolve according to the finalized 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for July 31, 2026. If the reported value falls exactly b…
  - (2026-07-24) [Polymarket] Will Dune: Messiah have the best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses more domestically on its opening weekend than any other movie in 2026. The “Weekend Box Office Performance” table on the page for the relevant mo…
  - (2026-07-24) [Polymarket] Will Baker Mayfield win the 2026 NFL MVP?
      This market will resolve to the player who wins the 2026 NFL Most Valuable Player award for the 2026-27 NFL season. In the event of a tie, this market will resolve according to the official winner as determined by NFL ru…
  - (2026-07-24) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-24) [Polymarket] Will MetaMask launch a token by September 30, 2026?
      This market will resolve to "Yes" if Metamask officially launches a token by September 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". The token must be actively and publicly transferable and tradable…

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-07-24) LoL: Anyone's Legend vs LGD Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $781,622 · resolves 2026-07-24
  - (2026-07-24) LoL: Anyone's Legend vs LGD Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $614,219 · resolves 2026-07-24
  - (2026-07-24) LoL: Anyone's Legend vs LGD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $592,922 · resolves 2026-07-24
  - (2026-07-24) Will U.S. viewership of the 2026 FIFA World Cup Final be between 46 million and 50 million?
      yes price: 100% · 24h volume: $411,348 · resolves 2026-07-19
  - (2026-07-24) Kharg Island no longer under Iranian control by July 31?
      yes price: 3% · 24h volume: $266,211 · resolves 2026-06-30
  - (2026-07-24) Mitch McConnell steps down from Senate before his term ends?
      yes price: 42% · 24h volume: $229,630 · resolves 2027-01-03

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 126 total
  - (2026-07-24) [USASpending] $22,440,930,497 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-07-24) [USASpending] $3,055,729,526 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-07-24) [USASpending] $1,605,134,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-24) [USASpending] $1,313,227,200 → SLS FEDERAL SERVICES LLC: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
      Agency: Department of Homeland Security. Description: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
  - (2026-07-24) [USASpending] $1,036,291,804 → L3HARRIS TECHNOLOGIES, INC.: TAS::80 0122::TAS DEVELOPMENT, MANUFACTURING AND SUPPORT TO
      Agency: National Aeronautics and Space Administration. Description: TAS::80 0122::TAS DEVELOPMENT, MANUFACTURING AND SUPPORT TO WEATHER OBSERVING INSTRUMENT
  - (2026-07-24) [USASpending] $1,027,192,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 38 total
  - (2026-07-24) MOVER ▼ Masayoshi Son — $64.53B ($-4.51B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-24) MOVER ▼ Tadashi Yanai & family — $63.89B ($-0.63B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-24) MOVER ▲ Francoise Bettencourt Meyers & family — $91.16B (+$0.43B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-24) MOVER ▲ Mukesh Ambani — $86.49B (+$0.21B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-24) MOVER ▲ Gautam Adani — $85.19B (+$0.20B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-24) MOVER ▲ Amancio Ortega — $136.84B (+$0.05B since yesterday)
      Spain · Fashion & Retail · source: Zara

### GDACS — global disaster alerts — 7 new of 243 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 10090 ha
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 10090 ha
  - (2026-07-22) [Green] Forest fires in France
      Wildfire · Green alert · France · Green impact for forestfire in 12807 ha

### USGS earthquakes (M4.5+, past day) — 7 new of 20 total
  - (2026-07-24) M 5.0 - 94 km SSE of Adak, Alaska
      M5.0 · 94 km SSE of Adak, Alaska · depth 10 km
  - (2026-07-24) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 35 km
  - (2026-07-24) M 4.8 - Mid-Indian Ridge
      M4.8 · Mid-Indian Ridge · depth 10 km
  - (2026-07-24) M 4.8 - 59 km NNW of San Antonio, Puerto Rico
      M4.8 · 59 km NNW of San Antonio, Puerto Rico · depth 10 km
  - (2026-07-23) M 4.7 - 56 km NW of Santa Domenica, Italy
      M4.7 · 56 km NW of Santa Domenica, Italy · depth 243.071 km
  - (2026-07-23) M 4.7 - southwest of Sumatra, Indonesia
      M4.7 · southwest of Sumatra, Indonesia · depth 10 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-24) [Japan] Travis Kalanick Atoms raises USD 1 . 7 billion in a16z - led funding round ; Ben Horowitz joins board
      japanherald.com · English
  - (2026-07-24) [Japan] South China Sea threats escalate as Chinese Coast Guard uses water cannons against Philippine vessels
      japanherald.com · English
  - (2026-07-24) [Japan] Update : China to initiate international alliance against telecom , online fraud
      japanherald.com · English
  - (2026-07-24) [Japan] Malaysian groups demand reversal of MMC Port boss appointment
      japanherald.com · English
  - (2026-07-24) [Japan] Trump Threatens To Use Iranian Assets To Pay For Shipping Damage
      japanherald.com · English
  - (2026-07-24) [Japan] US - Saudi nuclear deal could start Middle East arms race , fears Israel
      japanherald.com · English

### Court opinions of consequence (federal & state) — 4 new of 60 total
  - (2026-07-23) U.S. Court of Appeals, 5th Cir.: United States v. Debrow
  - (2026-07-23) U.S. Court of Appeals, 1st Cir.: Rana v. Blanche
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: United States v. Palomares
  - (2026-07-21) U.S. Court of Appeals, 1st Cir.: Recchia v. Campbell

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-24) [Marginal Revolution] The optimal Bayesian update?
      I see at least three updates one might make from the recent OAI/Hugging Face hacking incident: 1. “This happened sooner than I expected, and the story is more dramatic than I expected,” therefore I am more worried than b…
  - (2026-07-24) [Marginal Revolution] What I’ve been reading
      1. Christopher Priest and Nina Allan, The Illuminated Man: Life, Death and the Worlds of J.G. Ballard. Priest died before he finished this book, and his widow added material, including on Priest himself. This is in any c…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=32, 7d-median=22, 14d-median=21; carrying terms: safety, authorized, amendments, regulatory, special, provide, specifically, proposing, period, unless, persons, coast
- state_bills: today=166, 7d-median=124, 14d-median=122; carrying terms: modify, testing, consumer, regulatory, amending, justice, enacted, party, distribution, conditions, fiscal, changes
- state_news: today=812, 7d-median=747, 14d-median=780; carrying terms: coming, lower, lawyer, judges, consumer, milwaukee, charged, justice, experts, exceeded, women, special
- local_news: today=241, 7d-median=227, 14d-median=234; carrying terms: charged, google, fetchpriority, health, image, watch, thursday, voters, months, injured, accused, region
- foreign_news: today=1045, 7d-median=1024, 14d-median=1030; carrying terms: strengthen, colombia, coming, effect, condemns, inflation, judges, title, composition, consumer, ready, charged
- chinese_internal: today=298, 7d-median=299, 14d-median=301; carrying terms: title, google, caixin, global, cbmicefvx, cbmizkfvx, cbmickfvx, color, cbmibefvx, capital, cbmiyefvx, cbmia
- russian_internal: today=1096, 7d-median=982, 14d-median=945; carrying terms: reuters, journal, social, russian, street, raquo, title, client, google, wildberries, times, forbidden
- ukrainian_internal: today=119, 7d-median=125, 14d-median=126; carrying terms: strengthen, hmarochos, syrsky, cooperation, country, offensive, vessels, title, minister, network, attack, economic
- ukraine_theater: today=290, 7d-median=443, 14d-median=422; carrying terms: jqamsyoepen, hauxvxvgwwt, cuxpuw, suvzbc, bfnyruwxyxetx, qdzhtwgrpoxzplwnkn, vutvhuwjtwug, ddlvvpdlnjr, authorized, ppcxh, bwrjn, danish
- paper_bets: today=150, 7d-median=144, 14d-median=144; carrying terms: virginia, alaska, carlos, sachs, house, debut, receives, lifetime, cooperation, diabetes, district, flora
- weather: today=157, 7d-median=167, 14d-median=166; carrying terms: urban, extending, onshore, effect, warned, beaches, lower, southeast, island, source, affected, cooler
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: assets, spread, commodities, effective, unemployment, dexjpus, latest, recession, supply, rates, jolts, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, natural, russell, nasdaq, silver, yield, proxy, commodities, agriculture, bitcoin, large, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=126, 7d-median=117, 14d-median=118; carrying terms: qjrqy, btdyc, vzhjoeklrc, situation, dxriszdpae, respect, hamilton, inezudwdeug, dkryanlkvwvhme, lvmknindexwki, fzbkm, google
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, https, unauthorized, quiver, congresstrading, quiverquant, client, quantitative, error
- billionaires: today=38, 7d-median=38, 14d-median=37; carrying terms: warren, berkshire, japan, mukesh, commodities, canada, masayoshi, technology, carlos, googl, finance, holdings
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, district, blanche, international, insurance, charles, state, court, children, trade, supreme, robert
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, amended, holdings, capital, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: receipts, groom, james, warner, ossoff, lindsey, jonathan, brown, house, talarico, graham, senate
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, japanherald
- gdelt_gkg: today=25, 7d-median=25, 14d-median=35; carrying terms: english, trump, russia, chinese, themes, spanish, sanctions, perimeter, german, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: police, australia, domain, language, kingdom, english, death, canada, killing, health, iheart
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=9, 14d-median=9; carrying terms: position, belgium, kingdom, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: safety, cumulative, containing, infected, ratio, kozhikode, sentinel, release, observed, sustained, americas, alert
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: critical, appliances, option, function, server, product, remediation, sharepoint, microsoft, deserialization, oracle, granularity
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=243, 7d-median=196, 14d-median=180; carrying terms: papua, colombia, storm, green, congo, canada, mexico, speed, alert, medium, magnitude, italy
- usgs_quakes: today=20, 7d-median=18, 14d-median=19; carrying terms: depth, puerto, mexico, islands, indonesia, south, madero, ridge, region, abepura, northern
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, rates, resolves, prime, ethiopia, volume, minister, price, meeting, demeke, change, mekonnen
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: effects, interlocutor, interview, marginal, economist, class, https, conversable, caught, revolution, perhaps, useful
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: robotics, haven, working, bleepingcomputer, number, attack, schneier, malware, plates, video, computer, models
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: warren, magaziner, urban, frank, boyle, jamieson, houchin, house, salinas, herbert, grijalva, moylan
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, unavailable, either, claude, evidence, consensus, placed, sufficient, today, decision, module, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-21] ECB press: ECB appoints Boris Kisselevsky as Director General Secretariat
- [2026-07-23] ECB press: Monetary policy decisions
- [2026-07-23] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*