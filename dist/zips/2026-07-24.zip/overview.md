# WORLDSCOPE morning brief — 2026-07-24

## Headline
3503 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (790) · Russian Internal News (state + in-exile) (690) · State-Level News (386) · World leaders & government officials (324) · Chinese Internal News (226) · Local News: St. Louis + Atlanta (193) · U.S. Weather + Severe / Climate Outlooks (186) · State Legislative Action (148) · Ukraine Theater (total-war monitoring) (104) · Ukrainian Internal News (national + local Kyiv) (61) · GDELT GKG — themes / entities / watch areas (54) · GDACS — global disaster alerts (46)

## What changed today
### International News + Multilateral Institutions — 790 new of 1064 total
  - (2026-07-24) [Global] Cover Story newsletter: Should you be afraid of Elon Musk?
      An exclusive look at how we designed our cover
  - (2026-07-24) [Global] China, Philippine coastguard vessels clash in South China Sea
      China, Philippine coastguard vessels clash in South China Sea.
  - (2026-07-24) [Global] Paramount agrees to pause Warner Bros deal while court case plays out
      The delay, filed in court on Friday, can cost Paramount $1.7bn in fees if the deal is not closed by next June.
  - (2026-07-24) [Global] Iran’s Abbas Araghchi vows ‘we fear no one’
      Iranian Foreign Minister Abbas Araghchi said Iran does not fear threats or 'succumb to pressures'.
  - (2026-07-24) [Global] Fury dominates Wach in Thailand boxing bout ahead of Joshua showdown
      Tyson Fury forced his Polish opponent, Mariusz Wach, to retire in the fight at a Muay Thai stadium in Pattaya, Thailand.
  - (2026-07-24) [Global] Spanish police accuse tractor driver of sparking wildfire as blazes spread
      The number of people forced to flee the heatwave-induced fires in Spain and France has now passed the 100,000 mark.

### Russian Internal News (state + in-exile) — 690 new of 1008 total
  - (2026-07-24) Paramount согласилась заморозить процесс поглощения Warner Bros. почти на год | LEDE: Компания Paramount Skydance согласилась заморозить сделку по поглощению Warner Bros. Discovery до 1 июня] (ru: Par…
      Компания Paramount Skydance согласилась заморозить сделку по поглощению Warner Bros. Discovery до 1 июня 2027 года — пока федеральный судья не вынесет решение по антимонопольному иску, который ранее подали 12 штатов.
  - (2026-07-24) Трамп пригрозил Европе «значительными пошлинами» из-за штрафов, наложенных на американские бигтех-компании | LEDE: Дональд Трамп пообещал, что его администрация начнет расследование в отноше] (ru: Тра…
      Дональд Трамп пообещал, что его администрация начнет расследование в отношении Евросоюза в связи с практикой «ограбления» американских компаний, которым ЕС назначает многомиллиардные штрафы.
  - (2026-07-24) Прокурора Международного уголовного суда Карима Хана (это он выдал ордер на арест Путина) отстранили от должности по обвинению в домогательствах | LEDE: Страны-участницы Международного уголо] (ru: Про…
      Страны-участницы Международного уголовного суда (МУС) проголосовали за отстранение Карима Хана от должности главного прокурора, пишет Reuters со ссылкой на два дипломатических источника.
  - (2026-07-24) Неделю назад ВСУ начали бить по складам Wildberries. Вспоминаем, что произошло с тех пор. Девять атакованных объектов, десятки пострадавших, миллиарды рублей ущерба. В соцсетях спорят о справед] (ru:…
      Wildberries — крупнейший российский маркетплейс. В 2025 году его оборот превысил шесть триллионов рублей, а чистая прибыль достигла 175 миллиардов рублей. По оценке исследовательского агентства Data Insight, на Wildberri…
  - (2026-07-24) Зеленский заявил, что в следующем году у Украины будут дроны дальностью до 10 тысяч километров | LEDE: Украина планирует в 2027 году получить дроны с дальностью до 10 тысяч километров, заяви] (ru: Зел…
      Украина планирует в 2027 году получить дроны с дальностью до 10 тысяч километров, заявил Владимир Зеленский в интервью американской журналистке Лоре Лумер, приехавшей в Киев.
  - (2026-07-24) Энди Бернэм — новый премьер-министр Великобритании. Что о нем известно? И почему его уже сравнивают с Мамдани, а также называют «королем Севера» | LEDE: 17 июля Энди Бернэм официально сменил] (ru: Энд…
      17 июля Энди Бернэм официально сменил Кира Стармера на посту лидера Лейбористской партии. Три дня спустя он вступил в должность премьер-министра Великобритании. До этого Бернэм 16 лет был членом парламента, занимал посты…

### State-Level News — 386 new of 1061 total
  - (2026-07-24) [Alabama] Alabama Health Literacy Month
      Download
  - (2026-07-24) [California] CA landlord fights law meant to help low-income renters
      Should California landlords be required to rent to tenants with federal housing vouchers? They are under state law, but a Sacramento-based property manager is contest
  - (2026-07-24) [California] Public funding cuts, lost grants, stagnant wages: How economic woes are dimming a vibrant art scene
      <img width="1024" height="681" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072226-SD-Arts-AP-CM.jpg?fit=1024%2C681&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="An a…
  - (2026-07-24) [California] Aging oil refineries don’t need more public dollars. California should let them retire
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092925-Refinery-Workers-SK-10-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-24) [California] California can’t replant its forests fast enough to keep up with wildfires
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526_Reforestation_AHK_CM_75.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-24) [California] Newsom appointed a close ally to this state board. Environmental groups say he has a conflict of interest
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072326-CalEPA-BES-Meeting-MG-CM-23.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 226 new of 314 total
  - (2026-07-23) 韩国电竞明星Faker获封“警长” 名誉警衔兼任反网赌宣传大使 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1PcEk4dmQtV0ppUmNSb0g0RGN0Z3EtUmFVQTFxbUdBZ0NmOUxheU0zcGNPRzJBYUYzQ01jbDREQVNGS216RGZVRG] (zh:…
      韩国电竞明星Faker获封“警长” 名誉警衔兼任反网赌宣传大使 财新
  - (2026-07-24) 今日开盘：两市双双低开 沪指跌幅0.60% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBwSTQtSXF6WURFeGh4aG1rMXNpRXdWTE1zSmROLWNsR1B4Z2dPRFJxQkNsaS1obmpFYWUxeDg0NUNYSWh1Zkk3SXZqbi1uaXM5] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.60% 财新
  - (2026-07-24) 伊朗被曝已拒绝美方停火提议 特朗普“接近”决定是否扩大对伊行动 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE53eDJHMnNnWTBjblQ2Y2RINFBCdF94d0lHX0ZYeGJNOHBLMDVTZTk4V2hwemRfZjFPWDFHQ2pha2t6VG9vVXNtVF] (zh:…
      伊朗被曝已拒绝美方停火提议 特朗普“接近”决定是否扩大对伊行动 财新
  - (2026-07-24) 人事观察｜福建高层联动调整 58岁厦门市长伍斌任福建副省长 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBzNV9LdXZTLTBNZXhsRXFfdkJyUjc0R2dzNXlsWG9RLVgxV3FQQUZRdzM0bGFZSndzZ3g0eW9iZn] (zh:…
      人事观察｜福建高层联动调整 58岁厦门市长伍斌任福建副省长 china.caixin.com
  - (2026-07-24) 中国绿证价格指数正式发布 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5xSU4wMXVzaWg0aVlVYmNNMnZ4dUJZNWFkcTdNR0R0TnlrN0xYa1dUVXY1eFhoZUp0WktYVlpNdmVSd1pxc29KMVJYME40TmhCSDVia0JQN] (zh:…
      中国绿证价格指数正式发布 财新
  - (2026-07-24) 下周前瞻：美联储议息；秘鲁新总统就职 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBvc1BweDNyUXltTzNvNnE2MGI3SW9rODNZUmQzN0dSMXJFOTRjQXpTajVlZC1DT19yMWdZMTVkSVdPRU9aSkY0c] (zh:…
      下周前瞻：美联储议息；秘鲁新总统就职 china.caixin.com

### Local News: St. Louis + Atlanta — 193 new of 257 total
  - (2026-07-24) [St. Louis] The Boom Boom Room moves to Buddy’s in downtown St. Louis
      Two major players in the downtown food and entertainment scene are joining forces for a new collaboration. Buddy’s Local Grill & Bar (1001 Washington) is teaming up with The Boom Boom Room as the new resident entertainme…
  - (2026-07-24) [St. Louis] Photos: St. Louis Family Playdate at TotSpot Social
      On July 23, St. Louis Magazine celebrated one year of Family Playdates with a special birthday celebration at TotSpot Social, presented by Royal Banks of Missouri and sponsored by Ryan Lawn & Tree. Returning to the venue…
  - (2026-07-24) [St. Louis] Ask George: What summertime dish would you drive across St. Louis for?
      This may be a first: When I asked SLM’s dining team to weigh in, two people picked the same dish—and make that three if you include me. Denise Mueller-Peterson, Madi Lee, and I all chose Louie‘s prosciutto and shaved Par…
  - (2026-07-24) [St. Louis] St. Louis’ 70 Grand bus route is letting riders down, transit group says
      The 70 Grand bus route running from Broadway to Loughborough Commons services an average of 5,000 riders each weekday. However, the route boasting the highest ridership in the city is also frequently plagued by reliabili…
  - (2026-07-24) [St. Louis] Union Pacific’s Big Boy tour fun concealed a serious purpose
      This past weekend, thousands of St. Louisans sweated it out at Union Station to see the 1.2-million pound steam locomotive Big Boy stop by on its cross-country tour. It was a surprisingly emotional experience: Wherever t…
  - (2026-07-24) [St. Louis] Assault case against bedridden 85-year-old gets dismissed—for now
      Last November, 85-year-old Norman Fishel of Olivette suffered a massive hemorrhagic stroke, which left his entire left side paralyzed. Three days after that stroke, while in the intensive care unit at Mercy Hospital, the…

### U.S. Weather + Severe / Climate Outlooks — 186 new of 187 total
  - (2026-07-24) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 24 at 6:31PM CDT until July 24 at 7:00PM CDT by NWS Grand Forks ND
      At 631 PM CDT, a severe thunderstorm was located over Kelliher, or 39 miles northeast of Bemidji, moving southeast at 25 mph. HAZARD...Golf ball size hail and 60 mph wind gusts. SOURCE...Radar indicated. IMPACT...People…
  - (2026-07-24) [Extreme] Tornado Warning: Tornado Warning issued July 24 at 6:31PM CDT until July 24 at 7:15PM CDT by NWS Duluth MN
      TORDLH The National Weather Service in Duluth MN has issued a * Tornado Warning for... Northwestern Itasca County in north central Minnesota... Southwestern Koochiching County in north central Minnesota... * Until 715 PM…
  - (2026-07-24) [Moderate] Special Weather Statement: Special Weather Statement issued July 24 at 7:31PM EDT by NWS Jacksonville FL
      At 731 PM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Screven to near Raybon. Movement was southeast at 5 mph. HAZARD...Wind gusts around 40 mph. SOURCE...Radar indicated. IMPACT…
  - (2026-07-24) [Extreme] Tornado Warning: Tornado Warning issued July 24 at 6:28PM CDT until July 24 at 7:15PM CDT by NWS Grand Forks ND
      TORFGF The National Weather Service in Grand Forks has issued a * Tornado Warning for... Eastern Marshall County in northwestern Minnesota... * Until 715 PM CDT. * At 627 PM CDT, a severe thunderstorm capable of producin…
  - (2026-07-24) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 24 at 6:28PM CDT until July 24 at 6:45PM CDT by NWS Duluth MN
      At 627 PM CDT, a severe thunderstorm was located over Northome, moving southeast at 40 mph. HAZARD...Two inch hail and 60 mph wind gusts. SOURCE...Radar indicated. IMPACT...People and animals outdoors will be injured. Ex…
  - (2026-07-24) [Severe] Flash Flood Warning: Flash Flood Warning issued July 24 at 4:27PM PDT until July 24 at 7:30PM PDT by NWS Las Vegas NV
      FFWVEF The National Weather Service in Las Vegas has issued a * Flash Flood Warning for... Northwestern Inyo County in south central California... * Until 730 PM PDT. * At 427 PM PDT, Doppler radar indicated thunderstorm…

### State Legislative Action — 148 new of 252 total
  - (2026-07-24) [Alabama HB 42] Motor vehicles; reporting requirements for towed and unclaimed motor vehicles, further provided
      Motor Vehicles & Traffic
  - (2026-07-24) [Alabama HB 159] Retirement benefits, circuit clerks authorized to participate in supernumerary program and Employees' Retirement System based on separate years of service
      Retirement
  - (2026-07-24) [Alabama HB 7] Crimes and offenses, credible threat defined; penalties for crimes of making a terrorist threat in the first or second degree provided further for; principal to immediately contact law…
      Crimes & Offenses
  - (2026-07-24) [Alabama HB 8] Campus chaplains; public K-12 schools authorized to accept as volunteers, local boards of education and governing bodies authorized to vote on whether to allow, limitations provided
      Education
  - (2026-07-24) [Alabama HB 311] Retirement benefits; participation of qualifying sheriffs in supernumerary program and Employees' Retirement System based on separate years of service authorized
      Retirement
  - (2026-07-24) [Alabama HB 155] Homestead Exemptions; removing the annual verification requirement for qualifying permanently and totally disabled veterans
      Military

### Ukraine Theater (total-war monitoring) — 104 new of 324 total
  - (2026-07-24) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-24) [Liveuamap] CENTCOM: U.S. Central Command (CENTCOM) forces successfully completed the 13th straight night of strikes against Iran, July 23, at 9 p.m. ET. CENTCOM targeted Iranian military command cent…
      CENTCOM: U.S. Central Command (CENTCOM) forces successfully completed the 13th straight night of strikes aga
  - (2026-07-24) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com
  - (2026-07-24) [Liveuamap] Power blackout in Sudak after drone strike at the local substation which is still on fire - Liveuamap
      Power blackout in Sudak after drone strike at the local substation which is still on fire Liveua
  - (2026-07-23) [Liveuamap] The EU will include the Moscow Stock Exchange in the 21st package of sanctions against Russia – Reuters - Liveuamap
      The EU will include the Moscow Stock Exchange in the 21st package of sanctions against Russia – Reuters <font color="#
  - (2026-07-24) [Liveuamap] Smoke columns rising over St. Petersburg after drones strikes - Liveuamap
      Smoke columns rising over St. Petersburg after drones strikes Liveuamap

### Ukrainian Internal News (national + local Kyiv) — 61 new of 139 total
  - (2026-07-25) Прокурора МКС Каріма Хана офіційно звільнили з посади через домагання | LEDE: Міжнародний кримінальний суд підтвердив звільнення Каріма Хана з посади прокурора через доведене порушення службови] (uk:…
      Міжнародний кримінальний суд підтвердив звільнення Каріма Хана з посади прокурора через доведене порушення службових обов'язків.
  - (2026-07-25) Армія РФ вдарила по Запоріжжю: є постраждалі, пошкоджений торговий центр | LEDE: Внаслідок російської дронової атаки на Запоріжжя пошкоджено торговий центр, є постраждалі та виникла пожежа.] (uk: Армі…
      Внаслідок російської дронової атаки на Запоріжжя пошкоджено торговий центр, є постраждалі та виникла пожежа.
  - (2026-07-25) На Київщині 25 липня оголосили Днем жалоби після російської атаки | LEDE: На Київщині 25 липня оголосили День жалоби за загиблими від ракетної атаки Росії.] (uk: На Київщині 25 липня оголосили Днем жа…
      На Київщині 25 липня оголосили День жалоби за загиблими від ракетної атаки Росії.
  - (2026-07-24) Латвія викликала російського дипломата через удар по почесному консульству у Слов'янську | LEDE: ] (uk: Латвія викликала російського дипломата через удар по почесному консульству у Сло)
  - (2026-07-24) РФ вдарила реактивним безпілотником по Сумській громаді: загинув чоловік | LEDE: Російські війська ввечері 24 липня завдали удару по поштовому відділенню в Сумській громаді: загинув чоловік, ще] (uk:…
      Російські війська ввечері 24 липня завдали удару по поштовому відділенню в Сумській громаді: загинув чоловік, ще один поранений.
  - (2026-07-24) Трамп пригрозив Євросоюзу новими тарифами через оштрафований Google | LEDE: Президент США Дональд Трамп заявив, що доб'ється скасування штрафів ЄС проти американських технологічних гігантів і п] (uk:…
      Президент США Дональд Трамп заявив, що доб'ється скасування штрафів ЄС проти американських технологічних гігантів і пригрозив Євросоюзу новими тарифами.

### GDELT GKG — themes / entities / watch areas — 54 new of 54 total
  - (2026-07-24) [Russia oil sanctions perimeter · themes] U . S . Coast Guard Cutter Midgett returns to Honolulu following 5 - month Western Pacific patrol – Seapower Magazine
      seapowermagazine.org · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] CHIP SEAL CONSTRUCTION
      elynews.com · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] 中菲南海接連衝突 川普要與習談 - 國際 - 自由時報電子報
      news.ltn.com.tw · Chinese · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] Five officers hurt in police boat crash were responding to person in water
      burytimes.co.uk · English · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] ¿ Quién teme el crudo a 100 dólares ?
      expansion.com · Spanish · tone NA
  - (2026-07-24) [Russia oil sanctions perimeter · themes] New re - entry closet helps former Philadelphia inmates dress to succeed
      phillytrib.com · English · tone NA

### GDACS — global disaster alerts — 46 new of 225 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0
  - (2026-07-07) [Green] Flood in Chile
      Flood · Green alert · Chile · Magnitude 0

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-24) [Edgeworth Jason A] Form 4 (Reporting)
      filed 2026-07-24 23:14 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001493152-26-034645 Size: 7 KB
  - (2026-07-24) [BITMINE IMMERSION TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-07-24 23:14 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001493152-26-034645 Size: 7 KB
  - (2026-07-24) [Sechan II Robert J] Form 4 (Reporting)
      filed 2026-07-24 23:11 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001493152-26-034643 Size: 7 KB
  - (2026-07-24) [BITMINE IMMERSION TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-07-24 23:11 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001493152-26-034643 Size: 7 KB
  - (2026-07-24) [MALONEY MICHAEL STEPHEN] Form 4 (Reporting)
      filed 2026-07-24 23:07 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001493152-26-034641 Size: 7 KB
  - (2026-07-24) [BITMINE IMMERSION TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-07-24 23:07 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001493152-26-034641 Size: 7 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-24) [United States] Central Texas Transmission Line Fight Draws Celebrities , Lawmakers
      domain: kbat.com · language: English · tone:
  - (2026-07-24) [United Kingdom] Five officers hurt in police boat crash were responding to person in water
      domain: burytimes.co.uk · language: English · tone:
  - (2026-07-24) [United States] Pentagon says website issue caused discrepancy in Iran conflict death toll
      domain: wptv.com · language: English · tone:
  - (2026-07-24) [United States] Temple man sentenced to 20 years in 2024 shooting death
      domain: kwtx.com · language: English · tone:
  - (2026-07-24) [United States] Lakelin Lemmings Knows Exactly Who She I on Debut Single
      domain: kfilradio.com · language: English · tone:
  - (2026-07-24) [United States] The family of a man who was shot and killed by Madison police says he was exceptional
      domain: somdnews.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 57 total
  - (2026-07-24) [BleepingComputer] OnTrac notifies customers of data breach after network hack
      OnTrac parcel delivery company is informing that hackers breached its corporate network and may have accessed personal details belonging to its customers. [...]
  - (2026-07-24) [BleepingComputer] Hermes AI agent used to automate attack on Thai Finance Ministry
      A threat actor used the open-source Hermes AI agent in unattended "YOLO" mode to automate post-exploitation activity during an alleged breach of Thailand's Ministry of Finance. [...]
  - (2026-07-24) [BleepingComputer] Hackers hijack hotel Wi-Fi DNS to steal Microsoft 365 accounts
      Hackers are changing the DNS settings on Wi-Fi devices at hotels and conference centers to redirect users to fake Microsoft 365 login pages. [...]
  - (2026-07-24) [BleepingComputer] Microsoft blames massive Microsoft 365 outage on maintenance bug
      Microsoft says a bug in its automated network maintenance request system caused Thursday's massive outage by mistakenly removing IP routes from more devices than intended, disrupting Azure and Microsoft 365 services. [..…
  - (2026-07-24) [BleepingComputer] Chick-fil-A data breach affects more than 13,000 customers
      Chick-fil-A has confirmed that over 13,000 customers had their accounts breached in a wave of credential stuffing attacks targeting its website and mobile app between June 17 and June 19. [...]
  - (2026-07-24) [The Hacker News] BlueNoroff Zoom Phishing Kit Profiles Crypto Wallets Before Malware Delivery
      The North Korean threat actors behind the ClickFix-style campaigns that employ typosquatted Zoom and Microsoft Teams domains have been found to operate an active phishing kit to impersonate the videoconferencing platform…

### Court opinions of consequence (federal & state) — 31 new of 60 total
  - (2026-07-24) U.S. Court of Appeals, 6th Cir.: Christopher Hemwall v. Adam Douglas
  - (2026-07-24) U.S. Court of Appeals, 6th Cir.: United States v. Rishad Williams
  - (2026-07-24) U.S. Court of International Trade: Galvasid S.A. de C.V. v. United States
  - (2026-07-24) Arizona Supreme Court: A & P RANCH LTD v. COCHISE COUNTY
  - (2026-07-24) U.S. Court of Appeals, 8th Cir.: Becky Joseph v. Thomas-Grace Const. Inc.
  - (2026-07-24) U.S. Court of Appeals, 8th Cir.: Jennifer Audette v. Lake of the Woods County

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 23 new of 32 total
  - (2026-07-24) Amendment of Class D Airspace and Class E Airspace Over Westfield, MA
      This action amends Class D and Class E airspace over Westfield, MA. This action updates the airport name and geographic coordinates in both Westfield, MA Class D and Class E airspace legal descriptions. This action also…
  - (2026-07-24) Establishment of Class E Airspace; Ottawa, IL
      This action proposes to establish Class E airspace at OSF St Francis Medical Center Heliport, Ottawa, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-07-24) Proposed Amendment to the Definition of Huione Group, a Financial Institution Operating Outside the United States of Primary Money Laundering Concern; Extension of Comment Period
      FinCEN is extending the comment period for the referenced notice of proposed rulemaking (NPRM) it published to amend the existing definition of Huione Group to include, within the definition of that group, H-Pay Service…
  - (2026-07-24) Amendment of Class E Airspace; Alma, MI; correction
      This action corrects an NPRM published by the FAA in the Federal Register on July 10, 2026, amending the Class E airspace at Alma, MI. Specifically, this action corrects the title of the document erroneously published as…
  - (2026-07-24) Loan Performance Categories and Financial Reporting
      The Farm Credit Administration (FCA, we, or our) amends our regulatory high-risk loan performance categories by removing "Formally restructured loans (TDR)," also known as troubled debt restructurings. In 2022, changes i…
  - (2026-07-24) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a safety zone on the main branch of the Chicago River between Michigan Avenue Bridge (Mile Marker 326.5) and the Columbus Drive Bridge (Mile Marker 326.7) for the Annual Chicago Ducky Derby m…

### Paper Trading Scorecard — 22 new of 147 total
  - (2026-07-24) [Polymarket] Will Benjamin Netanyahu visit New York City by July 31?
      This market will resolve to “Yes” if Benjamin Netanyahu visits New York City between market creation and the listed date, 11:59 PM ET, Otherwise, this market will resolve to “No.” A “visit” refers to Netanyahu physically…
  - (2026-07-24) [Polymarket] Spread: Baltimore Orioles (-1.5)
      In the upcoming MLB game between the Atlanta Braves and Baltimore Orioles, scheduled for July 24 at 7:05 PM ET: This market will resolve to "Baltimore Orioles" if the Baltimore Orioles win the game by 2 or more runs. Oth…
  - (2026-07-24) [Polymarket] Iran leadership change by June 30, 2027?
      This market will resolve to "Yes" if the Supreme Leader of Iran, Mojtaba Khamenei, ceases to be the de facto leader of Iran at any point between market creation and the listed date (ET). Otherwise, this market will resol…
  - (2026-07-24) [Polymarket] Will Dune: Messiah have the best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses more domestically on its opening weekend than any other movie in 2026. The “Weekend Box Office Performance” table on the page for the relevant mo…
  - (2026-07-24) [Polymarket] Will Bitcoin reach $75,000 by December 31, 2026?
      This market will resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between the creation of this market through 11:59 PM ET on the last day of the year specified in the title has a final "High" price…
  - (2026-07-24) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…

### USGS earthquakes (M4.5+, past day) — 20 new of 20 total
  - (2026-07-24) M 6.0 - 82 km W of Sola, Vanuatu
      M6.0 · 82 km W of Sola, Vanuatu · depth 44.637 km
  - (2026-07-24) M 5.7 - 292 km SSE of Ushuaia, Argentina
      M5.7 · 292 km SSE of Ushuaia, Argentina · depth 10 km
  - (2026-07-24) M 5.7 - 49 km W of Turangi, New Zealand
      M5.7 · 49 km W of Turangi, New Zealand · depth 10 km
  - (2026-07-24) M 5.4 - 202 km W of Abepura, Indonesia
      M5.4 · 202 km W of Abepura, Indonesia · depth 10 km
  - (2026-07-24) M 5.3 - 39 km NW of San Antonio de los Cobres, Argentina
      M5.3 · 39 km NW of San Antonio de los Cobres, Argentina · depth 193.727 km
  - (2026-07-24) M 5.3 - 197 km W of Abepura, Indonesia
      M5.3 · 197 km W of Abepura, Indonesia · depth 10 km

### Government & military aircraft airborne (OpenSky) — 13 new of 13 total
  - (2026-07-24) PAT087 (United States)
      icao24: adfedd · position: (20.6436, -156.7262) · alt: 1318m · 409km/h
  - (2026-07-24) SAMU44 (France)
      icao24: 39ca84 · position: (47.2094, -1.5547) · on ground
  - (2026-07-24) PAT120 (United States)
      icao24: adfdd0 · position: (33.7711, -82.1169) · alt: 7315m · 456km/h
  - (2026-07-24) EAGLE31 (United States)
      icao24: ae7449 · position: (34.1778, -119.4498) · alt: 4739m · 430km/h
  - (2026-07-24) JAF1DE (Belgium)
      icao24: 44d1c2 · position: (46.4798, 21.2947) · alt: 12192m · 781km/h
  - (2026-07-24) RCH117 (United States)
      icao24: ae07dd · position: (35.6798, -81.5477) · alt: 10355m · 804km/h

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-07-24) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,964,688 · resolves 2026-06-01
  - (2026-07-24) Counter-Strike: Sharks vs FURIA (BO3) - BLAST Bounty Qualifier
      yes price: 100% · 24h volume: $948,325 · resolves 2026-07-25
  - (2026-07-24) Will U.S. viewership of the 2026 FIFA World Cup Final be between 46 million and 50 million?
      yes price: 100% · 24h volume: $839,733 · resolves 2026-07-19
  - (2026-07-24) Will LeBron James play for the Philadelphia 76ers in 2026-27?
      yes price: 100% · 24h volume: $808,650 · resolves 2026-10-31
  - (2026-07-24) Los Angeles Dodgers vs. New York Mets
      yes price: 52% · 24h volume: $537,892 · resolves 2026-07-31
  - (2026-07-24) Israel x Iran ceasefire continues through July 24?
      yes price: 99% · 24h volume: $460,522 · resolves 2026-07-24

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 129 total
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Reg…
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Regulatory Amendments Office o…
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-07-24) [USASpending] $22,440,930,497 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-07-24) [USASpending] $3,055,729,526 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-07-24) [USASpending] $1,605,134,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-24) [USASpending] $1,313,227,200 → SLS FEDERAL SERVICES LLC: BORDER WALL CONSTRUCTION FOR TCA-5 TON.
      Agency: Department of Homeland Security. Description: BORDER WALL CONSTRUCTION FOR TCA-5 TON.

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-24) [Japan] Wildfire in southwestern France forces evacuation of over 10 , 000
      japanherald.com · English
  - (2026-07-24) [Japan] Man , 41 , accused of flashing young girls in Nerima
      tokyoreporter.com · English
  - (2026-07-24) [Japan] Wall Street divided at week end , Dow gains 235 points
      japanherald.com · English
  - (2026-07-24) [Japan] 3 men ordered to pay ¥112 million over 1993 gym mat suffocation of classmate
      tokyoreporter.com · English
  - (2026-07-24) [Japan] Hokkaido men re - arrested in massive ¥900 million unordered seafood scam
      tokyoreporter.com · English
  - (2026-07-24) [Japan] Jenny Shin breaks out to 5 - shot lead at Women Scottish Open
      japanherald.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-24) [Marginal Revolution] The Decision, the sequel
      Imagine your career were coming to a close, how would you want it to end? By earning an especially large sum of money? Publishing a final wonderful paper? With an amazing act of mentorship? When it comes to Lebron, had h…
  - (2026-07-24) [Marginal Revolution] Friday assorted links
      1. How global was “antiquity”? 2. Why the Clarity Act is mired in muck (NYT). 3. Jim Olds on the new science plan. 4. Cyber capabilities of Kimi 3? 5. “Following a standard workplace safety check, I have just received an…
  - (2026-07-24) [Marginal Revolution] Talk Therapy is Speech
      IJ: On Wednesday, the United States District Court for the District of Columbia struck down a D.C. law that barred therapists from other jurisdictions from doing online teletherapy visits with clients in D.C. The decisio…
  - (2026-07-24) [Conversable Economist] Occupational Licensing: US and International
      The potential benefit of having the government require that certain jobs require an official license is quality control and protection. Personally, I rather like knowing that my nurse or doctor or dentist has gone throug…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 1 new of 32 total
  - (2026-07-24) MOVER ▲ Warren Buffett — $141.02B (+$0.36B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=32, 7d-median=22, 14d-median=21; carrying terms: proposing, certain, persons, final, remove, regulatory, special, service, amendment, amendments, published, based
- state_bills: today=252, 7d-median=124, 14d-median=122; carrying terms: appointed, administer, access, notice, website, county, recovery, forth, located, violence, physical, regulatory
- state_news: today=1061, 7d-median=747, 14d-median=782; carrying terms: student, massachusetts, scaled, fundraising, plant, permanent, reality, election, access, strong, nationwide, county
- local_news: today=257, 7d-median=227, 14d-median=236; carrying terms: cbmirgfbvv, sentenced, scaled, election, county, async, weekend, river, today, arrest, saportareport, suspect
- foreign_news: today=1064, 7d-median=1024, 14d-median=1030; carrying terms: student, videos, screenshot, ukrainian, holds, popular, uplands, herbalife, election, access, strong, personnel
- chinese_internal: today=314, 7d-median=303, 14d-median=306; carrying terms: global, cbmicefvx, target, cbmix, lxtfb, cbmizkfvx, cbmiw, cbmidefvx, title, color, capital, articles
- russian_internal: today=1008, 7d-median=982, 14d-median=945; carrying terms: netflix, google, bloomberg, gazeta, times, istories, europe, wildberries, raquo, media, novaya, found
- ukrainian_internal: today=139, 7d-median=128, 14d-median=132; carrying terms: ukrainian, sparked, launched, appointed, nationwide, strikes, pressure, front, continued, reported, defense, potential
- ukraine_theater: today=324, 7d-median=443, 14d-median=422; carrying terms: zjzxj, capabilities, vujrtzk, htjdqow, fnaflsnznnu, pmcupszxbptejqdezrvhnkewrmynboeddpai, cneyotvsrhzfsupxethzq, flauj, mezjnwpqufdqeny, cbmirgfbvv, bwfrelzfvffns, ukrainian
- paper_bets: today=147, 7d-median=144, 14d-median=144; carrying terms: lackey, primarily, prime, james, brazilian, votes, scheduled, price, theme, officially, number, succeed
- weather: today=187, 7d-median=171, 14d-median=169; carrying terms: beaches, atlantic, winds, afdmeg, impact, strong, message, water, county, effect, mobile, extending
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: pcepilfe, cpiaucsl, walcl, jtsjol, dexuseu, balance, consumption, energy, unemployment, funds, jolts, personal
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, bitcoin, natural, agriculture, china, corporate, large, close, proxy, nasdaq, futures, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=129, 7d-median=117, 14d-median=118; carrying terms: rkiye, uchicago, dmuexxau, muzjrufnbgvmn, adopted, trade, maintenance, square, human, stanford, territorial, certain
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, quantitative, client, unauthorized, quiverquant, https, httperror, congresstrading, error
- billionaires: today=32, 7d-median=36, 14d-median=35; carrying terms: amancio, julia, ballmer, euronext, bezos, italy, ellison, bernard, retail, google, oracle, bloomberg
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: trade, state, international, appeals, district, court, blanche, supreme, school, robert, board, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, therapeutics, scott, holdings, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: shawn, warner, james, cooper, jonathan, pinkston, lindsey, krishnamoorthi, senate, sherrod, robert, graham
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, japanherald
- gdelt_gkg: today=54, 7d-median=45, 14d-median=46; carrying terms: israel, english, hezbollah, trump, spanish, chinese, themes, russia, russian, iheart, sanctions, arabic
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: language, police, killed, australia, english, domain, kingdom, trump, death, killing, iheart, crash
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=13, 7d-median=9, 14d-median=9; carrying terms: position, belgium, kingdom, france, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: releases, tristan, among, primarily, activities, multi, strains, ratio, great, remained, individual, mauritania
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: server, mechanism, insufficient, vulnerability, association, federation, sharepoint, product, active, improper, suite, microsoft
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=225, 7d-median=196, 14d-median=180; carrying terms: storm, speed, kenya, guinea, drought, hungary, republic, flood, costa, somalia, italy, vietnam
- usgs_quakes: today=20, 7d-median=18, 14d-median=19; carrying terms: puerto, depth, mexico, islands, indonesia, ridge, south, abepura, russia, region, philippines, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, resolves, price, rates, minister, meeting, interest, volume, ethiopia, change, increase, normal
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, marginal, economist, useful, revolution, https, perhaps, class, links, paper, assorted, marginalrevolution
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: human, cybersecurity, giant, infrastructure, breach, microsoft, friday, exploitation, hacker, bleepingcomputer, better, surveillance
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: zachary, ellzey, cohen, warner, mejia, cotton, crawford, adams, costa, stefanik, margaret, emmer
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, claude, either, paper, evidence, today, converges, markets, placement, sufficient, consensus, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*