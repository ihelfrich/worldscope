# WORLDSCOPE morning brief — 2026-08-04

## Headline
2287 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (541) · Russian Internal News (state + in-exile) (511) · World leaders & government officials (324) · Chinese Internal News (196) · Ukraine Theater (total-war monitoring) (168) · U.S. Weather + Severe / Climate Outlooks (101) · Local News: St. Louis + Atlanta (98) · State-Level News (74) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (30)

## What changed today
### International News + Multilateral Institutions — 541 new of 960 total
  - (2026-08-04) [Global] Analysis: Trump challenged by cold reality from top allies
      A president used to bending US politics to his will faces two stinging losses in a matter of days, writes the BBC's Anthony Zurcher.
  - (2026-08-04) [Global] Five dead in Moscow region as Ukraine continues warehouse strikes
      Facilities in St Petersburg and Tver were also hit, while at least one was killed in Russian strikes on Ukraine.
  - (2026-08-04) [Global] What will happen when a SpaceX rocket collides with the Moon?
      Our satellite has endured countless blows over millions of years - and astronomers think this one could be a useful accident.
  - (2026-08-04) [Global] Arson arrest made over largest of Washington state's wildfires
      There are three wildfires in the Spokane area that have forced 60,000 to be evacuated from their homes.
  - (2026-08-04) [Global] Soldier kills four in gun rampage in Russian-occupied Crimea
      The region's Moscow-installed governor says the gunman has been detained after firing at fellow soldiers and civilians.
  - (2026-08-04) [Global] France wildfires reveal hundreds of WW2 shells in village
      Explosions heard in Le Porge as the wildfires raged are believed to have have been the old munitions.

### Russian Internal News (state + in-exile) — 511 new of 987 total
  - (2026-08-04) В Ленинградской области после атаки украинских беспилотников горит логистический центр Wildberries. Фотографии и видео. С середины июля ВСУ атаковали уже 20 складов маркетплейса | LEDE: Укра] (ru: В Л…
      Украинские беспилотники в ночь на 4 августа атаковали склад Wildberries в поселке Красный Бор в Ленинградской области, там начался сильный пожар. В компании утверждают, что провели «заблаговременную эвакуацию» сотруднико…
  - (2026-08-04) На Бориса Надеждина, уехавшего из России, составили протокол из-за интервью «Медузе» | LEDE: На политика Бориса Надеждина составили административный протокол об участии в деятельности «нежел] (ru: На…
      На политика Бориса Надеждина составили административный протокол об участии в деятельности «нежелательной» организации (статья 20.33 КоАП). Об этом сообщила пресс-служба московских судов.
  - (2026-08-04) Единственный производитель отечественных телевизоров из реестра Минпромторга признан банкротом | LEDE: Арбитражный суд Москвы признал банкротом ООО «Квант» — юрлицо группы компаний «Квант», ] (ru: Еди…
      Арбитражный суд Москвы признал банкротом ООО «Квант» — юрлицо группы компаний «Квант», которая занимается производством телевизоров, пишет «Коммерсант» со ссылкой на картотеку дел.
  - (2026-08-04) FT: Россия наращивает «теневой флот» танкеров для перевозки сжиженного природного газа в преддверии запрета поставок | LEDE: Россия наращивает «теневой флот» газовозов, пополняя его подержан] (ru: FT:…
      Россия наращивает «теневой флот» газовозов, пополняя его подержанными судами и первыми танкерами отечественной постройки, пишет Financial Times, ссылаясь на данные морской аналитической компании Windward.
  - (2026-08-04) В Лондоне впервые за 155 лет зафиксировали отсутствие осадков в течение месяца | LEDE: Метеостанция в Королевских ботанических садах Кью в Лондоне в июле зафиксировала отсутствие осадков в г] (ru: В Л…
      Метеостанция в Королевских ботанических садах Кью в Лондоне в июле зафиксировала отсутствие осадков в городе в течение календарного месяца. Это произошло впервые за всю историю наблюдений — с 1871 года, пишет Semafor.
  - (2026-08-04) Россия сбросила на Сумы авиабомбы, погибли двое детей и женщина. В Николаеве — одна погибшая в результате российского удара | LEDE: Российские войска в ночь на 4 августа атаковали гражданску] (ru: Рос…
      Российские войска в ночь на 4 августа атаковали гражданскую инфраструктуру города Сумы управляемыми авиабомбами, сообщил глава областной военной администрации Олег Григоров.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 196 new of 256 total
  - (2026-08-02) Cover Story: China’s Power Market Enters a More Volatile Era as Prices Go Real Time - caixinglobal.com
      Cover Story: China’s Power Market Enters a More Volatile Era as Prices Go Real Time caixinglobal.com
  - (2026-08-04) Tech Brief (Aug. 4): Alibaba Launches New Large Model to Power Enterprise-Facing AI Agent - caixinglobal.com
      Tech Brief (Aug. 4): Alibaba Launches New Large Model to Power Enterprise-Facing AI Agent caixinglobal.com
  - (2026-08-03) 吴清：支持企业跨境双向融资 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBYOXBMQ2xXMWQ3aHdZNlo4Y3ZfdkxjWEpDR0pSYUR3TGg5X2J4RlExbWtTYnF5R1MzUGlfQnNoMGtsbXFjRkZFQU5aUzlhX2lrZ211VGt4] (zh:…
      吴清：支持企业跨境双向融资 财新
  - (2026-08-04) A股现分红潮，有公司一口气发了62个亿，多家公司董事长提议派发“红包” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1KcE1oZ1BzSEJJQkx1OWpfVWdPTzAzeEtLdVdWSDhaQUIzdWVuQkpxaDNpclVzOGdDS2I1ZWZYX2tTRS1IT2] (zh:…
      A股现分红潮，有公司一口气发了62个亿，多家公司董事长提议派发“红包” 财新
  - (2026-08-03) 西班牙非洲飞地移民涌入危机暂解 移民政策之辩引爆欧洲政坛 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1iZmRwMVZyOFI5UFdqMl96UXNFMTRHWlhsTEN6Zkc3Q2lyVVVHYVQ0Z2NXaGpiMnZWcGpIV2pjYXgtaXlaeTBWdVNBe] (zh:…
      西班牙非洲飞地移民涌入危机暂解 移民政策之辩引爆欧洲政坛 财新
  - (2026-08-04) 今日开盘：两市双双高开 沪指涨幅0.18% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5RTGNQWlF6aHB4MWI0azN4Z2ZQb0JWMHZrdXpGaVBDMzhwTy1wYWh6WDhTSi1tcXMyMl9TN3B2dVNhOXJLei1XazhxZnlsYVZN] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.18% 财新

### Ukraine Theater (total-war monitoring) — 168 new of 354 total
  - (2026-08-04) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-03) [FIRMS] thermal anomaly 52.803, 32.226 (FRP 1.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-03 0037Z, FRP 1.48 MW
  - (2026-08-03) [FIRMS] thermal anomaly 51.925, 34.272 (FRP 0.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-03 0037Z, FRP 0.52 MW
  - (2026-08-03) [FIRMS] thermal anomaly 52.848, 29.988 (FRP 1.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-03 0037Z, FRP 1.35 MW
  - (2026-08-03) [FIRMS] thermal anomaly 52.847, 29.994 (FRP 1.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-03 0037Z, FRP 1.35 MW
  - (2026-08-03) [FIRMS] thermal anomaly 51.891, 34.193 (FRP 1.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-03 0037Z, FRP 1.12 MW

### U.S. Weather + Severe / Climate Outlooks — 101 new of 145 total
  - (2026-08-04) [Moderate] Heat Advisory: Heat Advisory issued August 4 at 3:37AM MDT until August 4 at 8:00PM MDT by NWS Albuquerque NM
      * WHAT...Temperatures from 98 to 103 expected. * WHERE...Middle Rio Grande Valley including the Albuquerque Metro Area, Northwest Plateau, West Central Plateau, and West Central Highlands. * WHEN...From noon today to 8 P…
  - (2026-08-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-04) [Moderate] Heat Advisory: Heat Advisory issued August 4 at 2:31AM PDT until August 8 at 8:00PM PDT by NWS Las Vegas NV
      * WHAT...Hot conditions expected with highs 80 to 90 degrees above 8000 feet and 90 to 100 degrees below 8000 feet. This will result in Moderate Heat Risk. * WHERE...In California, Eastern Sierra Slopes and White Mountai…
  - (2026-08-04) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 4 at 2:31AM PDT until August 8 at 8:00PM PDT by NWS Las Vegas NV
      * WHAT...Dangerously hot conditions with highs 110 to 120 degrees across the Mojave Desert. Highs 95 to 105 degrees across most of the southern Great Basin and Arizona Strip. Little to no overnight relief is expected, pa…
  - (2026-08-04) [Moderate] Special Weather Statement: Special Weather Statement issued August 4 at 4:20AM CDT by NWS Des Moines IA
      At 419 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from 11 miles northeast of Union Slogh to 9 miles west of Britt to 4 miles northeast of Dakota City. Movement was east at 50 mph. HAZA…
  - (2026-08-04) [Moderate] Special Weather Statement: Special Weather Statement issued August 4 at 4:17AM CDT by NWS Paducah KY
      Areas of patchy and locally dense fog are forming across the Quad State this morning. Visibilities as low as one half to one quarter of a mile are being observed at times. Any fog is expected to burn off within a couple…

### Local News: St. Louis + Atlanta — 98 new of 224 total
  - (2026-08-04) [St. Louis] Where Art Thou? – 8/4/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-03) [St. Louis] Judge warns St. Louis County to release police records in assault case
      It’s a case FOX 2 News broke almost two years ago, as road workers were being arrested as we interviewed them. Now, those workers are still being denied police records their attorneys have been asking for. The judge said…
  - (2026-08-04) [St. Louis] St. Louis County seeks new executive for first time in 7 years
      For the first time in more than 7 hours St. Louis County will be getting a new County Executive.
  - (2026-08-04) [St. Louis] Oakville residents oppose self-storage proposal
      Residents in an Oakville subdivision are pushing back against a proposal to build a self-storage facility near their neighborhood, voicing concerns about safety, privacy and the impact on the community.
  - (2026-08-04) [St. Louis] Alec Burleson hits 3 homers as Cardinals outslug Yankees 13-7 after losing 6-run lead
      Alec Burleson hit three two-run homers, including a drive into the second deck in right field that capped a seven-run eighth inning as the St. Louis Cardinals outslugged the New York Yankees for a 13-7 victory Monday nig…
  - (2026-08-04) [St. Louis] 'Wild ride', Austin Simmons details journey to Mizzou
      Six months before he arrived in Columbia, Mizzou was the last thing on Austin Simmons' mind.

### State-Level News — 74 new of 490 total
  - (2026-08-04) [Alaska] United States Coast Guard Appreciation Day 2026
      WHEREAS, the United States Coast Guard has courageously protected our country’s shores since August 4, 1790, and is the nation’s oldest continuous seafaring service; and WHEREAS, nearly three-quarters of Alaskans reside…
  - (2026-08-04) [Connecticut] Josh Elliott brings ‘black sheep’ instinct to gubernatorial challenge
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/05/DEM-CONVENTION_JH_010-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpri…
  - (2026-08-04) [Connecticut] Separate political truths from lies. Democracy depends on it
      <img width="165" height="86" src="https://ctmirror.org/wp-content/uploads/2026/07/AP-trump-speaking.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" sizes="(…
  - (2026-08-03) [Arizona] Critics say ‘Protect Girls Sports’ act will lead to intrusive bathroom policing
      Arizonans will decide in November whether schools should scrutinize who uses which bathrooms during school sports events. Republicans have framed it as a safety issue while critics warn it will only lead to intrusive pol…
  - (2026-08-03) [Arkansas] Democratic state officials urge US Supreme Court to affirm pause on Trump vote-by-mail order
      WASHINGTON — States do not have time before November’s midterm elections to comply with President Donald Trump’s executive order mandating overhauls of their mail-in-voting systems, two dozen Democratic state officials t…
  - (2026-08-03) [Colorado] Supporters of Colorado graduated income tax measure submit ​required number of petition signatures
      The supporters of a citizen initiative to put a graduated income-tax system in the Colorado constitution said Monday that they had submitted more than 157,000 signatures to the Colorado secretary of state’s office as the…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-04) [Russia oil sanctions perimeter · keywords] Russia Expands Shadow LNG Fleet Ahead of EU Import Ban
      slguardian.org · English · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · keywords] Europe primed for strong open after stateside rally on Monday - Newsquawk EU Market Open
      zerohedge.com · English · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · keywords] Caught on Camera : Drone Crashes Onto Packed Russian Beach as Tourists Run for Cover
      ibtimes.co.uk · English · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · keywords] Tengizchevroil - The Times Of Central Asia
      timesca.com · English · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · keywords] Russia Is Running Out of Soldiers , Oil , and Time | Peak Oil News and Message Boards
      peakoil.com · English · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · keywords] Zelensky WW3 masterstroke ? How drawing Iran into Ukraine war could spell doom for Putin invasion … with Trump help
      the-sun.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-04) [He Eric] Form 4 (Reporting)
      filed 2026-08-04 01:55 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001193125-26-331208 Size: 7 KB
  - (2026-08-04) [Agora, Inc.] Form 4 (Issuer)
      filed 2026-08-04 01:55 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001193125-26-331208 Size: 7 KB
  - (2026-08-04) [BUSH ANTOINETTE COOK] Form 4 (Reporting)
      filed 2026-08-04 01:40 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001209364-26-000002 Size: 5 KB
  - (2026-08-04) [Ares Management Corp] Form 4 (Issuer)
      filed 2026-08-04 01:40 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001209364-26-000002 Size: 5 KB
  - (2026-08-04) [BHUTANI ASHISH] Form 4 (Reporting)
      filed 2026-08-04 01:39 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001287727-26-000004 Size: 5 KB
  - (2026-08-04) [Ares Management Corp] Form 4 (Issuer)
      filed 2026-08-04 01:39 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001287727-26-000004 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-04) [United Kingdom] Andrew Harper mum issues 9 - word takedown as Labour to free son killers from jail early
      domain: aol.co.uk · language: English · tone:
  - (2026-08-04) [Australia] Central West mum side hustles spark creativity , earn income | Daily Liberal
      domain: dailyliberal.com.au · language: English · tone:
  - (2026-08-04) [India] Neeraj Bawana gang member arrested after encounter in Delhi | Delhi News
      domain: timesofindia.indiatimes.com · language: English · tone:
  - (2026-08-04) [United States] Researchers explore new ways to deter sea lamprey
      domain: ironmountaindailynews.com · language: English · tone:
  - (2026-08-04) [United Kingdom] Beach trip left swimmer with parasite and in hospital for a month after swallowing contaminated seawater
      domain: aol.co.uk · language: English · tone:
  - (2026-08-04) [Pakistan] Ukrainian strikes kill 11 in Russia and Crimea
      domain: pakistantoday.com.pk · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 30 new of 101 total
  - (2026-08-04) Росіяни скинули авіабомби на житлові будинки в центрі Краматорська, постраждали 15 людей | LEDE: Росіяни скинули дві авіабомби на центр Краматорська, в результаті чого отримали поранення 4 люди] (uk:…
      Росіяни скинули дві авіабомби на центр Краматорська, в результаті чого отримали поранення 4 людини.
  - (2026-08-04) Мадяр відзвітував про атаки на 15 складів Wildberries у РФ | LEDE: За 18 днів українські дрони спалили 13 із 15 складів Wildberries. Нові атаки зафіксовано у Красному Бору та Чехові.] (uk: Мадяр відзв…
      За 18 днів українські дрони спалили 13 із 15 складів Wildberries. Нові атаки зафіксовано у Красному Бору та Чехові.
  - (2026-08-04) Після Балі 2 тижні не виходив з дому: слідчі перевіряють зв’язок ветерана KRAKEN із убивством Комарова | LEDE: Українські слідчі органи розслідують ймовірну причетність ветерана підрозділу KRAK] (uk:…
      Українські слідчі органи розслідують ймовірну причетність ветерана підрозділу KRAKEN Гліба Новостройного до вбивства Ігоря Комарова на острові Балі.
  - (2026-08-04) У Литві не виключають, що РФ могла цілитися по їхньому посольству в Києві | LEDE: Міністр Литви не виключає умисної атаки РФ на посольство у Києві, відзначає рішучість Литви.] (uk: У Литві не виключаю…
      Міністр Литви не виключає умисної атаки РФ на посольство у Києві, відзначає рішучість Литви.
  - (2026-08-04) Минулого року Чехія прийняла більше українських чоловіків ніж жінок | LEDE: Минулого року чоловіки вперше становили більшість серед українців, які отримали тимчасовий захист у Чехії. За рік кіл] (uk:…
      Минулого року чоловіки вперше становили більшість серед українців, які отримали тимчасовий захист у Чехії. За рік кількість українських чоловіків працездатного віку в країні зросла більш як на 21 тисячу.
  - (2026-08-04) У Польщі фермер знайшов уламки дрона на полі | LEDE: У Мазовецькому воєводстві Польщі фермер знайшов на полі уламки безпілотника.] (uk: У Польщі фермер знайшов уламки дрона на полі)
      У Мазовецькому воєводстві Польщі фермер знайшов на полі уламки безпілотника.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-04) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (48.7313, 2.3545) · on ground · 27km/h
  - (2026-08-04) JAF94H (Bulgaria)
      icao24: 4520aa · position: (47.5755, 2.0399) · alt: 7170m · 795km/h
  - (2026-08-04) GAF262 (Germany)
      icao24: 3e8b41 · position: (43.5021, 14.3517) · alt: 10050m · 733km/h
  - (2026-08-04) PUMA22 (Slovenia)
      icao24: 506e1f · position: (45.6729, 14.9127) · alt: 1524m · 201km/h
  - (2026-08-04) GAF892 (Germany)
      icao24: 3f97fd · position: (59.8645, 9.6173) · alt: 6598m · 734km/h
  - (2026-08-04) RFF07 (Portugal)
      icao24: 496ca7 · position: (37.0192, -7.9725) · on ground · 18km/h

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-04) LoL: T1 vs Hanwha Life Esports (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 100% · 24h volume: $1,963,400 · resolves 2026-08-04
  - (2026-08-04) LoL: T1 vs Hanwha Life Esports - Game 2 Winner
      yes price: 100% · 24h volume: $840,269 · resolves 2026-08-04
  - (2026-08-04) LoL: T1 vs Hanwha Life Esports - Game 1 Winner
      yes price: 0% · 24h volume: $782,290 · resolves 2026-08-04
  - (2026-08-04) Will the Fed decrease interest rates by 25 bps after the September 2026 meeting?
      yes price: 2% · 24h volume: $597,384 · resolves 2026-09-16
  - (2026-08-04) Will Shakhtar Donetsk win the 2026-27 UEFA Champions League Championship?
      yes price: 0% · 24h volume: $446,845 · resolves 2027-05-30
  - (2026-08-04) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 1% · 24h volume: $342,970 · resolves 2026-09-16

### Paper Trading Scorecard — 10 new of 147 total
  - (2026-08-04) [Polymarket] Will WTI Crude Oil (WTI) hit (HIGH) $115 in August?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of August 2026, any 1-minute candle for the Active Month of WTI Crude Oil futures has a final "High" or "Low" price eq…
  - (2026-08-04) [Polymarket] Iran full airspace closure by August 31?
      This market will resolve to “Yes” if Iran initiates a general closure of its airspace, that is not solely due to weather conditions, between market creation and the specified date, 11:59 PM ET. Otherwise, this market wil…
  - (2026-08-04) [Polymarket] Will WTI Crude Oil (WTI) hit (HIGH) $120 in August?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of August 2026, any 1-minute candle for the Active Month of WTI Crude Oil futures has a final "High" or "Low" price eq…
  - (2026-08-04) [Manifold] Indonesia juara aff 2026
  - (2026-08-04) [Manifold] Will there be a major new AI regulation bill signed in the U.S. before September 30, 2026?
  - (2026-08-04) [Manifold] Will Mitch McConnell make a verifiable, live public appearance before 2027?

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 37 total
  - (2026-08-04) #30 Germán Larrea Mota Velasco & family — $64.73B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-08-04) MOVER ▼ Bernard Arnault & family — $147.07B ($-2.55B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-04) MOVER ▼ Masayoshi Son — $63.10B ($-1.82B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-08-04) MOVER ▼ Francoise Bettencourt Meyers & family — $94.59B ($-1.37B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-04) MOVER ▼ Mukesh Ambani — $89.35B ($-0.87B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-04) MOVER ▼ Tadashi Yanai & family — $67.28B ($-0.67B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-08-03) U.S. Court of Appeals, 2nd Cir.: Al Saidi v. Blanche
  - (2026-08-03) U.S. Court of Appeals, 2nd Cir.: Mueller v. Deutsche Bank AG
  - (2026-07-30) U.S. Court of Appeals, 4th Cir.: Harris Investment Holdings, LLC v. BFJ of USA, LLC
  - (2026-07-30) U.S. Court of Appeals, 4th Cir.: Vapor Technology Association v. McKinley Wooten, Jr.
  - (2026-07-30) Supreme Court of California: People v. Sanmiguel
  - (2026-07-30) U.S. Court of Appeals, 2nd Cir.: S Pharmacy, Inc. v. Johnson & Johnson Consumer Inc.

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-04) [South Korea] Inter - Korean goodwill matches of young soccer players foster environment of unity and friendship
      english.hani.co.kr · English
  - (2026-08-04) [South Korea] [ Editorial ] Drone incident should serve as a wake - up call for US - Korea communication
      english.hani.co.kr · English
  - (2026-08-04) [South Korea] Cabinet clears bill to strip prosecutors of investigative power
      koreatimes.co.kr · English
  - (2026-08-04) [South Korea] Samsung Galaxy Z8 foldables set record with 1 . 44 mil . preorders
      koreatimes.co.kr · English
  - (2026-08-04) [South Korea] Can better tourist etiquette help address overtourism ?
      koreatimes.co.kr · English
  - (2026-08-04) [South Korea] Sweating for savings : Korea exercise incentive program sees participation double
      koreatimes.co.kr · English

### IT, InfoSys & cybersecurity news (last 7 days) — 5 new of 52 total
  - (2026-08-04) [BleepingComputer] Hotel Wi-Fi attacks use custom malware to breach Microsoft 365 accounts
      Microsoft has linked a global campaign targeting hospitality Wi-Fi networks to the Russian threat actor Midnight Blizzard, also known as APT29. [...]
  - (2026-08-04) [The Hacker News] CISA Adds Exploited N-able N-central Flaw to KEV After Customer Compromises
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Monday added a high-severity security flaw impacting N-able N-central to its Known Exploited Vulnerabilities (KEV) catalog following reports of active e…
  - (2026-08-04) [Computer Weekly] The King spoke not a word on AI - then the end of term turned
      There was pomp and pageant at state opening of Parliament some 12 weeks ago. Nothing unusual in that, nor in the lack of any mention of artificial intelligence (AI). In 2024, <a href="https://www.computerweekly.com/news/…
  - (2026-08-04) [Computer Weekly] How AI kicked in for the 2026 FIFA World Cup
      In this week’s Computer Weekly, we go behind the scenes at the technology operations centre for the FIFA World Cup to find out how AI helped make the football even better for fans. Our latest buyer’s guide looks at the i…
  - (2026-08-03) [BleepingComputer] New Pass-ta-key attacks let malware hijack Google-synced passkeys
      Security researchers have discovered three attacks that allow malware on already-compromised Windows devices to abuse Google Password Manager's synced passkeys to take over accounts, bypass user verification, and extract…

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 102 total
  - (2026-07-31) [FARA] Criminal Division | Whistleblower Awards Pilot Program - justice.gov
      Criminal Division | Whistleblower Awards Pilot Program justice.gov
  - (2026-07-28) [FARA] Office of Information Policy | FOIA Library - justice.gov
      Office of Information Policy | FOIA Library justice.gov
  - (2026-08-04) [USASpending] $1,608,568,595 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
      Agency: Department of State. Description: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
  - (2026-08-04) [USASpending] $1,589,272,070 → ASSOCIATION OF UNIVERSITIES FOR RESEARCH IN ASTRONOMY, INC.: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT SPAN THE MAJOR
      Agency: National Aeronautics and Space Administration. Description: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT SPAN THE MAJOR PHASES OF THE MISSION BEGINNING WITH FORMULATION THROUGH DEVELOPMENT AND TESTING, AND ENDIN…

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-04) [Marginal Revolution] The economics of H-1B immigration
      We study the effects of H-1B immigration on U.S. industries that employ H-1B workers and their trading partners. Using a novel cross-industry design and the 1999–2003 expansion of the H-1B visa cap for identification, we…
  - (2026-08-04) [Marginal Revolution] Emergent Ventures winners, 57th cohort
      Oisin O’Gorman, 15, Dublin, misinformation and fakes. Karsen Lee Wahal, Stanford, is AI killing the web?, and measuring media slant. Davy Deng, with Claire Wang (previous winner), whole brain emulation, MIT. Enej Grmek,…

### USGS earthquakes (M4.5+, past day) — 1 new of 9 total
  - (2026-08-04) M 4.6 - 112 km WSW of Puerto Madero, Mexico
      M4.6 · 112 km WSW of Puerto Madero, Mexico · depth 10 km

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: program, order, proposes, proposing, safety, requires, issued, rulemaking, management, standard, action, provide
- state_bills: today=0, 7d-median=108, 14d-median=112; carrying terms: licenses, known, employee, purposes, specific, private, protection, maximum, rates, issue, existing, services
- state_news: today=490, 7d-median=758, 14d-median=492; carrying terms: string, decision, known, employee, voting, declined, private, groups, permalink, family, calls, stylized
- local_news: today=224, 7d-median=224, 14d-median=226; carrying terms: former, evening, atlanta, family, events, uploads, figure, missouri, multiple, mother, decoding, night
- foreign_news: today=960, 7d-median=1022, 14d-median=1006; carrying terms: retries, official, decision, guizhou, known, match, practical, dreamed, private, groups, shangri, discipline
- chinese_internal: today=256, 7d-median=256, 14d-median=264; carrying terms: firms, china, chinese, record, google, caixin, global, people, https, stock, sales, office
- russian_internal: today=987, 7d-median=916, 14d-median=898; carrying terms: street, reuters, novaya, novayagazeta, title, httperror, russian, media, found, forbidden, times, centcom
- ukrainian_internal: today=101, 7d-median=133, 14d-median=132; carrying terms: former, overnight, takeaways, according, facilities, reported, cruise, government, minister, kyivindependent, russians, restrictions
- ukraine_theater: today=354, 7d-median=639, 14d-median=633; carrying terms: known, firms, active, coverage, acquired, client, anomaly, error, thermal, polygons, extra, deepstatemap
- paper_bets: today=147, 7d-median=141, 14d-median=136; carrying terms: democratic, official, world, achieved, according, office, scheduled, career, humanoid, kylian, florida, virginia
- weather: today=145, 7d-median=173, 14d-median=174; carrying terms: impact, overnight, corridor, monitoring, interstate, level, evening, beach, until, watch, short, likely
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, consumption, total, dexchus, rates, latest, pcepilfe, unrate, energy, treasury, cpilfesl, growth
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, rates, large, corporate, futures, range, natural, nasdaq, treasury, silver, commodities, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=102, 7d-median=104, 14d-median=104; carrying terms: libya, abuses, democratic, transnistria, active, junior, specific, palestinian, production, leland, related, groups
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quiverquant, https, unauthorized, client, error, quantitative, quiver, httperror
- billionaires: today=37, 7d-median=37, 14d-median=37; carrying terms: warren, gcarsoa, oracle, fashion, larry, francoise, italy, yanai, brokerage, finance, devasini, arnault
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: johnson, appeals, california, jones, supreme, arizona, delaware, services, texas, court, county, blanche
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, group, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, receipts, alexandria, talarico, shawn, platner, jonathan, david, warner, congress, disbursements, ossoff
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, korea
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, trump, netanyahu, keywords, russian, drone, israeli, strikes, hamas, claims
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: crisis, domain, language, iheart, english, years
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=16; carrying terms: position, canada, belgium, ground, kingdom, china, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: democratic, announcing, rajshahi, patient, ratio, continued, official, travel, world, containing, according, known
- cisa_kev: today=10, 7d-median=10, 14d-median=11; carrying terms: point, authentication, improper, wordpress, overflow, functionality, inclusion, check, sphere, stack, command, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=233, 7d-median=286, 14d-median=286; carrying terms: impact, herzegovina, austria, democratic, forest, serbia, croatia, agricultural, republic, italy, monaco, typhoon
- usgs_quakes: today=9, 7d-median=17, 14d-median=18; carrying terms: depth, islands, japan, region, mexico, russia, argentina, severo, kuril, puerto
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, strait, prime, august, normal, returns, traffic, hormuz, ceasefire, rates
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: government, economist, revolution, marginal, conversableeconomist, having, conversable, https, class, toward, climate, strong
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: essay, ransomware, world, groups, government, bleepingcomputer, cybersecurity, models, systems, companies, attacks, group
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: nikki, rochester, gilbert, ezell, chuck, radewagen, sherman, kristen, ruben, palmer, hoyer, susie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, market, consensus, decision, placed, sufficient, paper, converges, markets, identify, module, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*