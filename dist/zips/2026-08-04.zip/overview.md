# WORLDSCOPE morning brief — 2026-08-04

## Headline
2127 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (559) · Russian Internal News (state + in-exile) (466) · World leaders & government officials (324) · Chinese Internal News (195) · U.S. Weather + Severe / Climate Outlooks (102) · Local News: St. Louis + Atlanta (87) · State-Level News (75) · GDELT GKG — themes / entities / watch areas (50) · Ukraine Theater (total-war monitoring) (49) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (31)

## What changed today
### International News + Multilateral Institutions — 559 new of 1000 total
  - (2026-08-04) [Global] Three lions die of suspected heatstroke at Tokyo zoo as Japan swelters
  - (2026-08-04) [Global] Nine Lives, the feral cat that terrorised New Zealand’s rare ducks, is caught after three years
  - (2026-08-04) [Global] Japan’s prime minister tours earthquake-hit sites as recovery efforts hampered by soaring temperatures
  - (2026-08-04) [Global] NSW will not implement recommendation of long-awaited hate speech report – as it happened
  - (2026-08-04) [Global] NSW Liberal admits to leaking confidential report to young conservative powerbrokers, inquiry hears
  - (2026-08-04) [Global] Trump wants ‘fair treatment’ in fight over Labor’s levy on tech giants to pay for news, US trade group warns

### Russian Internal News (state + in-exile) — 466 new of 943 total
  - (2026-08-04) В Ленинградской области после атаки украинских беспилотников горит логистический центр Wildberries. Фотографии и видео. С середины июля ВСУ атаковали уже 20 складов маркетплейса | LEDE: Укра] (ru: В Л…
      Украинские беспилотники в ночь на 4 августа атаковали склад Wildberries в поселке Красный Бор в Ленинградской области, там начался сильный пожар. В компании утверждают, что провели «заблаговременную эвакуацию» сотруднико…
  - (2026-08-04) На Бориса Надеждина, уехавшего из России, составили протокол из-за интервью «Медузе» | LEDE: На политика Бориса Надеждина составили административный протокол об участии в деятельности «нежел] (ru: На…
      На политика Бориса Надеждина составили административный протокол об участии в деятельности «нежелательной» организации (статья 20.33 КоАП). Об этом сообщила пресс-служба московских судов.
  - (2026-08-04) Единственный производитель отечественных телевизоров из реестра Минпромторга признан банкротом | LEDE: Арбитражный суд Москвы признал банкротом ООО «Квант» — юрлицо группы компаний «Квант», ] (ru: Еди…
      Арбитражный суд Москвы признал банкротом ООО «Квант» — юрлицо группы компаний «Квант», которая занимается производством телевизоров, пишет «Коммерсант» со ссылкой на картотеку дел.
  - (2026-08-04) FT: Россия наращивает «теневой флот» танкеров для перевозки сжиженного природного газа в преддверии запрета поставок | LEDE: Россия наращивает «теневой флот» газовозов, пополняя его подержан] (ru: FT:…
      Россия наращивает «теневой флот» газовозов, пополняя его подержанными судами и первыми танкерами отечественной постройки, пишет Financial Times, ссылаясь на данные морской аналитической компании Windward.
  - (2026-08-04) В Лондоне впервые за 155 лет зафиксировали отсутствие осадков в течение месяца | LEDE: Метеостанция в Королевских ботанических садах Кью в Лондоне в июле зафиксировала отсутствие осадков в г] (ru: В Л…
      Метеостанция в Королевских ботанических садах Кью в Лондоне в июле зафиксировала отсутствие осадков в городе в течение календарного месяца. Это произошло впервые за всю историю наблюдений — с 1871 года, пишет Semafor.
  - (2026-08-04) Россия сбросила на Сумы авиабомбы, погибли двое детей и женщина. В Николаеве — одна погибшая в результате российского удара | LEDE: Российские войска в ночь на 4 августа атаковали гражданску] (ru: Рос…
      Российские войска в ночь на 4 августа атаковали гражданскую инфраструктуру города Сумы управляемыми авиабомбами, сообщил глава областной военной администрации Олег Григоров.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 195 new of 256 total
  - (2026-08-04) Tech Brief (Aug. 4): Alibaba Launches New Large Model to Power Enterprise-Facing AI Agent - Caixin Global
      Tech Brief (Aug. 4): Alibaba Launches New Large Model to Power Enterprise-Facing AI Agent Caixin Global
  - (2026-08-03) 黑龙江省开展2026年世界肝炎日系列科普宣传活动 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1BQ0VTYS1PNFAzS1JwYmRSWVBnOEVWOFBjSXlITjVpU2xjajJUTy1RWXBlSHV2amR0UGh4czdEdDZfOFNOQ2lVTzRBVjNT] (zh:…
      黑龙江省开展2026年世界肝炎日系列科普宣传活动 人民网
  - (2026-08-03) 黑龙江省惠民疫苗接种 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9WbmtJdkZDMjVRZDJmLTR4SmVzcUtwSGpWN25EaWE1bXl2X3R5aGM0aFdJMkhCUk5NNkplaDBlb3o1Z2llZ3pVR21TZjQ5bUhiNnF2THhyTE] (zh:…
      黑龙江省惠民疫苗接种 人民网
  - (2026-08-03) 国别频道 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFAyWUloa1laZ1FaWUszbGNTZXY3LTNiZ3dMZThTY09PUF9xUEU0Y3o3UE50anZTVGRScHBJUDctc3FSd2NQNFUxeUQ4MVZGcHVhek56dEFVRDdwemFM] (zh:…
      国别频道 人民网
  - (2026-08-04) 新场景里看活力丨海河夜航人 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5UbXpBcm9HZXU3VjViR3VFWTlMRktJUFBILTJVY1JRaU1TVXBIcjE2LWt2dVlYbks5TlhKMjUwQXZLSTE1SWJQREx1aUNhMTNWVkFoNzZ] (zh:…
      新场景里看活力丨海河夜航人 人民网
  - (2026-08-03) 上半年江苏规上数字产品制造业增长13.5% - 人民网－江苏频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5fQko3aWRHNnhPZnF5YzBpaEt4aXpFX01MR250dGM3bnMyTzh0ZHVVTjNjTnpXczdkY0JDdTlLNjkxV2NwaFBYa3FCUH] (zh:…
      上半年江苏规上数字产品制造业增长13.5% 人民网－江苏频道

### U.S. Weather + Severe / Climate Outlooks — 102 new of 146 total
  - (2026-08-04) [Moderate] Gale Warning: Gale Warning issued August 4 at 2:47AM PDT until August 4 at 3:00AM PDT by NWS Eureka CA
      * WHAT...Very steep and hazardous seas 9 to 11 feet and north winds 15 to 25 kt with gusts up to 30 kt expected. * WHERE...Waters from Pt. St. George to Cape Mendocino CA from 10 to 60 nm. * WHEN...Until 3 PM PDT this af…
  - (2026-08-04) [Moderate] Hazardous Seas Warning: Hazardous Seas Warning issued August 4 at 2:47AM PDT until August 4 at 9:00AM PDT by NWS Eureka CA
      * WHAT...Very steep and hazardous seas 9 to 14 feet and north winds 15 to 25 kt with gusts up to 30 kt. * WHERE...Waters from Cape Mendocino to Pt. Arena CA from 10 to 60 nm. * WHEN...Until 9 AM PDT this morning. * IMPAC…
  - (2026-08-04) [Moderate] Hazardous Seas Warning: Hazardous Seas Warning issued August 4 at 2:47AM PDT until August 4 at 3:00PM PDT by NWS Eureka CA
      * WHAT...Very steep and hazardous seas 9 to 11 feet and north winds 15 to 25 kt with gusts up to 30 kt expected. * WHERE...Waters from Pt. St. George to Cape Mendocino CA from 10 to 60 nm. * WHEN...Until 3 PM PDT this af…
  - (2026-08-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-04) [Moderate] Heat Advisory: Heat Advisory issued August 4 at 3:37AM MDT until August 4 at 8:00PM MDT by NWS Albuquerque NM
      * WHAT...Temperatures from 98 to 103 expected. * WHERE...Middle Rio Grande Valley including the Albuquerque Metro Area, Northwest Plateau, West Central Plateau, and West Central Highlands. * WHEN...From noon today to 8 P…
  - (2026-08-04) [Moderate] Heat Advisory: Heat Advisory issued August 4 at 2:31AM PDT until August 8 at 8:00PM PDT by NWS Las Vegas NV
      * WHAT...Hot conditions expected with highs 80 to 90 degrees above 8000 feet and 90 to 100 degrees below 8000 feet. This will result in Moderate Heat Risk. * WHERE...In California, Eastern Sierra Slopes and White Mountai…

### Local News: St. Louis + Atlanta — 87 new of 206 total
  - (2026-08-04) [St. Louis] Where Art Thou? – 8/4/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-04) [St. Louis] See the Aug. 4, 1926, front page: Hawes' lead for senator grows to 50,000
      Headlines from the Aug. 4, 1926, front page include: Antisaloon vote falls far below what was forecast
  - (2026-08-04) [St. Louis] Dr. Barton Goldsmith: Red flags of high-tech dating
      When it comes to dating, and online dating in particular, there are things you need to look out for. I’ve been turned down more times than a nerd at the prom, so I know rejection, and I also know it…
  - (2026-08-04) [St. Louis] Dailey, Michael
      Mike died peacefully after a long illness with family present at Mercy South on the 19th of July. A son, brother, father and grandfather, he loved his family and will be greatly missed. Preceded in death by his father Ge…
  - (2026-08-04) [St. Louis] Schnake, Christine
      Schnake, Christine
  - (2026-08-04) [St. Louis] From Chappell Roan to Olivia Dean: How female pop stars came to own their careers
      Female pop stardom has changed a lot since the early aughts. Here is a look at what’s changed for the better and the worse.

### State-Level News — 75 new of 490 total
  - (2026-08-03) [Arizona] Critics say ‘Protect Girls Sports’ act will lead to intrusive bathroom policing
      Arizonans will decide in November whether schools should scrutinize who uses which bathrooms during school sports events. Republicans have framed it as a safety issue while critics warn it will only lead to intrusive pol…
  - (2026-08-03) [Arkansas] Democratic state officials urge US Supreme Court to affirm pause on Trump vote-by-mail order
      WASHINGTON — States do not have time before November’s midterm elections to comply with President Donald Trump’s executive order mandating overhauls of their mail-in-voting systems, two dozen Democratic state officials t…
  - (2026-08-03) [Colorado] Supporters of Colorado graduated income tax measure submit ​required number of petition signatures
      The supporters of a citizen initiative to put a graduated income-tax system in the Colorado constitution said Monday that they had submitted more than 157,000 signatures to the Colorado secretary of state’s office as the…
  - (2026-08-04) [Alaska] Early voting opens for Alaska’s 2026 primary election — here’s what to expect
      Early in-person voting began Monday at 10 locations in the Railbelt, Juneau and Nome for Alaska’s Aug. 18 statewide primary election. As of July 31, just under 10,000 voters had requested absentee ballots for the electio…
  - (2026-08-04) [Alaska] Getting ready to vote? Compare candidates with the 2026 Alaska Voter Guide
      The Alaska Beacon, Alaska Public Media, KTOO and the Anchorage Daily News worked together this year and have created a voter guide to help Alaskans make informed choices when they vote. The 2026 Alaska Voter Guide won’t…
  - (2026-08-03) [Alaska] The future of Alaska’s pollinators
      On an August evening in Interior Alaska, the sun hangs low over the hills as a bumblebee makes its final foraging trip of the season. The fireweed is fading, the nights are cooling, and the bee will soon retreat undergro…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-04) [Russia oil sanctions perimeter · themes] Stanze in affitto per studenti e lavoratori , Milano la più cara dItalia : 700 euro il prezzo medio ( in calo del 4 per cento ). Meno stanze in centro : « For…
      milano.corriere.it · Italian · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · themes] CCTV shows man allegedly wheeling Brit woman body in suitcase through Athens
      bristolpost.co.uk · English · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · themes] Enflasyon rahatlattı , peki faiz ne olacak ? Uzman isim tarih verdi !
      ekonomi.haber7.com · Turkish · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · themes] 苦茶油爆致癌 ！ 疑中國進口苦茶籽混充 檢調17路搜索傳喚7人到案 | 社會 | 三立新聞網 SETN . COM
      setn.com · Chinese · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · themes] Interior instalará boyas también en Melilla y ordena devolver de forma automática por tierra a los migrantes que superen las nuevas barreras en las dos ciudad…
      diariovasco.com · Spanish · tone NA
  - (2026-08-04) [Russia oil sanctions perimeter · themes] Хлеб резко подорожал в Хабаровском крае АМУР . Инфо
      amur.info · Russian · tone NA

### Ukraine Theater (total-war monitoring) — 49 new of 242 total
  - (2026-08-04) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-02) [Liveuamap] Lebanon news on live map - lebanon.liveuamap.com - Liveuamap
      Lebanon news on live map - lebanon.liveuamap.com Liveuamap
  - (2026-07-31) [Liveuamap] Number of wounded as result of Russian airstrike in Kherson increased to 4 - Liveuamap
      Number of wounded as result of Russian airstrike in Kherson increased to 4 Liveuamap
  - (2026-08-03) [Liveuamap] The Cameroon-flagged vessel Nadezhda was attacked by drones in the Black Sea. Four sailors, including three Turks, were injured, the newspaper Cumhuriyet reported. Black Sea - Ukraine Inte…
      The Cameroon-flagged vessel Nadezhda was attacked by drones in the Black Sea. Four sailors, including three Turks, were injured
  - (2026-08-04) [Liveuamap] Fire at the industrial enterprise in Chernihiv as result of drone strike - Liveuamap
      Fire at the industrial enterprise in Chernihiv as result of drone strike Liveuamap
  - (2026-07-31) [Liveuamap] 1 person wounded as result of Russian strike at the shopping mall in Pavlohrad - Liveuamap
      1 person wounded as result of Russian strike at the shopping mall in Pavlohrad Liveuamap</fo

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-04) [He Eric] Form 4 (Reporting)
      filed 2026-08-04 01:55 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001193125-26-331208 Size: 7 KB
  - (2026-08-04) [Agora, Inc.] Form 4 (Issuer)
      filed 2026-08-04 01:55 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001193125-26-331208 Size: 7 KB
  - (2026-08-04) [BUSH ANTOINETTE COOK] Form 4 (Reporting)
      filed 2026-08-04 01:40 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001209364-26-000002 Size: 5 KB
  - (2026-08-04) [Ares Management Corp] Form 4 (Issuer)
      filed 2026-08-04 01:40 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001209364-26-000002 Size: 5 KB
  - (2026-08-04) [BHUTANI ASHISH] Form 4 (Reporting)
      filed 2026-08-04 01:39 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001287727-26-000004 Size: 5 KB
  - (2026-08-04) [Ares Management Corp] Form 4 (Issuer)
      filed 2026-08-04 01:39 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001287727-26-000004 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-04) [India] UNESCO 25 new World Heritage sites for 2026 : One new Indian landmark makes the prestigious global list ; see all the new entries
      domain: timesofindia.indiatimes.com · language: English · tone:
  - (2026-08-04) [United Kingdom] CCTV shows man allegedly wheeling Brit woman body in suitcase through Athens
      domain: bristolpost.co.uk · language: English · tone:
  - (2026-08-04) [India] Zelenskyy Unveils FREYJA Missile Shield , Carpathian Initiative
      domain: newkerala.com · language: English · tone:
  - (2026-08-04) [United States] Missouri cyclosporiasis cases double to over 1 , 000
      domain: kfvs12.com · language: English · tone:
  - (2026-08-04) [United Kingdom] Segro agrees £14 billion takeover from US firm Prologsis
      domain: echo-news.co.uk · language: English · tone:
  - (2026-08-04) [United States] Man charged after rock attack on Native woman in Bozeman | State
      domain: fairfieldsuntimes.com · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 31 new of 102 total
  - (2026-08-04) Росіяни вдарили ракетами поблизу ринку на Одещині: троє людей постраждали | LEDE: Унаслідок ракетної атаки РФ по передмістю Одеси постраждали троє чоловіків, зруйновано цивільну інфраструктуру.] (uk:…
      Унаслідок ракетної атаки РФ по передмістю Одеси постраждали троє чоловіків, зруйновано цивільну інфраструктуру.
  - (2026-08-04) Трамп хоче, щоб у вівторок Іран пішов на угоду щодо відкриття Ормузької протоки | LEDE: Президент США Дональд Трамп тисне на Іран, щоб той ще у вівторок уклав угоду з Оманом щодо Ормузької прот] (uk:…
      Президент США Дональд Трамп тисне на Іран, щоб той ще у вівторок уклав угоду з Оманом щодо Ормузької протоки, інакше країні загрожують руйнівні авіаудари.
  - (2026-08-04) Росіяни скинули авіабомби на житлові будинки в центрі Краматорська, постраждали 15 людей | LEDE: Росіяни скинули дві авіабомби на центр Краматорська, в результаті чого отримали поранення 4 люди] (uk:…
      Росіяни скинули дві авіабомби на центр Краматорська, в результаті чого отримали поранення 4 людини.
  - (2026-08-04) Мадяр відзвітував про атаки на 15 складів Wildberries у РФ | LEDE: За 18 днів українські дрони спалили 13 із 15 складів Wildberries. Нові атаки зафіксовано у Красному Бору та Чехові.] (uk: Мадяр відзв…
      За 18 днів українські дрони спалили 13 із 15 складів Wildberries. Нові атаки зафіксовано у Красному Бору та Чехові.
  - (2026-08-04) Після Балі 2 тижні не виходив з дому: слідчі перевіряють зв’язок ветерана KRAKEN із убивством Комарова | LEDE: Українські слідчі органи розслідують ймовірну причетність ветерана підрозділу KRAK] (uk:…
      Українські слідчі органи розслідують ймовірну причетність ветерана підрозділу KRAKEN Гліба Новостройного до вбивства Ігоря Комарова на острові Балі.
  - (2026-08-04) У Литві не виключають, що РФ могла цілитися по їхньому посольству в Києві | LEDE: Міністр Литви не виключає умисної атаки РФ на посольство у Києві, відзначає рішучість Литви.] (uk: У Литві не виключаю…
      Міністр Литви не виключає умисної атаки РФ на посольство у Києві, відзначає рішучість Литви.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-04) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (47.5699, 1.7553) · alt: 8039m · 688km/h
  - (2026-08-04) JAF94H (Bulgaria)
      icao24: 4520aa · position: (45.8805, 1.234) · alt: 10675m · 842km/h
  - (2026-08-04) GAF262 (Germany)
      icao24: 3e8b41 · position: (42.3342, 16.0134) · alt: 10050m · 747km/h
  - (2026-08-04) PUMAA (France)
      icao24: 39ddf7 · position: (44.5848, 5.3977) · alt: 1402m · 247km/h
  - (2026-08-04) SAMU37 (France)
      icao24: 39ca87 · position: (47.1084, 1.1983) · alt: 746m · 246km/h
  - (2026-08-04) PUMA22 (Slovenia)
      icao24: 506e1f · position: (45.8666, 15.3194) · alt: 1280m · 266km/h

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-04) LoL: T1 vs Hanwha Life Esports (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 100% · 24h volume: $1,963,400 · resolves 2026-08-04
  - (2026-08-04) LoL: T1 vs Hanwha Life Esports - Game 2 Winner
      yes price: 100% · 24h volume: $840,269 · resolves 2026-08-04
  - (2026-08-04) LoL: T1 vs Hanwha Life Esports - Game 1 Winner
      yes price: 0% · 24h volume: $782,290 · resolves 2026-08-04
  - (2026-08-04) Will the Fed decrease interest rates by 25 bps after the September 2026 meeting?
      yes price: 2% · 24h volume: $597,384 · resolves 2026-09-16
  - (2026-08-04) Will Shakhtar Donetsk win the 2026-27 UEFA Champions League Championship?
      yes price: 0% · 24h volume: $446,845 · resolves 2027-05-30
  - (2026-08-04) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 1% · 24h volume: $342,970 · resolves 2026-09-16

### Paper Trading Scorecard — 9 new of 145 total
  - (2026-08-04) [Polymarket] Iran full airspace closure by August 31?
      This market will resolve to “Yes” if Iran initiates a general closure of its airspace, that is not solely due to weather conditions, between market creation and the specified date, 11:59 PM ET. Otherwise, this market wil…
  - (2026-08-04) [Polymarket] Will Elon Musk post 80-99 tweets from July 31 to August 7, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 31 12:00 PM ET to August 7, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and r…
  - (2026-08-04) [Manifold] Indonesia juara aff 2026
  - (2026-08-04) [Manifold] Will there be a major new AI regulation bill signed in the U.S. before September 30, 2026?
  - (2026-08-04) [Manifold] Will Mitch McConnell make a verifiable, live public appearance before 2027?
  - (2026-08-04) [Manifold] does 2 + 2 = 4

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 37 total
  - (2026-08-04) #30 Germán Larrea Mota Velasco & family — $64.73B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-08-04) MOVER ▼ Bernard Arnault & family — $147.23B ($-2.39B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-04) MOVER ▼ Masayoshi Son — $63.10B ($-1.82B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-08-04) MOVER ▼ Francoise Bettencourt Meyers & family — $94.53B ($-1.43B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-04) MOVER ▼ Mukesh Ambani — $89.23B ($-1.00B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-04) MOVER ▼ Tadashi Yanai & family — $67.28B ($-0.67B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 102 total
  - (2026-08-03) [OFAC] Issuance of Amended Venezuela-related General License and Frequently Asked Question - ofac.treasury.gov
      Issuance of Amended Venezuela-related General License and Frequently Asked Question ofac.treasury.gov
  - (2026-07-30) [OFAC] Counter Terrorism Designations; Non-Proliferation Designation Update - ofac.treasury.gov
      Counter Terrorism Designations; Non-Proliferation Designation Update ofac.treasury.gov
  - (2026-07-29) [OFAC] Iran-related Designations - ofac.treasury.gov
      Iran-related Designations ofac.treasury.gov
  - (2026-08-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra - ofac.treasury.gov
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra ofac.treasury.gov
  - (2026-08-04) [USASpending] $1,608,568,595 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
      Agency: Department of State. Description: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
  - (2026-08-04) [USASpending] $1,589,272,070 → ASSOCIATION OF UNIVERSITIES FOR RESEARCH IN ASTRONOMY, INC.: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT SPAN THE MAJOR
      Agency: National Aeronautics and Space Administration. Description: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT SPAN THE MAJOR PHASES OF THE MISSION BEGINNING WITH FORMULATION THROUGH DEVELOPMENT AND TESTING, AND ENDIN…

### IT, InfoSys & cybersecurity news (last 7 days) — 6 new of 52 total
  - (2026-08-04) [BleepingComputer] Hotel Wi-Fi attacks use custom malware to breach Microsoft 365 accounts
      Microsoft has linked a global campaign targeting hospitality Wi-Fi networks to the Russian threat actor Midnight Blizzard, also known as APT29. [...]
  - (2026-08-04) [The Hacker News] CISA Adds Exploited N-able N-central Flaw to KEV After Customer Compromises
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Monday added a high-severity security flaw impacting N-able N-central to its Known Exploited Vulnerabilities (KEV) catalog following reports of active e…
  - (2026-08-04) [Computer Weekly] Payment fraud a ‘fully fledged’ transnational security threat, says think tank
      Over half the world’s population are targeted by payment scams each week as authorised payment fraud becomes a “fully fledged” global security threat, rather than a consumer protection issue, warns the Royal United Servi…
  - (2026-08-04) [Computer Weekly] The King spoke not a word on AI - then the end of term turned
      There was pomp and pageant at state opening of Parliament some 12 weeks ago. Nothing unusual in that, nor in the lack of any mention of artificial intelligence (AI). In 2024, <a href="https://www.computerweekly.com/news/…
  - (2026-08-04) [Computer Weekly] How AI kicked in for the 2026 FIFA World Cup
      In this week’s Computer Weekly, we go behind the scenes at the technology operations centre for the FIFA World Cup to find out how AI helped make the football even better for fans. Our latest buyer’s guide looks at the i…
  - (2026-08-03) [BleepingComputer] New Pass-ta-key attacks let malware hijack Google-synced passkeys
      Security researchers have discovered three attacks that allow malware on already-compromised Windows devices to abuse Google Password Manager's synced passkeys to take over accounts, bypass user verification, and extract…

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-08-03) U.S. Court of Appeals, 2nd Cir.: Al Saidi v. Blanche
  - (2026-08-03) U.S. Court of Appeals, 2nd Cir.: Mueller v. Deutsche Bank AG
  - (2026-07-30) U.S. Court of Appeals, 1st Cir.: Kim v. Blanche
  - (2026-07-30) U.S. Court of Appeals, 1st Cir.: North End Chamber of Commerce, Inc. v. City of Boston
  - (2026-07-30) U.S. Court of Appeals, 1st Cir.: United States v. Gonzalez

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-04) [Marginal Revolution] The economics of H-1B immigration
      We study the effects of H-1B immigration on U.S. industries that employ H-1B workers and their trading partners. Using a novel cross-industry design and the 1999–2003 expansion of the H-1B visa cap for identification, we…
  - (2026-08-04) [Marginal Revolution] Emergent Ventures winners, 57th cohort
      Oisin O’Gorman, 15, Dublin, misinformation and fakes. Karsen Lee Wahal, Stanford, is AI killing the web?, and measuring media slant. Davy Deng, with Claire Wang (previous winner), whole brain emulation, MIT. Enej Grmek,…

### USGS earthquakes (M4.5+, past day) — 1 new of 9 total
  - (2026-08-04) M 4.6 - 112 km WSW of Puerto Madero, Mexico
      M4.6 · 112 km WSW of Puerto Madero, Mexico · depth 10 km

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: final, program, rulemaking, standard, requires, amend, action, published, proposes, provide, notice, certain
- state_bills: today=0, 7d-median=108, 14d-median=112; carrying terms: child, responsible, reporting, protection, operating, defines, based, allows, activities, issue, updated, creates
- state_news: today=490, 7d-median=758, 14d-median=492; carrying terms: child, women, debate, plant, style, especially, politicians, american, nevada, others, insurance, conference
- local_news: today=206, 7d-median=224, 14d-median=226; carrying terms: close, srcset, sheriff, fatal, magazine, content, saportareport, friday, illinois, scaled, based, family
- foreign_news: today=1000, 7d-median=1022, 14d-median=1006; carrying terms: child, women, german, xuejun, issuer, operation, hardware, style, cabinet, resistance, iranian, american
- chinese_internal: today=256, 7d-median=256, 14d-median=264; carrying terms: china, caixin, global, people, google, chinese, firms, https, record, price, sales, market
- russian_internal: today=943, 7d-median=916, 14d-median=898; carrying terms: reuters, title, russian, novaya, forbidden, europe, telegram, axios, wildberries, istories, client, press
- ukrainian_internal: today=102, 7d-median=133, 14d-median=132; carrying terms: economic, across, reported, dnipropetrovsk, minister, capacity, russian, state, cabinet, damage, sources, iranian
- ukraine_theater: today=242, 7d-median=639, 14d-median=633; carrying terms: cartography, maintained, snapshot, daily, google, alerts, deepstatemap, firms, polygons, token, coverage, community
- paper_bets: today=145, 7d-median=141, 14d-median=136; carrying terms: winner, title, multiple, scheduled, minister, washington, alaska, launch, qualify, state, specified, pennsylvania
- weather: today=146, 7d-median=173, 14d-median=174; carrying terms: rainfall, afdlwx, across, southeastern, impacts, discussion, state, damage, marine, effect, inland, central
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: labor, energy, walcl, pcepilfe, unemployment, payems, consumption, supply, dexjpus, effective, cpilfesl, jolts
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, close, rates, yield, china, crude, corporate, futures, silver, large, equities, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=102, 7d-median=104, 14d-median=104; carrying terms: burundi, economic, agency, entities, space, annexation, technology, contract, bosnia, union, adopted, abuses
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, client, quiverquant, https, httperror, error, congresstrading, quiver, quantitative
- billionaires: today=37, 7d-median=37, 14d-median=37; carrying terms: larry, amazon, tiktok, buffett, technology, mukesh, facebook, canada, brokerage, hathaway, meyers, fashion
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: texas, jones, county, services, court, appeals, supreme, johnson, california, delaware, blanche, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, michael, group
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, talarico, brown, cooper, shawn, graham, raised, senate, house, jonathan, congress, ossoff
- gdelt_regions: today=0, 7d-median=6, 14d-median=9; carrying terms: english, china
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, trump, keywords, netanyahu, spanish, crisis, themes, russian, chinese, israeli
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: crisis, domain, language, english, iheart
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=16; carrying terms: position, canada, belgium, france, ground, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: numbers, increases, discharged, oecusse, parganas, previously, across, beginning, fatality, broader, kozhikode, global
- cisa_kev: today=10, 7d-median=10, 14d-median=11; carrying terms: buffer, point, check, vulnerability, deserialization, fortinet, based, smartconsole, authentication, conflict, inclusion, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=233, 7d-median=286, 14d-median=286; carrying terms: austria, medium, russia, slovakia, indonesia, salvador, hungary, depth, romania, flood, republic, thailand
- usgs_quakes: today=9, 7d-median=17, 14d-median=18; carrying terms: depth, region, islands, japan, russia, mexico, kuril, argentina, severo, puerto
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, returns, traffic, normal, hormuz, august, ceasefire, strait, prime, abiebie
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: class, having, marginal, revolution, economist, https, conversableeconomist, government, conversable, toward, neutral, union
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: ransomware, technology, bleepingcomputer, cyber, weekday, vulnerability, government, attacks, researchers, report, company, systems
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: economic, schweikert, hillary, orden, eleanor, crawford, ilhan, weber, tonko, smucker, union, whitesides
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, module, placed, sufficient, identify, either, paper, decision, consensus, claude, today, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*