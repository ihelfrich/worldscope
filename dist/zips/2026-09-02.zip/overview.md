# WORLDSCOPE morning brief — 2026-09-02

## Headline
3616 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (756) · Russian Internal News (state + in-exile) (701) · Ukraine Theater (total-war monitoring) (498) · State-Level News (326) · World leaders & government officials (324) · Chinese Internal News (229) · Local News: St. Louis + Atlanta (201) · U.S. Weather + Severe / Climate Outlooks (167) · State Legislative Action (64) · Ukrainian Internal News (national + local Kyiv) (55) · IT, InfoSys & cybersecurity news (last 7 days) (43) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 756 new of 1084 total
  - (2026-09-02) [Global] Zelensky says airlines should avoid Russian airspace as Ukraine escalates drone operations
      Chinese and Gulf state airlines are among those still using Russian airspace. Meanwhile, Russia says it will intensify its own attacks on Ukraine.
  - (2026-09-02) [Global] BBC travels inside occupied Lebanon as officials say Israel expanding positions
      A BBC team joined a humanitarian mission of the UN peacekeeping force, which says Israeli troops are fortifying positions and continuing demolitions.
  - (2026-09-02) [Global] Why US troops have a history in this raucous Thai city
      The BBC's Jonathan Head looks at the historical echoes of US troops arriving in Pattaya, a beach resort famous for its racy bars.
  - (2026-09-02) [Global] South Korea jails care home head for sexually assaulting disabled residents
      The man, surnamed Kim, was handed a 15-year prison term for abusing three residents at the facility near Seoul.
  - (2026-09-02) [Global] Bus crash on Egypt's Red Sea coast kills 16
      Another 28 people are injured in the accident in the South Sinai governorate, officials say.
  - (2026-09-02) [Global] Charlie Kirk murder suspect pleads not guilty as judge clears way for death penalty trial
      The 23-year-old is charged with aggravated murder, a capital offence in Utah, and six other counts.

### Russian Internal News (state + in-exile) — 701 new of 1134 total
  - (2026-09-02) Илья Трабер дал первое интервью после освобождения из СИЗО. Он заявил, что благодарен следствию, которое «потратило время, чтобы разобраться» | LEDE: Петербургский бизнесмен Илья Трабер, кот] (ru: Иль…
      Петербургский бизнесмен Илья Трабер, которого в конце августа выпустили из СИЗО, поговорил с изданием «Фонтанка». Это первое интервью Трабера после его освобождения и прекращения уголовного дела против него.
  - (2026-09-02) «Мы к этому готовимся». Глава Минтранса РФ — об угрозах Зеленского сделать небезопасным российское небо | LEDE: Российские авиационные службы не допустят «значимых перерывов» в работе гражда] (ru: «Мы…
      Российские авиационные службы не допустят «значимых перерывов» в работе гражданской авиации, заявил глава Минтранса РФ Андрей Никитин. Так он прокомментировал угрозы президента Украины Владимира Зеленского сделать россий…
  - (2026-09-02) В немецком Аугсбурге рядом с железнодорожным вокзалом произошел взрыв. Движение поездов остановлено | LEDE: Около железнодорожного вокзала в Аугсбурге в Баварии произошел взрыв, пострадали д] (ru: В н…
      Около железнодорожного вокзала в Аугсбурге в Баварии произошел взрыв, пострадали два человека — подростки 17 и 18 лет, получившие легкие травмы.
  - (2026-09-02) Главу благотворительного фонда «Дом с маяком» Лиду Мониаву доставили в СК. Ей грозит уголовное дело о «фейках» о российской армии | LEDE: Главу благотворительного фонда «Дом с маяком» Лиду М] (ru: Гла…
      Главу благотворительного фонда «Дом с маяком» Лиду Мониаву утром 2 сентября доставили в Следственный комитет, сообщил «Медузе» один из ее адвокатов.
  - (2026-09-02) Авиакомпания Pegasus отменила рейсы между Москвой и Турцией после предупреждения Зеленского о небезопасности российского неба | LEDE: Турецкая бюджетная авиакомпания Pegasus отменила как мин] (ru: Ави…
      Турецкая бюджетная авиакомпания Pegasus отменила как минимум один рейс из Бодрума в Москву, который должен был вылететь в 00:05 в ночь на 2 сентября, пишет телеграм-канал «Осторожно, новости».
  - (2026-09-02) FT: Россия тайно помогала Ирану разрабатывать сверхзвуковые крылатые ракеты | LEDE: Россия в рамках секретной программы под кодовым названием C430L с 2023 года помогала Ирану разрабатывать с] (ru: FT:…
      Россия в рамках секретной программы под кодовым названием C430L с 2023 года помогала Ирану разрабатывать современные сверхзвуковые крылатые ракеты, пишет Financial Times.

### Ukraine Theater (total-war monitoring) — 498 new of 677 total
  - (2026-09-02) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-01) [FIRMS] thermal anomaly 44.848, 34.237 (FRP 14.13 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-01 0941Z, FRP 14.13 MW
  - (2026-09-01) [FIRMS] thermal anomaly 44.846, 34.231 (FRP 14.13 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-01 0941Z, FRP 14.13 MW
  - (2026-09-01) [FIRMS] thermal anomaly 44.850, 34.232 (FRP 14.46 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-01 0941Z, FRP 14.46 MW
  - (2026-09-01) [FIRMS] thermal anomaly 44.852, 34.238 (FRP 14.46 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-01 0941Z, FRP 14.46 MW
  - (2026-09-01) [FIRMS] thermal anomaly 45.437, 34.630 (FRP 10.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-01 0941Z, FRP 10.29 MW

### State-Level News — 326 new of 736 total
  - (2026-09-01) [California] 15,000+ arrests. 7,000+ stolen vehicles recovered. Crime Suppression Teams deliver results across California
      Source
  - (2026-09-01) [California] Governor Newsom visits CHP Academy, highlights next generation of officers and California’s public safety progress
      Source
  - (2026-09-01) [Alabama] Governor Ivey Honors the Life and Legacy of Dolly Parton, Provides Update on Dolly Parton Imagination Library in Alabama
      MONTGOMERY – Governor Kay Ivey on Tuesday joined Alabamians and people across the country in mourning the passing of Dolly Parton, whose extraordinary life and legacy touched generations through her music, generosity and…
  - (2026-09-01) [Alabama] Analysis | Tuberville brief offers court a path to affirm dismissal
  - (2026-09-01) [Alabama] Opinion | Could it be—an Alabama governor’s race with substance?
  - (2026-09-01) [Alabama] Opinion | My game plan for data centers

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 229 new of 296 total
  - (2026-08-31) Cover Story: How U.S. Tech Blockade Sparked China’s AI Chip Boom - caixinglobal.com
      Cover Story: How U.S. Tech Blockade Sparked China’s AI Chip Boom caixinglobal.com
  - (2026-09-01) China Slashes Hidden Local Government Debt by Half in Two Years - caixinglobal.com
      China Slashes Hidden Local Government Debt by Half in Two Years caixinglobal.com
  - (2026-08-31) Xi and Putin Pledge Deeper Coordination at SCO Summit in Bishkek - caixinglobal.com
      Xi and Putin Pledge Deeper Coordination at SCO Summit in Bishkek caixinglobal.com
  - (2026-09-01) Beijing Scraps Longstanding Tax Break for Foreign Investors’ Dividends - caixinglobal.com
      Beijing Scraps Longstanding Tax Break for Foreign Investors’ Dividends caixinglobal.com
  - (2026-09-01) Former Top Political Adviser and Acclaimed Musician Sentenced to 15 Years for Corruption - caixinglobal.com
      Former Top Political Adviser and Acclaimed Musician Sentenced to 15 Years for Corruption caixinglobal.com
  - (2026-09-01) 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxPazgtWEZMRlJNMTJXQnZhdzMyQnp0SWZiamFBbjFIVGFqdzJKVkZxU2dNZ0loeVIzTFBSLUxzZHVzUHdscXdpb] (zh:…
      责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn 人民日报

### Local News: St. Louis + Atlanta — 201 new of 239 total
  - (2026-09-01) [St. Louis] South County man shouted racial slur, opened fire on teen
      A South County man in his 40s turned himself into police on Monday after allegedly going on a racial slur-filled rampage at his apartment complex off Lemay Ferry Road. Kyle C. Blair is currently in St. Louis County Jail…
  - (2026-09-01) [St. Louis] Where in Chesterfield 9/2/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-09-01) [St. Louis] St. Louis mom launches line of plant-dyed baby essentials
      Emily Hiemenz knew what her daughter’s baby blanket was made from, but she wondered: What gave it its color? After becoming a mother, Hiemenz began asking the same question about all sorts of products. “I started thinkin…
  - (2026-09-01) [St. Louis] Café O’Play will bring coffee, food, and kid-friendly play to University City this fall
      Parents can bring their kids to plenty of coffee shops across the metro area. Café O’Play (6757 Olive, University City), however, wants to be a coffee shop where families feel like they were actually invited. Slated to o…
  - (2026-09-01) [St. Louis] 5 must-hit Labor Day weekend events in St. Louis
      Gateway Cup | September 4–7 Zoom through some of the city’s coolest neighborhoods on two wheels, or cheer from the sidelines as your favorites show off their need for speed. The Gateway Cup closes out summer every year,…
  - (2026-09-01) [St. Louis] Innovation Week looks to fill the gap of entrepreneurial focused events in St. Louis this fall
      Mike Seper wasn’t intending to organize a series of innovation-focused events this October, but the director of innovation and intellectual property at the University of Missouri-St. Louis jumped in when he saw an autumn…

### U.S. Weather + Severe / Climate Outlooks — 167 new of 168 total
  - (2026-09-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-02) [Moderate] Special Weather Statement: Special Weather Statement issued September 2 at 4:22AM CDT by NWS Milwaukee/Sullivan WI
      At 422 AM CDT, Doppler radar was tracking a strong thunderstorm near Princeton, or 8 miles west of Berlin, moving northeast at 55 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds coul…
  - (2026-09-02) [Moderate] Gale Warning: Gale Warning issued September 2 at 2:21AM PDT until September 2 at 11:00PM PDT by NWS Seattle WA
      * WHAT...Southeast winds 25 to 35 kt. * WHERE...East Entrance U. S. Waters Strait Of Juan De Fuca, Northern Inland Waters Including The San Juan Islands and Admiralty Inlet. * WHEN...Until 11 PM PDT this evening. * IMPAC…
  - (2026-09-02) [Moderate] Gale Warning: Gale Warning issued September 2 at 2:21AM PDT until September 2 at 5:00PM PDT by NWS Seattle WA
      * WHAT...South winds 25 to 35 kt and seas 8 to 13 ft. * WHERE...Coastal Waters from Cape Flattery to Cape Shoalwater out to 60 nm. * WHEN...Until 5 PM PDT this afternoon. * IMPACTS...Strong winds will cause hazardous sea…
  - (2026-09-02) [Moderate] Special Weather Statement: Special Weather Statement issued September 2 at 5:21AM EDT by NWS Detroit/Pontiac MI
      At 521 AM EDT, Doppler radar was tracking a strong thunderstorm near Marion Springs, or 9 miles west of Chesaning, moving east at 40 mph. HAZARD...Winds in excess of 40 mph and penny size hail. SOURCE...Radar indicated.…
  - (2026-09-02) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 2 at 4:18AM CDT until September 2 at 5:00AM CDT by NWS La Crosse WI
      SVRARX The National Weather Service in La Crosse has issued a * Severe Thunderstorm Warning for... Mower County in southeastern Minnesota... * Until 500 AM CDT. * At 417 AM CDT, a severe thunderstorm was located over Ros…

### State Legislative Action — 64 new of 72 total
  - (2026-09-02) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-09-02) [Alaska HB 96] An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
      An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
  - (2026-09-02) [Alaska HJR 23] Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
      Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
  - (2026-09-02) [Alaska HB 10] An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
      An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
  - (2026-09-02) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…
  - (2026-09-01) [Arizona SB 1480] crime-free lease addendum; renters.
      crime-free lease addendum; renters.

### Ukrainian Internal News (national + local Kyiv) — 55 new of 111 total
  - (2026-09-02) Глава МЗС Італії припустив, що Росія втручатиметься у парламентські вибори в країні | LEDE: Італійський міністр закордонних справ Антоніо Таяні висловив занепокоєння, що Росія може втрутитися в] (uk:…
      Італійський міністр закордонних справ Антоніо Таяні висловив занепокоєння, що Росія може втрутитися в парламентські вибори в Італії, які заплановані на 2027 рік.
  - (2026-09-02) Під час вибуху на вокзалі в Німеччині постраждали українці – ЗМІ | LEDE: На вокзалі в Аугсбурзі стався вибух, поранені українські громадяни 17 і 18 років. Рух потягів зупинено, триває розслідув] (uk:…
      На вокзалі в Аугсбурзі стався вибух, поранені українські громадяни 17 і 18 років. Рух потягів зупинено, триває розслідування поліції.
  - (2026-09-02) Полк "Скеля" перейшов в оперативне підпорядкування корпусу "Азов" і вже виконує бойові завдання | LEDE: 425-й окремий штурмовий полк "Скеля" перейшов до підпорядкування корпусу НГУ "Азов". Трив] (uk:…
      425-й окремий штурмовий полк "Скеля" перейшов до підпорядкування корпусу НГУ "Азов". Триває переміщення та об'єднання сил полку на фронті.
  - (2026-09-02) Умланд: Захід має перестати дозволяти ядерним погрозам Кремля стримувати допомогу Україні | LEDE: ] (uk: Умланд: Захід має перестати дозволяти ядерним погрозам Кремля стримувати допомог)
  - (2026-09-02) "Європа має бути готовою": У НАТО назвали підозрілими останні інциденти в різних країнах | LEDE: Командування об'єднаних сил НАТО повідомило про підозрілі атаки на інфраструктуру та порушення п] (uk:…
      Командування об'єднаних сил НАТО повідомило про підозрілі атаки на інфраструктуру та порушення простору в різних країнах Європи.
  - (2026-09-02) УП: На місце протистояння СБУ і ГУР у Києві прибули працівники ДБР і керівник "Альфи" | LEDE: На місце протистояння воєнної розвідки і Служби безпеки України у Києві прибули представники Держав] (uk:…
      На місце протистояння воєнної розвідки і Служби безпеки України у Києві прибули представники Державного бюро розслідувань і керівник ЦСО "А" СБУ.

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 57 total
  - (2026-09-02) [BleepingComputer] US charges Russian for infecting 80,000 freelancers with malware
      A California federal grand jury has indicted a Russian national for his role in a phishing campaign that infected thousands of freelancers with TVRAT and DarkVNC malware. [...]
  - (2026-09-02) [BleepingComputer] Sality botnet infrastructure dismantled in joint global takedown
      International law enforcement agencies and private partners have seized Sality malware infrastructure in a joint action aiming to disrupt and take down the peer-to-peer (P2P) botnet. [...]
  - (2026-09-02) [BleepingComputer] SonicWall warns of actively exploited SMA1000 zero-day flaws
      SonicWall warned customers that threat actors are chaining two new SMA1000 zero-day vulnerabilities in remote code execution attacks. [...]
  - (2026-09-02) [The Hacker News] GeoNetwork Fixes Unauthenticated RCE Chain Affecting Government Geoportal Backends
      Two vulnerabilities in GeoNetwork can be chained to achieve unauthenticated remote code execution (RCE) on the open-source geospatial metadata catalog, which sits behind many government and agency geoportals. The project…
  - (2026-09-02) [The Hacker News] Extradited Russian Hacker Faces Charges Over Excel Malware Campaign That Infected Thousands
      The U.S. Department of Justice (DoJ) has charged a Russian national, extradited from Cyprus on August 28, with using roughly 255 fake accounts on a freelance platform to send malware-laced Excel attachments to about 80,0…
  - (2026-09-02) [The Hacker News] Researchers Use Claude to Port Pre-Auth RCE Exploit From One PLC Model to Another
      Forescout Research - Vedere Labs said it used Anthropic's Claude to port a working pre-authentication remote code execution (RCE) exploit from one WAGO programmable logic controller (PLC) to another, executing attacker-s…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-02) [Bristol James Arthur] Form 4 (Reporting)
      filed 2026-09-02 01:59 UTC · role: Reporting — Filed: 2026-09-01 AccNo: 0001493152-26-041137 Size: 8 KB
  - (2026-09-02) [Ernexa Therapeutics Inc.] Form 4 (Issuer)
      filed 2026-09-02 01:59 UTC · role: Issuer — Filed: 2026-09-01 AccNo: 0001493152-26-041137 Size: 8 KB
  - (2026-09-02) [Cicala Peter] Form 4 (Reporting)
      filed 2026-09-02 01:56 UTC · role: Reporting — Filed: 2026-09-01 AccNo: 0001493152-26-041135 Size: 8 KB
  - (2026-09-02) [Ernexa Therapeutics Inc.] Form 4 (Issuer)
      filed 2026-09-02 01:56 UTC · role: Issuer — Filed: 2026-09-01 AccNo: 0001493152-26-041135 Size: 8 KB
  - (2026-09-02) [Polinsky David] Form 4 (Reporting)
      filed 2026-09-02 01:49 UTC · role: Reporting — Filed: 2026-09-01 AccNo: 0001493152-26-041133 Size: 6 KB
  - (2026-09-02) [Ernexa Therapeutics Inc.] Form 4 (Issuer)
      filed 2026-09-02 01:49 UTC · role: Issuer — Filed: 2026-09-01 AccNo: 0001493152-26-041133 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-02) [India] Vijaya Lakshmi Pandit : the lamp of India
      domain: thehindu.com · language: English · tone:
  - (2026-09-02) [United States] Report : South Florida hospitals would absorb over two - thirds of Amendment 3 healthcare impact | Health Wellness
      domain: miamitimesonline.com · language: English · tone:
  - (2026-09-02) [India] Lindsay Clancy : Netizens fume as TikTok trend shows women pretending to harm their kids , Totally sick and demented
      domain: hindustantimes.com · language: English · tone:
  - (2026-09-02) [Trinidad and Tobago] US Energy Secretary Wright to visit Venezuela amid Chevron plans to expand operations
      domain: trinidadtimes.com · language: English · tone:
  - (2026-09-02) [China] What Shenzhen transformation reveals about the path to an Asia - Pacific community
      domain: en.people.cn · language: English · tone:
  - (2026-09-02) [China] Climate change warnings preceded Nepal disaster , say experts
      domain: eco-business.com · language: English · tone:

### Court opinions of consequence (federal & state) — 33 new of 60 total
  - (2026-09-01) U.S. Court of Appeals, 8th Cir.: Don Gibson v. James Mullis
  - (2026-09-01) U.S. Court of Appeals, 8th Cir.: United States v. Candace Scott
  - (2026-09-01) U.S. Court of Appeals, 8th Cir.: United States v. Hector Benavidez
  - (2026-09-01) U.S. Court of Appeals, D.C. Cir.: John Doe v. SEC
  - (2026-09-01) U.S. Court of Appeals, D.C. Cir.: Medical Imaging & Technology Alliance v. Library of Congress
  - (2026-09-01) U.S. Court of Appeals, D.C. Cir.: Robert Bergdahl v. United States

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-09-02) GAF182 (Germany)
      icao24: 3e8b41 · position: (42.963, 15.1344) · alt: 10660m · 783km/h
  - (2026-09-02) GAF219 (Germany)
      icao24: 3f6219 · position: (52.4566, 11.7217) · alt: 6088m · 516km/h
  - (2026-09-02) GAF144 (Germany)
      icao24: 3f7588 · position: (47.941, 16.1901) · alt: 8221m · 823km/h
  - (2026-09-02) GAF297 (Germany)
      icao24: 3ea1cc · position: (52.7102, 10.1875) · alt: 403m · 200km/h
  - (2026-09-02) PLAT13 (United Kingdom)
      icao24: 43029a · position: (49.0774, 21.0966) · alt: 259m
  - (2026-09-02) SAMU13 (France)
      icao24: 39c902 · position: (43.8857, 4.8221) · alt: 289m · 217km/h

### Paper Trading Scorecard — 27 new of 132 total
  - (2026-09-02) [Polymarket] Will Trump be impeached before his term ends?
      This market will resolve to “Yes“ if the US House of Representatives, by simple majority vote, approves or passes one or more articles of impeachment of President Donald Trump between market creation and January 20, 2029…
  - (2026-09-02) [Polymarket] Will AfD win the most seats in the 2026 Sachsen-Anhalt parliamentary elections?
      Parliamentary elections to elect the Landtag of Sachsen-Anhalt are scheduled to take place on September 6, 2026. This market will resolve to the political party that wins the greatest number of seats in the state parliam…
  - (2026-09-02) [Polymarket] Will the Fed decrease interest rates by 25 bps after the December 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-09-02) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-09-02) [Manifold] Daily Coinflip
  - (2026-09-02) [Manifold] Will I regret purchasing a Dyson camerajet? ($500USD Toothbrush)

### USGS earthquakes (M4.5+, past day) — 18 new of 19 total
  - (2026-09-02) M 5.6 - 159 km WSW of Abepura, Indonesia
      M5.6 · 159 km WSW of Abepura, Indonesia · depth 69.052 km
  - (2026-09-02) M 5.3 - 66 km NNW of Arthurs Point, New Zealand
      M5.3 · 66 km NNW of Arthurs Point, New Zealand · depth 10 km
  - (2026-09-02) M 5.2 - 70 km NNW of Arthurs Point, New Zealand
      M5.2 · 70 km NNW of Arthurs Point, New Zealand · depth 10 km
  - (2026-09-02) M 5.2 - 95 km SSW of Nikolski, Alaska
      M5.2 · 95 km SSW of Nikolski, Alaska · depth 35 km
  - (2026-09-01) M 5.2 - 35 km SE of Sarangani, Philippines
      M5.2 · 35 km SE of Sarangani, Philippines · depth 120.779 km
  - (2026-09-01) M 5.0 - 118 km SSE of Isangel, Vanuatu
      M5.0 · 118 km SSE of Isangel, Vanuatu · depth 122.461 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-09-02) LoL: Hanwha Life Esports vs T1 - Game 1 Winner
      yes price: 0% · 24h volume: $1,607,358 · resolves 2026-09-02
  - (2026-09-02) LoL: Hanwha Life Esports vs T1 - Game 2 Winner
      yes price: 4% · 24h volume: $1,479,710 · resolves 2026-09-02
  - (2026-09-02) LoL: Hanwha Life Esports vs T1 (BO5) - LCK Playoffs
      yes price: 22% · 24h volume: $1,127,135 · resolves 2026-09-02
  - (2026-09-02) Will John Fetterman win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $1,025,010 · resolves 2028-11-07
  - (2026-09-02) Will Tulsi Gabbard win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $643,685 · resolves 2028-11-07
  - (2026-09-02) US Open WTA: Daria Kasatkina vs Paula Badosa
      yes price: 8% · 24h volume: $485,056 · resolves 2026-09-06

### U.S. Federal Action — 10 new of 16 total
  - (2026-09-02) Continuation of the National Emergency With Respect to Foreign Interference in or Undermining Public Confidence in United States Elections
  - (2026-09-02) Honoring the American History of the Great Lakes and Renaming Lake Ontario as Lake America
  - (2026-09-02) Repeal of Fossil Fuel Restrictions for New Federal Buildings and Major Renovations of Federal Buildings
      The Department of Energy (DOE) is reviewing its recent guidance related to the implementation of newly adopted provisions regarding Clean Energy for New Federal Buildings and Major Renovations of Federal Buildings (CER).…
  - (2026-09-02) Safety Zone; Bay Bridge Paddle; Chesapeake Bay, Annapolis, MD
      The Coast Guard is establishing a temporary safety zone for navigable waters of the Chesapeake Bay, adjacent to the shoreline at Sandy Point State Park and between and adjacent to the spans of the William P. Lane Jr. Mem…
  - (2026-09-02) Safety Zone; Lake St. Clair, Grosse Pointe Farms, MI
      The Coast Guard is establishing a temporary safety zone for the navigable waters of Lake St. Clair for a fireworks display. The safety zone is needed to protect personnel, vessels, and the marine environment from potenti…
  - (2026-09-02) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA proposes to supersede Airworthiness Directive (AD) 2021-17-07, which applies to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2021-17-07 requires inspecting for damage…

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 109 total
  - (2026-09-02) [USASpending] $35,199,796,917 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-09-02) [USASpending] $27,613,237,659 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-09-02) [USASpending] $22,442,309,468 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-09-02) [USASpending] $19,926,468,210 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-09-02) [USASpending] $14,753,060,287 → FLUOR MARINE PROPULSION, LLC: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND NAVAL NUCLEAR PROPULSION PROGRAM SUPPORT
  - (2026-09-02) [USASpending] $3,572,209,102 → PANTEXAS DETERRENCE, LLC: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION
      Agency: Department of Energy. Description: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION OF THE PANTEX PLANT

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-02) [Marginal Revolution] America is still poised for a data center boom
      Eric Levitz, via Matt Yglesias. The post America is still poised for a data center boom appeared first on Marginal REVOLUTION.
  - (2026-09-02) [Marginal Revolution] The College Wage Premium in the Generative AI Era
      After expanding for four decades, the U.S. college wage premium is experiencing a sustained contraction, dropping sharply from 0.626 in 2022 to 0.575 in 2026. Using Current Population Survey Outgoing Rotation Group data…
  - (2026-09-01) [Marginal Revolution] Who values democracy?
      This paper examines the conventional view that redistribution is central to the democratization process using data from stock markets. Consistent with this view, democratizations have a large, negative impact on asset va…
  - (2026-09-01) [Conversable Economist] The Bank of North America (Before Hamilton’s First Bank of the United States)
      Thanks to the power of musical theater and the genius of Lin-Manuel Miranda, I can now speak in public spaces about Alexander Hamilton and the First Bank of the United States without watching people’s eyes glaze over in…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=16, 7d-median=27, 14d-median=23; carrying terms: proposed, public, national, specifically, safety, certain, temporary, unless, management, service, published, amends
- state_bills: today=72, 7d-median=78, 14d-median=86; carrying terms: agencies, within, order, request, establishes, safety, district, certain, things, beginning, community, requiring
- state_news: today=736, 7d-median=648, 14d-median=614; carrying terms: raise, although, within, senate, filed, opinion, august, elected, court, request, kansas, thursday
- local_news: today=239, 7d-median=239, 14d-median=238; carrying terms: trump, blank, august, court, driver, width, shooting, murder, district, south, killed, atlanta
- foreign_news: today=1084, 7d-median=1048, 14d-median=1034; carrying terms: region, investments, raise, contest, errno, composition, currently, bribery, improvements, timed, investors, showing
- chinese_internal: today=296, 7d-median=296, 14d-median=290; carrying terms: cbmiw, caixin, google, articles, https, cbmix, lxtfa, cbmixkfvx, china, cbmickfvx, cbmiakfvx, blank
- russian_internal: today=1134, 7d-median=1074, 14d-median=1052; carrying terms: novaya, financial, error, wildberries, reuters, times, novayagazeta, social, media, istories, telegram, found
- ukrainian_internal: today=111, 7d-median=122, 14d-median=117; carrying terms: region, remains, logistics, error, august, regional, damaged, visit, launched, energy, intelligence, missile
- ukraine_theater: today=677, 7d-median=236, 14d-median=784; carrying terms: region, cuxnujh, ntdvroexxetjsuuy, mzlnblvpu, jqamsyoepen, axhim, fsmwnfnwlnnuhxtg, armed, cjlmahr, restore, cbmiwgfbvv, cuxoa
- paper_bets: today=132, 7d-median=132, 14d-median=132; carrying terms: secretary, democratic, james, donald, place, trump, mamdani, earthquake, lifetime, humanoid, theme, midterm
- weather: today=168, 7d-median=133, 14d-median=144; carrying terms: region, remains, wednesday, radar, small, houston, result, humid, forecasts, streams, impacts, bring
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: money, dexchus, consumption, supply, unrate, commodities, dexjpus, energy, funds, unemployment, payems, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, close, agriculture, commodities, yield, credit, futures, natural, equities, crypto, large, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=109, 7d-median=109, 14d-median=106; carrying terms: institute, integrated, democratic, region, adopted, forward, satisfying, snapshot, accordance, campaign, alliance, space
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, quiver, client, congresstrading, httperror, error, quiverquant, unauthorized, https
- billionaires: today=0, 7d-median=0, 14d-median=15
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, supreme, delaware, appeals, america, smith, company, connecticut, services, center, estate
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, holdings, brian, michael, david, robert, wupen, lumentum, therapeutics
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: house, receipts, james, talarico, robert, sherrod, graham, cycle, johnson, angels, david, raised
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: english, trump, keywords, jpost, themes, against, ukrainian, sanctions, russian, strikes, indiatimes, russia
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: trump, hospital, police, health, english, kingdom, domain, iheart, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, ground, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=0, 7d-median=40, 14d-median=40; carrying terms: institute, region, democratic, substantial, remains, alerted, summarizes, diphtheria, geographical, manifestations, cluster, awareness
- cisa_kev: today=17, 7d-median=20, 14d-median=15; carrying terms: server, product, request, authentication, improper, function, microsoft, forgery, injection, vulnerability, vendor, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=19, 7d-median=13, 14d-median=14; carrying terms: depth, indonesia, islands, japan, ruteng, chile, philippines, tonga, ridge, kuril, vanuatu, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: championship, decrease, champions, price, volume, shakhtar, meeting, donetsk, league, resolves, september, interest
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, marginal, conversable, class, revolution, https, together, demand, shows, future, years, center
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: artificial, systems, million, going, against, computerweekly, intelligence, weekly, incident, models, around, world
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: brecheen, gooden, philip, ezell, donald, mcmahon, speech, christopher, kaptur, trump, warsh, finstad
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, claude, unavailable, converges, sufficient, consensus, today, paper, either, decision, module, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*