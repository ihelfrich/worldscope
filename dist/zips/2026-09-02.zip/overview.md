# WORLDSCOPE morning brief — 2026-09-02

## Headline
3429 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (801) · Russian Internal News (state + in-exile) (750) · State-Level News (367) · World leaders & government officials (324) · Chinese Internal News (252) · Local News: St. Louis + Atlanta (212) · U.S. Weather + Severe / Climate Outlooks (173) · Ukraine Theater (total-war monitoring) (79) · State Legislative Action (66) · Ukrainian Internal News (national + local Kyiv) (66) · IT, InfoSys & cybersecurity news (last 7 days) (44) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 801 new of 1097 total
  - (2026-09-02) [Global] Guinea-Bissau voters approve new constitution expanding presidential powers
  - (2026-09-02) [Global] Almost half of world’s farmers poisoned by pesticides every year, experts find
  - (2026-09-01) [Global] Mark Carney tells US to ‘start being serious’ amid escalating trade war
  - (2026-09-01) [Global] MapQuest app reaches No 1 on US Apple list after defying Trump’s Lake Ontario order
  - (2026-09-01) [Global] Echoes of cold war as US accused of meddling in another Brazilian election
  - (2026-09-01) [Global] Trump suggests he is reviewing US support for UK over Falkland Islands

### Russian Internal News (state + in-exile) — 750 new of 1181 total
  - (2026-09-02) В Киеве то ли похитили, то ли задержали заместителя командира «Русского добровольческого корпуса» (воюет на стороне ВСУ). Из-за этого сотрудники украинских спецслужб устроили перестрелку | LEDE] (ru:…
      Служба безопасности Украины утром 2 сентября объявила, что совместно с украинской военной разведкой (ГУР) предотвратила теракт, который готовила ФСБ против «одного из лидеров российского оппозиционного политического наци…
  - (2026-09-02) Бывшего главу Росавиации Александра Нерадько отпустили из СИЗО под домашний арест. Его обвиняют в хищениях в Домодедово | LEDE: Мосгорсуд перевел бывшего главу Росавиации Александра Нерадько] (ru: Быв…
      Мосгорсуд перевел бывшего главу Росавиации Александра Нерадько, которого обвиняют в мошенничестве, из СИЗО под домашний арест. Об этом РБК сообщили два источника, знакомые с ходом процесса.
  - (2026-09-02) Телеканалы в России обязаны тратить время на дебаты перед выборами. Вот только сами партии на них не ходят. Подборка абсурдных видео | LEDE: На российском ТВ начались теледебаты перед выбора] (ru: Тел…
      На российском ТВ начались теледебаты перед выборами в Госдуму. По закону государственные телеканалы обязаны предоставлять партиям и кандидатам бесплатное эфирное время, однако полностью заполнить этот объем агитационным…
  - (2026-09-02) В Перми загорелся цех завода «Роскосмоса» | LEDE: В поселке Новые Ляды в Свердловском районе Перми загорелся цех предприятия, сообщает местное издание 59.ru. ] (ru: В Перми загорелся цех завода «Роско…
      В поселке Новые Ляды в Свердловском районе Перми загорелся цех предприятия, сообщает местное издание 59.ru.
  - (2026-09-02) Илья Трабер дал первое интервью после освобождения из СИЗО. Он заявил, что благодарен следствию, которое «потратило время, чтобы разобраться» | LEDE: Петербургский бизнесмен Илья Трабер, кот] (ru: Иль…
      Петербургский бизнесмен Илья Трабер, которого в конце августа выпустили из СИЗО, поговорил с изданием «Фонтанка». Это первое интервью Трабера после его освобождения и прекращения уголовного дела против него.
  - (2026-09-02) «Мы к этому готовимся». Глава Минтранса РФ — об угрозах Зеленского сделать небезопасным российское небо | LEDE: Российские авиационные службы не допустят «значимых перерывов» в работе гражда] (ru: «Мы…
      Российские авиационные службы не допустят «значимых перерывов» в работе гражданской авиации, заявил глава Минтранса РФ Андрей Никитин. Так он прокомментировал угрозы президента Украины Владимира Зеленского сделать россий…

### State-Level News — 367 new of 770 total
  - (2026-09-01) [Alabama] Governor Ivey Honors the Life and Legacy of Dolly Parton, Provides Update on Dolly Parton Imagination Library in Alabama
      MONTGOMERY – Governor Kay Ivey on Tuesday joined Alabamians and people across the country in mourning the passing of Dolly Parton, whose extraordinary life and legacy touched generations through her music, generosity and…
  - (2026-09-01) [California] 15,000+ arrests. 7,000+ stolen vehicles recovered. Crime Suppression Teams deliver results across California
      Source
  - (2026-09-01) [California] Governor Newsom visits CHP Academy, highlights next generation of officers and California’s public safety progress
      Source
  - (2026-09-02) [California] In standoff with Newsom, California Democrats claw back $450 million for climate projects
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/09/042220_Housing-Construction_BANG_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-09-01) [California] Why a bill to juice condo construction died even though California lawmakers voted for it
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/02/080719_LosAngeles_AW_CM_61.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-09-01) [California] California utilities to reclaim unused money from school air conditioning program
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/111222_Lake-Marie-Elementary_LJ_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 252 new of 300 total
  - (2026-09-01) 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxPazgtWEZMRlJNMTJXQnZhdzMyQnp0SWZiamFBbjFIVGFqdzJKVkZxU2dNZ0loeVIzTFBSLUxzZHVzUHdscXdpb] (zh:…
      责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn 人民日报
  - (2026-09-02) 习近平同埃及总统塞西会谈 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5ldXBVOXRUa1lCZ2VRNGQ4Zkp3R2VKTkExN0lIbXpBZ0M3dzNDbVFvZWJ6WTR3eGR1Z2VwRGFSOVZVdFpVWmZrRnZRWGpzTV9fd0F] (zh:…
      习近平同埃及总统塞西会谈 人民网-图片频道
  - (2026-09-01) 习近平抵达开罗对埃及进行国事访问 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9PMXlBODR0bmtPR3BQX0lyVVFMclpiVVBRVUVwazlCRWpNc0Z6ejcyenZ2ejZJNEhRdmFUckNtNkx5YnliNVQ4aUExMktlbDN] (zh:…
      习近平抵达开罗对埃及进行国事访问 人民网-图片频道
  - (2026-09-02) 2026年韩国品牌大奖今日揭晓 - 人民网韩国频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE52Z2ZSRXRPMTFueVRpck8tZG9kaTBBd0RHMXhVSzZwX0RHVThjcUpKdDlkd2ZYSUR0eU92OGJlR21lLVdlbnQ5dEpZRkwzTWhTX] (zh:…
      2026年韩国品牌大奖今日揭晓 人民网韩国频道
  - (2026-09-02) 第十四届范敬宜新闻教育奖申报通知（2026年）--传媒 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTFBvNjhxSXh5dnRUc2pKQjdkQnlsTWtUbnByVFJIdzBWZGhWTG8wV01nZ18xaDlxbzZBRDA3RjVwZ2ZIQzBnQ2RsbF9mW] (zh:…
      第十四届范敬宜新闻教育奖申报通知（2026年）--传媒 人民网
  - (2026-09-01) 山东荣成： 千帆竞发开启秋捕 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBTM0kydVoxTkNvVlRwR3RMR2liY2haeHJxZ1pDOUotQmlzdjY5VzBPV1dGcW5SdlA3SFdYMGlaclNaV19Ya3ZRdWJoTi1nNEExbWRTa] (zh:…
      山东荣成： 千帆竞发开启秋捕 人民图片

### Local News: St. Louis + Atlanta — 212 new of 243 total
  - (2026-09-02) [St. Louis] A home in the Grand Center Arts District hits the market
      Contemporary LivingDesigned by renowned MOS Architects, this single-family residence blends both contemporary and outdoor living. Expansive glass walls throughout the house frame views of the surrounding gardens and outd…
  - (2026-09-02) [St. Louis] 5 ways St. Louis can take care of its e-bike problem
      As St. Louis continues to be smothered by an avalanche of technology-driven problems like computer-assisted carjackings and energy-guzzling data centers, there’s only one problem we can all agree is worse than all of the…
  - (2026-09-02) [St. Louis] St. Louis is already seeing results from Missouri legislature’s plan to revitalize downtowns
      There was fanfare and palpable relief earlier this year when Governor Mike Kehoe signed into law sweeping legislation designed to boost the economic prospects of downtowns across the state. And now, backers of the Missou…
  - (2026-09-01) [St. Louis] South County man shouted racial slur, opened fire on teen
      A South County man in his 40s turned himself into police on Monday after allegedly going on a racial slur-filled rampage at his apartment complex off Lemay Ferry Road. Kyle C. Blair is currently in St. Louis County Jail…
  - (2026-09-01) [St. Louis] Where in Chesterfield 9/2/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-09-01) [St. Louis] St. Louis mom launches line of plant-dyed baby essentials
      Emily Hiemenz knew what her daughter’s baby blanket was made from, but she wondered: What gave it its color? After becoming a mother, Hiemenz began asking the same question about all sorts of products. “I started thinkin…

### U.S. Weather + Severe / Climate Outlooks — 173 new of 173 total
  - (2026-09-02) [Severe] Flash Flood Warning: Flash Flood Warning issued September 2 at 6:53AM CDT until September 2 at 9:30AM CDT by NWS Houston/Galveston TX
      FFWHGX The National Weather Service in Houston/Galveston has issued a * Flash Flood Warning for... Northeastern Liberty County in southeastern Texas... * Until 930 AM CDT. * At 653 AM CDT, Doppler radar and automated rai…
  - (2026-09-02) [Severe] Special Marine Warning: Special Marine Warning issued September 2 at 6:53AM CDT until September 2 at 7:45AM CDT by NWS Houston/Galveston TX
      SMWHGX The National Weather Service in League City has issued a * Special Marine Warning for... Coastal waters from High Island to Freeport TX out 20 NM... Galveston Bay... * Until 745 AM CDT. * At 653 AM CDT, a shower w…
  - (2026-09-02) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 2 at 7:52AM EDT until September 2 at 8:45AM EDT by NWS Cleveland OH
      SVRCLE The National Weather Service in Cleveland has issued a * Severe Thunderstorm Warning for... Eastern Ashtabula County in northeastern Ohio... Western Crawford County in northwestern Pennsylvania... * Until 845 AM E…
  - (2026-09-02) [Extreme] Tornado Warning: Tornado Warning issued September 2 at 7:51AM EDT until September 2 at 8:15AM EDT by NWS State College PA
      TORCTP The National Weather Service in State College PA has issued a * Tornado Warning for... Southern Warren County in north central Pennsylvania... * Until 815 AM EDT. * At 751 AM EDT, a severe thunderstorm capable of…
  - (2026-09-02) [Moderate] Wind Advisory: Wind Advisory issued September 2 at 4:49AM PDT until September 2 at 5:00PM PDT by NWS Seattle WA
      * WHAT...South winds 20 to 35 mph expected. * WHERE...Grays Harbor County Coast and Northern Washington Coast. * WHEN...Until 5 PM PDT this afternoon. * IMPACTS...Gusty winds will blow around unsecured objects. Tree limb…
  - (2026-09-02) [Moderate] Wind Advisory: Wind Advisory issued September 2 at 4:49AM PDT until September 2 at 8:00PM PDT by NWS Seattle WA
      * WHAT...Southeast winds 20 to 35 mph expected. * WHERE...Island County, Lowlands of Western Whatcom County, Port Townsend Area, and San Juan County. * WHEN...Until 8 PM PDT this evening. * IMPACTS...Gusty winds will blo…

### Ukraine Theater (total-war monitoring) — 79 new of 239 total
  - (2026-09-02) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-01) [Liveuamap] Power plant in eastern Germany hit by several "homemade rockets" packed with explosives, according to Märkische Allgemeine Zeitung Brandenburg, Germany - Ukraine Interactive map - Ukraine…
      Power plant in eastern Germany hit by several "homemade rockets" packed with explosives, according to Märkische Allgemeine Zeit
  - (2026-09-01) [Liveuamap] Sheremetyevo Airport has switched to operations subject to clearance. Around 10 flights have been delayed. - Liveuamap
      Sheremetyevo Airport has switched to operations subject to clearance. Around 10 flights have been delayed. <
  - (2026-09-01) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap
  - (2026-08-31) [Liveuamap] Sudan: 200 more Rapid Support Forces fighters defect and join the army - sudan.liveuamap.com
      Sudan: 200 more Rapid Support Forces fighters defect and join the army sudan.liveuamap.com
  - (2026-09-02) [Liveuamap] China Interactive News Map - china.liveuamap.com - Liveuamap
      China Interactive News Map - china.liveuamap.com Liveuamap

### State Legislative Action — 66 new of 68 total
  - (2026-09-02) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-09-02) [Alaska HB 96] An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
      An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
  - (2026-09-02) [Alaska HJR 23] Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
      Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
  - (2026-09-02) [Alaska HB 10] An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
      An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
  - (2026-09-02) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…
  - (2026-09-01) [Arizona SB 1480] crime-free lease addendum; renters.
      crime-free lease addendum; renters.

### Ukrainian Internal News (national + local Kyiv) — 66 new of 119 total
  - (2026-09-02) Ердоган закликав створити механізм з безпеки судноплавства в Чорному морі | LEDE: ] (uk: Ердоган закликав створити механізм з безпеки судноплавства в Чорному морі)
  - (2026-09-02) В Естонії обрали нову президентку: нею стала канцлерка юстиції Юлле Мадізе | LEDE: Канцлерку юстиції Юлле Мадізе підтримали 71 депутат із 101. Інавгурація нового президента Естонії відбудеться ] (uk:…
      Канцлерку юстиції Юлле Мадізе підтримали 71 депутат із 101. Інавгурація нового президента Естонії відбудеться 12 жовтня 2026 року.
  - (2026-09-02) Фон дер Ляєн: Україна запросила в ЄС фінансування на закупівлю ракет до Patriot | LEDE: Єврокомісія отримала запит України на мільярди євро для закупівлі ракет PAC-3 для систем Patriot. Країни ] (uk:…
      Єврокомісія отримала запит України на мільярди євро для закупівлі ракет PAC-3 для систем Patriot. Країни ЄС розглядають питання фінансування.
  - (2026-09-02) Найближчі дні в Україні будуть теплими, місцями – короткочасні дощі | LEDE: В Україні в найближчі дні прогнозують короткочасні дощі та температуру до 27°. У Києві вночі 14-17°, вдень до +23°.] (uk: На…
      В Україні в найближчі дні прогнозують короткочасні дощі та температуру до 27°. У Києві вночі 14-17°, вдень до +23°.
  - (2026-09-02) ЗМІ: радники Трампа хочуть стримати його від ескалації проти Ірану на тлі виборів у США | LEDE: Провідні помічники президента США Дональда Трампа наполягають на тому, щоб утриматися від ескалац] (uk:…
      Провідні помічники президента США Дональда Трампа наполягають на тому, щоб утриматися від ескалації війни з Іраном до проміжних виборів до Конгресу у листопаді, щоб запобігти поразці Республіканської партії.
  - (2026-09-02) Рада ЄС погодила тимчасову лібералізацію торгівлі з Вірменією: торкнеться 80% експорту | LEDE: ] (uk: Рада ЄС погодила тимчасову лібералізацію торгівлі з Вірменією: торкнеться 80% ек)

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 57 total
  - (2026-09-02) [BleepingComputer] Microsoft Defender flags legitimate Google search links as malicious
      Microsoft is investigating an issue causing the Defender for Office 365 security software to mistakenly block access to legitimate Google search links. [...]
  - (2026-09-02) [BleepingComputer] US charges Russian for infecting 80,000 freelancers with malware
      A California federal grand jury has indicted a Russian national for his role in a phishing campaign that infected thousands of freelancers with TVRAT and DarkVNC malware. [...]
  - (2026-09-02) [BleepingComputer] Sality botnet infrastructure dismantled in joint global takedown
      International law enforcement agencies and private partners have seized Sality malware infrastructure in a joint action aiming to disrupt and take down the peer-to-peer (P2P) botnet. [...]
  - (2026-09-02) [BleepingComputer] SonicWall warns of actively exploited SMA1000 zero-day flaws
      SonicWall warned customers that threat actors are chaining two new SMA1000 zero-day vulnerabilities in remote code execution attacks. [...]
  - (2026-09-02) [The Hacker News] Attackers Exploit Two SonicWall SMA 1000 Zero-Days That May Form an Attack Chain
      SonicWall has released security updates to address two security flaws impacting its Secure Mobile Access (SMA) 1000 series VPN appliances that have been exploited in zero-day attacks. The vulnerabilities, discovered inte…
  - (2026-09-02) [The Hacker News] GeoNetwork Fixes Unauthenticated RCE Chain Affecting Government Geoportal Backends
      Two vulnerabilities in GeoNetwork can be chained to achieve unauthenticated remote code execution (RCE) on the open-source geospatial metadata catalog, which sits behind many government and agency geoportals. The project…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-02) [Chesky Brian] Form 4/A (Reporting)
      filed 2026-09-02 11:51 UTC · amended · role: Reporting — Filed: 2026-09-02 AccNo: 0001193125-26-379365 Size: 20 KB
  - (2026-09-02) [Airbnb, Inc.] Form 4/A (Issuer)
      filed 2026-09-02 11:51 UTC · amended · role: Issuer — Filed: 2026-09-02 AccNo: 0001193125-26-379365 Size: 20 KB
  - (2026-09-02) 497 - Tidal Trust II (0001924868) (Filer)
      filed 2026-09-02 11:34 UTC — Filed: 2026-09-02 AccNo: 0001999371-26-019514 Size: 317 KB
  - (2026-09-02) 497 - Tidal Trust II (0001924868) (Filer)
      filed 2026-09-02 11:33 UTC — Filed: 2026-09-02 AccNo: 0001999371-26-019513 Size: 311 KB
  - (2026-09-02) [Jay Stefanie] Form 4 (Reporting)
      filed 2026-09-02 11:32 UTC · role: Reporting — Filed: 2026-09-02 AccNo: 0001849124-26-000003 Size: 303 KB
  - (2026-09-02) [Criteo S.A.] Form 4 (Issuer)
      filed 2026-09-02 11:32 UTC · role: Issuer — Filed: 2026-09-02 AccNo: 0001849124-26-000003 Size: 303 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-02) [] Nearly £3 , 000 raised for family after death of brother
      domain: glasgowtimes.co.uk · language: English · tone:
  - (2026-09-02) [Canada] The weak link in Canada ambitions - The Globe and Mail
      domain: theglobeandmail.com · language: English · tone:
  - (2026-09-02) [Virgin Islands] Thousands still missing as Nepal - Tibet flood relief & recovery intensifies
      domain: virginislandsnewsonline.com · language: English · tone:
  - (2026-09-02) [United States] Iran Claims U . S . Attack Killed Civilians At Wedding
      domain: 570wkbn.iheart.com · language: English · tone:
  - (2026-09-02) [Ireland] HSE fined more than €600k after medical records found covered in animal droppings and mould
      domain: irishmirror.ie · language: English · tone:
  - (2026-09-02) [United Kingdom] Trump threat against an NBC journalist is an attack on reality | Margaret Sullivan
      domain: theguardian.com · language: English · tone:

### Court opinions of consequence (federal & state) — 37 new of 60 total
  - (2026-09-01) Arizona Supreme Court: In Re Term of Parental Rights as to M.P.
  - (2026-09-01) Arizona Supreme Court: Industrial Park Center v. Great Northern Insurance
  - (2026-09-01) U.S. Court of Appeals, 11th Cir.: Anne Guthrie v. Coal Bed Services Inc.
  - (2026-09-01) U.S. Court of Appeals, 11th Cir.: Clarissa Zafirov v. Florida Medical Associates, LLC
  - (2026-09-01) U.S. Court of Appeals, 5th Cir.: United States v. Tampico
  - (2026-09-01) U.S. Court of Appeals, 5th Cir.: United States v. Padilla

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-09-02) #1 Elon Musk — $879.75B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-09-02) #2 Larry Page — $274.23B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-02) #3 Jeff Bezos — $263.37B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-09-02) #4 Sergey Brin — $253.00B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-02) #5 Michael Dell — $231.39B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-09-02) #6 Mark Zuckerberg — $198.69B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-02) JAF50T (Bulgaria)
      icao24: 4520ce · position: (38.8204, -4.7151) · alt: 11887m · 878km/h
  - (2026-09-02) PAT303 (United States)
      icao24: adfecb · position: (38.0949, -84.0694) · alt: 6454m · 381km/h
  - (2026-09-02) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (37.4741, -3.5246) · alt: 11285m · 829km/h
  - (2026-09-02) GAF182 (Germany)
      icao24: 3e8b41 · position: (32.9034, 31.8259) · alt: 10050m · 754km/h
  - (2026-09-02) SAM883 (United States)
      icao24: adfeb9 · position: (31.8471, -85.8222) · alt: 8107m · 939km/h
  - (2026-09-02) SAMU37 (France)
      icao24: 39ca87 · position: (48.0703, 2.0588) · alt: 6339m · 231km/h

### Paper Trading Scorecard — 28 new of 132 total
  - (2026-09-02) [Polymarket] Will Trump be impeached before his term ends?
      This market will resolve to “Yes“ if the US House of Representatives, by simple majority vote, approves or passes one or more articles of impeachment of President Donald Trump between market creation and January 20, 2029…
  - (2026-09-02) [Polymarket] Will AfD win the most seats in the 2026 Sachsen-Anhalt parliamentary elections?
      Parliamentary elections to elect the Landtag of Sachsen-Anhalt are scheduled to take place on September 6, 2026. This market will resolve to the political party that wins the greatest number of seats in the state parliam…
  - (2026-09-02) [Polymarket] Will the Fed decrease interest rates by 25 bps after the December 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-09-02) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-09-02) [Manifold] Will Grok 4.7 be released on 9/11?
  - (2026-09-02) [Manifold] Will OpenAI officially confirm that Astra uses a recurrent-depth (looped) architecture by Dec 31, 2026?

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-09-02) M 5.6 - 159 km WSW of Abepura, Indonesia
      M5.6 · 159 km WSW of Abepura, Indonesia · depth 69.052 km
  - (2026-09-02) M 5.3 - 66 km NNW of Arthurs Point, New Zealand
      M5.3 · 66 km NNW of Arthurs Point, New Zealand · depth 10 km
  - (2026-09-02) M 5.2 - South Sandwich Islands region
      M5.2 · South Sandwich Islands region · depth 84.064 km
  - (2026-09-02) M 5.2 - 70 km NNW of Arthurs Point, New Zealand
      M5.2 · 70 km NNW of Arthurs Point, New Zealand · depth 10 km
  - (2026-09-02) M 5.2 - 95 km SSW of Nikolski, Alaska
      M5.2 · 95 km SSW of Nikolski, Alaska · depth 35 km
  - (2026-09-01) M 5.2 - 35 km SE of Sarangani, Philippines
      M5.2 · 35 km SE of Sarangani, Philippines · depth 120.779 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-09-02) LoL: Hanwha Life Esports vs T1 (BO5) - LCK Playoffs
      yes price: 52% · 24h volume: $2,775,255 · resolves 2026-09-02
  - (2026-09-02) LoL: Hanwha Life Esports vs T1 - Game 2 Winner
      yes price: 0% · 24h volume: $1,798,881 · resolves 2026-09-02
  - (2026-09-02) LoL: Hanwha Life Esports vs T1 - Game 3 Winner
      yes price: 100% · 24h volume: $1,434,164 · resolves 2026-09-02
  - (2026-09-02) LoL: Hanwha Life Esports vs T1 - Game 4 Winner
      yes price: 100% · 24h volume: $1,336,704 · resolves 2026-09-02
  - (2026-09-02) Will John Fetterman win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $1,025,095 · resolves 2028-11-07
  - (2026-09-02) Will Tulsi Gabbard win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $643,809 · resolves 2028-11-07

### U.S. Federal Action — 10 new of 16 total
  - (2026-09-02) Continuation of the National Emergency With Respect to Foreign Interference in or Undermining Public Confidence in United States Elections
  - (2026-09-02) Honoring the American History of the Great Lakes and Renaming Lake Ontario as Lake America
  - (2026-09-02) Repeal of Fossil Fuel Restrictions for New Federal Buildings and Major Renovations of Federal Buildings
      The Department of Energy (DOE) is reviewing its recent guidance related to the implementation of newly adopted provisions regarding Clean Energy for New Federal Buildings and Major Renovations of Federal Buildings (CER).…
  - (2026-09-02) Safety Zone; Bay Bridge Paddle; Chesapeake Bay, Annapolis, MD
      The Coast Guard is establishing a temporary safety zone for navigable waters of the Chesapeake Bay, adjacent to the shoreline at Sandy Point State Park and between and adjacent to the spans of the William P. Lane Jr. Mem…
  - (2026-09-02) Safety Zone; Lake St. Clair, Grosse Pointe Farms, MI
      The Coast Guard is establishing a temporary safety zone for the navigable waters of Lake St. Clair for a fireworks display. The safety zone is needed to protect personnel, vessels, and the marine environment from potenti…
  - (2026-09-02) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA proposes to supersede Airworthiness Directive (AD) 2021-17-07, which applies to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2021-17-07 requires inspecting for damage…

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 109 total
  - (2026-09-02) [USASpending] $35,199,796,917 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-09-02) [USASpending] $27,613,237,659 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-09-02) [USASpending] $22,442,309,468 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-09-02) [USASpending] $19,926,468,210 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-09-02) [USASpending] $14,753,060,287 → FLUOR MARINE PROPULSION, LLC: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND NAVAL NUCLEAR PROPULSION PROGRAM SUPPORT
  - (2026-09-02) [USASpending] $3,572,209,102 → PANTEXAS DETERRENCE, LLC: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION
      Agency: Department of Energy. Description: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION OF THE PANTEX PLANT

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-02) [Marginal Revolution] America is still poised for a data center boom
      Eric Levitz, via Matt Yglesias. The post America is still poised for a data center boom appeared first on Marginal REVOLUTION.
  - (2026-09-02) [Marginal Revolution] The College Wage Premium in the Generative AI Era
      After expanding for four decades, the U.S. college wage premium is experiencing a sustained contraction, dropping sharply from 0.626 in 2022 to 0.575 in 2026. Using Current Population Survey Outgoing Rotation Group data…
  - (2026-09-01) [Marginal Revolution] Who values democracy?
      This paper examines the conventional view that redistribution is central to the democratization process using data from stock markets. Consistent with this view, democratizations have a large, negative impact on asset va…
  - (2026-09-01) [Conversable Economist] The Bank of North America (Before Hamilton’s First Bank of the United States)
      Thanks to the power of musical theater and the genius of Lin-Manuel Miranda, I can now speak in public spaces about Alexander Hamilton and the First Bank of the United States without watching people’s eyes glaze over in…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=16, 7d-median=27, 14d-median=22; carrying terms: service, specifically, public, national, unless, amends, management, certain, proposed, temporary, safety, published
- state_bills: today=68, 7d-median=78, 14d-median=80; carrying terms: subject, develop, corporation, education, eligible, pursuant, service, development, officer, request, advisory, order
- state_news: today=770, 7d-median=648, 14d-median=597; carrying terms: world, braun, freedom, house, vermont, media, opinion, august, cases, student, officer, comes
- local_news: today=243, 7d-median=243, 14d-median=243; carrying terms: child, crash, woman, august, driver, louis, atlanta, student, across, police, music, taken
- foreign_news: today=1097, 7d-median=1048, 14d-median=1027; carrying terms: depict, rahul, bachelor, catch, dailystar, child, house, lofted, media, woman, delegation, congress
- chinese_internal: today=300, 7d-median=296, 14d-median=289; carrying terms: cbmizkfvx, cbmib, cbmickfvx, cbmizefvx, google, lxtfb, caixin, politics, articles, color, cbmibkfvx, lxtfa
- russian_internal: today=1181, 7d-median=1074, 14d-median=1030; carrying terms: financial, politico, truth, forbidden, axios, media, social, title, reuters, street, httperror, telegram
- ukrainian_internal: today=119, 7d-median=122, 14d-median=119; carrying terms: kyivindependent, ukraine, president, institute, media, around, august, sources, vechirniy, forces, comes, targets
- ukraine_theater: today=239, 7d-median=236, 14d-median=834; carrying terms: ujzbsg, cjvbbja, sgjtyxhrcju, qzzjrdjgyzd, jcmzkewvpum, nfcwrvzaoa, wthjqk, ytqzrtdzvfbdaxweltzjfczvfsbvftqtqyvgn, zudrgv, dmkvxvhpzsm, zdfltdfdfyjjhtknitfnqsmuzngjfyk, rnbplwzhlv
- paper_bets: today=132, 7d-median=132, 14d-median=132; carrying terms: least, world, leaders, named, pennsylvania, minnesota, former, mamdani, international, alaska, verve, erupt
- weather: today=173, 7d-median=133, 14d-median=143; carrying terms: central, beach, please, valley, oregon, humid, levels, marine, upper, develop, producing, around
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: implied, money, commodities, jtsjol, balance, consumption, dexchus, total, spread, personal, payrolls, assets
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: large, natural, yield, corporate, bitcoin, russell, commodities, crypto, china, proxy, rates, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=109, 7d-median=109, 14d-median=106; carrying terms: central, accelerator, misappropriation, terrorist, security, drilling, missions, niger, events, foreign, sovereignty, hfufrmmg
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, quiver, unauthorized, https, client, httperror, quantitative, quiverquant
- billionaires: today=30, 7d-median=0, 14d-median=30; carrying terms: walton, mexico, spacex, commodities, diversified, canada, walmart, warren, meyers, madrid, microsoft, euronext
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, appeals, connecticut, delaware, community, company, services, america, board, florida
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, financial, brian, filer, trust, finance, tidal, america
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, senate, ocasio, talarico, david, graham, johnson, ossoff, platner, james, robert, pinkston
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=50, 14d-median=50; carrying terms: keywords, english, strikes, jpost, trump, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: hospital, iheart, kingdom, domain, language, trump, health, english
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, germany, ground, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: central, exposure, phase, noted, influenza, world, ratio, largest, ethiopia, regio, niger, valley
- cisa_kev: today=17, 7d-median=20, 14d-median=17; carrying terms: function, remediation, missing, zimbra, microsoft, suite, injection, vulnerability, trueconf, product, mlflow, synacor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=19, 7d-median=13, 14d-median=14; carrying terms: depth, indonesia, islands, japan, ruteng, south, region, chile, philippines, ridge, sandwich, kuril
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, championship, volume, resolves, shakhtar, champions, presidential, league, rates, september, decrease, interest
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, conversable, class, together, https, economist, marginal, demand, shows, future, labor, years
- tech_news: today=57, 7d-median=56, 14d-median=55; carrying terms: incident, world, attacks, hacker, according, devices, around, agents, industry, cybersecurity, companies, record
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: christopher, rashida, stephanie, reserve, fetterman, cynthia, pallone, margaret, vindman, risch, horsford, burgess
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, markets, consensus, placement, claude, placed, converges, unavailable, sufficient, decision, module, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*