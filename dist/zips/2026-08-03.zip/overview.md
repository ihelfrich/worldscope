# WORLDSCOPE morning brief — 2026-08-03

## Headline
3236 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (760) · Russian Internal News (state + in-exile) (693) · State-Level News (379) · World leaders & government officials (324) · Chinese Internal News (197) · Local News: St. Louis + Atlanta (194) · U.S. Weather + Severe / Climate Outlooks (175) · Ukraine Theater (total-war monitoring) (151) · Ukrainian Internal News (national + local Kyiv) (59) · State Legislative Action (45) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 760 new of 993 total
  - (2026-08-03) [Global] Stronger EU borders needed after Ceuta crisis, von der Leyen says
  - (2026-08-03) [Global] How Ceuta migrant crisis exposes divisions within Europe - The Latest
  - (2026-08-03) [Global] Ceuta leader accuses Morocco over ‘atrocity’ of mass border crossing
  - (2026-08-03) [Global] Weather tracker: Austria breaks heat records as Japan braces for Typhoon Dolphin
  - (2026-08-03) [Global] Nauru officially changes its name to Naoero
  - (2026-08-03) [Global] Yen hits three-month high after Trump helps prop up currency

### Russian Internal News (state + in-exile) — 693 new of 865 total
  - (2026-08-04) Bloomberg: переработка нефти в России упала до минимума с 2002 года | LEDE: В июле 2026 года средняя производительность переработки нефти в России составила 3,6 миллиона баррелей в сутки. Эт] (ru: Blo…
      В июле 2026 года средняя производительность переработки нефти в России составила 3,6 миллиона баррелей в сутки. Это минимальный уровень с мая 2002 года, пишет Bloomberg со ссылкой на выводы EA Analytics.
  - (2026-08-03) Сайты российских банков перестали автоматически открываться в зарубежных браузерах | LEDE: Сайты российских банков — в частности ВТБ, Сбера, Альфа-банка, Россельхозбанка, банка «Уралсиб», Пр] (ru: Сай…
      Сайты российских банков — в частности ВТБ, Сбера, Альфа-банка, Россельхозбанка, банка «Уралсиб», Промсвязьбанка и банка «Санкт-Петербург» — перестали открываться в зарубежных браузерах. На это обратил внимание РБК.
  - (2026-08-03) Залужный: Украина никогда не вступит в НАТО | LEDE: Посол Украины в Великобритании, бывший главнокомандующий ВСУ Валерий Залужный усомнился в том, что Украина когда-либо вступит в НАТО. Он в] (ru: Зал…
      Посол Украины в Великобритании, бывший главнокомандующий ВСУ Валерий Залужный усомнился в том, что Украина когда-либо вступит в НАТО. Он высказался на эту тему во время дискуссии по евроатлантической интеграции на совеща…
  - (2026-08-03) Украинский дрон попал по пляжу в Геленджике. Куда он летел? Его сбили? Точных ответов нет. Но недалеко от места ЧП находится объект, который могла защищать ПВО | LEDE: 3 августа украинский д] (ru: Укр…
      3 августа украинский дрон взорвался на пляже в селе Архипо-Осиповка, которое входит в состав города Геленджика. По последним данным, число погибших в результате инцидента достигло семи человек, среди них трое детей. Еще…
  - (2026-08-03) После удара украинских дронов по Подмосковью в местные водоемы попали химикаты. В соцсетях публикуют кадры погибшей рыбы | LEDE: В реку Гнилуша, протекающую через городской округ Домодедово,] (ru: Пос…
      В реку Гнилуша, протекающую через городской округ Домодедово, попали химические вещества, что вызвало мор рыбы. Об этом изданию Msk1 рассказала глава Домодедово Евгения Хрусталева.
  - (2026-08-03) За последний месяц сразу три издания для бухгалтеров и HR-специалистов выпустили статьи о том, как вести воинский учет при мобилизации | LEDE: С начала июля три российских профессиональных и] (ru: За…
      С начала июля три российских профессиональных издания, ориентированных на бухгалтеров, кадровых специалистов и руководителей организаций, опубликовали новые или обновили старые обзоры о ведении воинского учета при мобили…

### State-Level News — 379 new of 490 total
  - (2026-08-03) [California] ‘No me acosen’: Legisladores de California y EE. UU. debaten sobre la tecnología de lectura de matrículas
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/021926-Flock-Camera-LV-CM-06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-03) [California] ¿Inundaciones violentas u olas gigantescas? Así se prepara San Diego para un invierno de clima extremo bajo el efecto de El Niño
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/020224_Flood-San-Diego_AH_CM_16.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-08-03) [California] Deals to watch as CA lawmakers make final sprint
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/02/022336-Capitol-Session-FG-CM-10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-08-03) [California] Keep an eye on these 5 deals as California lawmakers close out the legislative session
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/052826_Assembly-Session_MG_CM_29.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-08-03) [California] ‘Don’t Flock me’: California, U.S. lawmakers debate license plate reader technology
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/021926-Flock-Camera-LV-CM-06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-03) [California] ‘Kids are actually eating the food’: State expands lunch program that pairs schools with farms
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072826_SCHOOL-MEALS_AHK_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 197 new of 253 total
  - (2026-08-02) Cover Story: China’s Power Market Enters a More Volatile Era as Prices Go Real Time - Caixin Global
      Cover Story: China’s Power Market Enters a More Volatile Era as Prices Go Real Time Caixin Global
  - (2026-08-03) 美国将洽洽瓜子、思念水饺列入制裁清单 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5IVkk3OEY0bnExNHVmRmplaVFGdm9IZ0pxYS14Mm5BT1kzeTZxWTNpMGZxenRYdWU1YV91ZnBaWlVoTDFhek45X05mX2Nob0ZlV] (zh:…
      美国将洽洽瓜子、思念水饺列入制裁清单 观察者网
  - (2026-08-03) 特朗普最近为什么特别反常 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBYRXlpcVNNM2VLM1pyQWFyMWplVmpnM2I2bUZoQXhIdC1HNFY5Z0YzZFEtT2phajVnb2JaM29yQjJhMDNjVkpJRElUZEJkQnIydExLRE9] (zh:…
      特朗普最近为什么特别反常 观察者网
  - (2026-08-03) 熊本灾区：求你们别寄千纸鹤来--我就是要寄 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1uQVZQbk5vNWxDak5nR29JczJVQkVMVlB2NmJjY2dTS1FGUjRBU21ZWjU4ckF0alA4S3M0d0JmQkVJZThQbEZWQU51c0RNcG0y] (zh:…
      熊本灾区：求你们别寄千纸鹤来--我就是要寄 风闻
  - (2026-08-03) 瑞幸门店被指一员工疑似用奶油枪给同事喂食，你介意这种操作吗？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFA0VkVWeHRuQm1fNHRuMU9Gcms2eHQ0NVFJdm9CRTRSUW9sWUlscVdWQmFPOUdleTFXTGVsbmR1U0R4dE1MRlVDemx] (zh:…
      瑞幸门店被指一员工疑似用奶油枪给同事喂食，你介意这种操作吗？ 风闻
  - (2026-08-03) 在电影《桥》的取景地，我遇见了正在修桥的中国人 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBJWE9tMjNrMWNfeUo0LXd6MXh5dDJoalFJMWNnd0RUWlJaLURlajd3S0ZzVzUySGZBcEJHOEQ4V2UyUXNJN1ppMjVDOEFhcG] (zh:…
      在电影《桥》的取景地，我遇见了正在修桥的中国人 风闻

### Local News: St. Louis + Atlanta — 194 new of 230 total
  - (2026-08-03) [St. Louis] Attend one of America’s most inspiring sports awards shows right here in St. Louis
      Some of the most inspiring stories in sports don’t begin with a championship. They begin with an act of character. For more than 20 years, the Musial Awards has brought those stories and the selfless, remarkable people r…
  - (2026-08-03) [St. Louis] Photos: Noah Kahan performs a sold-out show at Busch Stadium
      Butterflies, fireflies, ladybugs—bugs of all sorts adorned the piano and flitted about on screen prior to Noah Kahan’s dynamic, 140-minute concert at Busch Stadium on Sunday night. Thousands of fans wore them as well. Do…
  - (2026-08-03) [St. Louis] STL Fringe Fest returns to Grand Center
      If you’re a fan of improvisational comedy, musical theater, or darkly absurd multiverse mash-ups, then you’re in luck. STL Fringe Fest, organized by St. Lou Fringe, returns August 4–9. The festival hosts 45 shows featuri…
  - (2026-08-03) [St. Louis] Why more St. Louis businesses and families are rediscovering the community bank
      There’s a quiet shift happening in how St. Louisans think about their bank. After years of consolidation, app-only startups, and the impersonal churn of national institutions, a growing number of people and businesses ar…
  - (2026-08-03) [St. Louis] Ask Veronica: How do I rehome a rooster?
      Just last weekend, I was up early watering the plants when I heard the sound of a rooster coming from the other side of my fence. My neighbor, Lee Cagle, had texted earlier in the week to apologize in advance for the coc…
  - (2026-08-03) [St. Louis] Review: Taste of Jiangnan brings one of China’s great regional cuisines to University City
      Think of Jiangnan—and if you enjoy real Chinese food you should—as sort of the Paris of China. The analogy’s not entirely apt, but if we’re talking about Chinese cuisine, the foods of the Jiangnan region—the complexities…

### U.S. Weather + Severe / Climate Outlooks — 175 new of 177 total
  - (2026-08-03) [Severe] Special Marine Warning: Special Marine Warning issued August 3 at 7:32PM EDT until August 3 at 8:30PM EDT by NWS Key West FL
      SMWKEY The National Weather Service in Key West has issued a * Special Marine Warning for... Hawk Channel and Straits of Florida from west end of Seven Mile Bridge to Halfmoon Shoal out 20 nm... * Until 830 PM EDT. * At…
  - (2026-08-03) [Severe] Dust Storm Warning: Dust Storm Warning issued August 3 at 4:28PM MST until August 3 at 6:30PM MST by NWS Tucson AZ
      The National Weather Service in Tucson has issued a * Dust Storm Warning for... Northeastern Cochise County in southeastern Arizona... * Until 630 PM MST. * At 428 PM MST, an area of blowing dust was located near San Sim…
  - (2026-08-03) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 3 at 4:28PM MST until August 3 at 5:30PM MST by NWS Tucson AZ
      SVRTWC The National Weather Service in Tucson has issued a * Severe Thunderstorm Warning for... North Central Cochise County in southeastern Arizona... * Until 530 PM MST. * At 428 PM MST, a severe thunderstorm was locat…
  - (2026-08-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-03) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 3 at 4:22PM MST until August 3 at 5:15PM MST by NWS Tucson AZ
      SVRTWC The National Weather Service in Tucson has issued a * Severe Thunderstorm Warning for... Northeastern Cochise County in southeastern Arizona... * Until 515 PM MST. * At 422 PM MST, severe thunderstorms were locate…
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 6:19PM CDT by NWS Bismarck ND
      A cold frontal passages has brought winds up to 55 mph observed across a few sites in south central North Dakota. This cold front will continue to impact parts of south central North Dakota the next few hours bringing a…

### Ukraine Theater (total-war monitoring) — 151 new of 639 total
  - (2026-08-03) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-02) [FIRMS] thermal anomaly 52.845, 29.992 (FRP 0.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 0.9 MW
  - (2026-08-02) [FIRMS] thermal anomaly 52.847, 29.989 (FRP 1.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 1.61 MW
  - (2026-08-02) [FIRMS] thermal anomaly 52.238, 33.792 (FRP 1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 1 MW
  - (2026-08-02) [FIRMS] thermal anomaly 51.895, 29.341 (FRP 3.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 3.01 MW
  - (2026-08-02) [FIRMS] thermal anomaly 51.894, 29.330 (FRP 3.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 3.01 MW

### Ukrainian Internal News (national + local Kyiv) — 59 new of 125 total
  - (2026-08-04) Умєров розповів, чим займатиметься на посаді голови Служби зовнішньої розвідки | LEDE: Новопризначений голова Служби зовнішньої розвідки України Рустем Умєров заявив, що на новій посаді зосеред] (uk:…
      Новопризначений голова Служби зовнішньої розвідки України Рустем Умєров заявив, що на новій посаді зосередиться на розвитку міжнародного співробітництва, реалізації стратегічних оборонних проєктів та посиленні спроможнос…
  - (2026-08-04) Зеленський звільнив низку послів та змінив представника України при ЮНЕСКО | LEDE: Президент Володимир Зеленський підписав серію указів про кадрові зміни в дипломатичному корпусі України, звіль] (uk:…
      Президент Володимир Зеленський підписав серію указів про кадрові зміни в дипломатичному корпусі України, звільнивши послів у кількох державах та призначивши нову постійну представницю при ЮНЕСКО.
  - (2026-08-04) Зеленський запровадив санкції проти підприємств російського ОПК – серед них є українське | LEDE: Президент Володимир Зеленський увів у дію рішення Ради національної безпеки і оборони України пр] (uk:…
      Президент Володимир Зеленський увів у дію рішення Ради національної безпеки і оборони України про застосування санкцій проти 23 компаній та 20 фізичних осіб, залучених до виробництва озброєння та обслуговування потреб ро…
  - (2026-08-03) Молдова запроваджує заходи економії електроенергії та води через обміління Дністра | LEDE: ] (uk: Молдова запроваджує заходи економії електроенергії та води через обміління Дніст)
  - (2026-08-03) Через удар російських дронів палають склади з продуктами біля Дніпра | LEDE: Масштабна пожежа на складах із продуктами під Дніпром через атаку російських дронів. Інформація про постраждалих уто] (uk:…
      Масштабна пожежа на складах із продуктами під Дніпром через атаку російських дронів. Інформація про постраждалих уточнюється.
  - (2026-08-03) В Ірані заявили, що готувалися вдарити по трьох об’єктах в Україні | LEDE: Старший радник лідера Ірану Мохсен Резаї заявив, що іранська армія готувалася завдати удару по трьох цілях в Україні п] (uk:…
      Старший радник лідера Ірану Мохсен Резаї заявив, що іранська армія готувалася завдати удару по трьох цілях в Україні після атаки на торгове судно в Каспійському морі.

### State Legislative Action — 45 new of 108 total
  - (2026-08-03) [Alabama SB 159] Taxation; Energy use in commercial greenhouses, pivot irrigation systems, and poultry houses, exempt from utility gross receipts and utility service use tax
      Taxation & Revenue
  - (2026-08-03) [Alabama SB 322] Unauthorized entry of a critical infrastructure facility; reservoirs removed from list of facilities
      Crimes & Offenses
  - (2026-08-03) [Alabama SB 376] Mobile County, City of Semmes annexation
      Mobile County
  - (2026-08-03) [Alabama SB 13] Taxation; Energy use in poultry houses, exempt from utility gross receipts and utility service use tax
      Taxation & Revenue
  - (2026-08-03) [Alabama SB 264] Municipalities; annexation, all municipalities authorized to extend corporate limits by resolution and special election
      Counties & Municipalities
  - (2026-08-03) [Alaska HB 16] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits for state and local office; direct…

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 57 total
  - (2026-08-03) [BleepingComputer] New DOUBLECUP ClickFix service hides malware in browser cache images
      A new Russian loader-as-a-service named DOUBLECUP uses ClickFix attacks to hide malicious code in PNG images cached by victims' browsers, ultimately delivering CountLoader to Windows and macOS devices and a new remote ac…
  - (2026-08-03) [BleepingComputer] Fake Roblox Xeno script launcher pushes infostealer, RAT malware
      Fake Xeno Executor installers are infecting unsuspecting Roblox players with malware that provides remote access and steals sensitive information. [...]
  - (2026-08-03) [BleepingComputer] N-able warns of N-central auth bypass flaw exploited in attacks
      N-able is warning customers that hackers are exploiting an authentication bypass vulnerability (CVE-2026-18577) affecting both hosted and on-premises N-central servers. [...]
  - (2026-08-03) [BleepingComputer] ExfilSquad hackers leak info of over 100,000 UK police officers, staff
      A cyberattack on the U.K.'s Police National Legal Database (PNLD) has compromised contact data of more than 100,000 police officers and other criminal justice professionals. [...]
  - (2026-08-03) [BleepingComputer] Inside the Underground Business of the Android BTMOB RAT malware
      Flare researchers analyzed thousands of underground posts to examine how the BTMOB Android malware operation evolved into a fragmented ecosystem of resellers, source-code vendors, custom versions, and competing sales cha…
  - (2026-08-03) [The Hacker News] 18 Malicious npm Packages Deliver Cross-Platform RAT to Alibaba Tool Users
      Cybersecurity researchers have discovered a new set of malicious npm packages that target users of Alibaba developer tools with a cross-platform remote access trojan (RAT) as part of a sophisticated, targeted software su…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-03) [Penn Mark Jeffery] Form 4 (Reporting)
      filed 2026-08-03 23:33 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001104659-26-089928 Size: 6 KB
  - (2026-08-03) [Stagwell Inc] Form 4 (Issuer)
      filed 2026-08-03 23:33 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001104659-26-089928 Size: 6 KB
  - (2026-08-03) [KESTRA MEDICAL TECHNOLOGIES, LTD.] Form 4 (Issuer)
      filed 2026-08-03 23:32 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001193125-26-331065 Size: 9 KB
  - (2026-08-03) [Ford Alfred J Jr] Form 4 (Reporting)
      filed 2026-08-03 23:32 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001193125-26-331065 Size: 9 KB
  - (2026-08-03) [KESTRA MEDICAL TECHNOLOGIES, LTD.] Form 4 (Issuer)
      filed 2026-08-03 23:30 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001193125-26-331062 Size: 9 KB
  - (2026-08-03) [Mahboob Vaseem] Form 4 (Reporting)
      filed 2026-08-03 23:30 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001193125-26-331062 Size: 9 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 28 new of 141 total
  - (2026-08-03) [Polymarket] Will the Cleveland Guardians win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-08-03) [Polymarket] Will Ralph Norman be the new Republican nominee for Senate in South Carolina?
      This market will resolve according to the winner of the special Republican Primary for United States Senator from South Carolina, including any potential runoff. If no 2026 special South Carolina Republican Senate Primar…
  - (2026-08-03) [Polymarket] New pandemic in 2026?
      This market will resolve to "Yes" if the World Health Organization (WHO) declares any disease a pandemic between January 1, 2026 and December 31, 2026 11:59 PM ET. Otherwise, this market will resolve to "No". The resolut…
  - (2026-08-03) [Polymarket] Will the US strike 13 countries in 2026?
      This market will resolve according to the total number of different countries' soil that the United States initiates a drone, missile, or air strike on between January 1, 2026, 12:00 AM ET and December 31, 2026, 11:59 PM…
  - (2026-08-03) [Manifold] Will Anthropic stop deprecating models and make old ones available for access by the end of the year?
  - (2026-08-03) [Manifold] Will there be new US-Iran peace talks before August 31?

### Court opinions of consequence (federal & state) — 26 new of 60 total
  - (2026-08-04) Connecticut Supreme Court: Ashworth v. Branford
  - (2026-08-04) Connecticut Supreme Court: TOV Realty, LLC v. Suarez
  - (2026-08-03) U.S. Court of Appeals, 11th Cir.: City of Brunswick v. Honeywell International, Inc.
  - (2026-08-03) U.S. Court of Appeals, 11th Cir.: United States v. Alonso Pineda-Torres
  - (2026-08-03) U.S. Court of Appeals, 6th Cir.: United States v. Joshua Starling
  - (2026-08-03) U.S. Court of Appeals, 6th Cir.: Yarlen Henry v. City of Detroit, Mich.

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Board of Peace Reaffirms Hamas Disarmament Before IDF Withdrawal
      themedialine.org · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Trump Announces Gaza Disarmament Deal as Hamas Signals Conditional Acceptance – NaturalNews . com
      naturalnews.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Speak Out in Defense of Spain Territorial Integrity , Spanish MEP Urges Netanyahu
      themedialine.org · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Board of Peace envoy meets with Netanyahu on Gaza disarmament deal and urges a halt to strikes
      news4jax.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Gaza weapons disarmament must come before Israeli withdrawal , peace board says
      albawaba.net · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Even if Hamas disarms , the challenge in Gaza will be accountability - 04 - Aug - 2026
      home.nzcity.co.nz · English · tone NA

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-03) Dota 2: Team Liquid vs Vici Gaming (BO3) - 1win Essence Playoffs
      yes price: 100% · 24h volume: $1,401,571 · resolves 2026-08-04
  - (2026-08-03) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $747,594 · resolves 2026-06-01
  - (2026-08-03) Canadian Open: Matteo Berrettini vs Mariano Navone
      yes price: 8% · 24h volume: $514,378 · resolves 2026-08-10
  - (2026-08-03) Will Trump speak to Emmanuel Macron in July?
      yes price: 1% · 24h volume: $464,193 · resolves 2026-07-31
  - (2026-08-03) LoL: Karmine Corp vs Team Heretics - Game 2 Winner
      yes price: 100% · 24h volume: $429,345 · resolves 2026-08-03
  - (2026-08-03) St. Louis Cardinals vs. New York Yankees
      yes price: 56% · 24h volume: $399,764 · resolves 2026-08-10

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-08-03) M 5.2 - 66 km WNW of San Alejandro, Peru
      M5.2 · 66 km WNW of San Alejandro, Peru · depth 125.256 km
  - (2026-08-03) M 5.0 - 36 km NNE of Suez, Egypt
      M5.0 · 36 km NNE of Suez, Egypt · depth 10 km
  - (2026-08-03) M 4.9 - 85 km S of Severo-Kuril’sk, Russia
      M4.9 · 85 km S of Severo-Kuril’sk, Russia · depth 57.695 km
  - (2026-08-03) M 4.9 - Fiji region
      M4.9 · Fiji region · depth 10 km
  - (2026-08-03) M 4.9 - 14 km ESE of Yibin, China
      M4.9 · 14 km ESE of Yibin, China · depth 10 km
  - (2026-08-03) M 4.8 - 198 km SE of Severo-Kuril’sk, Russia
      M4.8 · 198 km SE of Severo-Kuril’sk, Russia · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-08-03) #30 Masayoshi Son — $64.92B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-03) MOVER ▲ Elon Musk — $725.94B (+$35.82B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-03) MOVER ▲ Larry Ellison — $181.00B (+$13.49B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-03) MOVER ▲ Larry Page — $305.09B (+$12.98B since yesterday)
      United States · Technology · source: Google
  - (2026-08-03) MOVER ▲ Sergey Brin — $281.37B (+$11.93B since yesterday)
      United States · Technology · source: Google
  - (2026-08-03) MOVER ▲ Mark Zuckerberg — $202.66B (+$11.37B since yesterday)
      United States · Technology · source: Facebook

### Government & military aircraft airborne (OpenSky) — 9 new of 9 total
  - (2026-08-03) PAT871 (United States)
      icao24: adfe49 · position: (39.8264, -74.6678) · alt: 632m · 357km/h
  - (2026-08-03) SAMU45 (France)
      icao24: 39ca85 · position: (48.1881, 1.701) · alt: 464m · 238km/h
  - (2026-08-03) NCR852 (United States)
      icao24: acb84d · position: (61.2102, -144.1141) · alt: 9448m · 959km/h
  - (2026-08-03) GAF857 (Germany)
      icao24: 3f9a92 · position: (40.9191, -76.4258) · alt: 10210m · 992km/h
  - (2026-08-03) RCH341 (United States)
      icao24: ae145a · position: (40.6538, -100.9265) · alt: 10668m · 928km/h
  - (2026-08-03) RCH5005 (United States)
      icao24: ae0676 · position: (26.7843, 127.3714) · alt: 9144m · 905km/h

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-08-03) [Marginal Revolution] How does the market regard stablecoins?
      We study the demand for safety and liquidity in the crypto ecosystem. We do so under a framework in which a representative investor allocates liquidity across stablecoin deposits in lending pools and traditional safe ass…
  - (2026-08-03) [Marginal Revolution] Monday assorted links
      1. A new simulation argument? 2. PC on aesthetics. 3. An interview with Yiyang Zhuge. 4. The truth and aesthetics of going to church? 5. Some forms of math cope? And a different view. 6. At the demolition derby. The post…
  - (2026-08-03) [Marginal Revolution] What should I ask Nick Bostrom?
      Yes I will be doing a Conversation with him. So what should I ask? If you need them, here are various Bostrom links. The post What should I ask Nick Bostrom? appeared first on Marginal REVOLUTION.
  - (2026-08-03) [Conversable Economist] Summer 2026 Journal of Economic Perspectives Freely Available Online
      I have been the Managing Editor of the Journal of Economic Perspectives since the first issue in Summer 1987. The JEP is published by the American Economic Association, which decided back in 2011–to my delight–that the j…

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 104 total
  - (2026-08-03) [OFAC] Issuance of Amended Venezuela-related General License and Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Issuance of Amended Venezuela-related General License and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra Office of Foreign Assets Control (.gov)
  - (2026-08-03) [UN Sanctions] page checksum 2151774f2271
      Active UN Security Council sanctions committees page snapshot

### GDACS — global disaster alerts — 3 new of 236 total
  - (2026-07-25) [Green] Flood in Yemen
      Flood · Green alert · Yemen · Magnitude 0
  - (2026-07-25) [Green] Flood in Yemen
      Flood · Green alert · Yemen · Magnitude 0
  - (2026-07-25) [Green] Flood in Yemen
      Flood · Green alert · Yemen · Magnitude 0

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 10 total
  - (2026-08-03) CVE-2026-18577 · N-able N-central: N-able N-central Authentication Bypass Using an Alternate Path or Channel Vulnerability
      vendor: N-able · product: N-central · CISA remediation by 2026-08-06

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: proposing, taking, action, order, safety, standard, notice, issued, program, proposes, published, provide
- state_bills: today=108, 7d-median=108, 14d-median=112; carrying terms: conditions, appropriations, assistance, county, private, service, adopt, action, business, reporting, schools, policy
- state_news: today=490, 7d-median=758, 14d-median=493; carrying terms: focus, tariffs, attention, session, chief, candidate, young, leaving, world, agenda, catching, power
- local_news: today=230, 7d-median=228, 14d-median=228; carrying terms: evening, world, court, faces, afternoon, fetchpriority, weekend, emergency, crash, https, illinois, public
- foreign_news: today=993, 7d-median=1022, 14d-median=1007; carrying terms: boxing, successful, author, session, promotes, tehran, traditional, mainland, helped, world, firms, power
- chinese_internal: today=253, 7d-median=266, 14d-median=265; carrying terms: firms, china, https, chinese, caixin, google, global, people, record, market, office, stock
- russian_internal: today=865, 7d-median=916, 14d-median=879; carrying terms: telegram, bloomberg, openai, patriot, https, associated, centcom, group, wildberries, novaya, error, gazeta
- ukrainian_internal: today=125, 7d-median=133, 14d-median=133; carrying terms: campaign, hmarochos, history, developments, targeting, intercepted, reports, power, defenses, additional, service, court
- ukraine_theater: today=639, 7d-median=639, 14d-median=639; carrying terms: firms, https, nominal, polygon, error, alerts, daily, thermal, coverage, known, acquired, frontline
- paper_bets: today=141, 7d-median=134, 14d-median=134; carrying terms: sachs, mamdani, token, alaska, russell, source, hampshire, colonize, alphabetically, kansas, fusion, season
- weather: today=177, 7d-median=173, 14d-median=175; carrying terms: vessels, evening, formation, northwest, afddtx, conditions, inland, ridge, moderate, likely, afdhgx, additional
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: total, headline, unrate, assets, jolts, funds, sheet, dcoilwtico, recession, spread, pcepilfe, dexchus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, large, nasdaq, credit, corporate, proxy, agriculture, rates, yield, close, crypto, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=104, 7d-median=104, 14d-median=104; carrying terms: protests, recognition, production, embargo, events, campaign, support, energy, prohibited, leland, tiananmen, yemen
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, https, quantitative, httperror, quiver, quiverquant, congresstrading, error, client
- billionaires: today=40, 7d-median=37, 14d-median=37; carrying terms: hathaway, amancio, gautam, peterffy, exchange, alice, euronext, giancarlo, steve, google, mexico, ballmer
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: county, california, court, jones, texas, services, delaware, johnson, appeals, supreme, arizona, gregory
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, daniel, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, raised, cortez, angels, talarico, sherrod, brown, elect, johnson, alexandria, house, booker
- gdelt_regions: today=0, 7d-median=6, 14d-median=9; carrying terms: english, china
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, trump, spanish, netanyahu, keywords, israeli, strike, drone, strikes, attacks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=9, 7d-median=15, 14d-median=15; carrying terms: position, france, ground, china
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: focus, onset, ethiopian, welfare, americas, ethiopia, discharged, algeria, monthly, among, driven, support
- cisa_kev: today=10, 7d-median=10, 14d-median=12; carrying terms: overflow, sharepoint, control, buffer, untrusted, command, smartconsole, authentication, microsoft, check, management, deserialization
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=236, 7d-median=287, 14d-median=286; carrying terms: liechtenstein, costa, papua, salvador, ethiopia, mexico, flood, hungary, forest, guinea, monaco, herzegovina
- usgs_quakes: today=14, 7d-median=20, 14d-median=20; carrying terms: depth, islands, region, japan, mexico, russia, china, severo, kuril, alaska, argentina
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, prime, traffic, normal, ceasefire, august, strait, returns, hormuz, interest
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: economist, having, https, marginal, class, government, conversableeconomist, revolution, conversable, assorted, links, toward
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: campaign, review, years, hacker, world, autonomous, networks, access, third, going, essay, newsletter
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: ronny, patty, martin, agriculture, lynch, hoeven, blake, pelosi, brett, masto, rochester, bonamici
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, sufficient, converges, today, unavailable, paper, module, identify, decision, placed, placement, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*