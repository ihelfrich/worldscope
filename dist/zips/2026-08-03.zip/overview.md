# WORLDSCOPE morning brief — 2026-08-03

## Headline
2237 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (620) · Russian Internal News (state + in-exile) (560) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (133) · State-Level News (113) · Ukraine Theater (total-war monitoring) (109) · Local News: St. Louis + Atlanta (78) · Ukrainian Internal News (national + local Kyiv) (40) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (29)

## What changed today
### International News + Multilateral Institutions — 620 new of 956 total
  - (2026-08-03) [Global] Pakistan-administered Kashmir elections and protests – all you need to know
      Protests over refugee seats turn deadly, forcing staggered elections under internet blackout and calls for a boycott.
  - (2026-08-03) [Global] Ukraine strikes Russia’s biggest retailer again
      Ukraine has struck another warehouse belonging to Russian e-commerce giant Wildberries in a long-range drone attack.
  - (2026-08-03) [Global] Israel defies Trump’s peace plan as it escalates deadly attacks on Gaza
      Israel escalates Gaza attacks and pushes hardline demands, threatening the US-backed peace roadmap.
  - (2026-08-03) [Global] US cricket player Reddy receives eight-year ban for match-fixing
      ICC Anti-Corruption Tribunal says Akhilesh Reddy guilty of three offences during Abu Dhabi T10 competition in November.
  - (2026-08-03) [Global] North Koreans flood new ‘tourist zone’ beach amid heatwave
      North Koreans flood new ‘tourist zone’ beach amid heatwave
  - (2026-08-03) [Global] First moments of Egypt earthquake caught during livestream
      A magnitude 5.4 earthquake struck Egypt, north of Suez early on Monday, startling a content creator during a livestream.

### Russian Internal News (state + in-exile) — 560 new of 861 total
  - (2026-08-03) Погиб Глен Хансард — музыкант, ставший одним из символов Ирландии. Если он шептал, то так, как будто рядом — никого. Если кричал, то так, что тряслись стены | LEDE: 29 июля погиб Глен Хансар] (ru: Пог…
      29 июля погиб Глен Хансард — ирландский музыкант, фронтмен группы The Frames, участник дуэта Swell Season и обладатель «Оскара»: в 2008 году он получил награду за песню «Falling Slowly» из фильма «Однажды». Хансард попал…
  - (2026-08-03) В Геленджике украинский дрон упал на пляж с отдыхающими. Система оповещения не работала | LEDE: В результате атаки украинских беспилотников в поселке Архипо-Осиповка в Геленджике погибли шес] (ru: В Г…
      В результате атаки украинских беспилотников в поселке Архипо-Осиповка в Геленджике погибли шесть человек, среди них трое детей. Об этом сообщил губернатор Краснодарского края Вениамин Кондратьев.
  - (2026-08-03) В Красноярском крае резко подешевел бензин. Возможно, из-за визита Путина | LEDE: Цены на топливо на заправках в Красноярском крае резко снизились более чем на 20 рублей, сообщают корреспонд] (ru: В К…
      Цены на топливо на заправках в Красноярском крае резко снизились более чем на 20 рублей, сообщают корреспонденты издания NGS24. По их словам, изменения произошли вечером, 2 августа, на АЗС краевой сети «Красноярскнефтепр…
  - (2026-08-03) Рустем Умеров (переговорщик с Россией и США) назначен главой Службы внешней разведки Украины | LEDE: Владимир Зеленский назначит секретаря Совета национальной безопасности Украины Рустема Ум] (ru: Рус…
      Владимир Зеленский назначит секретаря Совета национальной безопасности Украины Рустема Умерова главой Службы внешней разведки, сообщили «Украинская правда» и «РБК-Украина» со ссылкой на источники.
  - (2026-08-03) Борис Надеждин уехал во Францию | LEDE: Политик Борис Надеждин уехал из России во Францию. Он опубликовал в своем телеграм-канале видео, на котором он стоит на фоне Эйфелевой башни в Париже.] (ru: Бор…
      Политик Борис Надеждин уехал из России во Францию. Он опубликовал в своем телеграм-канале видео, на котором он стоит на фоне Эйфелевой башни в Париже.
  - (2026-08-03) «Киевские террористы хотели припугнуть итальянцев, работающих в России». МИД РФ — о взрыве в московском ресторане Balzi Rossi | LEDE: Посольство России в Италии прокомментировало взрыв в мос] (ru: «Ки…
      Посольство России в Италии прокомментировало взрыв в московском ресторане Balzi Rossi, обвинив в причастности к нему Украину.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 133 new of 145 total
  - (2026-08-03) [Severe] Special Marine Warning: Special Marine Warning issued August 3 at 8:21AM EDT until August 3 at 9:45AM EDT by NWS Mount Holly NJ
      SMWPHI The National Weather Service in Mount Holly NJ has issued a * Special Marine Warning for... Delaware Bay... Coastal waters from Cape May NJ to Cape Henlopen DE out 20 nm... * Until 945 AM EDT. * At 820 AM EDT, a s…
  - (2026-08-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-03) [Moderate] Gale Warning: Gale Warning issued August 3 at 4:16AM AKDT until August 3 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-08-03) [Moderate] Gale Warning: Gale Warning issued August 3 at 4:16AM AKDT until August 3 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-08-03) [Severe] Flash Flood Warning: Flash Flood Warning issued August 3 at 8:15AM EDT until August 3 at 11:45AM EDT by NWS Boston/Norton MA
      FFWBOX The National Weather Service in Norton has issued a * Flash Flood Warning for... West Central Bristol County in southeastern Massachusetts... Northwestern Bristol County in Rhode Island... Kent County in Rhode Isl…
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 7:11AM CDT by NWS Bismarck ND
      At 710 AM CDT, strong thunderstorms were located along a line extending from Bismarck to near St. Anthony. Movement was northeast at 50 mph. HAZARD...Wind gusts up to 55 mph. SOURCE...Surface observations. IMPACT...Gusty…

### State-Level News — 113 new of 252 total
  - (2026-08-03) [Connecticut] What to know about CT’s efforts to jumpstart a quantum economy
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/LAMONT-NSF-PRESSER-0715-0715-SG-20-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decodin…
  - (2026-08-03) [Connecticut] CT insurers deny adequate coverage for chronic illness
      <img width="1024" height="576" src="https://ctmirror.org/wp-content/uploads/2026/07/Autoinjector_with_Amgevita_by_Amgen_Adalimumab-1024x576.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=""…
  - (2026-08-03) [California] ‘Don’t Flock me’: California, U.S. lawmakers debate license plate reader technology
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/021926-Flock-Camera-LV-CM-06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-03) [California] ‘Kids are actually eating the food’: State expands lunch program that pairs schools with farms
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072826_SCHOOL-MEALS_AHK_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-03) [California] California voters have approved billions of dollars in bonds. Why don’t we track results?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/07/053124-Bakersfield-Rural-Homelessness-LV_05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size w…
  - (2026-08-03) [Delaware] At the Delaware State Fair, young farmers showcase their cattle-log
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/08/cow_lineup.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decod…

### Ukraine Theater (total-war monitoring) — 109 new of 421 total
  - (2026-08-03) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-02) [FIRMS] thermal anomaly 52.845, 29.992 (FRP 0.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 0.9 MW
  - (2026-08-02) [FIRMS] thermal anomaly 52.847, 29.989 (FRP 1.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 1.61 MW
  - (2026-08-02) [FIRMS] thermal anomaly 52.238, 33.792 (FRP 1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 1 MW
  - (2026-08-02) [FIRMS] thermal anomaly 51.895, 29.341 (FRP 3.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 3.01 MW
  - (2026-08-02) [FIRMS] thermal anomaly 51.894, 29.330 (FRP 3.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-02 2259Z, FRP 3.01 MW

### Local News: St. Louis + Atlanta — 78 new of 164 total
  - (2026-08-03) [St. Louis] Event parking switchover trips up downtown St. Louis visitors
      For a while now, people arriving late to a concert at Enterprise Center or a game at Busch Stadium have justified their own tardiness by telling themselves some version of, Well, it’s after 7 p.m., so at least I don’t ha…
  - (2026-08-03) [St. Louis] Hundreds gather to honor couple murdered in Guatemala after removal from Overland
      The recent murders of Nixon Pérez Paz and Glendy Marisol González de la Cruz—an Overland couple who had been forced to return to Guatemala—sent shock waves through the St. Louis region’s immigrant Hispanic community. But…
  - (2026-08-03) [St. Louis] UMSL’s Anchor Accelerator is all about growing local startups
      Scott Morris is intentionally picky about which companies he chooses for the University of Missouri-St. Louis’ Anchor Accelerator, the business development program he runs as the director of UMSL’s Entrepreneurship and I…
  - (2026-08-03) [St. Louis] Local author Chet Hardin details the toxic relationship behind a shocking crime in ‘The Vampire’s Cult’
      St. Louis–based investigative journalist Chet Hardin previously worked alongside author Toni Natalie to expose notorious “Hollywood sex cult” NXIVM in The Program: Inside the Mind of Keith Raniere and the Rise and Fall o…
  - (2026-08-03) [St. Louis] Lou’s Clues – 8/3/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-03) [St. Louis] Inside NCAA Headquarters located in Indianapolis on Friday, March 10, 2023. Ncaa President Charlie Baker
      Logos of NCAA member schools are displayed on a wall inside NCAA Headquarters in Indianapolis.

### Ukrainian Internal News (national + local Kyiv) — 40 new of 109 total
  - (2026-08-03) Зеленський розповів про переговори щодо створення антибалістичної системи "Фрея" | LEDE: Зеленський повідомив, що до коаліції зі створення антибалістичної системи "Фрея" вже входять десять держ] (uk:…
      Зеленський повідомив, що до коаліції зі створення антибалістичної системи "Фрея" вже входять десять держав і дванадцять компаній, а переговори щодо її розширення тривають.
  - (2026-08-03) Соратник Качинського використав напад українця на польку, щоб розкритикувати уряд Туска | LEDE: Польські політики закликають до жорстких заходів після нападу українця у Вроцлаві. Затриманому за] (uk:…
      Польські політики закликають до жорстких заходів після нападу українця у Вроцлаві. Затриманому загрожує депортація.
  - (2026-08-03) Росіяни атакували саперів під час розмінування на Запоріжжі: двоє поранених | LEDE: Двоє саперів ДСНС отримали травми через прицільний удар РФ у Запорізькому районі.] (uk: Росіяни атакували саперів пі…
      Двоє саперів ДСНС отримали травми через прицільний удар РФ у Запорізькому районі.
  - (2026-08-03) Влада Сеути заявила, що в місті лишається до п’яти тисяч мігрантів з Марокко | LEDE: Мер Сеути Хуан Хесус Вівас у понеділок заявив, що у місті досі лишаються від 3 до 5 тисяч мігрантів з Марокк] (uk:…
      Мер Сеути Хуан Хесус Вівас у понеділок заявив, що у місті досі лишаються від 3 до 5 тисяч мігрантів з Марокко.
  - (2026-08-03) "Гучно слухали музику": у польській поліції розповіли подробиці побиття українців | LEDE: Прессекретар Воєводської поліції в Гожуві-Великопольському в ефірі Радіо ZET розповів, що безпосередньо] (uk:…
      Прессекретар Воєводської поліції в Гожуві-Великопольському в ефірі Радіо ZET розповів, що безпосередньою причиною конфлікту, який закінчився побиттям трьох українців у Любуському воєводстві Польщі, стало гучне відтворенн…
  - (2026-08-03) Росіяни вдарили по АЗС на Дніпропетровщині – убили 3 людей | LEDE: Троє людей загинули під час атаки на автозаправку у Криворізькому районі Дніпропетровщини 3 серпня.] (uk: Росіяни вдарили по АЗС на Д…
      Троє людей загинули під час атаки на автозаправку у Криворізькому районі Дніпропетровщини 3 серпня.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-03) 497J - Tidal Trust IV (0002043390) (Filer)
      filed 2026-08-03 12:23 UTC — Filed: 2026-08-03 AccNo: 0001999371-26-016738 Size: 7 KB
  - (2026-08-03) 425 - COLUMBIA FUNDS SERIES TRUST I (0000773757) (Subject)
      filed 2026-08-03 12:11 UTC — Filed: 2026-08-03 AccNo: 0001193125-26-329588 Size: 17 KB
  - (2026-08-03) 497K - COLUMBIA FUNDS SERIES TRUST I (0000773757) (Filer)
      filed 2026-08-03 12:08 UTC — Filed: 2026-08-03 AccNo: 0001193125-26-329584 Size: 13 KB
  - (2026-08-03) [Distler Stephen] Form 4 (Reporting)
      filed 2026-08-03 12:07 UTC · role: Reporting — Filed: 2026-08-03 AccNo: 0001193125-26-329577 Size: 5 KB
  - (2026-08-03) [Princeton Bancorp, Inc.] Form 4 (Issuer)
      filed 2026-08-03 12:07 UTC · role: Issuer — Filed: 2026-08-03 AccNo: 0001193125-26-329577 Size: 5 KB
  - (2026-08-03) 497 - COLUMBIA FUNDS SERIES TRUST I (0000773757) (Filer)
      filed 2026-08-03 12:05 UTC — Filed: 2026-08-03 AccNo: 0001193125-26-329575 Size: 13 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-03) [United States] Trump Announces Fresh Iran Talks after Strike Uturn | Peak Oil News and Message Boards
      domain: peakoil.com · language: English · tone:
  - (2026-08-03) [United Kingdom] Couple face huge court bill after losing neighbours fight over ornamental squirrel
      domain: independent.co.uk · language: English · tone:
  - (2026-08-03) [India] This silent heart condition may begin with unexplained fatigue : Cardiologist shares 5 signs , steps for early detection
      domain: hindustantimes.com · language: English · tone:
  - (2026-08-03) [India] Hundreds hold candlelight vigil in New York to mark one month since Lobga Rangzen death ; renew call for Tibetan independence
      domain: aninews.in · language: English · tone:
  - (2026-08-03) [Singapore] How a US - Japan pact to hit yen speculators came together
      domain: businesstimes.com.sg · language: English · tone:
  - (2026-08-03) [United Kingdom] Stoic Duke of Kent , 90 , hosts a Kensington Palace engagement for a cause close to his heart
      domain: tatler.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-03) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (34.8759, -6.224) · alt: 10668m · 871km/h
  - (2026-08-03) GAF615 (Germany)
      icao24: 3f6533 · position: (49.032, 3.4744) · alt: 8534m · 939km/h
  - (2026-08-03) JAF1VY (Bulgaria)
      icao24: 4520aa · position: (49.1125, 2.0711) · alt: 8839m · 806km/h
  - (2026-08-03) PAT959 (United States)
      icao24: adfe8d · position: (38.5828, -78.6537) · alt: 2773m · 452km/h
  - (2026-08-03) CFC2589 (Canada)
      icao24: c2b5a3 · position: (45.2977, -75.6294) · alt: 335m · 222km/h
  - (2026-08-03) GAF891 (Germany)
      icao24: 3f97fd · position: (49.4015, 11.2132) · alt: 2621m · 501km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Trump Announces Fresh Iran Talks after Strike Uturn | Peak Oil News and Message Boards
      peakoil.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Spain Migrant Crisis Follows Years of Israeli Warnings , US Pushback
      military.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Israel conveys concern to US on Gaza plan – The Frontier Post
      thefrontierpost.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Aoun urges judiciary to issue Beirut port blast indictment
      naharnet.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] UN says Israeli demolitions in Lebanon deeply concerning
      naharnet.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Lebanese military delegation to take part in Rome talks with Israel
      naharnet.com · English · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 21 new of 57 total
  - (2026-08-03) [The Hacker News] FOMO in the SOC: Where AI Platforms like Claude Actually Fit
      AI is moving incredibly fast, and every security leader is feeling the pressure to keep up. AI platforms like Claude, Codex and Cursor are already helping security teams write detections, investigate alerts, summarize in…
  - (2026-08-03) [The Hacker News] Chinese Threat Actor Uses Leaked DarkSword Kit to Deploy GHOSTBLADE on iOS
      An unknown Chinese-threat actor has been observed running a campaign targeting Apple iOS devices by leveraging a publicly leaked version of the DarkSword exploit kit. Attack surface management platform Censys said it ide…
  - (2026-08-03) [The Hacker News] PNLD Breach Exposes U.K. Police and Government Contact Details on Dark Web
      The Police National Legal Database (PNLD) has confirmed that police, government and customer contact information was compromised and published on the dark web. The data included names, organisations and work email addres…
  - (2026-08-03) [The Hacker News] Thermo Fisher Patches Flaw That Could Make DNA File Tampering Nearly Undetectable
      Thermo Fisher Scientific has patched a flaw in select Applied Biosystems human identification software that could allow data files to be altered before analysis software loads them. The vendor's July 31 security bulletin…
  - (2026-08-03) [The Hacker News] N-able Says Attackers Take Over N-central Servers After Initial Fix Proves Incomplete
      N-able said attackers exploited an authentication bypass in N-central to gain remote administrative access and reach the customer systems managed through those servers. Its first fix was incomplete. CVE-2026-18577 affect…
  - (2026-08-03) [The Record] Russian hackers hijack hotel Wi-Fi networks to spy on travelers, Microsoft says
      Russian state-sponsored hackers have been compromising hotel Wi-Fi networks around the world to steal travelers' login credentials and infect devices with espionage malware, Microsoft said.

### Paper Trading Scorecard — 15 new of 129 total
  - (2026-08-03) [Polymarket] Will the Cleveland Guardians win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-08-03) [Polymarket] Will the US strike 13 countries in 2026?
      This market will resolve according to the total number of different countries' soil that the United States initiates a drone, missile, or air strike on between January 1, 2026, 12:00 AM ET and December 31, 2026, 11:59 PM…
  - (2026-08-03) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-08-03) [Manifold] Will a Democrat win Tennessee's 2026 governor election?
  - (2026-08-03) [Manifold] Will this Angine de Poitrine video get more views than the number of inhabitants of the Tokyo metro area within a year?
  - (2026-08-03) [Manifold] If I get a tetanus shot for my scrape will I regret it?

### Chinese Internal News — 14 new of 23 total
  - (2026-08-03) Chinese EV sales falter at home as growth slows
  - (2026-08-03) Multinational giants defy China’s sluggish retail market with strong 2026 sales
  - (2026-08-03) Hong Kong’s Chinese bond futures are a major step for the global yuan
  - (2026-08-03) China’s tech giants race to put AI on delivery riders’ heads
  - (2026-08-03) China’s social security fund boosts stakes in A-share firms in first 7 months, data shows
  - (2026-08-03) Chinese EV demand cools

### State Legislative Action — 9 new of 73 total
  - (2026-08-03) [California AB 2461] Oil and gas: bonding requirements.
      Under existing law, the Geologic Energy Management Division in the Department of Conservation regulates the drilling, operation, maintenance, and abandonment of oil and gas wells in the state. The State Oil and Gas Super…
  - (2026-08-03) [California AB 2050] Common interest developments: reserve accounts.
      Existing law, the Davis-Stirling Common Interest Development Act, governs the management and operation of common interest developments, and requires an association to manage a common interest development, including requi…
  - (2026-08-03) [California AB 2716] Oil and gas: bonding requirements.
      Existing law authorizes the Geologic Energy Management Division in the Department of Conservation to require an operator of an oil and gas well to provide, in addition to specified types of required indemnity bonds, an a…
  - (2026-08-03) [California AB 2506] Cannabis: tribal-state agreements.
      Existing law, the Control, Regulate and Tax Adult Use of Marijuana Act (AUMA) , an initiative measure approved by the voters as Proposition 64 at the November 8, 2016, statewide general election, authorizes a person who…
  - (2026-08-03) [California AB 2711] Oil and gas: notice of intention.
      Existing law establishes the Geologic Energy Management Division in the Department of Conservation, under the direction of the State Oil and Gas Supervisor, who is required to supervise the drilling, operation, maintenan…
  - (2026-08-03) [California AB 2521] California Council on Science and Technology: water availability study: Central Valley.
      Existing law establishes the Department of Water Resources within the Natural Resources Agency and vests it with various powers and duties related to water. Existing law requires the State Water Resources Control Board t…

### USGS earthquakes (M4.5+, past day) — 9 new of 19 total
  - (2026-08-03) M 5.2 - 66 km WNW of San Alejandro, Peru
      M5.2 · 66 km WNW of San Alejandro, Peru · depth 125.256 km
  - (2026-08-03) M 5.0 - 36 km NNE of Suez, Egypt
      M5.0 · 36 km NNE of Suez, Egypt · depth 10 km
  - (2026-08-03) M 4.9 - 85 km S of Severo-Kuril’sk, Russia
      M4.9 · 85 km S of Severo-Kuril’sk, Russia · depth 57.695 km
  - (2026-08-03) M 4.9 - Fiji region
      M4.9 · Fiji region · depth 10 km
  - (2026-08-03) M 4.9 - 14 km ESE of Yibin, China
      M4.9 · 14 km ESE of Yibin, China · depth 10 km
  - (2026-08-03) M 4.8 - 152 km S of Hydaburg, Alaska
      M4.8 · 152 km S of Hydaburg, Alaska · depth 15 km

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-08-03) LoL: Nongshim Red Force vs T1 (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 44% · 24h volume: $1,010,874 · resolves 2026-08-03
  - (2026-08-03) LoL: Gen.G vs Hanwha Life Esports (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 0% · 24h volume: $842,075 · resolves 2026-08-03
  - (2026-08-03) LoL: Nongshim Red Force vs T1 - Game 1 Winner
      yes price: 0% · 24h volume: $517,887 · resolves 2026-08-03
  - (2026-08-03) Dota 2: LGD Gaming vs 1win - Game 2 Winner
      yes price: 0% · 24h volume: $517,611 · resolves 2026-08-03
  - (2026-08-03) Will Trump speak to Emmanuel Macron in July?
      yes price: 1% · 24h volume: $499,823 · resolves 2026-07-31
  - (2026-08-03) LoL: HANJIN BRION Challengers vs BNK FearX Youth (BO3) - LCK Challengers League Rounds 3-4 Trial Group
      yes price: 0% · 24h volume: $427,425 · resolves 2026-08-03

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-08-04) Connecticut Supreme Court: Ashworth v. Branford
  - (2026-08-04) Connecticut Supreme Court: TOV Realty, LLC v. Suarez
  - (2026-07-31) Alaska Supreme Court: In Re Meeker Revocable Trust U/A/D July 15, 2014
  - (2026-07-29) U.S. Court of Appeals, 11th Cir.: The Town of Pine Hill, Alabama v. 3M Company
  - (2026-07-29) U.S. Court of Appeals, 11th Cir.: African People's Education and Defense Fund, Inc. v. Pinellas County

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 33 total
  - (2026-08-03) #30 Masayoshi Son — $64.92B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-03) MOVER ▼ Bernard Arnault & family — $150.42B ($-1.02B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-03) MOVER ▲ Amancio Ortega — $146.47B (+$0.34B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-03) MOVER ▼ Francoise Bettencourt Meyers & family — $96.48B ($-0.18B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### GDACS — global disaster alerts — 3 new of 234 total
  - (2026-07-25) [Green] Flood in Yemen
      Flood · Green alert · Yemen · Magnitude 0
  - (2026-07-25) [Green] Flood in Yemen
      Flood · Green alert · Yemen · Magnitude 0
  - (2026-07-25) [Green] Flood in Yemen
      Flood · Green alert · Yemen · Magnitude 0

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-03) [Marginal Revolution] On infinite ethics
      Infinite numbers have long troubled utilitarian ethicists: if the universe is boundless, then there is infinite positive utility and infinite negative utility, and we can’t even define our current state, let alone affect…
  - (2026-08-03) [Marginal Revolution] *Rome’s Age of Revolution*
      The author is Tim Whitmarsh and the subtitle is Augustus, Empire and the Making of Christianity. This is the most important book on the history of Christianity I have read in a long time, and it is also an important work…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: management, notice, requires, safety, standard, program, proposed, rulemaking, taking, published, proposes, final
- state_bills: today=73, 7d-median=106, 14d-median=112; carrying terms: specified, hours, safety, board, projects, housing, schools, allows, defines, comprehensive, right, person
- state_news: today=252, 7d-median=758, 14d-median=493; carrying terms: review, homeland, released, bubble, medical, company, massive, congressional, afternoon, arkansas, protest, primary
- local_news: today=164, 7d-median=224, 14d-median=224; carrying terms: vehicle, afternoon, emergency, court, magazine, evening, world, injured, according, killed, people, https
- foreign_news: today=956, 7d-median=1022, 14d-median=1007; carrying terms: review, tourist, released, company, images, afternoon, incident, menghai, since, israeli, odisha, millions
- chinese_internal: today=23, 7d-median=266, 14d-median=265; carrying terms: google, caixin, china, record, global, people, firms, https, chinese, office, price, market
- russian_internal: today=861, 7d-median=916, 14d-median=879; carrying terms: telegram, novayagazeta, bloomberg, istories, title, error, centcom, wildberries, novaya, times, https, russian
- ukrainian_internal: today=109, 7d-median=133, 14d-median=133; carrying terms: assault, company, massive, warfare, minister, court, talks, today, injured, using, carefully, crimea
- ukraine_theater: today=421, 7d-median=627, 14d-median=627; carrying terms: httperror, community, google, snapshot, known, acquired, viirs, unauthorized, nominal, polygon, liveuamap, maintained
- paper_bets: today=129, 7d-median=134, 14d-median=134; carrying terms: specified, drought, general, carolina, earthquake, lifetime, benefits, office, payable, minister, senate, determined
- weather: today=145, 7d-median=173, 14d-median=173; carrying terms: tuesday, doppler, ocean, afdmfl, hours, likely, hurricane, afternoon, watch, valleys, onshore, today
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: money, vixcls, crude, labor, dexjpus, recession, effective, consumption, payems, cpiaucsl, latest, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, silver, crude, natural, corporate, rates, china, range, yield, crypto, russell, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=87, 7d-median=104, 14d-median=104; carrying terms: restrictive, homeland, involvement, management, integrity, libya, renewable, checksum, sanctions, company, terrorist, agency
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, client, httperror, quiver, quantitative, quiverquant, congresstrading, error, https
- billionaires: today=33, 7d-median=35, 14d-median=35; carrying terms: peterffy, walton, larry, google, euronext, japan, semiconductors, france, india, trading, michael, bloomberg
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: johnson, appeals, court, supreme, blanche, arizona, texas, jones, services, county, delaware, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, bancorp, michael, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, alexandria, johnson, cortez, talarico, james, filing, platner, warner, angels, michael, raised
- gdelt_regions: today=0, 7d-median=6, 14d-median=9; carrying terms: english, china
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, trump, keywords, crisis, saudi, israeli, conflict, white, nuclear, house
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: crisis, domain, language, english, years
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: position, canada, belgium, france, ground, kingdom, china
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: geographical, pregnant, poverty, sylvatic, general, dhaka, derived, ministry, ebola, province, india, announcing
- cisa_kev: today=9, 7d-median=9, 14d-median=12; carrying terms: stack, injection, management, conflict, smartconsole, vulnerability, improper, control, authentication, untrusted, sharepoint, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=234, 7d-median=287, 14d-median=286; carrying terms: impact, drought, russia, slovakia, macedonia, somalia, france, green, alert, flood, colombia, forest
- usgs_quakes: today=19, 7d-median=20, 14d-median=20; carrying terms: depth, japan, south, indonesia, region, russia, china, philippines, mexico, tonga, severo, kuril
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, strait, returns, ceasefire, traffic, hormuz, normal, august, effective, invade
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: having, conversable, government, students, class, marginal, certain, college, conversableeconomist, revolution, doctor, become
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: review, vulnerability, company, going, today, world, according, using, originally, targeted, weekly, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: homeland, fetterman, alexandria, beatty, husted, nydia, davidson, rounds, mcclellan, warsh, suhas, bradley
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, placement, unavailable, evidence, either, paper, claude, consensus, converges, market, today, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*