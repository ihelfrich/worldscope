# WORLDSCOPE morning brief — 2026-08-03

## Headline
2247 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (571) · Russian Internal News (state + in-exile) (527) · World leaders & government officials (324) · Chinese Internal News (198) · U.S. Weather + Severe / Climate Outlooks (161) · State-Level News (83) · GDELT GKG — themes / entities / watch areas (74) · Local News: St. Louis + Atlanta (65) · Ukraine Theater (total-war monitoring) (57) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (35) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 571 new of 951 total
  - (2026-08-03) [Global] Weather tracker: Austria breaks heat records as Japan braces for Typhoon Dolphin
  - (2026-08-03) [Global] Nauru officially changes its name to Naoero
  - (2026-08-03) [Global] Yen hits three-month high after Trump helps prop up currency
  - (2026-08-03) [Global] ‘Stop all outdoor activities’: South Korea records its highest ever temperature
  - (2026-08-03) [Global] New Zealand legislation making English an official language ridiculed as ‘pathetic’
  - (2026-08-03) [Global] Massive Attack speak about ‘surreal experience’ of being banned from Singapore over Palestinian flag

### Russian Internal News (state + in-exile) — 527 new of 831 total
  - (2026-08-03) Рустем Умеров (переговорщик с Россией и США) станет главой Службы внешней разведки Украины | LEDE: Владимир Зеленский назначит секретаря Совета национальной безопасности Украины Рустема Умер] (ru: Рус…
      Владимир Зеленский назначит секретаря Совета национальной безопасности Украины Рустема Умерова главой Службы внешней разведки, сообщили «Украинская правда» и «РБК-Украина» со ссылкой на источники.
  - (2026-08-03) Борис Надеждин уехал во Францию | LEDE: Политик Борис Надеждин уехал из России во Францию. Он опубликовал в своем телеграм-канале видео, на котором он стоит на фоне Эйфелевой башни в Париже.] (ru: Бор…
      Политик Борис Надеждин уехал из России во Францию. Он опубликовал в своем телеграм-канале видео, на котором он стоит на фоне Эйфелевой башни в Париже.
  - (2026-08-03) «Киевские террористы хотели припугнуть итальянцев, работающих в России». МИД РФ — о взрыве в московском ресторане Balzi Rossi | LEDE: Посольство России в Италии прокомментировало взрыв в мос] (ru: «Ки…
      Посольство России в Италии прокомментировало взрыв в московском ресторане Balzi Rossi, обвинив в причастности к нему Украину.
  - (2026-08-03) Сотрудникам Wildberries запретили приносить на склады смартфоны. Разрешены только кнопочные телефоны без камер | LEDE: Сотрудникам Wildberries с 3 августа запретили проносить на склады свои ] (ru: Сот…
      Сотрудникам Wildberries с 3 августа запретили проносить на склады свои смартфоны, пишет телеграм-канал «Осторожно, новости» со ссылкой на внутреннее уведомление, разосланное компанией.
  - (2026-08-03) Украинские беспилотники атаковали Геленджик и аннексированный Крым. Погибли шесть человек | LEDE: Три человека погибли, еще двое получили ранения в результате атаки украинских беспилотников ] (ru: Укр…
      Три человека погибли, еще двое получили ранения в результате атаки украинских беспилотников в аннексированном Крыму, заявил назначенный РФ глава полуострова Сергей Аксенов. О других последствиях ударов Украины он не сооб…
  - (2026-08-03) Польский пловец с пятой попытки пересек Балтийское море. Он преодолел 160 километров вплавь | LEDE: Польский пловец на сверхдлинные дистанции Бартломей Кубковский переплыл Балтийское море, п] (ru: Пол…
      Польский пловец на сверхдлинные дистанции Бартломей Кубковский переплыл Балтийское море, преодолев 160 километров пути примерно за 55 часов.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 198 new of 240 total
  - (2026-08-02) 秘鲁纳斯卡观光飞机坠毁13人遇难 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBiY0VfU0tHajE3NTMwc0oxUkFYTFpMMFFDMUIwTDVfd2x3RmJtRGxaTW9VbFBtZFJkYzBWajJxemlTb3hXSllXSmIwNTV0NDgwNmpua] (zh:…
      秘鲁纳斯卡观光飞机坠毁13人遇难 财新
  - (2026-08-03) 吴清：支持企业跨境双向融资 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBYOXBMQ2xXMWQ3aHdZNlo4Y3ZfdkxjWEpDR0pSYUR3TGg5X2J4RlExbWtTYnF5R1MzUGlfQnNoMGtsbXFjRkZFQU5aUzlhX2lrZ211VGt4] (zh:…
      吴清：支持企业跨境双向融资 财新
  - (2026-08-03) 《悬案》背后｜影视 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1aVWRiejZCd0JKV19nWngwbzdJS3BJaFNzNlo4dEFNSm9QUmZnRElSU21mYzhyMkVSak8wVTNQSWVLektiNGNvLUZaLVo1cHBzdTF0d1pGYzRG] (zh:…
      《悬案》背后｜影视 财新
  - (2026-08-03) 7月人事综述：换届之年 “70后”省级党委副书记受瞩目 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE0wRTI5NGd1MXNkc3ozOFhWZ2RjSmwxbXM4U2F6QWNyVFktTl9CWWI0eHAtbXM5YXhIWG5fd0VPRkdV] (zh:…
      7月人事综述：换届之年 “70后”省级党委副书记受瞩目 china.caixin.com
  - (2026-08-03) 米琴：《奥德赛》对战争的反思 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBSWjRCQ0RocnYtQi1WVlNoUWNtOVgtdWprWWNLN2lVTUFaWmsxU0ZmNTB4SUo5YXUydmJ2U3pQQXRpYlhLLWFqWC1QWWtrdmQwV3NwcXJ] (zh:…
      米琴：《奥德赛》对战争的反思 财新
  - (2026-08-02) 外汇贷款“专户”管理进一步简化 有出口贸易背景不必另开户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1PNkVZWWdVak5XSlJ0MHkwbHg3aEtOcG40ZmROYnhHYzNELTR0S3psclZrUFV1WjNrMTVPZmdNNDlIalgwcUdFYlpRS] (zh:…
      外汇贷款“专户”管理进一步简化 有出口贸易背景不必另开户 财新

### U.S. Weather + Severe / Climate Outlooks — 161 new of 174 total
  - (2026-08-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-03) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 3 at 6:31AM EDT until August 3 at 10:00AM EDT by NWS Greenville-Spartanburg SC
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Portions of northeast Georgia and Upstate South Carolina. * WHEN...Until 10 AM EDT this morning. * IMPACTS...Low visibility could make driving conditio…
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 6:31AM EDT by NWS Upton NY
      At 631 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from Oakville to Prospect to near Cheshire to Hamden to New Haven to near Orange. Movement was northeast at 50 mph. HAZARD...Wind gust…
  - (2026-08-03) [Severe] Flood Warning: Flood Warning issued August 3 at 6:26AM EDT until August 3 at 8:00AM EDT by NWS Mount Holly NJ
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...A portion of southeast Pennsylvania, including the following counties, Bucks and Montgomery. * WHEN...Until 800 AM EDT. * IMPACTS...It will take sever…
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 5:25AM CDT by NWS Grand Forks ND
      At 525 AM CDT, Doppler radar was tracking a strong thunderstorm near Grygla, or 25 miles northeast of Thief River Falls, moving east at 25 mph. HAZARD...Nickel size hail. SOURCE...Radar indicated. IMPACT...Minor hail dam…
  - (2026-08-03) [Severe] Red Flag Warning: Red Flag Warning issued August 3 at 4:23AM MDT until August 4 at 9:00PM MDT by NWS Salt Lake City UT
      * AFFECTED AREA...Fire Weather Zone 489 San Rafael Swell. * WINDS...Northwest 10 to 20 mph with gusts up to 30 mph. * RELATIVE HUMIDITY...5 to 10 percent. Little to no overnight recovery will occur. * IMPACTS...Critical…

### State-Level News — 83 new of 223 total
  - (2026-08-03) [Connecticut] CT insurers deny adequate coverage for chronic illness
      <img width="1024" height="576" src="https://ctmirror.org/wp-content/uploads/2026/07/Autoinjector_with_Amgevita_by_Amgen_Adalimumab-1024x576.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=""…
  - (2026-08-03) [Arkansas] Wildfire smoke is now the primary pollutant affecting pregnancy, study shows
      A new study examining pollution levels across a 16-year span found that while general pollution levels from sources such as cars and industry have significantly declined, recent increases in wildfire smoke air pollution…
  - (2026-08-03) [Arkansas] Waitlist, policy changes stir worries among families of Arkansans with disabilities
      Laura Hellinga moved to a new house in Highfill two years ago, hoping it would be more accessible for her 15-year-old daughter, who was born with a rare joint disorder and uses a motorized wheelchair. Their previous hous…
  - (2026-08-03) [Georgia] Georgia Power breaks ground on natural gas expansion at Plant Bowen despite air pollution concerns
      EUHARLEE, Ga. — A major natural gas expansion at Georgia Power’s Plant Bowen will hurt air quality in the Atlanta region, which is already struggling with ozone pollution, according to environmental groups challenging a…
  - (2026-08-03) [Georgia] Wildfire smoke is now the primary pollutant affecting pregnancy, study shows
      A new study examining pollution levels across a 16-year span found that while general pollution levels from sources such as cars and industry have significantly declined, recent increases in wildfire smoke air pollution…
  - (2026-08-03) [Florida] Florida’s GOP primary for governor: Undignified. Unedifying. Flat-out godawful.
      I know y’all would probably rather not talk about the Republican candidates for governor of Florida. However, distasteful as it is, we must: The primary is Aug. 18. Now, this family-friendly publication frowns on scatolo…

### GDELT GKG — themes / entities / watch areas — 74 new of 74 total
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] The United Arab Emirate delicate balancing act – The Irish Times
      irishtimes.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Israel says it has serious concerns with Hamas disarmament deal
      knpr.org · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Susan Kokinda Breaks Down Camp David Meeting and Ongoing Mid East Conflict
      theconservativetreehouse.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Avigdor Liberman rejects Gadi Eisenkot direction , focuses on replacing Benjamin Netanyahu government
      jpost.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Israel says it has serious concerns with Hamas disarmament deal
      wdiy.org · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Israel says it has serious concerns with Hamas disarmament deal
      wkms.org · English · tone NA

### Local News: St. Louis + Atlanta — 65 new of 192 total
  - (2026-08-03) [St. Louis] UMSL’s Anchor Accelerator is all about growing local startups
      Scott Morris is intentionally picky about which companies he chooses for the University of Missouri-St. Louis’ Anchor Accelerator, the business development program he runs as the director of UMSL’s Entrepreneurship and I…
  - (2026-08-03) [St. Louis] Local author Chet Hardin details the toxic relationship behind a shocking crime in ‘The Vampire’s Cult’
      St. Louis–based investigative journalist Chet Hardin previously worked alongside author Toni Natalie to expose notorious “Hollywood sex cult” NXIVM in The Program: Inside the Mind of Keith Raniere and the Rise and Fall o…
  - (2026-08-03) [St. Louis] Lou’s Clues – 8/3/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-03) [St. Louis] President Trump says Iran war talks will begin Monday after he holds off on 'massive' strikes
      President Donald Trump announced new talks to wind down the war in Iran, starting Monday. He has said he's holding off on massive strikes at the urging of allies.
  - (2026-08-03) [St. Louis] Fires near Spokane, Washington, have burned 600 structures and forced 60,000 evacuations
      The fires in and around Spokane, Washington state's second largest city, burned about 8.2 square miles over the weekend.
  - (2026-08-03) [St. Louis] Who is Chad Williams? What we know about the suspected shooter at an Idaho In-N-Out
      Authorities have released more details about the 24-year-old suspect in a Twin Falls, Idaho, mass shooting, who died by a self-inflicted gunshot wound.

### Ukraine Theater (total-war monitoring) — 57 new of 243 total
  - (2026-08-03) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-02) [Liveuamap] Lebanon news on live map - lebanon.liveuamap.com - Liveuamap
      Lebanon news on live map - lebanon.liveuamap.com Liveuamap
  - (2026-07-30) [Liveuamap] Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160 - Liveuamap
      Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160
  - (2026-08-01) [Liveuamap] Israeli Defense Minister Israel Katz: If the Palestinian Authority starts an Intifada, it's war. We will deal with it the same way we dealt with Gaza and Lebanon. Any city involved will be…
      Israeli Defense Minister Israel Katz: If the Palestinian Authority starts an Intifada
  - (2026-08-01) [Liveuamap] A new airborne assault brigade will be stationed in the Homel region near the Ukrainian border. In Belarus, the formation of the 37th Separate Guards Airborne Assault Brigade of Special Op…
      A new airborne assault brigade will be stationed in the Homel region near the Ukrainian border. In Belarus, the
  - (2026-08-03) [Liveuamap] At Lyman direction clashes yesterday near Lyman, Stavky, Dibrova and near Novoselivka, Ozerne and Zarichne, - General Staff of Armed Forces of Ukraine reports Donetsk Oblast, Ukraine - Ukr…
      At Lyman direction clashes yesterday near Lyman, Stavky, Dibrova and near Novoselivka, Ozerne and Zarichne, - General Staff of A

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-03) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-08-03 10:32 UTC — Filed: 2026-08-03 AccNo: 0001918704-26-022214 Size: 921 KB
  - (2026-08-03) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-08-03 10:32 UTC — Filed: 2026-08-03 AccNo: 0001918704-26-022214 Size: 921 KB
  - (2026-08-03) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-08-03 10:30 UTC — Filed: 2026-08-03 AccNo: 0001918704-26-022213 Size: 669 KB
  - (2026-08-03) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-08-03 10:30 UTC — Filed: 2026-08-03 AccNo: 0001918704-26-022213 Size: 669 KB
  - (2026-08-03) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-08-03 10:28 UTC — Filed: 2026-08-03 AccNo: 0001918704-26-022212 Size: 549 KB
  - (2026-08-03) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-08-03 10:28 UTC — Filed: 2026-08-03 AccNo: 0001918704-26-022212 Size: 549 KB

### Ukrainian Internal News (national + local Kyiv) — 35 new of 105 total
  - (2026-08-03) Росіяни атакували транспортну інфраструктуру на Одещині: 6 постраждалих | LEDE: Внаслідок удару по Одещині 3 серпня постраждали 6 людей, частину госпіталізовано. Триває ліквідація наслідків.] (uk: Рос…
      Внаслідок удару по Одещині 3 серпня постраждали 6 людей, частину госпіталізовано. Триває ліквідація наслідків.
  - (2026-08-03) На Черкащині у чоловіка вилучили 7 автоматів, 10 гранатометів і понад 6,5 тисячі набоїв | LEDE: У 58-річного жителя Черкаського району вилучили арсенал зброї та боєприпасів. Суд відправив чолов] (uk:…
      У 58-річного жителя Черкаського району вилучили арсенал зброї та боєприпасів. Суд відправив чоловіка під домашній арешт.
  - (2026-08-03) У Румунії підірвали скелю на дні Дунаю, щоб допомогти ключовій АЕС | LEDE: У понеділок вранці румунські військові підірвали скелю Пиржоая на дні Дунаю, використавши 180 кілограмів вибухівки, в ] (uk:…
      У понеділок вранці румунські військові підірвали скелю Пиржоая на дні Дунаю, використавши 180 кілограмів вибухівки, в рамках операції, спрямованої на перенаправлення більшого потоку Дунаю до Чернаводської атомної електро…
  - (2026-08-03) Глава МЗС Іспанії запевнив, що із Сеути повернуть усіх мігрантів "до останнього" | LEDE: Міністр закордонних справ Іспанії Хосе Мануель Альбарес пообіцяв, що ті мігранти, які заполонили іспансь] (uk:…
      Міністр закордонних справ Іспанії Хосе Мануель Альбарес пообіцяв, що ті мігранти, які заполонили іспанську Сеуту, "до останнього" повернуться в Марокко.
  - (2026-08-03) У Польщі побили ще трьох громадян України: консульство відреагувало | LEDE: Генконсульство України у Вроцлаві реагує на напад на українців у Кожухові, встановлюються обставини та мотиви.] (uk: У Польщ…
      Генконсульство України у Вроцлаві реагує на напад на українців у Кожухові, встановлюються обставини та мотиви.
  - (2026-08-03) У Запоріжжі троє людей постраждали через російську атаку на АЗС | LEDE: 3 серпня у Запоріжжі дрон влучив у АЗС: поранено трьох людей] (uk: У Запоріжжі троє людей постраждали через російську атаку на А…
      3 серпня у Запоріжжі дрон влучив у АЗС: поранено трьох людей

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-08-03) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (46.3672, 0.8214) · alt: 10972m · 774km/h
  - (2026-08-03) GAF615 (Germany)
      icao24: 3f6533 · position: (54.8979, -3.6386) · alt: 12496m · 859km/h
  - (2026-08-03) GAF681 (Germany)
      icao24: 3e0f78 · position: (47.6344, 11.332) · alt: 1104m · 233km/h
  - (2026-08-03) GAF682 (Germany)
      icao24: 3e0f77 · position: (47.6329, 11.3317) · alt: 1104m · 234km/h
  - (2026-08-03) JAF97T (Belgium)
      icao24: 44d1ba · position: (50.9529, 4.7567) · alt: 929m · 349km/h
  - (2026-08-03) JAF1YV (Belgium)
      icao24: 44d1a6 · position: (44.0281, 15.5992) · alt: 11582m · 843km/h

### Paper Trading Scorecard — 13 new of 127 total
  - (2026-08-03) [Polymarket] Will the Cleveland Guardians win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-08-03) [Polymarket] Will WTI Crude Oil (WTI) hit (LOW) $65 in August?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of August 2026, any 1-minute candle for the Active Month of WTI Crude Oil futures has a final "High" or "Low" price eq…
  - (2026-08-03) [Polymarket] Will the US strike 13 countries in 2026?
      This market will resolve according to the total number of different countries' soil that the United States initiates a drone, missile, or air strike on between January 1, 2026, 12:00 AM ET and December 31, 2026, 11:59 PM…
  - (2026-08-03) [Polymarket] Will Bitcoin dip to $40,000 in August?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa…
  - (2026-08-03) [Manifold] Will this Angine de Poitrine performance get more views than the inhabitants in the Tokyo metro area within a year?
  - (2026-08-03) [Manifold] If I get a tetanus shot for my scrape will I regret it?

### State Legislative Action — 10 new of 74 total
  - (2026-08-03) [California AB 2461] Oil and gas: bonding requirements.
      Under existing law, the Geologic Energy Management Division in the Department of Conservation regulates the drilling, operation, maintenance, and abandonment of oil and gas wells in the state. The State Oil and Gas Super…
  - (2026-08-03) [California AB 2050] Common interest developments: reserve accounts.
      Existing law, the Davis-Stirling Common Interest Development Act, governs the management and operation of common interest developments, and requires an association to manage a common interest development, including requi…
  - (2026-08-03) [California AB 2716] Oil and gas: bonding requirements.
      Existing law authorizes the Geologic Energy Management Division in the Department of Conservation to require an operator of an oil and gas well to provide, in addition to specified types of required indemnity bonds, an a…
  - (2026-08-03) [California AB 2506] Cannabis: tribal-state agreements.
      Existing law, the Control, Regulate and Tax Adult Use of Marijuana Act (AUMA) , an initiative measure approved by the voters as Proposition 64 at the November 8, 2016, statewide general election, authorizes a person who…
  - (2026-08-03) [California AB 2711] Oil and gas: notice of intention.
      Existing law establishes the Geologic Energy Management Division in the Department of Conservation, under the direction of the State Oil and Gas Supervisor, who is required to supervise the drilling, operation, maintenan…
  - (2026-08-03) [California AB 2521] California Council on Science and Technology: water availability study: Central Valley.
      Existing law establishes the Department of Water Resources within the Natural Resources Agency and vests it with various powers and duties related to water. Existing law requires the State Water Resources Control Board t…

### IT, InfoSys & cybersecurity news (last 7 days) — 10 new of 52 total
  - (2026-08-03) [The Hacker News] Thermo Fisher Patches Flaw That Could Make DNA File Tampering Nearly Undetectable
      Thermo Fisher Scientific has patched a flaw in select Applied Biosystems human identification software that could allow data files to be altered before analysis software loads them. The vendor's July 31 security bulletin…
  - (2026-08-03) [The Hacker News] N-able Says Attackers Take Over N-central Servers After Initial Fix Proves Incomplete
      N-able said attackers exploited an authentication bypass in N-central to gain remote administrative access and reach the customer systems managed through those servers. Its first fix was incomplete. CVE-2026-18577 affect…
  - (2026-08-03) [The Hacker News] Hugging Face Diffusers Flaws Could Let Model Repositories Execute Arbitrary Code
      Three high-severity security flaws have been disclosed in Hugging Face's Diffusers library that could allow crafted model repositories to stealthily execute arbitrary code on machines that load it, opening the artificial…
  - (2026-08-03) [Computer Weekly] Court document in Asato case reveals xAI/Grok sexual prompts
      Court documents in the legal case brought against xAI, the developer of Grok, by Labour MP Jess Asata shows that the artificial intelligence (AI) engine operates with no restrictions on sexual content. In particular, the…
  - (2026-08-03) [Computer Weekly] MPs demand answers on Fujitsu’s inclusion in lucrative frameworks
      MPs on the Business and Trade Select Committee have written to the secretary of state to demand answers over Fujitsu’s inclusion in frameworks worth more than £50bn in total. Fujitsu is at the centre of the Post Office s…
  - (2026-08-03) [Computer Weekly] Cyber protection against advances in frontier AI models
      In April, the AI Security Institute (AISI) evaluated Mythos Preview ,&nbsp;the experimental frontier artificial intelligence (AI) model that was the latest release of Anthropic’s Claude tool. Following its analysis, AISI…

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-08-03) LoL: Gen.G vs Hanwha Life Esports (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 0% · 24h volume: $777,336 · resolves 2026-08-03
  - (2026-08-03) Will Trump speak to Emmanuel Macron in July?
      yes price: 1% · 24h volume: $491,262 · resolves 2026-07-31
  - (2026-08-03) Dota 2: GLYPH vs PlayTime (BO3) - Games of the Future Playoffs
      yes price: 0% · 24h volume: $423,608 · resolves 2026-08-03
  - (2026-08-03) LoL: Nongshim Red Force vs T1 (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 70% · 24h volume: $386,393 · resolves 2026-08-03
  - (2026-08-03) LoL: Gen.G vs Hanwha Life Esports - Game 2 Winner
      yes price: 0% · 24h volume: $360,144 · resolves 2026-08-03
  - (2026-08-03) LoL: Gen.G vs Hanwha Life Esports - Game 1 Winner
      yes price: 0% · 24h volume: $342,689 · resolves 2026-08-03

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 35 total
  - (2026-08-03) #30 Masayoshi Son — $64.92B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-03) MOVER ▲ Bernard Arnault & family — $151.44B (+$1.50B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-03) MOVER ▲ Francoise Bettencourt Meyers & family — $96.66B (+$0.42B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-03) MOVER ▲ Amancio Ortega — $146.13B (+$0.34B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-03) MOVER ▼ Gautam Adani — $85.38B ($-0.14B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-08-03) MOVER ▼ Mukesh Ambani — $90.22B ($-0.10B since yesterday)
      India · Diversified · source: Diversified

### USGS earthquakes (M4.5+, past day) — 5 new of 16 total
  - (2026-08-03) M 5.2 - 66 km WNW of San Alejandro, Peru
      M5.2 · 66 km WNW of San Alejandro, Peru · depth 125.256 km
  - (2026-08-03) M 5.0 - 36 km NNE of Suez, Egypt
      M5.0 · 36 km NNE of Suez, Egypt · depth 10 km
  - (2026-08-03) M 4.9 - 14 km ESE of Yibin, China
      M4.9 · 14 km ESE of Yibin, China · depth 10 km
  - (2026-08-03) M 4.8 - 152 km S of Hydaburg, Alaska
      M4.8 · 152 km S of Hydaburg, Alaska · depth 15 km
  - (2026-08-03) M 4.5 - 5 km NNW of Sánchez, Dominican Republic
      M4.5 · 5 km NNW of Sánchez, Dominican Republic · depth 10 km

### Court opinions of consequence (federal & state) — 4 new of 60 total
  - (2026-07-31) Alaska Supreme Court: In Re Meeker Revocable Trust U/A/D July 15, 2014
  - (2026-07-29) U.S. Court of Appeals, 5th Cir.: United States v. Hunter
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: Serenity Investments, LLC v. Sun Hung Kai Strategic Capital, Ltd.
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: United States v. Yates

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-03) [Marginal Revolution] On infinite ethics
      Infinite numbers have long troubled utilitarian ethicists: if the universe is boundless, then there is infinite positive utility and infinite negative utility, and we can’t even define our current state, let alone affect…
  - (2026-08-03) [Marginal Revolution] *Rome’s Age of Revolution*
      The author is Tim Whitmarsh and the subtitle is Augustus, Empire and the Making of Christianity. This is the most important book on the history of Christianity I have read in a long time, and it is also an important work…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: rulemaking, provide, proposing, published, notice, order, taking, issued, amend, management, proposed, final
- state_bills: today=74, 7d-median=106, 14d-median=112; carrying terms: office, state, programs, adopt, employee, provides, housing, procedures, among, owner, human, agency
- state_news: today=223, 7d-median=758, 14d-median=493; carrying terms: async, mississippi, power, columbia, arizona, canada, center, population, polls, around, short, programs
- local_news: today=192, 7d-median=224, 14d-median=224; carrying terms: around, being, suspect, events, residents, against, investigation, closed, community, killed, close, weekend
- foreign_news: today=951, 7d-median=1022, 14d-median=1007; carrying terms: jilin, strategy, buildings, around, population, ongoing, guardian, prize, berlin, preview, communist, trust
- chinese_internal: today=240, 7d-median=266, 14d-median=265; carrying terms: global, firms, https, google, people, china, caixin, chinese, record, sales, market, office
- russian_internal: today=831, 7d-median=916, 14d-median=879; carrying terms: times, street, press, centcom, httperror, client, novayagazeta, wildberries, gazeta, group, found, forbidden
- ukrainian_internal: today=105, 7d-median=133, 14d-median=133; carrying terms: power, around, center, ongoing, foreign, affected, against, regional, takeaways, political, negotiations, whether
- ukraine_theater: today=243, 7d-median=627, 14d-median=627; carrying terms: community, alerts, known, viirs, https, active, daily, deepstatemap, cartography, polygon, google, coverage
- paper_bets: today=127, 7d-median=134, 14d-median=134; carrying terms: according, office, colorado, actively, chair, arizona, state, theme, jinping, israel, population, pirates
- weather: today=174, 7d-median=173, 14d-median=174; carrying terms: particularly, along, arizona, state, threat, weather, around, saturday, short, center, messages, especially
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, consumption, dexchus, latest, assets, commodities, payrolls, personal, spread, cpiaucsl, walcl, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, corporate, silver, yield, natural, futures, agriculture, commodities, equities, large, close, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=102, 7d-median=104, 14d-median=104; carrying terms: prohibiting, state, belarus, satisfying, renewable, accellerator, republic, serious, renewab, transition, border, document
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, quiverquant, congresstrading, https, unauthorized, quiver, httperror, error, client
- billionaires: today=35, 7d-median=35, 14d-median=35; carrying terms: london, meyers, francoise, brokerage, bernard, tokyo, changpeng, huang, tadashi, canada, source, discount
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: arizona, johnson, jones, blanche, texas, court, services, county, appeals, supreme, california, commerce
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, group
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, pinkston, lindsey, warner, shawn, krishnamoorthi, platner, cooper, ocasio, trone, elect, cycle
- gdelt_regions: today=0, 7d-median=6, 14d-median=9; carrying terms: english, china
- gdelt_gkg: today=74, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, trump, keywords, russian, netanyahu, chinese, themes, spanish, israeli, attacks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=16, 14d-median=16; carrying terms: position, belgium, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: according, routine, deaths, along, aboard, outbreak, state, clade, hospital, analyzed, spread, canada
- cisa_kev: today=9, 7d-median=9, 14d-median=12; carrying terms: untrusted, fortinet, wordpress, authentication, point, sharepoint, vulnerability, inclusion, management, remediation, deserialization, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=231, 7d-median=287, 14d-median=286; carrying terms: liechtenstein, cyclone, slovakia, vietnam, croatia, bulgaria, belarus, serbia, colombia, czech, genevieve, canada
- usgs_quakes: today=16, 7d-median=20, 14d-median=20; carrying terms: depth, japan, south, indonesia, russia, philippines, china, mexico, tonga, alaska, xiuma
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, normal, august, strait, traffic, returns, ceasefire, hormuz, increase, meeting
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: doctor, students, conversable, economist, marginalrevolution, marginal, certain, revolution, conversableeconomist, government, golden, class
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: power, essay, target, threat, cybersecurity, internet, model, being, weekly, scope, computer, against
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: barrett, office, terri, salinas, boozman, durbin, houlahan, warner, emmer, emily, chair, clyde
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, decision, converges, module, consensus, identify, sufficient, evidence, market, placed, today, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*