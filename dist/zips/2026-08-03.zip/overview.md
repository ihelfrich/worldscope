# WORLDSCOPE morning brief — 2026-08-03

## Headline
2092 new items across 21 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (520) · Russian Internal News (state + in-exile) (481) · World leaders & government officials (324) · Chinese Internal News (187) · U.S. Weather + Severe / Climate Outlooks (158) · Ukraine Theater (total-war monitoring) (145) · Local News: St. Louis + Atlanta (49) · State-Level News (48) · Ukrainian Internal News (national + local Kyiv) (34) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (30) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### International News + Multilateral Institutions — 520 new of 946 total
  - (2026-08-03) [Global] Dangerous summers: How heatwaves and wildfires change life across Europe
      Climate change makes Europe's summers hotter, intensifying fires and droughts while threatening lives and economies.
  - (2026-08-03) [Global] ‘He had a lot of profiles’: The rise of online drug-facilitated rape gangs
      Cases across many countries point to a worrying trend of men gathering on the internet to carry out sexual abuse crimes.
  - (2026-08-03) [Global] Myanmar releases first images of Aung San Suu Kyi since 2021 military coup
      Myanmar releases first images of Aung San Suu Kyi since 2021 military coup.
  - (2026-08-03) [Global] Australia warns H5N1 likely to spread after first mass mortality episode
      Agriculture minister ​says testing confirmed H5N1 bird flu in a group of 49 dead and 35 sick terns.
  - (2026-08-03) [Global] Who is Jordan Salinas, ‘hero’ bystander who confronted Idaho shooter?
      Suspected attacker, identified as 24-year-old Chad Williams, killed at least three people in the US on Saturday.
  - (2026-08-03) [Global] ‘US backs off from Iran before markets open on weekdays’
      ‘US backs off from Iran before markets open on weekdays’

### Russian Internal News (state + in-exile) — 481 new of 815 total
  - (2026-08-03) Сотрудникам Wildberries запретили приносить на склады смартфоны. Разрешены только кнопочные телефоны без камер | LEDE: Сотрудникам Wildberries с 3 августа запретили проносить на склады свои ] (ru: Сот…
      Сотрудникам Wildberries с 3 августа запретили проносить на склады свои смартфоны, пишет телеграм-канал «Осторожно, новости» со ссылкой на внутреннее уведомление, разосланное компанией.
  - (2026-08-03) Украинские беспилотники атаковали Геленджик и аннексированный Крым. Погибли шесть человек | LEDE: Три человека погибли, еще двое получили ранения в результате атаки украинских беспилотников ] (ru: Укр…
      Три человека погибли, еще двое получили ранения в результате атаки украинских беспилотников в аннексированном Крыму, заявил назначенный РФ глава полуострова Сергей Аксенов. О других последствиях ударов Украины он не сооб…
  - (2026-08-03) Польский пловец с пятой попытки пересек Балтийское море. Он преодолел 160 километров вплавь | LEDE: Польский пловец на сверхдлинные дистанции Бартломей Кубковский переплыл Балтийское море, п] (ru: Пол…
      Польский пловец на сверхдлинные дистанции Бартломей Кубковский переплыл Балтийское море, преодолев 160 километров пути примерно за 55 часов.
  - (2026-08-03) Forbes: ущерб продавцов Wildberries после ударов Украины по складам оценили в 215-280 миллиардов рублей | LEDE: Селлеры Wildberries в результате атак украинских дронов на склады компании мог] (ru: For…
      Селлеры Wildberries в результате атак украинских дронов на склады компании могли потерять около 215–280 миллиардов рублей. Такой оценкой потерь продавцов поделился с Forbes ведущий аналитик исследовательского агентства D…
  - (2026-08-03) Леонид Слуцкий покинул футбольный клуб «Шанхай Шэньхуа» после трех поражений подряд | LEDE: Главный тренер китайского клуба «Шанхай Шэньхуа» Леонид Слуцкий объявил об отставке после того, ка] (ru: Лео…
      Главный тренер китайского клуба «Шанхай Шэньхуа» Леонид Слуцкий объявил об отставке после того, как его команда трижды подряд проиграла в чемпионате Китая.
  - (2026-08-03) Мобильные операторы начали блокировать звонки без маркировки — по закону, вступившему в силу еще год назад | LEDE: Мобильные операторы начали блокировать звонки от бизнеса, который не заключ] (ru: Моб…
      Мобильные операторы начали блокировать звонки от бизнеса, который не заключил договоры на маркировку своих вызовов, пишет «Коммерсант» со ссылкой на несколько источников на рынке и в отрасли.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 187 new of 238 total
  - (2026-08-02) 秘鲁纳斯卡观光飞机坠毁13人遇难 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBiY0VfU0tHajE3NTMwc0oxUkFYTFpMMFFDMUIwTDVfd2x3RmJtRGxaTW9VbFBtZFJkYzBWajJxemlTb3hXSllXSmIwNTV0NDgwNmpua] (zh:…
      秘鲁纳斯卡观光飞机坠毁13人遇难 财新
  - (2026-08-03) 吴清：支持企业跨境双向融资 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBYOXBMQ2xXMWQ3aHdZNlo4Y3ZfdkxjWEpDR0pSYUR3TGg5X2J4RlExbWtTYnF5R1MzUGlfQnNoMGtsbXFjRkZFQU5aUzlhX2lrZ211VGt4] (zh:…
      吴清：支持企业跨境双向融资 财新
  - (2026-08-03) 《悬案》背后｜影视 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1aVWRiejZCd0JKV19nWngwbzdJS3BJaFNzNlo4dEFNSm9QUmZnRElSU21mYzhyMkVSak8wVTNQSWVLektiNGNvLUZaLVo1cHBzdTF0d1pGYzRG] (zh:…
      《悬案》背后｜影视 财新
  - (2026-08-03) 7月人事综述：换届之年 “70后”省级党委副书记受瞩目 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE0wRTI5NGd1MXNkc3ozOFhWZ2RjSmwxbXM4U2F6QWNyVFktTl9CWWI0eHAtbXM5YXhIWG5fd0VPRkdV] (zh:…
      7月人事综述：换届之年 “70后”省级党委副书记受瞩目 china.caixin.com
  - (2026-08-03) 米琴：《奥德赛》对战争的反思 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBSWjRCQ0RocnYtQi1WVlNoUWNtOVgtdWprWWNLN2lVTUFaWmsxU0ZmNTB4SUo5YXUydmJ2U3pQQXRpYlhLLWFqWC1QWWtrdmQwV3NwcXJ] (zh:…
      米琴：《奥德赛》对战争的反思 财新
  - (2026-08-02) 外汇贷款“专户”管理进一步简化 有出口贸易背景不必另开户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1PNkVZWWdVak5XSlJ0MHkwbHg3aEtOcG40ZmROYnhHYzNELTR0S3psclZrUFV1WjNrMTVPZmdNNDlIalgwcUdFYlpRS] (zh:…
      外汇贷款“专户”管理进一步简化 有出口贸易背景不必另开户 财新

### U.S. Weather + Severe / Climate Outlooks — 158 new of 173 total
  - (2026-08-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 5:24AM EDT by NWS Upton NY
      At 524 AM EDT, Doppler radar was tracking a strong thunderstorm over Mount Kisco, moving northeast at 30 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs a…
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 4:23AM CDT by NWS Lincoln IL
      Patchy dense fog has formed across central Illinois in the last couple of hours. Visibility may fall below one-quarter mile to one mile at times through early morning, leading to potentially hazardous travel conditions.…
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 4:21AM CDT by NWS Des Moines IA
      WHAT...Patchy fog with visibilities around or under a mile. WHERE...Mainly south of US Highway 20 and along and east of I-35. WHEN...Through 8am. IMPACTS...Drivers should be alert for reduced visibility at times. PREPARE…
  - (2026-08-03) [Moderate] Special Weather Statement: Special Weather Statement issued August 3 at 5:20AM EDT by NWS Gray ME
      A very moist air mass in place this morning has lead to the development of areas of dense fog. Motorists are urged to use caution during the morning commute. The fog should gradually thin as the rain rates increase.
  - (2026-08-03) [Moderate] Hazardous Seas Warning: Hazardous Seas Warning issued August 3 at 2:19AM PDT until August 4 at 9:00PM PDT by NWS Medford OR
      * WHAT...For the Gale Warning, north winds 25 to 35 kt with gusts up to 45 kt and seas 8 to 13 ft at 9 seconds. For the Small Craft Advisory, north winds 25 to 35 kt with gusts up to 45 kt and seas 8 to 13 ft at 9 second…

### Ukraine Theater (total-war monitoring) — 145 new of 639 total
  - (2026-08-03) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-02) [Liveuamap] Lebanon news on live map - lebanon.liveuamap.com - Liveuamap
      Lebanon news on live map - lebanon.liveuamap.com Liveuamap
  - (2026-07-30) [Liveuamap] Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160 - Liveuamap
      Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160
  - (2026-08-01) [Liveuamap] Israeli Defense Minister Israel Katz: If the Palestinian Authority starts an Intifada, it's war. We will deal with it the same way we dealt with Gaza and Lebanon. Any city involved will be…
      Israeli Defense Minister Israel Katz: If the Palestinian Authority starts an Intifada
  - (2026-08-03) [Liveuamap] Ukraine - Liveuamap
      Ukraine Liveuamap
  - (2026-08-01) [Liveuamap] A new airborne assault brigade will be stationed in the Homel region near the Ukrainian border. In Belarus, the formation of the 37th Separate Guards Airborne Assault Brigade of Special Op…
      A new airborne assault brigade will be stationed in the Homel region near the Ukrainian border. In Belarus, the

### Local News: St. Louis + Atlanta — 49 new of 186 total
  - (2026-08-03) [St. Louis] Lou’s Clues – 8/3/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-02) [St. Louis] ICE detains 1 after pursuit in St. Charles, police searching for driver - First Alert 4
      ICE detains 1 after pursuit in St. Charles, police searching for driver First Alert 4
  - (2026-08-03) [St. Louis] See the Aug. 3, 1926, front page: Thousans of ballots cast in local primary
      Headlines from the Aug. 3, 1926, front page include: Jacob Katz won't tell what he did with $8,000 fund
  - (2026-08-03) [St. Louis] It's a bird! It's a plane! It's a...drone delivering your Walmart order?
      Plus: Kangaroo finds his way home
  - (2026-08-03) [St. Louis] The Short List: August 3
      Welcome to The Short List newsletter, a look at what's ahead in the St. Louis area — key news happenings, big sports matchups, can't-miss events and maybe even food recommendations.
  - (2026-08-03) [St. Louis] FROM BOONDOGGLE TO NOW BOOMING
      Linda Profer, left, and Makenna Elledge, 14, from Wood River, walk to their car at MidAmerica St. Louis Airport in Mascoutah after returning home from their trip to Destin, Fla., on Monday, July 27, 2026. The airport had…

### State-Level News — 48 new of 194 total
  - (2026-08-03) [Connecticut] CT insurers deny adequate coverage for chronic illness
      <img width="1024" height="576" src="https://ctmirror.org/wp-content/uploads/2026/07/Autoinjector_with_Amgevita_by_Amgen_Adalimumab-1024x576.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=""…
  - (2026-08-03) [feed error] FL Governor (Florida): HTTPError
      404 Client Error: Not Found for url: https://www.flgov.com/feed/
  - (2026-08-03) [Florida] Florida’s GOP primary for governor: Undignified. Unedifying. Flat-out godawful.
      I know y’all would probably rather not talk about the Republican candidates for governor of Florida. However, distasteful as it is, we must: The primary is Aug. 18. Now, this family-friendly publication frowns on scatolo…
  - (2026-08-03) [Maine] On the essential distinction between news and views | Opinion
      <img width="1024" height="768" src="https://www.pressherald.com/wp-content/uploads/sites/4/2023/04/MST-and-PPH-1682291688.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="a…
  - (2026-08-03) [Maine] What to do if you see a black bear in Maine
      <img width="1024" height="718" src="https://w2pcms.com/wp-content/uploads/sites/10/2024/12/Suzie-the-Black-bear.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" size…
  - (2026-08-03) [Maine] Maine preschoolers should do the math | Opinion
      <img width="1000" height="670" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/08/Education_Immigrants_in_School_06015.jpg?w=1000" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…

### Ukrainian Internal News (national + local Kyiv) — 34 new of 105 total
  - (2026-08-03) Генконсульство України засудило напад українця на польку у Вроцлаві | LEDE: Генеральне консульство України у Вроцлаві засудило інцидент, що стався у цьому місті, внаслідок якого тяжкі тілесні у] (uk:…
      Генеральне консульство України у Вроцлаві засудило інцидент, що стався у цьому місті, внаслідок якого тяжкі тілесні ушкодження отримала громадянка Польщі, а правоохоронними органами було затримано громадянина України за…
  - (2026-08-03) Сили оборони уразили місце підготовки та пусків БпЛА у Брянській області РФ | LEDE: ЗСУ уразили склади, ремонтну базу, об'єкти БпЛА та вузол зв'язку окупантів у Криму й РФ] (uk: Сили оборони уразили м…
      ЗСУ уразили склади, ремонтну базу, об'єкти БпЛА та вузол зв'язку окупантів у Криму й РФ
  - (2026-08-03) На вулицях Сеути все ще лишаються тисячі нелегальних мігрантів | LEDE: Попри те, що більшість мігрантів, які заполонили іспанську Сеуту, вже добровільно залишили анклав, на вулицях міста досі л] (uk:…
      Попри те, що більшість мігрантів, які заполонили іспанську Сеуту, вже добровільно залишили анклав, на вулицях міста досі лишаються тисячі марокканців, і їхнє повернення видається складним завданням.
  - (2026-08-03) УП: Зеленський вирішив призначити Умєрова головою СЗР | LEDE: Умєров може очолити Службу зовнішньої розвідки — джерела в політичних колах УП] (uk: УП: Зеленський вирішив призначити Умєрова головою СЗР…
      Умєров може очолити Службу зовнішньої розвідки — джерела в політичних колах УП
  - (2026-08-03) Мадяр: Остання турбіна АЕС в Угорщині ще працює, але попереду найважчі 5 днів | LEDE: Прем'єр Угорщини Петер Мадяр повідомив у понеділок, що остання турбіна АЕС "Пакш" все ще працює, але найваж] (uk:…
      Прем'єр Угорщини Петер Мадяр повідомив у понеділок, що остання турбіна АЕС "Пакш" все ще працює, але найважчі дні ще попереду.
  - (2026-08-03) Іран спростував слова Трампа про переговори з США | LEDE: Іран заявив, що не веде перемовин із США, а контактує лише з Оманом щодо безпеки Ормузької протоки.] (uk: Іран спростував слова Трампа про пер…
      Іран заявив, що не веде перемовин із США, а контактує лише з Оманом щодо безпеки Ормузької протоки.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-03) GAF615 (Germany)
      icao24: 3f6533 · position: (57.8383, -3.1744) · alt: 518m · 390km/h
  - (2026-08-03) GAF123 (Germany)
      icao24: 3f6219 · position: (3.2019, 101.5076) · alt: 434m · 236km/h
  - (2026-08-03) PUMA52 (Slovenia)
      icao24: 506e19 · position: (45.8994, 14.8822) · alt: 1493m · 200km/h
  - (2026-08-03) SAMU06 (France)
      icao24: 39c901 · position: (43.6843, 7.1675) · alt: 243m · 212km/h
  - (2026-08-03) CFC2974 (Canada)
      icao24: c2b585 · position: (60.4168, 10.2365) · alt: 4114m · 557km/h
  - (2026-08-03) CFC4065 (Canada)
      icao24: c2b3eb · position: (45.1028, -79.7806) · alt: 9547m · 853km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Iran executes two men accused of spying for Israel during conflict
      dailypost.ng · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Someone will die : Incitement against journalists alarms Israel as elections near
      egyptindependent.com · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Israel says it has serious concerns with Hamas disarmament deal
      upr.org · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Israel says it has serious concerns with Hamas disarmament deal
      kunr.org · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Israel says it has serious concerns with Hamas disarmament deal
      kcbx.org · English · tone NA
  - (2026-08-03) [Israel-Iran-Hezbollah axis · keywords] Details of US preparations for new strike on Iran revealed : Operation involving Israel called off at last minute
      news.am · English · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 13 new of 57 total
  - (2026-08-03) [The Hacker News] Thermo Fisher Patches Flaw That Could Make DNA File Tampering Nearly Undetectable
      Thermo Fisher Scientific has patched a flaw in select Applied Biosystems human identification software that could allow data files to be altered before analysis software loads them. The vendor's July 31 security bulletin…
  - (2026-08-03) [The Hacker News] N-able Says Attackers Take Over N-central Servers After Initial Fix Proves Incomplete
      N-able said attackers exploited an authentication bypass in N-central to gain remote administrative access and reach the customer systems managed through those servers. Its first fix was incomplete. CVE-2026-18577 affect…
  - (2026-08-03) [The Hacker News] Hugging Face Diffusers Flaws Could Let Model Repositories Execute Arbitrary Code
      Three high-severity security flaws have been disclosed in Hugging Face's Diffusers library that could allow crafted model repositories to stealthily execute arbitrary code on machines that load it, opening the artificial…
  - (2026-08-03) [The Register] As Larry Ellison bets the farm, Oracle says it loves AI-written code, just not in OpenJDK
      Use it to debug and review, says Big Red, but don't submit its output
  - (2026-08-03) [The Register] Claude Code is revolutionizing digital archaeology. Enterprise better dig it
      'As a big AI skeptic, you just blew my mind'
  - (2026-08-03) [The Register] AI is 'both the weapon and the target' in latest wave of cyberattacks
      CrowdStrike tracks 89% surge in machine-assisted activity as patch windows shrink to 48 hours

### Paper Trading Scorecard — 11 new of 125 total
  - (2026-08-03) [Polymarket] Will the Cleveland Guardians win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-08-03) [Polymarket] Will Zelenskyy and Putin meet next in Italy / Vatican before 2027?
      This market will resolve according to the location of the next meeting between Volodymyr Zelenskyy and Vladimir Putin by December 31, 2026, 11:59 PM ET. If no meeting takes place by December 31 ET, this market will resol…
  - (2026-08-03) [Polymarket] Will the US strike 13 countries in 2026?
      This market will resolve according to the total number of different countries' soil that the United States initiates a drone, missile, or air strike on between January 1, 2026, 12:00 AM ET and December 31, 2026, 11:59 PM…
  - (2026-08-03) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-08-03) [Manifold] Will I stay in masters this season?
  - (2026-08-03) [Manifold] Will OpenAI or Anthropic have a stronger model by the end of 2026?

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-08-03) LoL: Gen.G vs Hanwha Life Esports (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 0% · 24h volume: $674,663 · resolves 2026-08-03
  - (2026-08-03) Dota 2: GLYPH vs PlayTime - Game 2 Winner
      yes price: 100% · 24h volume: $578,299 · resolves 2026-08-03
  - (2026-08-03) Will Trump speak to Emmanuel Macron in July?
      yes price: 1% · 24h volume: $491,551 · resolves 2026-07-31
  - (2026-08-03) Will Wes Moore win the 2028 Democratic presidential nomination?
      yes price: 2% · 24h volume: $313,764 · resolves 2028-11-07
  - (2026-08-03) LoL: Gen.G vs Hanwha Life Esports - Game 1 Winner
      yes price: 0% · 24h volume: $310,954 · resolves 2026-08-03
  - (2026-08-03) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 56% · 24h volume: $301,708 · resolves 2026-09-16

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 36 total
  - (2026-08-03) #30 Masayoshi Son — $64.92B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-03) MOVER ▲ Bernard Arnault & family — $149.94B (+$3.68B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-03) MOVER ▲ Amancio Ortega — $145.79B (+$2.39B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-03) MOVER ▲ Tadashi Yanai & family — $67.95B (+$1.05B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-08-03) MOVER ▲ Francoise Bettencourt Meyers & family — $96.25B (+$0.89B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-03) MOVER ▲ Gautam Adani — $85.53B (+$0.67B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Court opinions of consequence (federal & state) — 7 new of 60 total
  - (2026-07-31) Alaska Supreme Court: In Re Meeker Revocable Trust U/A/D July 15, 2014
  - (2026-07-29) U.S. Court of Appeals, 5th Cir.: United States v. Hunter
  - (2026-07-29) U.S. Court of International Trade: Ningxia Guanghua Cherishmet Activated Carbon Co. v. United States
  - (2026-07-29) U.S. Court of International Trade: Tube Forgings of Am., Inc. v. United States
  - (2026-07-29) U.S. Court of Appeals, 2nd Cir.: Ohindo v. Ball
  - (2026-07-29) U.S. Court of Appeals, 2nd Cir.: United States v. Greebel

### State Legislative Action — 6 new of 79 total
  - (2026-08-02) [Vermont H 905] An act relating to miscellaneous amendments to the prohibitions on discrimination
      An act relating to miscellaneous amendments to the prohibitions on discrimination
  - (2026-08-01) [Vermont H 957] An act relating to approval of amendments to the charter of the Town of Williston
      An act relating to approval of amendments to the charter of the Town of Williston
  - (2026-08-03) [Wisconsin AB 1] Relating to: changes to the educational assessment program and the school and school district accountability report. (FE)
      Relating to: changes to the educational assessment program and the school and school district accountability report. (FE)
  - (2026-08-03) [Wisconsin AB 1] Relating to: an income tax subtraction for qualified tips and for qualified overtime compensation; state aid for school districts; surplus refund payments; increasing funding for spec…
      Relating to: an income tax subtraction for qualified tips and for qualified overtime compensation; state aid for school districts; surplus refund payments; increasing funding for special education and school age parents…
  - (2026-08-03) [Wisconsin SB 1] Relating to: an income tax subtraction for qualified tips and for qualified overtime compensation; state aid for school districts; surplus refund payments; increasing funding for spec…
      Relating to: an income tax subtraction for qualified tips and for qualified overtime compensation; state aid for school districts; surplus refund payments; increasing funding for special education and school age parents…
  - (2026-08-03) [Wisconsin SB 1] Relating to: onetime individual income tax rebates. (FE)
      Relating to: onetime individual income tax rebates. (FE)

### USGS earthquakes (M4.5+, past day) — 5 new of 18 total
  - (2026-08-03) M 5.2 - 66 km WNW of San Alejandro, Peru
      M5.2 · 66 km WNW of San Alejandro, Peru · depth 125.256 km
  - (2026-08-03) M 5.0 - 36 km NNE of Suez, Egypt
      M5.0 · 36 km NNE of Suez, Egypt · depth 10 km
  - (2026-08-03) M 4.9 - 14 km ESE of Yibin, China
      M4.9 · 14 km ESE of Yibin, China · depth 10 km
  - (2026-08-03) M 4.8 - 152 km S of Hydaburg, Alaska
      M4.8 · 152 km S of Hydaburg, Alaska · depth 15 km
  - (2026-08-03) M 4.5 - 5 km NNW of Sánchez, Dominican Republic
      M4.5 · 5 km NNW of Sánchez, Dominican Republic · depth 10 km

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-03) [Marginal Revolution] On infinite ethics
      Infinite numbers have long troubled utilitarian ethicists: if the universe is boundless, then there is infinite positive utility and infinite negative utility, and we can’t even define our current state, let alone affect…
  - (2026-08-03) [Marginal Revolution] *Rome’s Age of Revolution*
      The author is Tim Whitmarsh and the subtitle is Augustus, Empire and the Making of Christianity. This is the most important book on the history of Christianity I have read in a long time, and it is also an important work…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: published, standard, final, order, taking, requires, management, issued, rulemaking, program, safety, proposes
- state_bills: today=79, 7d-median=106, 14d-median=112; carrying terms: service, written, individuals, property, california, requires, apply, create, assistance, temporary, board, social
- state_news: today=194, 7d-median=758, 14d-median=493; carrying terms: consider, agents, every, north, party, growing, susan, bottom, announced, calling, whose, service
- local_news: today=186, 7d-median=224, 14d-median=224; carrying terms: suspect, north, missing, service, children, close, south, atlanta, neighborhood, charged, person, charges
- foreign_news: today=946, 7d-median=1022, 14d-median=1007; carrying terms: working, wechat, party, soldiers, universities, france, strategy, announced, protein, times, container, understanding
- chinese_internal: today=238, 7d-median=266, 14d-median=265; carrying terms: record, china, https, global, google, people, caixin, chinese, firms, market, office, sales
- russian_internal: today=815, 7d-median=916, 14d-median=879; carrying terms: openai, istories, gazeta, times, reuters, europe, street, https, russian, title, centcom, associated
- ukrainian_internal: today=105, 7d-median=133, 14d-median=133; carrying terms: ukrinform, north, injuring, growing, france, europe, odesa, civilians, guided, aerial, capacity, warehouse
- ukraine_theater: today=639, 7d-median=639, 14d-median=639; carrying terms: cartography, https, community, daily, known, viirs, google, polygon, polygons, liveuamap, maintained, deepstatemap
- paper_bets: today=125, 7d-median=134, 14d-median=134; carrying terms: cancelled, named, koivun, north, speed, chair, openai, population, party, colonize, announced, james
- weather: today=173, 7d-median=173, 14d-median=173; carrying terms: messages, moderate, national, afdbox, north, rivers, storms, valleys, doppler, health, synopsis, shortly
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: walcl, supply, spread, cpiaucsl, unrate, pcepilfe, payems, jtsjol, dcoilwtico, vixcls, payrolls, unemployment
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, bitcoin, proxy, range, silver, yield, russell, large, corporate, natural, nasdaq, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=102, 7d-median=104, 14d-median=104; carrying terms: prior, national, river, operations, renewab, february, hybrid, groups, haiti, islamic, operation, funds
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, quantitative, error, https, congresstrading, client, httperror, unauthorized
- billionaires: today=36, 7d-median=36, 14d-median=36; carrying terms: yiming, holdings, steve, nasdaq, investments, london, bloomberg, amancio, hathaway, telecom, adani, tesla
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, county, jones, texas, services, johnson, california, supreme, appeals, court, commerce, technologies
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, holdings, amended, robert, steven, carecloud, joshua, david, allen
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, graham, alexandria, angels, trone, johnson, disbursements, michael, warner, filing, brown, raised
- gdelt_regions: today=0, 7d-median=6, 14d-median=9; carrying terms: english, china
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, hezbollah, israel, trump, keywords, spanish, crisis, netanyahu, strike, nuclear, conflict, strikes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: position, canada, belgium, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: published, virology, release, cross, known, february, watery, active, national, geographically, unrelated, bloody
- cisa_kev: today=9, 7d-median=9, 14d-median=12; carrying terms: overflow, control, command, injection, improper, vulnerability, interpretation, microsoft, functionality, vendor, smartconsole, untrusted
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=231, 7d-median=287, 14d-median=286; carrying terms: ukraine, ethiopia, australia, forest, north, speed, zambia, vietnam, impact, democratic, venezuela, earthquake
- usgs_quakes: today=18, 7d-median=20, 14d-median=20; carrying terms: depth, indonesia, japan, south, mexico, russia, china, philippines, tonga, honmachi, xiuma, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, traffic, august, normal, returns, hormuz, ceasefire, strait, increase, meeting
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: conversable, having, marginal, doctor, class, government, college, marginalrevolution, https, economist, revolution, certain
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: research, groups, openai, record, targeted, information, cyber, weekday, according, models, download, found
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: dallas, knott, mccollum, tonko, keith, beatty, national, shomari, friedman, gonzalez, blanche, harrigan
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, market, identify, consensus, converges, module, placed, decision, either, today, claude, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*