# WORLDSCOPE morning brief — 2026-09-03

## Headline
3720 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (827) · Russian Internal News (state + in-exile) (769) · Ukraine Theater (total-war monitoring) (457) · State-Level News (332) · World leaders & government officials (324) · Chinese Internal News (234) · Local News: St. Louis + Atlanta (210) · U.S. Weather + Severe / Climate Outlooks (163) · State Legislative Action (80) · Ukrainian Internal News (national + local Kyiv) (64) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 827 new of 1107 total
  - (2026-09-03) [Global] Victims sue South African government over 1961 Sharpeville massacre that left 91 dead
  - (2026-09-02) [Global] New constitution in Guinea-Bissau will undermine democracy, opponents say
  - (2026-09-03) [Global] The US and Venezuela: a century-old relationship drenched in oil
  - (2026-09-02) [Global] Apple Maps renames Lake Ontario as ‘Lake America’ for US users after Trump order
  - (2026-09-02) [Global] Trump ally defends Venezuela oil deal amid ‘gunpoint diplomacy’ criticism
  - (2026-09-02) [Global] Pete Hegseth criticized for body-shaming Canadian cadets: ‘Literally they’re kids’

### Russian Internal News (state + in-exile) — 769 new of 1224 total
  - (2026-09-03) «Важные истории» поговорили с одним из разработчиков СОРМ — системы, с помощью которой ФСБ следит за россиянами. Он уехал из России и вывез архив внутренних документов | LEDE: Журналисты изд] (ru: «Ва…
      Журналисты издания «Важные истории» поговорили с 24-летним программистом Иваном Кирсановым, который работал в компании из холдинга «Цитадель». Этот холдинг — главный разработчик СОРМ, системы слежки для ФСБ. В 2025 году…
  - (2026-09-03) В Саратовской области преступник тяжело ранил генерала. Украина называет военного ответственным за удар России по больнице «Охматдет» в Киеве | LEDE: В Саратовской области совершено покушени] (ru: В С…
      В Саратовской области совершено покушение на офицера Воздушно-космических сил России, сообщают близкие к силовикам телеграм-каналы Mash, Baza и Shot. Пострадавшего госпитализировали в тяжелом состоянии. Следственный коми…
  - (2026-09-03) Европа не успела заполнить газовые хранилища к осени. Это грозит ростом цен зимой | LEDE: Европа подходит к зиме со слишком низкими запасами газа, что грозит усилением глобальной конкуренции] (ru: Евр…
      Европа подходит к зиме со слишком низкими запасами газа, что грозит усилением глобальной конкуренции за поставки, пишет Bloomberg.
  - (2026-09-03) Uber впервые начнет тестировать роботакси с пассажирами в Лондоне | LEDE: Американская компания Uber совместно с британским стартапом Wayve впервые начнет перевозить пассажиров в Лондоне в б] (ru: Ube…
      Американская компания Uber совместно с британским стартапом Wayve впервые начнет перевозить пассажиров в Лондоне в беспилотных роботакси, пишет The New York Times. В первом этапе тестирования будут участвовать 15 автомоб…
  - (2026-09-03) В Мюнхене на стройплощадку перед офисом оборонного концерна бросили зажигательные снаряды. Задержаны двое граждан Болгарии | LEDE: В Мюнхене на строительную площадку перед штаб-квартирой тех] (ru: В М…
      В Мюнхене на строительную площадку перед штаб-квартирой технологического концерна Rohde & Schwarz, работающего в оборонной отрасли, бросили емкости с зажигательной смесью, сообщает медиакомпания BR24.
  - (2026-09-03) «Дело не в СВО». Путин заявил, что война не определяет рождаемость в России | LEDE: Война с Украиной влияет на рождаемость в России, но не является основной причиной демографического кризиса] (ru: «Де…
      Война с Украиной влияет на рождаемость в России, но не является основной причиной демографического кризиса, заявил Владимир Путин на пленарном заседании Восточного экономического форума.

### Ukraine Theater (total-war monitoring) — 457 new of 612 total
  - (2026-09-03) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-02) [FIRMS] thermal anomaly 52.803, 32.224 (FRP 0.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 0.52 MW
  - (2026-09-02) [FIRMS] thermal anomaly 52.803, 32.223 (FRP 0.49 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 0.49 MW
  - (2026-09-02) [FIRMS] thermal anomaly 52.849, 29.989 (FRP 1.33 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 1.33 MW
  - (2026-09-02) [FIRMS] thermal anomaly 51.891, 29.342 (FRP 8.34 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 8.34 MW
  - (2026-09-02) [FIRMS] thermal anomaly 51.893, 29.346 (FRP 4.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 4.05 MW

### State-Level News — 332 new of 737 total
  - (2026-09-02) [Alabama] Governor Ivey Backs Trump Administration Trucking Crackdown as Alabama Leads the Way
      MONTGOMERY – Governor Kay Ivey on Wednesday applauded the Trump Administration for launching a sweeping federal initiative to combat fraud and illegal activity in the commercial trucking industry, while highlighting Alab…
  - (2026-09-02) [California] Governor Newsom announces nearly 15,300 illegal hemp, kratom and 7-OH products removed from California store shelves
      Source
  - (2026-09-02) [California] California’s legal cannabis market generates $8.4 billion for Californians as state cracks down on illicit operators
      Source
  - (2026-09-02) [California] Governor Newsom announces CalGuard has seized $534 million in deadly fentanyl, helping keep drugs off the streets as crime falls statewide
      <a href="https://www.gov.ca.gov/2026/09/02/governor-newsom-announces-calguard-has-seized-534-million-in-deadly-
  - (2026-09-01) [Alaska] Flags to be Flown at Half-Staff in Honor of Former Representative Carl Morgan
      Governor Dunleavy has ordered that Alaska and United States flags fly at half-staff between sunrise and sunset on September 2, 2026, in honor of former legislator Carl Morgan.
  - (2026-09-01) [Alaska] Recovery Month 2026
      WHEREAS, it is essential that all Alaskans recognize the critical need for affordable, accessible, and high-quality substance abuse treatment; and WHEREAS, substance abuse, co-occurring mental disorders, and related phys…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 234 new of 282 total
  - (2026-09-02) Beijing Tells Carmakers to Curb Price Wars, Strengthen Overseas Compliance - Caixin Global
      Beijing Tells Carmakers to Curb Price Wars, Strengthen Overseas Compliance Caixin Global
  - (2026-09-02) Rising Sales, Falling Profits Expose Margin Strain Across China’s A-Share Market - Caixin Global
      Rising Sales, Falling Profits Expose Margin Strain Across China’s A-Share Market Caixin Global
  - (2026-09-03) Anthropic、Meta、谷歌、 阿里齐发模型更新编程能力较量白热化 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE1CZ0Rtd0wtcEo5RDlrU0RCdFdVd2ZLUTFvaVJfWWFsM3JUMFpyclJEcWJNR2VQVlRDblYyQ2] (zh:…
      Anthropic、Meta、谷歌、 阿里齐发模型更新编程能力较量白热化 Caixin Global
  - (2026-09-01) 华为上半年净利润下滑36% 研发费用超1200亿元创新高 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9aSUVDaGlfTzNYVFVKeGN4WW5sOHNmbVNDXzAySDBMbDI3cnJwUVM5NFZEaEU1MmY2RDI1ODJ6Y2tfV1] (zh:…
      华为上半年净利润下滑36% 研发费用超1200亿元创新高 Caixin Global
  - (2026-09-03) 记者手记｜英国报纸进入￡5时代 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1qZ3hWVFRZd0hPLUcybXo3T0VCWDJoQkRIUmw5dXM5bkhzUFp3N21tbXAxckgtSGVBamJkVy1hUWVpVlkzcTVHcmRUQ] (zh:…
      记者手记｜英国报纸进入￡5时代 mini.caixin.com
  - (2026-09-03) AI、电气化与资源竞争：全球经济的新逻辑 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9SRlVlMnFZdk0yUXpGRlcwRnhvZ0tYOUpJRmE3RjJrbTYxRHladTA5RWJPT0d5YURpVWNlYlJCRC1YVFF4UVpxV0] (zh:…
      AI、电气化与资源竞争：全球经济的新逻辑 Caixin Global

### Local News: St. Louis + Atlanta — 210 new of 238 total
  - (2026-09-03) [St. Louis] Ferguson Chophouse serves up steakhouse classics, seafood, and more in North County
      Located at the heart of Ferguson, Ferguson Chophouse (242 S. Florissant) serves up prime-cut steaks, fresh seafood, and more. Industry veterans Kirk Saunders and chef Kevin Green run the restaurant, which is open for din…
  - (2026-09-03) [St. Louis] Jake Zimmerman is looking forward to playing Whiteyball
      For 14 years, Jake Zimmerman likes to joke, he’s had “the least sexy job in politics.” The St. Louis native and Harvard Law grad has made that lack of pizzazz his calling card. He could have gone to New York City and mad…
  - (2026-09-03) [St. Louis] Save Lives Now! pushes forward in St. Louis despite political complications
      Save Lives Now! is still alive. That was a big takeaway from Wednesday’s meeting of the advisory council of this region-wide, evidence-based initiative to quell gun violence in St. Louis—an initiative that, despite leade…
  - (2026-09-03) [St. Louis] Where in Clayton 9/3/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-09-03) [St. Louis] Where in the Lou 9/3/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-09-02) [St. Louis] A day in the life of Megan Sinclair
      Before the rest of the house is awake, Megan Sinclair is already moving. Her alarm goes off around 5:45 a.m. She makes coffee, gets ready, and makes every bed in the house. She opens the blinds and windows, letting the m…

### U.S. Weather + Severe / Climate Outlooks — 163 new of 163 total
  - (2026-09-03) [Moderate] Special Weather Statement: Special Weather Statement issued September 3 at 7:52AM EDT by NWS Grand Rapids MI
      At 752 AM EDT, Doppler radar was tracking a strong thunderstorm 7 miles southeast of Baldwin, moving east at 50 mph. HAZARD...Winds in excess of 40 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds co…
  - (2026-09-03) [Moderate] Special Weather Statement: Special Weather Statement issued September 3 at 6:50AM CDT by NWS Bismarck ND
      At 650 AM CDT, strong thunderstorms were located from 8 miles north of Makoti to 7 miles southeast of Granville, or from 26 miles southwest of Minot to 24 miles east of Minot, moving east at 30 mph. HAZARD...Wind gusts u…
  - (2026-09-03) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 3 at 7:50AM EDT until September 3 at 8:00AM EDT by NWS Pittsburgh PA
      At 750 AM EDT, severe thunderstorms were located along a line from 9 miles west of Indiana to 6 miles south of Apollo, moving southeast at 40 mph. HAZARD...60 mph wind gusts and small hail. SOURCE...Radar indicated. IMPA…
  - (2026-09-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-03) [Moderate] Special Weather Statement: Special Weather Statement issued September 3 at 3:42AM AKDT by NWS Anchorage AK
      A strong front moved toward the Kuskokwim Delta coast overnight. Southerly onshore winds gusting up to 40 mph coupled with a lengthy fetch will promote elevated water levels 1 to 2 feet above normal high tide through ear…
  - (2026-09-03) [Moderate] Gale Warning: Gale Warning issued September 3 at 3:41AM AKDT until September 3 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…

### State Legislative Action — 80 new of 87 total
  - (2026-09-02) [Alaska HB 27] An Act relating to cardiopulmonary resuscitation education in public schools; relating to the duties of the Department of Education and Early Development; relating to medical care for m…
      An Act relating to cardiopulmonary resuscitation education in public schools; relating to the duties of the Department of Education and Early Development; relating to medical care for major emergencies; and providing for…
  - (2026-09-03) [California AB 611] Voluntary tax contribution funds: spinal cord injury research.
      Existing law allows an individual taxpayer to contribute amounts in excess of their personal income tax liability for the support of specified funds and accounts, including, among others, to the California Cancer Researc…
  - (2026-09-03) [California AB 2266] Electricity: load-serving entities.
      Existing law requires the Public Utilities Commission to set resource adequacy and resource procurement obligations for load-serving entities, which include electrical corporations, electric service providers, and commun…
  - (2026-09-03) [California AB 2313] Gas corporations: gas distribution service line replacements: alternatives.
      Existing law vests the Public Utilities Commission with regulatory authority over public utilities, including gas corporations. Existing law requires, until January 1, 2031, gas corporations to submit to the commission a…
  - (2026-09-03) [California ACR 162] Relative to the Congressman Doug LaMalfa Memorial Highway.
      This measure would designate a specified portion of State Route 99 in the County of Butte as the Congressman Doug LaMalfa Memorial Highway. The measure would request that the Department of Transportation determine the co…
  - (2026-09-03) [California AB 1590] California Career Technical Education Incentive Grant Program: revised allocation formula.
      Existing law establishes the California Career Technical Education Incentive Grant Program, administered by the State Department of Education, with the purpose of encouraging, maintaining, and strengthening the delivery…

### Ukrainian Internal News (national + local Kyiv) — 64 new of 128 total
  - (2026-09-03) У Польщі закликають посилити контроль над в’їздом росіян до ЄС | LEDE: ] (uk: У Польщі закликають посилити контроль над в’їздом росіян до ЄС)
  - (2026-09-03) Каплунов: СБУ за моєї допомоги намагалися дискредитувати Буданова | LEDE: Заступник командира з бойової роботи "Російського добровольчого корпусу" Степан Каплунов заявив, що СБУ за його допомог] (uk:…
      Заступник командира з бойової роботи "Російського добровольчого корпусу" Степан Каплунов заявив, що СБУ за його допомогою намагалася дискредитувати командира спецпідрозділу "Тимура" Дмитра Іванова та голову ОП Кирила Буд…
  - (2026-09-03) Атака росіян по Дніпру: 8 поранених, один – у важкому стані | LEDE: Зросла кількість поранениз внаслідок російської атаки 3 вересня по Дніпру, наразі відомо про 8 поранених, одна людина у важко] (uk:…
      Зросла кількість поранениз внаслідок російської атаки 3 вересня по Дніпру, наразі відомо про 8 поранених, одна людина у важкому стані.
  - (2026-09-03) ДБР затримало нацгвардійця з 1 млн грн: підозрюють у крадіжці дронів і НРК | LEDE: Правоохоронці викрили військового, який продав дрони та вибухівку на 1 млн грн. Чоловіка арештували із заставо] (uk:…
      Правоохоронці викрили військового, який продав дрони та вибухівку на 1 млн грн. Чоловіка арештували із заставою 2,5 млн грн.
  - (2026-09-03) Путін знову запевняє, що в Росії не готують мобілізацію: "Люди йдуть добровільно" | LEDE: Російський правитель Володимир Путін вкотре заявив, що на сьогодні не розглядає можливості проведення д] (uk:…
      Російський правитель Володимир Путін вкотре заявив, що на сьогодні не розглядає можливості проведення додаткової мобілізації, а розмови про це назвав "інформаційною атакою" напередодні виборів до Держдуми РФ.
  - (2026-09-03) Ультраправа партія "АдН" закликала шукати "український слід" в інциденті з дроном у Лейпцигу | LEDE: У Бундестазі партія "Альтернатива для Німеччини" запитує про причетність України до інцидент] (uk:…
      У Бундестазі партія "Альтернатива для Німеччини" запитує про причетність України до інциденту з дроном, яку уряд покладає на Росію. Є підозрювані з Білорусі та Латвії.

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 56 total
  - (2026-09-03) [BleepingComputer] Plex warns users to patch security vulnerabilities immediately
      Plex urged users this week to update their desktop clients and media servers immediately to patch multiple security vulnerabilities. [...]
  - (2026-09-03) [BleepingComputer] Microsoft Teams, Outlook fail to launch on ARM-based Windows PCs
      Microsoft is working to fix a known issue that causes crashes and launch failures for Microsoft Teams and New Outlook users after installing updates released since the August 2026 Patch Tuesday. [...]
  - (2026-09-03) [The Hacker News] Attackers Turn Trusted Node.js Runtime Into Malware Delivery Tool in Targeted Attacks
      Threat actors are leveraging the trusted Node.js JavaScript runtime in multiple cyber attacks as a way to deploy malicious payloads. According to a new report published by the Symantec Threat Hunter Team today, the attac…
  - (2026-09-03) [The Hacker News] Shai-Hulud's Reach Just Grew to 469 Credential Locations. Here's What That Means
      In early August, GitGuardian researchers found that a recent Shai-Hulud infostealer worm variant had evolved to scan for credentials across 469 locations across developer environments, Continuous Integration/Continuous D…
  - (2026-09-03) [The Hacker News] Pegasus Zero-Click Spyware Exploit Infects Serbian Student Movement Member's iPhone
      The iPhone belonging to a member of Serbia's student protest movement was infected with NSO Group's Pegasus spyware, according to new findings from the Citizen Lab in collaboration with the SHARE Foundation. "Our analysi…
  - (2026-09-03) [The Hacker News] Researcher Releases FalconFlank PoC Showing Privilege Escalation in CrowdStrike Falcon
      The security researcher known as Chaotic Eclipse (aka INFINITE NIGHTMARE, MSNightmare, and Nightmare-Eclipse) has dropped a new zero-day dubbed FalconFlank, a privilege escalation flaw impacting Crowdstrike Falcon. "Falc…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-03) 424B3 - 1st FRANKLIN FINANCIAL CORP (0000038723) (Filer)
      filed 2026-09-03 11:49 UTC — Filed: 2026-09-03 AccNo: 0001628280-26-060248 Size: 29 KB
  - (2026-09-03) 425 - EQUITY BANCSHARES INC (0001227500) (Subject)
      filed 2026-09-03 11:49 UTC — Filed: 2026-09-03 AccNo: 0001193125-26-381059 Size: 9 MB
  - (2026-09-03) 485BXT - Themes ETF Trust (0001976322) (Filer)
      filed 2026-09-03 11:43 UTC — Filed: 2026-09-03 AccNo: 0001829126-26-009691 Size: 24 KB
  - (2026-09-03) 485BXT - Themes ETF Trust (0001976322) (Filer)
      filed 2026-09-03 11:43 UTC — Filed: 2026-09-03 AccNo: 0001829126-26-009691 Size: 24 KB
  - (2026-09-03) 485BXT - Themes ETF Trust (0001976322) (Filer)
      filed 2026-09-03 11:35 UTC — Filed: 2026-09-03 AccNo: 0001829126-26-009690 Size: 24 KB
  - (2026-09-03) 485BXT - Themes ETF Trust (0001976322) (Filer)
      filed 2026-09-03 11:35 UTC — Filed: 2026-09-03 AccNo: 0001829126-26-009690 Size: 24 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-03) GAF527 (Germany)
      icao24: 3dbc00 · position: (51.5818, 9.2786) · alt: 2743m · 318km/h
  - (2026-09-03) JAF9XT (Bulgaria)
      icao24: 4520ce · position: (36.3901, -4.7051) · alt: 11285m · 811km/h
  - (2026-09-03) JAF95J (Bulgaria)
      icao24: 4520aa · position: (40.7712, -7.0747) · alt: 10668m · 814km/h
  - (2026-09-03) PAT570 (United States)
      icao24: adfe54 · position: (35.6014, -81.1208) · alt: 6705m · 485km/h
  - (2026-09-03) CFC01 (Canada)
      icao24: c2c1f1 · position: (45.5963, -77.5643) · alt: 9174m · 787km/h
  - (2026-09-03) CNA22 (Spain)
      icao24: 3475cb · position: (27.6884, -15.8486) · alt: 1402m · 127km/h

### Paper Trading Scorecard — 24 new of 133 total
  - (2026-09-03) [Polymarket] Will the price of Bitcoin be above $72,000 on September 4?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-09-03) [Polymarket] Will Extended launch a token by September 30 2026?
      This market will resolve to “Yes” if Extended (https://x.com/extendedapp) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token m…
  - (2026-09-03) [Kalshi] US unemployment rate at year-end 2036
      December 2036
  - (2026-09-03) [Kalshi] US unemployment rate at year-end 2035
      December 2035
  - (2026-09-03) [Kalshi] US unemployment rate at year-end 2034
      December 2034
  - (2026-09-03) [Manifold] Diesel prices highest in history by EOY?

### U.S. Federal Action — 18 new of 18 total
  - (2026-09-03) Establishing the United States Space Academy
  - (2026-09-03) List of Approved Spent Fuel Storage Casks: Holtec International HI-STORM Flood/Wind System, Certificate of Compliance No. 1032, Amendment No. 10
      The U.S. Nuclear Regulatory Commission (NRC) is confirming the effective date of October 6, 2026, for the direct final rule that was published in the Federal Register on July 23, 2026. This direct final rule amended the…
  - (2026-09-03) Form PF; Reporting Requirements for All Filers and Large Hedge Fund Advisers; Further Extension of Compliance Date
      The Commodity Futures Trading Commission (the "CFTC") and the Securities and Exchange Commission (the "SEC") (collectively, "we" or the "Commissions") are further extending the compliance date for the amendments to Form…
  - (2026-09-03) Notice of Availability and Request for Comment: Revision to the Voluntary Standard for Products Containing Button Cell or Coin Batteries
      The U.S. Consumer Product Safety Commission's (Commission or CPSC) mandatory rule, Safety Standard for Button Cell or Coin Batteries and Consumer Products Containing Such Products, incorporates by reference UL 4200A, Sta…
  - (2026-09-03) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A318, A319, A320, and A321 series airplanes. This proposed AD was prompted by reports of one engine fire switch self-releasing, causin…
  - (2026-09-03) Special Local Regulation; Allegheny River Mile Markers 0-3.5 and Ohio River Mile Marker 0-3, Pittsburgh, PA
      The Coast Guard is establishing a temporary special local regulation (SLR) on the waters of the Allegheny River from mile marker 0 to mile marker 3.5 and the Ohio River from mile marker 0 to mile marker 3 in Pittsburgh,…

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-09-02) U.S. Court of Appeals, 6th Cir.: United States v. Glenn Daeward Boyd
  - (2026-09-02) U.S. Court of International Trade: Zoetis Servs. LLC v. United States
  - (2026-09-02) U.S. Court of Appeals, Federal Cir.: Netlist, Inc. v. Micron Technology, Inc.
  - (2026-09-02) U.S. Court of Appeals, 1st Cir.: Instituto Medico del Norte, Inc. v. Greengift Capital, LLC
  - (2026-09-02) U.S. Court of Appeals, 8th Cir.: B. P. v. Todd Blanche
  - (2026-09-02) U.S. Court of Appeals, 8th Cir.: Paulina Perez v. Todd Blanche

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-09-03) M 6.3 - 84 km SSW of Nikolski, Alaska
      M6.3 · 84 km SSW of Nikolski, Alaska · depth 35 km · TSUNAMI
  - (2026-09-02) M 6.2 - South Sandwich Islands region
      M6.2 · South Sandwich Islands region · depth 125.905 km
  - (2026-09-02) M 5.9 - southern East Pacific Rise
      M5.9 · southern East Pacific Rise · depth 10 km
  - (2026-09-02) M 5.6 - 71 km WSW of Puerto Madero, Mexico
      M5.6 · 71 km WSW of Puerto Madero, Mexico · depth 10 km
  - (2026-09-03) M 5.4 - 21 km WNW of Jiangyou, China
      M5.4 · 21 km WNW of Jiangyou, China · depth 10 km
  - (2026-09-02) M 5.4 - 82 km S of Isangel, Vanuatu
      M5.4 · 82 km S of Isangel, Vanuatu · depth 93.091 km

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-03) LoL: BNK FEARX vs Dplus KIA - Game 2 Winner
      yes price: 100% · 24h volume: $1,883,761 · resolves 2026-09-03
  - (2026-09-03) LoL: BNK FEARX vs Dplus KIA - Game 3 Winner
      yes price: 0% · 24h volume: $1,814,573 · resolves 2026-09-03
  - (2026-09-03) Will Sarah Huckabee Sanders win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,686,171 · resolves 2028-11-07
  - (2026-09-03) LoL: BNK FEARX vs Dplus KIA (BO5) - LCK Playoffs
      yes price: 38% · 24h volume: $1,676,827 · resolves 2026-09-03
  - (2026-09-03) Will Elon Musk win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,332,048 · resolves 2028-11-07
  - (2026-09-03) Will Nikki Haley win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,160,513 · resolves 2028-11-07

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 110 total
  - (2026-09-02) [OFAC] Reminder to file the 2026 Annual Report of Blocked Property; Issuance of Amended Venezuela-related General Licenses and Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Reminder to file the 2026 Annual Report of Blocked Property; Issuance of Amended Venezuela-related General Licenses and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-09-02) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54C Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54C Authorizing the Supply Office of Foreign Assets Control (.gov)
  - (2026-09-02) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 55A Authorizing Negotiatio - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 55A Authorizing Negotiatio Office of Foreign Assets Control (.gov)
  - (2026-09-02) [OFAC] Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Frequently Asked Qu
  - (2026-09-02) [OFAC] Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions Office of Foreign A
  - (2026-09-03) [USASpending] $4,683,777,952 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration. Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES

### CISA Known Exploited Vulnerabilities (last 14d) — 7 new of 23 total
  - (2026-09-02) CVE-2026-59822 · BerriAI LiteLLM: BerriAI LiteLLM Improper Authentication Vulnerability
      vendor: BerriAI · product: LiteLLM · CISA remediation by 2026-09-16
  - (2026-09-02) CVE-2026-48710 · Kludex Starlette: Kludex Starlette HTTP Request/Response Smuggling Vulnerability
      vendor: Kludex · product: Starlette · CISA remediation by 2026-09-16
  - (2026-09-02) CVE-2026-49869 · Kestra Kestra OSS: Kestra OSS OS Command Injection Vulnerability
      vendor: Kestra · product: Kestra OSS · CISA remediation by 2026-09-05
  - (2026-09-02) CVE-2026-82329 · JFrog Artifactory: JFrog Artifactory Improper Authentication Vulnerability
      vendor: JFrog · product: Artifactory · CISA remediation by 2026-09-05
  - (2026-09-02) CVE-2026-9586 · Sangoma Switchvox: Sangoma Switchvox SQL Injection Vulnerability
      vendor: Sangoma · product: Switchvox · CISA remediation by 2026-09-05
  - (2026-09-02) CVE-2026-83548 · SonicWall SMA1000 Appliances: SonicWall SMA1000 Appliances Server-Side Request Forgery Vulnerability
      vendor: SonicWall · product: SMA1000 Appliances · CISA remediation by 2026-09-05

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-03) [Marginal Revolution] How Much Redistribution Will AI Require?
      How much redistribution will AI require? A common scenario is that AI raises output enormously, but labor’s share of income collapses. GDP per capita goes up but workers get poorer, and making workers whole requires mass…
  - (2026-09-03) [Marginal Revolution] Thursday assorted links
      1. “Some crazy stats from this new JEL paper: – IV est. average 3–10x OLS (meta analysis) – Sign. results 30x more likely to be published in experimental econ (Andrews & Kasy) – <2% of empirical polisci report null-only…
  - (2026-09-03) [Marginal Revolution] My excellent Conversation with Michael Moritz
      Here is the audio, video, and transcript. Here is the episode summary: Michael Moritz has written books through every phase of his life: the first history of Apple and an account of Chrysler’s near-death while he was a j…
  - (2026-09-02) [Conversable Economist] US Energy: Source to End-Use
      Maybe my perceptions are incorrect on this point, but my sense is that a lot of people believe that the US economy is making strong progress toward clean non-carbon energy, driven by increases in solar and wind power. I…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 33 total
  - (2026-09-03) MOVER ▼ Mukesh Ambani — $89.44B ($-0.46B since yesterday)
      India · Diversified · source: Diversified
  - (2026-09-03) MOVER ▼ Amancio Ortega — $144.27B ($-0.30B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-09-03) MOVER ▲ Bernard Arnault & family — $134.57B (+$0.12B since yesterday)
      France · Fashion & Retail · source: LVMH

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=25, 14d-median=19; carrying terms: specifically, national, certain, unless, temporary, published, proposed, safety, management, amends, commission, associated
- state_bills: today=87, 7d-median=78, 14d-median=80; carrying terms: provided, health, based, application, makes, subject, property, contract, california, community, government, known
- state_news: today=737, 7d-median=648, 14d-median=597; carrying terms: asking, residents, health, httperror, elected, pushing, sports, based, collins, although, ctmirror, biggest
- local_news: today=238, 7d-median=238, 14d-median=238; carrying terms: shooting, school, people, season, alert, content, years, uploads, south, falcons, resize, missing
- foreign_news: today=1107, 7d-median=1064, 14d-median=1027; carrying terms: provided, autonomous, residents, giant, health, steps, httperror, stance, communist, shifts, brainpower, based
- chinese_internal: today=282, 7d-median=291, 14d-median=286; carrying terms: people, cbmiakfvx, lxtfa, cbmidefvx, caixin, cbmia, https, cbmiw, title, target, cbmibefvx, cbmib
- russian_internal: today=1224, 7d-median=1074, 14d-median=1030; carrying terms: gazeta, russian, truth, forbidden, social, novaya, found, httperror, https, europe, bloomberg, wildberries
- ukrainian_internal: today=128, 7d-median=122, 14d-median=119; carrying terms: elections, logistics, france, httperror, strikes, operations, ground, people, facility, civilian, month, government
- ukraine_theater: today=612, 7d-median=239, 14d-median=735; carrying terms: foowdtsfduwnjiwvzfbg, dhvldvs, cqkxuyjhhsdbtchpzsm, cjzyt, pbrgd, repairs, plwwzxelr, fkofcyq, ysjhxefzpazbtdgtqndz, fzehjre, ctjouelxx, hcdxewbec
- paper_bets: today=133, 7d-median=133, 14d-median=132; carrying terms: former, general, named, nuclear, trump, election, legal, johnson, remain, hampshire, humanoid, earthquake
- weather: today=163, 7d-median=133, 14d-median=143; carrying terms: galveston, significantly, gusty, cause, afdlox, rainfall, norton, remain, detroit, children, hazard, health
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: latest, effective, cpiaucsl, pcepilfe, total, money, growth, consumption, walcl, headline, dexchus, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, credit, yield, silver, large, equities, range, futures, crypto, bitcoin, proxy, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=110, 7d-median=110, 14d-median=108; carrying terms: general, nuclear, sovereignty, sectoral, belarus, transition, foreign, square, burundi, relation, order, committees
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, https, quiverquant, congresstrading, unauthorized, quiver, client, quantitative, error
- billionaires: today=33, 7d-median=0, 14d-median=30; carrying terms: nasdaq, canada, mining, spain, infrastructure, oracle, tesla, brokerage, adani, peterffy, zhang, google
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, court, supreme, appeals, connecticut, america, delaware, services, county, company, thomas, board
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, financial, trust, filer, jpmorgan, chase
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: alexandria, pinkston, robert, filing, booker, jonathan, senate, angels, ossoff, ocasio, cycle, disbursements
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: trump, english, keywords
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, ground, germany, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: exposed, bangladesh, operator, private, general, fourth, jinka, situation, chikungunya, reference, infected, confirmation
- cisa_kev: today=23, 7d-median=20, 14d-median=20; carrying terms: missing, vulnerability, critical, vendor, microsoft, product, remediation, suite, synacor, command, function, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=15, 7d-median=14, 14d-median=14; carrying terms: depth, islands, japan, region, south, chile, tonga, sandwich, alaska, china, vanuatu, papua
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, donetsk, championship, volume, meeting, presidential, price, league, september, decrease, resolves, shakhtar
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, https, conversable, revolution, marginal, class, shows, years, government, labor, conversableeconomist, economy
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: hacker, schneier, cybersecurity, today, spectrum, people, agents, company, technica, month, computerweekly, review
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: scholten, jerrold, general, jamieson, emmer, angus, vicente, staff, booker, houlahan, hayes, brett
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, either, module, consensus, sufficient, placement, placed, converges, identify, market, decision, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*