# WORLDSCOPE morning brief — 2026-09-03

## Headline
3701 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (802) · Russian Internal News (state + in-exile) (730) · Ukraine Theater (total-war monitoring) (459) · World leaders & government officials (324) · State-Level News (305) · Chinese Internal News (230) · Local News: St. Louis + Atlanta (200) · U.S. Weather + Severe / Climate Outlooks (168) · State Legislative Action (121) · Ukrainian Internal News (national + local Kyiv) (60) · IT, InfoSys & cybersecurity news (last 7 days) (43) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 802 new of 1090 total
  - (2026-09-02) [Global] New constitution in Guinea-Bissau will undermine democracy, opponents say
  - (2026-09-02) [Global] Apple Maps renames Lake Ontario as ‘Lake America’ for US users after Trump order
  - (2026-09-02) [Global] Trump ally defends Venezuela oil deal amid ‘gunpoint diplomacy’ criticism
  - (2026-09-02) [Global] Pete Hegseth criticized for body-shaming Canadian cadets: ‘Literally they’re kids’
  - (2026-09-02) [Global] Tumbler Ridge mass shooting victims file 30 new lawsuits against OpenAI
  - (2026-09-02) [Global] China’s falling emissions amid Iran war spark hope of decarbonisation watershed

### Russian Internal News (state + in-exile) — 730 new of 1188 total
  - (2026-09-03) В Мюнхене на стройплощадку перед офисом оборонного концерна бросили зажигательные снаряды. Задержаны двое граждан Болгарии | LEDE: В Мюнхене на строительную площадку перед штаб-квартирой тех] (ru: В М…
      В Мюнхене на строительную площадку перед штаб-квартирой технологического концерна Rohde & Schwarz, работающего в оборонной отрасли, бросили емкости с зажигательной смесью, сообщает медиакомпания BR24.
  - (2026-09-03) «Дело не в СВО». Путин заявил, что война не определяет рождаемость в России | LEDE: Война с Украиной влияет на рождаемость в России, но не является основной причиной демографического кризиса] (ru: «Де…
      Война с Украиной влияет на рождаемость в России, но не является основной причиной демографического кризиса, заявил Владимир Путин на пленарном заседании Восточного экономического форума.
  - (2026-09-03) В Киеве снова стрельба. Полиция проводит операцию по задержанию вооруженного преступника | LEDE: В Святошинском районе Киева произошла стрельба. ] (ru: В Киеве снова стрельба. Полиция проводит операци…
      В Святошинском районе Киева произошла стрельба.
  - (2026-09-03) «Коммерсант»: российские нефтяные компании не закрыли около 60% биржевых контрактов на поставку бензина — из-за атак Украины на НПЗ | LEDE: С мая по сентябрь российские нефтяные компании не ] (ru: «Ко…
      С мая по сентябрь российские нефтяные компании не смогли закрыть около 60% контрактов на поставку бензина, заключенных на Петербургской бирже, следует из оценок источников «Коммерсанта» в отрасли.
  - (2026-09-03) В Подмосковье украинские беспилотники попали в жилые дома в Кубинке и Павловском Посаде. В Сочи атакован морской порт | LEDE: Украинские беспилотники атаковали Московскую область, в Кубинке ] (ru: В П…
      Украинские беспилотники атаковали Московскую область, в Кубинке и Павловском Посаде есть попадания в жилые дома, сообщил губернатор Андрей Воробьев.
  - (2026-09-03) «Агентство»: в России усилили охрану пропагандистов. К руководителям гостелеканалов и телеведущим приставили сотрудников Росгвардии | LEDE: Власти России усилили охрану руководителей государ] (ru: «Аг…
      Власти России усилили охрану руководителей государственных телеканалов и телеведущих после атак Украины на российских военных и пропагандистов, рассказали источники «Агентства».

### Ukraine Theater (total-war monitoring) — 459 new of 612 total
  - (2026-09-02) [FIRMS] thermal anomaly 52.803, 32.224 (FRP 0.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 0.52 MW
  - (2026-09-02) [FIRMS] thermal anomaly 52.803, 32.223 (FRP 0.49 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 0.49 MW
  - (2026-09-02) [FIRMS] thermal anomaly 52.849, 29.989 (FRP 1.33 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 1.33 MW
  - (2026-09-02) [FIRMS] thermal anomaly 51.891, 29.342 (FRP 8.34 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 8.34 MW
  - (2026-09-02) [FIRMS] thermal anomaly 51.893, 29.346 (FRP 4.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 4.05 MW
  - (2026-09-02) [FIRMS] thermal anomaly 51.895, 29.338 (FRP 4.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-02 0115Z, FRP 4.69 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 305 new of 718 total
  - (2026-09-02) [Alabama] Governor Ivey Backs Trump Administration Trucking Crackdown as Alabama Leads the Way
      MONTGOMERY – Governor Kay Ivey on Wednesday applauded the Trump Administration for launching a sweeping federal initiative to combat fraud and illegal activity in the commercial trucking industry, while highlighting Alab…
  - (2026-09-02) [California] Governor Newsom announces nearly 15,300 illegal hemp, kratom and 7-OH products removed from California store shelves
      Source
  - (2026-09-02) [California] California’s legal cannabis market generates $8.4 billion for Californians as state cracks down on illicit operators
      Source
  - (2026-09-02) [California] Governor Newsom announces CalGuard has seized $534 million in deadly fentanyl, helping keep drugs off the streets as crime falls statewide
      <a href="https://www.gov.ca.gov/2026/09/02/governor-newsom-announces-calguard-has-seized-534-million-in-deadly-
  - (2026-09-03) [Connecticut] New Steelpointe apartments fuel affordability debate in Bridgeport
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/STEELPOINTE-BPT-0825-SG-04-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fet…
  - (2026-09-03) [Connecticut] We are one rainstorm away from another public health crisis
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/screenshot-2026-07-07-at-74105-am-1024x768.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="as…

### Chinese Internal News — 230 new of 279 total
  - (2026-09-02) 习近平和彭丽媛同埃及总统塞西夫妇共同参观大埃及博物馆 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFBaWWdvanpSd2lPTzUzVkpaUUdQMW5SZDEwazJpZDY4OXpIX21UVEsyaUZSZEpMVGU4cU9MWmtjSEYzeHl5bkNja] (zh:…
      习近平和彭丽媛同埃及总统塞西夫妇共同参观大埃及博物馆 人民网-图片频道
  - (2026-09-03) 「新三種の神器」に続き、中国製AIグラスやロボットが海外で売れ行き好調 - 人民網日本語版 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZ0FVX3lxTE9zZUhQcl9FSmRRaFpkV1pLZEpjZTlzLXJXNEZ3UERKd1g5MS12TUhoU2RJaGdCMXNsRnVYSFRTSUhlT] (zh:…
      「新三種の神器」に続き、中国製AIグラスやロボットが海外で売れ行き好調 人民網日本語版
  - (2026-09-03) 江苏如皋： 古籍文化进校园 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE8tWGk2bUNDcE1uUUZqbFhsOE94cDA0LXk1Y3B2VzVPTGVKeTB6V0JsZTQ3UFJxN3J0VnA3SENidUJnZkw0XzdSZ1hVZHliM0FsR1VkWW] (zh:…
      江苏如皋： 古籍文化进校园 人民图片
  - (2026-09-03) 云南昆明： 斗南花市夜经济活力足 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE8zZkhMZXdHanJUdmljWEpCQnFYNk4xM29CQlFlbm52ZWpHTFhDcV9MVzJhcEs2bDEwTE5hSGNxdFJPMkUzcTdmWVVqUnFvWFNLTkU] (zh:…
      云南昆明： 斗南花市夜经济活力足 人民图片
  - (2026-09-03) 2026低空经济发展大会在安徽芜湖举行 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1meXJjT2cwb2FfLVpYMDVNa28xZHRkbTA1ZzBjeElxREJlOUJ6azVFUnoyWHNsUVpJSWs2bm5TSGpkZVhZWUVoR3hRb1lTUGw5] (zh:…
      2026低空经济发展大会在安徽芜湖举行 人民图片
  - (2026-09-03) 江苏无锡： 江苏首个机场宠物专属服务空间投运 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1DbUdrWTlTM05WWTRUcl9KYzZWczFnZU0xUmpNZEtlcUZRZG1iSFpubEtkYkluTlRpYkdpaWhMZXBrdXZpM0FuMVVnSnZzc] (zh:…
      江苏无锡： 江苏首个机场宠物专属服务空间投运 人民图片

### Local News: St. Louis + Atlanta — 200 new of 226 total
  - (2026-09-03) [St. Louis] Where in Clayton 9/3/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-09-03) [St. Louis] Where in the Lou 9/3/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-09-02) [St. Louis] A day in the life of Megan Sinclair
      Before the rest of the house is awake, Megan Sinclair is already moving. Her alarm goes off around 5:45 a.m. She makes coffee, gets ready, and makes every bed in the house. She opens the blinds and windows, letting the m…
  - (2026-09-02) [St. Louis] ‘Weaving the Infinite’ showcases textile artist Olga de Amaral’s decades-long career
      The unbridled beauty of Olga de Amaral’s textile work will be on display at the Pulitzer Arts Foundation’s upcoming exhibition, Weaving the Infinite, running from September 10—January 31, 2027. Produced in collaboration…
  - (2026-09-02) [St. Louis] St. Louis CITY SC goes big as transformative transfer window closes
      St. Louis CITY SC is putting the finishing touches on a dramatic roster overhaul that could transform the club into a Western Conference contender. The biggest move is not yet official, but appears imminent. CITY is repo…
  - (2026-09-02) [St. Louis] Top things to do in St. Louis this weekend: September 4–6
      Musiq Soulchild | September 3–5 Musiq Soulchild’s fingerprints are all over 21st century hip-hop, neo-soul, and R&B. He’s been putting out his own records and collaborating with basically everyone since his Y2K debut, Ai…

### U.S. Weather + Severe / Climate Outlooks — 168 new of 169 total
  - (2026-09-03) [Moderate] Special Weather Statement: Special Weather Statement issued September 3 at 4:33AM CDT by NWS Bismarck ND
      At 433 AM CDT /333 AM MDT/, a line of strong thunderstorms was located from 13 miles north of Epping to 13 miles northeast of Watford City, or from 25 miles northeast of Williston to 13 miles northeast of Watford City, m…
  - (2026-09-03) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 3 at 5:31AM EDT until September 3 at 6:30AM EDT by NWS Pittsburgh PA
      SVRPBZ The National Weather Service in Pittsburgh has issued a * Severe Thunderstorm Warning for... Northeastern Columbiana County in east central Ohio... Mercer County in northwestern Pennsylvania... Venango County in n…
  - (2026-09-03) [Moderate] Special Weather Statement: Special Weather Statement issued September 3 at 5:29AM EDT by NWS Cleveland OH
      At 529 AM EDT, Doppler radar was tracking a strong thunderstorm near Kinsman, or 17 miles north of Warren, moving east at 40 mph. HAZARD...Wind gusts of 50 to 55 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could…
  - (2026-09-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-03) [Severe] Flood Warning: Flood Warning issued September 3 at 5:26AM EDT until September 3 at 9:15AM EDT by NWS Mount Holly NJ
      * WHAT...Urban areas and small streams flooding caused by excessive rainfall is expected. * WHERE...Northern New Castle County in northern Delaware... Northwestern Burlington County in southern New Jersey... Northwestern…
  - (2026-09-03) [Moderate] Special Weather Statement: Special Weather Statement issued September 3 at 5:25AM EDT by NWS Jacksonville FL
      Patchy dense fog and low stratus has developed across inland Southeast Georgia and inland Northeast Florida early this morning. Local visibilities of one half mile or less can be expected at times through sunrise. Visibi…

### State Legislative Action — 121 new of 183 total
  - (2026-09-02) [Delaware HB 223] AN ACT TO AMEND TITLE 16 OF THE DELAWARE CODE RELATING TO INFORMATIONAL MATERIALS CONCERNING MENSTRUAL DISORDERS.
      This Act requires the Department of Health and Social Services, in conjunction with the Department of Education, to develop or obtain informational materials concerning menstrual disorders to be provided upon request to…
  - (2026-09-02) [Delaware SB 301] AN ACT TO AMEND TITLE 16 OF THE DELAWARE CODE RELATING TO HOSPITAL DISCHARGE PLANS FOR PREGNANT PATIENTS.
      This Act requires that a hospital create a discharge plan if a pregnant patient who is experiencing signs or symptoms consistent with labor is discharged before delivery. This requirement to create a discharge plan appli…
  - (2026-09-02) [Delaware SB 310] AN ACT TO AMEND TITLE 20 OF THE DELAWARE CODE RELATING TO THE DELAWARE DISASTER RECOVERY FUND.
      This Act creates a Disaster Recovery Fund (the "Fund") to provide disaster recovery assistance to Delaware residents and local governments affected by disasters. The Fund is intended to provide means for program creation…
  - (2026-09-02) [Delaware SJR 20] DIRECTING THE DIVISION OF MEDICAID AND MEDICAL ASSISTANCE TO EVALUATE ASSESSMENTS FOR INDIVIDUALS RECEIVING HOME AND COMMUNITY-BASED SERVICES.
      This resolution requires the Department of Health & Social Services to evaluate the feasibility of using independent assessment tools and assessors for the determination of support needs for individuals eligible for Home…
  - (2026-09-02) [Delaware HB 435] AN ACT TO AMEND TITLES 18, 29, AND 31 OF THE DELAWARE CODE RELATING TO CERTIFIED REGISTERED NURSE ANESTHETISTS.
      This Act prohibits individual, group, state employee, and Medicaid health plans from differentiating in the reimbursement rate of a health service based on whether the service was provided by a certified registered nurse…
  - (2026-09-02) [Delaware SB 307] AN ACT TO AMEND TITLE 26 OF THE DELAWARE CODE RELATING TO ELIGIBLE TELECOMMUNICATIONS CARRIERS FOR LIFELINE SERVICES.
      This Act gives Delaware’s Public Service Commission (“Commission”) the authority to designate a telecommunications provider or reseller as an eligible telecommunications carrier (“ETC”) for the purpose of providing Lifel…

### Ukrainian Internal News (national + local Kyiv) — 60 new of 124 total
  - (2026-09-03) Богуславець: Хто вніс понад мільярд застави за топпосадовців Зеленського | LEDE: ] (uk: Богуславець: Хто вніс понад мільярд застави за топпосадовців Зеленського)
  - (2026-09-03) Розвідка, дрони, ППО: Німеччина активізує військову підтримку України після атаки РФ в Лейпцигу | LEDE: Уряд Німеччини планує передати Україні ударні дрони та ракети Iris-T, а також розширити п] (uk:…
      Уряд Німеччини планує передати Україні ударні дрони та ракети Iris-T, а також розширити повноваження спецслужб для протидії Росії.
  - (2026-09-03) СБУ показала відео, де Каплунов визнає зв'язок з ФСБ РФ. Його адвокат заявляє про зізнання під тиском | LEDE: Служба безпеки України показала відео, де Каплунов визнає зв’язки з ФСБ Росії. Адво] (uk:…
      Служба безпеки України показала відео, де Каплунов визнає зв’язки з ФСБ Росії. Адвокат заявив, що його змусили зробити це під тиском і погрозами.
  - (2026-09-03) Рада позбавила мандатів двох нардепів зі "Слуги народу" | LEDE: Парламент достроково припинив депутатські повноваження Андрія Жупанина і Остапа Шипайла з фракції «Слуга народу» 3 вересня. Підтр] (uk:…
      Парламент достроково припинив депутатські повноваження Андрія Жупанина і Остапа Шипайла з фракції «Слуга народу» 3 вересня. Підтримали понад 230 нардепів.
  - (2026-09-03) Путін: Домовлятися про кінець війни мають насамперед Україна і Росія | LEDE: Російський лідер Володимир Путін заявив, що домовлятися про закінчення війни мають її безпосередні учасники – Україн] (uk:…
      Російський лідер Володимир Путін заявив, що домовлятися про закінчення війни мають її безпосередні учасники – Україна і Росія.
  - (2026-09-03) Каплунов розповів про перебування у "таємній в’язниці", де йому погрожували "зникнути назавжди" | LEDE: Степан Каплунов описав, як співробітники Служби безпеки України утримували та змусили йог] (uk:…
      Степан Каплунов описав, як співробітники Служби безпеки України утримували та змусили його визнати зв’язки з ФСБ під психологічним тиском.

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 57 total
  - (2026-09-03) [BleepingComputer] Microsoft Teams, Outlook fail to launch on ARM-based Windows PCs
      Microsoft is working to fix a known issue that causes crashes and launch failures for Microsoft Teams and New Outlook users after installing updates released since the August 2026 Patch Tuesday. [...]
  - (2026-09-03) [The Hacker News] Researcher Releases FalconFlank PoC Showing Privilege Escalation in CrowdStrike Falcon
      The security researcher known as Chaotic Eclipse (aka INFINITE NIGHTMARE, MSNightmare, and Nightmare-Eclipse) has dropped a new zero-day dubbed FalconFlank, a privilege escalation flaw impacting Crowdstrike Falcon. "Falc…
  - (2026-09-03) [The Hacker News] CISA Adds Seven Exploited Flaws as Attackers Deploy Reverse Shells and Crypto Miners
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Wednesday added seven security flaws to its Known Exploited Vulnerabilities (KEV) catalog after they landed in attackers' crosshairs. The vulnerabilitie…
  - (2026-09-03) [The Register] UK's Online Safety Act has made 'absolutely no difference,' kids say
      Children's Commissioner also furious with Ofcom over a string of failures
  - (2026-09-03) [The Register] British wind power to drive Maersk container ship
      Rotor sails claimed to deliver fuel and emissions savings of 21%
  - (2026-09-03) [The Register] Your VMware renewal invoice ate your AI budget – what now?
      SPONSORED POST: A free event with Nutanix on Oct 7 can win some of it back

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-03) [Marino Mark A.] Form 4 (Reporting)
      filed 2026-09-03 01:53 UTC · role: Reporting — Filed: 2026-09-02 AccNo: 0001810019-26-000105 Size: 6 KB
  - (2026-09-03) [Rackspace Technology, Inc.] Form 4 (Issuer)
      filed 2026-09-03 01:53 UTC · role: Issuer — Filed: 2026-09-02 AccNo: 0001810019-26-000105 Size: 6 KB
  - (2026-09-03) [Rackspace Technology, Inc.] Form 4 (Issuer)
      filed 2026-09-03 01:53 UTC · role: Issuer — Filed: 2026-09-02 AccNo: 0001810019-26-000104 Size: 6 KB
  - (2026-09-03) [SINHA DHARMENDRA KUMAR] Form 4 (Reporting)
      filed 2026-09-03 01:53 UTC · role: Reporting — Filed: 2026-09-02 AccNo: 0001810019-26-000104 Size: 6 KB
  - (2026-09-03) [Rackspace Technology, Inc.] Form 4 (Issuer)
      filed 2026-09-03 01:52 UTC · role: Issuer — Filed: 2026-09-02 AccNo: 0001810019-26-000103 Size: 6 KB
  - (2026-09-03) [Kandiah Gajakarnan Vibushanan] Form 4 (Reporting)
      filed 2026-09-03 01:52 UTC · role: Reporting — Filed: 2026-09-02 AccNo: 0001810019-26-000103 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-03) [Azerbaijan] Tokayev calls Laos key and reliable partner for Kazakhstan in Southeast Asia
      domain: trend.az · language: English · tone:
  - (2026-09-03) [United States] Hong Kong court upholds convictions of Cardinal Joseph Zen and others over protester relief fund
      domain: news4jax.com · language: English · tone:
  - (2026-09-03) [Pakistan] Nepalis pin hopes on wall of the missing in hunt for relatives after deadly flood
      domain: tribune.com.pk · language: English · tone:
  - (2026-09-03) [United Kingdom] Newton Emerson : The public sector problem Stormont refuses to confront
      domain: irishnews.com · language: English · tone:
  - (2026-09-03) [Australia] Merrylands West shooting victim identified as Joshua Macdonald
      domain: theage.com.au · language: English · tone:
  - (2026-09-03) [United States] Six Workers Injured During Load - Out After Ed Sheeran Concert in Detroit
      domain: hot101.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 26 new of 137 total
  - (2026-09-03) [Polymarket] Will the price of Bitcoin be above $72,000 on September 4?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-09-03) [Polymarket] Will Elon Musk post 320-339 tweets from August 28 to September 4, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from August 28 12:00 PM ET to September 4, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts…
  - (2026-09-03) [Polymarket] Will Extended launch a token by September 30 2026?
      This market will resolve to “Yes” if Extended (https://x.com/extendedapp) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token m…
  - (2026-09-03) [Kalshi] US unemployment rate at year-end 2036
      December 2036
  - (2026-09-03) [Kalshi] US unemployment rate at year-end 2035
      December 2035
  - (2026-09-03) [Kalshi] US unemployment rate at year-end 2034
      December 2034

### Government & military aircraft airborne (OpenSky) — 26 new of 26 total
  - (2026-09-03) GAF527 (Germany)
      icao24: 3dbc00 · position: (50.9575, 8.009) · alt: 1775m · 219km/h
  - (2026-09-03) SAMU71 (France)
      icao24: 398c4e · position: (46.0956, 5.9656) · alt: 975m · 254km/h
  - (2026-09-03) SAMU05 (France)
      icao24: 39ca81 · position: (43.5597, 5.4817) · alt: 624m · 243km/h
  - (2026-09-03) GAF190 (Germany)
      icao24: 3f6219 · position: (43.8053, 27.8001) · alt: 10058m · 742km/h
  - (2026-09-03) JAF7CB (Belgium)
      icao24: 44d1a6 · position: (44.8146, -0.8623) · alt: 10363m · 798km/h
  - (2026-09-03) JAF29J (Belgium)
      icao24: 44d1b3 · position: (41.4608, 19.1306) · alt: 11780m · 780km/h

### Court opinions of consequence (federal & state) — 19 new of 60 total
  - (2026-09-02) U.S. Court of International Trade: Zoetis Servs. LLC v. United States
  - (2026-09-02) U.S. Court of Appeals, 1st Cir.: Instituto Medico del Norte, Inc. v. Greengift Capital, LLC
  - (2026-09-02) U.S. Court of Appeals, 11th Cir.: The Town of Pine Hill, Alabama v. 3M Company
  - (2026-09-02) U.S. Court of Appeals, 11th Cir.: Andrew Filipowski v. Commissioner of Internal Revenue
  - (2026-09-02) U.S. Court of Appeals, 8th Cir.: B. P. v. Todd Blanche
  - (2026-09-02) U.S. Court of Appeals, 8th Cir.: Paulina Perez v. Todd Blanche

### U.S. Federal Action — 18 new of 18 total
  - (2026-09-03) Establishing the United States Space Academy
  - (2026-09-03) List of Approved Spent Fuel Storage Casks: Holtec International HI-STORM Flood/Wind System, Certificate of Compliance No. 1032, Amendment No. 10
      The U.S. Nuclear Regulatory Commission (NRC) is confirming the effective date of October 6, 2026, for the direct final rule that was published in the Federal Register on July 23, 2026. This direct final rule amended the…
  - (2026-09-03) Form PF; Reporting Requirements for All Filers and Large Hedge Fund Advisers; Further Extension of Compliance Date
      The Commodity Futures Trading Commission (the "CFTC") and the Securities and Exchange Commission (the "SEC") (collectively, "we" or the "Commissions") are further extending the compliance date for the amendments to Form…
  - (2026-09-03) Notice of Availability and Request for Comment: Revision to the Voluntary Standard for Products Containing Button Cell or Coin Batteries
      The U.S. Consumer Product Safety Commission's (Commission or CPSC) mandatory rule, Safety Standard for Button Cell or Coin Batteries and Consumer Products Containing Such Products, incorporates by reference UL 4200A, Sta…
  - (2026-09-03) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A318, A319, A320, and A321 series airplanes. This proposed AD was prompted by reports of one engine fire switch self-releasing, causin…
  - (2026-09-03) Special Local Regulation; Allegheny River Mile Markers 0-3.5 and Ohio River Mile Marker 0-3, Pittsburgh, PA
      The Coast Guard is establishing a temporary special local regulation (SLR) on the waters of the Allegheny River from mile marker 0 to mile marker 3.5 and the Ohio River from mile marker 0 to mile marker 3 in Pittsburgh,…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-03) LoL: BNK FEARX vs Dplus KIA - Game 1 Winner
      yes price: 100% · 24h volume: $1,844,671 · resolves 2026-09-03
  - (2026-09-03) Will Sarah Huckabee Sanders win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,683,256 · resolves 2028-11-07
  - (2026-09-03) Will Elon Musk win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,332,053 · resolves 2028-11-07
  - (2026-09-03) Will Nikki Haley win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,155,920 · resolves 2028-11-07
  - (2026-09-03) LoL: BNK FEARX vs Dplus KIA - Game 2 Winner
      yes price: 76% · 24h volume: $1,063,444 · resolves 2026-09-03
  - (2026-09-03) Will Elon Musk win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $818,659 · resolves 2028-11-07

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 110 total
  - (2026-09-02) [OFAC] Reminder to file the 2026 Annual Report of Blocked Property; Issuance of Amended Venezuela-related General Licenses and Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Reminder to file the 2026 Annual Report of Blocked Property; Issuance of Amended Venezuela-related General Licenses and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-09-02) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54C Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54C Authorizing the Supply Office of Foreign Assets Control (.gov)
  - (2026-09-02) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 55A Authorizing Negotiatio - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 55A Authorizing Negotiatio Office of Foreign Assets Control (.gov)
  - (2026-09-02) [OFAC] Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Frequently Asked Qu
  - (2026-09-02) [OFAC] Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions Office of Foreign A
  - (2026-09-03) [USASpending] $4,683,777,952 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration. Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES

### USGS earthquakes (M4.5+, past day) — 12 new of 13 total
  - (2026-09-02) M 6.2 - South Sandwich Islands region
      M6.2 · South Sandwich Islands region · depth 125.905 km
  - (2026-09-02) M 5.9 - southern East Pacific Rise
      M5.9 · southern East Pacific Rise · depth 10 km
  - (2026-09-02) M 5.6 - 71 km WSW of Puerto Madero, Mexico
      M5.6 · 71 km WSW of Puerto Madero, Mexico · depth 10 km
  - (2026-09-02) M 5.4 - 82 km S of Isangel, Vanuatu
      M5.4 · 82 km S of Isangel, Vanuatu · depth 93.091 km
  - (2026-09-02) M 5.4 - 53 km W of Bulolo, Papua New Guinea
      M5.4 · 53 km W of Bulolo, Papua New Guinea · depth 65.164 km
  - (2026-09-02) M 5.2 - 78 km SSW of Nikolski, Alaska
      M5.2 · 78 km SSW of Nikolski, Alaska · depth 35 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-09-03) MOVER ▲ Michael Dell — $250.72B (+$19.32B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-09-03) MOVER ▼ Elon Musk — $872.34B ($-7.41B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-09-03) MOVER ▲ Jensen Huang — $193.73B (+$5.93B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-09-03) MOVER ▲ Larry Ellison — $188.45B (+$4.98B since yesterday)
      United States · Technology · source: Oracle
  - (2026-09-03) MOVER ▲ Mark Zuckerberg — $203.54B (+$4.85B since yesterday)
      United States · Technology · source: Facebook
  - (2026-09-03) MOVER ▼ Bernard Arnault & family — $134.45B ($-2.88B since yesterday)
      France · Fashion & Retail · source: LVMH

### CISA Known Exploited Vulnerabilities (last 14d) — 7 new of 23 total
  - (2026-09-02) CVE-2026-59822 · BerriAI LiteLLM: BerriAI LiteLLM Improper Authentication Vulnerability
      vendor: BerriAI · product: LiteLLM · CISA remediation by 2026-09-16
  - (2026-09-02) CVE-2026-48710 · Kludex Starlette: Kludex Starlette HTTP Request/Response Smuggling Vulnerability
      vendor: Kludex · product: Starlette · CISA remediation by 2026-09-16
  - (2026-09-02) CVE-2026-49869 · Kestra Kestra OSS: Kestra OSS OS Command Injection Vulnerability
      vendor: Kestra · product: Kestra OSS · CISA remediation by 2026-09-05
  - (2026-09-02) CVE-2026-82329 · JFrog Artifactory: JFrog Artifactory Improper Authentication Vulnerability
      vendor: JFrog · product: Artifactory · CISA remediation by 2026-09-05
  - (2026-09-02) CVE-2026-9586 · Sangoma Switchvox: Sangoma Switchvox SQL Injection Vulnerability
      vendor: Sangoma · product: Switchvox · CISA remediation by 2026-09-05
  - (2026-09-02) CVE-2026-83548 · SonicWall SMA1000 Appliances: SonicWall SMA1000 Appliances Server-Side Request Forgery Vulnerability
      vendor: SonicWall · product: SMA1000 Appliances · CISA remediation by 2026-09-05

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-03) [Marginal Revolution] Thursday assorted links
      1. “Some crazy stats from this new JEL paper: – IV est. average 3–10x OLS (meta analysis) – Sign. results 30x more likely to be published in experimental econ (Andrews & Kasy) – <2% of empirical polisci report null-only…
  - (2026-09-03) [Marginal Revolution] My excellent Conversation with Michael Moritz
      Here is the audio, video, and transcript. Here is the episode summary: Michael Moritz has written books through every phase of his life: the first history of Apple and an account of Chrysler’s near-death while he was a j…
  - (2026-09-02) [Marginal Revolution] Richard Fontaine interviews me about AI
      For the American Society for AI. The post Richard Fontaine interviews me about AI appeared first on Marginal REVOLUTION.
  - (2026-09-02) [Conversable Economist] US Energy: Source to End-Use
      Maybe my perceptions are incorrect on this point, but my sense is that a lot of people believe that the US economy is making strong progress toward clean non-carbon energy, driven by increases in solar and wind power. I…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=25, 14d-median=20; carrying terms: national, unless, proposed, specifically, management, temporary, safety, certain, amends, action, commission, regulatory
- state_bills: today=183, 7d-median=78, 14d-median=86; carrying terms: retail, specific, adopt, provisions, privacy, required, governing, service, budget, defined, state, commission
- state_news: today=718, 7d-median=648, 14d-median=622; carrying terms: connecticut, sites, projects, administration, grand, facility, freedom, attachment, businesses, ballot, massachusetts, limits
- local_news: today=226, 7d-median=226, 14d-median=240; carrying terms: attachment, murder, blank, magazine, killed, width, another, google, games, against, season, trial
- foreign_news: today=1090, 7d-median=1064, 14d-median=1034; carrying terms: hormuz, liberation, stresses, chairman, specific, treasury, administration, remote, temple, improper, attachment, certificate
- chinese_internal: today=279, 7d-median=291, 14d-median=288; carrying terms: blank, cbmidefvx, google, cbmibkfvx, target, cbmiw, lxtfb, cbmia, china, cbmizefvx, cbmickfvx, cbmib
- russian_internal: today=1188, 7d-median=1074, 14d-median=1052; carrying terms: novayagazeta, forbidden, europe, client, wildberries, https, found, washington, novaya, gazeta, bloomberg, truth
- ukrainian_internal: today=124, 7d-median=122, 14d-median=120; carrying terms: volodymyr, facility, strikes, vechirniy, visit, aerial, killed, httperror, another, region, study, critical
- ukraine_theater: today=612, 7d-median=239, 14d-median=784; carrying terms: wtvrazjz, small, oznbya, jdqzvasurmyvvnt, aehwrvd, cdnlvuvcynziotvyowc, ministry, blenfuamt, hnefr, dwjjzejqug, zxrvcxnmmxrzbut, quality
- paper_bets: today=137, 7d-median=134, 14d-median=132; carrying terms: market, openai, committed, theme, supervolcano, starts, leader, israel, guilty, special, drought, mamdani
- weather: today=169, 7d-median=133, 14d-median=144; carrying terms: small, coastal, metro, significant, advisory, northwest, locations, afdokx, quality, rivers, afdmfl, lower
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: openings, rates, nonfarm, indicator, cpilfesl, payrolls, balance, jolts, recession, spread, walcl, growth
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, china, rates, silver, corporate, futures, range, bitcoin, natural, agriculture, russell, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=110, 7d-median=110, 14d-median=107; carrying terms: program, terrorist, sectoral, active, institute, specific, qaida, transition, snapshot, administration, satisfying, cbmizefvx
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, congresstrading, quantitative, unauthorized, https, quiverquant, client, httperror, error
- billionaires: today=40, 7d-median=0, 14d-median=30; carrying terms: julia, warren, meyers, bettencourt, source, retail, tiktok, buffett, bernard, zhang, technologies, nasdaq
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, court, supreme, connecticut, appeals, america, company, services, county, thomas, board, center
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, financial, michael, ronald, therapeutics, robert, technology, joint
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, ocasio, committee, cortez, disbursements, david, talarico, trone, sherrod, robert, cycle, jonathan
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, defense
- gdelt_gkg: today=0, 7d-median=50, 14d-median=50; carrying terms: keywords, english, against, jpost, strikes, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, kingdom, english, language, trump, trial, russia, israel, killed, police, canada, germany
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, germany, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: niger, kerala, january, blood, symptoms, unrelated, viruses, evolve, infant, sites, infecting, significant
- cisa_kev: today=23, 7d-median=20, 14d-median=18; carrying terms: server, injection, missing, vendor, improper, remediation, forgery, microsoft, collaboration, command, product, authentication
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=13, 14d-median=14; carrying terms: depth, islands, japan, region, south, tonga, chile, sandwich, alaska, papua, guinea, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, decrease, meeting, price, championship, volume, resolves, donetsk, interest, league, september, champions
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, marginal, conversable, https, economist, revolution, shows, conversableeconomist, government, years, economy, sense
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: intelligence, weekly, recent, hackers, companies, world, critical, cybersecurity, using, industry, across, computerweekly
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: schiff, eleanor, gdelt, evans, cindy, ernst, adelita, comer, moskowitz, kevin, griffith, patty
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, paper, evidence, market, placement, either, placed, consensus, claude, identify, today, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*