# WORLDSCOPE morning brief — 2026-09-13

## Headline
2718 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (694) · Russian Internal News (state + in-exile) (550) · Ukraine Theater (total-war monitoring) (364) · World leaders & government officials (324) · Chinese Internal News (183) · Local News: St. Louis + Atlanta (118) · U.S. Weather + Severe / Climate Outlooks (116) · State-Level News (89) · GDELT GKG — themes / entities / watch areas (75) · Ukrainian Internal News (national + local Kyiv) (62) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (25)

## What changed today
### International News + Multilateral Institutions — 694 new of 928 total
  - (2026-09-13) [Global] AI staff 'genuinely frightened' for humanity's future, ex-Anthropic researcher tells BBC
      It comes as the AI firm's boss has called for the technology's development to be slowed down, citing "serious" risks.
  - (2026-09-13) [Global] Dramatic insider warnings over AI fall flat with some in Silicon Valley
      A recent spate of stark warnings about the dangers of AI has been met with scepticism by executives and investors.
  - (2026-09-12) [Global] Anthropic boss Dario Amodei calls for AI development to slow down
      The call comes amid growing concerns that AI models may become able to inflict serious damage worldwide.
  - (2026-09-12) [Global] 'Skimpflation' warning as tinned mackerel alternative hits more supermarket shelves
      Consumer group Which? has called the sale of jack mackerel, a cheaper, less nutritious species of fish, an example of "skimpflation".
  - (2026-09-13) [Global] 'It's cost upon cost for working families - they get no help'
      The government needs to do more to support working families, a charity in Rotherham says.
  - (2026-09-13) [Global] Oil prices create 'huge worry' as winter looms
      The warning comes after the US-Iran conflict drives up heating oil and fuel costs.

### Russian Internal News (state + in-exile) — 550 new of 914 total
  - (2026-09-13) Во французском Перпиньяне каждую осень проходит фестиваль новостной фотожурналистики. Вот самые интересные кадры этого года | LEDE: Visa pour lʼImage — один из крупнейших ежегодных фестивале] (ru: Во…
      Visa pour lʼImage — один из крупнейших ежегодных фестивалей фотожурналистики в мире. Он проходит во французском Перпиньяне и длится несколько недель. К закрытию фестиваля «Медуза» выбрала несколько десятков кадров с фест…
  - (2026-09-13) Война. 1663-й день. Россия атаковала дронами АЗС и пассажирский поезд возле границы Украины и Польши. Индия и Китай «активно предлагают» Путину помощь в мирном урегулировании | LEDE: «Медуза] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-13) В Кремле рассказали о планах возобновления переговоров России, США и Украины в октябре | LEDE: Пресс-секретарь президента РФ Дмитрий Песков заявил, что переговоры о мирном урегулировании с у] (ru: В К…
      Пресс-секретарь президента РФ Дмитрий Песков заявил, что переговоры о мирном урегулировании с участием США, России и Украины могут возобновиться в октябре.
  - (2026-09-13) Венеция-2026. Итоги. «Золотой лев» — у фильма о травле датчанок, спавших с немцами во время оккупации. Приз за режиссуру — у «Дау». Актерская награда — у сыгравшего лучшую роль в карьере Джона ] (ru:…
      Завершился 83-й Венецианский кинофестиваль. Главный приз, «Золотой лев», достался фильму «Женщина неизвестна», действие которого происходит в Дании после Второй мировой войны. Вторую по значимости награду, Гран-При, полу…
  - (2026-09-13) Теннисистка из Казахстана Елена Рыбакина стала победительницей US Open. В финале она обыграла Арину Соболенко из Беларуси | LEDE: Елена Рыбакина, выступающая за Казахстан, стала чемпионкой т] (ru: Тен…
      Елена Рыбакина, выступающая за Казахстан, стала чемпионкой теннисного турнира US Open в женском одиночном разряде. В финале Рыбакина победила Арину Соболенко из Беларуси со счетом 6:4, 5:7, 6:2.
  - (2026-09-13) Revolut передал мошенникам данные клиентов. В банке приняли поддельный запрос от госорганов за подлинный | LEDE: Британский необанк Revolut передал мошенникам информацию, содержащую персонал] (ru: Rev…
      Британский необанк Revolut передал мошенникам информацию, содержащую персональные данные клиентов, приняв поддельный запрос от госорганов за подлинный, сообщает Reuters.

### Ukraine Theater (total-war monitoring) — 364 new of 530 total
  - (2026-09-13) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-13) [Liveuamap] Israeli Chief of Staff: Any attack on northern towns or Israeli military forces will be met with a swift and strong response, and the Blue Line in Lebanon will remain under our complete co…
      Israeli Chief of Staff: Any attack on northern towns or Israeli military forces will be met with a swift and st
  - (2026-09-13) [Liveuamap] Houthis forces control the center of the Al-Dhubab Directorate after taking control. - yemen.liveuamap.com
      Houthis forces control the center of the Al-Dhubab Directorate after taking control. y
  - (2026-09-13) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2026-09-12) [Liveuamap] China Interactive News Map - china.liveuamap.com - Liveuamap
      China Interactive News Map - china.liveuamap.com Liveuamap
  - (2026-09-12) [Liveuamap] Explosions were reported in Sloviansk na Kubani - Liveuamap
      Explosions were reported in Sloviansk na Kubani Liveuamap

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 183 new of 256 total
  - (2026-09-11) Caixin Global – Latest China News & Headlines - Caixin Global
      Caixin Global – Latest China News & Headlines Caixin Global
  - (2026-09-12) 火线评论｜“催捐”为自导自演，流量生意何以屡次重创舆论场 - opinion.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5sZ3FDbHpPSFZ2VGtjSkdDVjY2MU5NNnkzVVBaV0tITkZIWW5vNTFBUHdqT2syYWUyQ1NZVGd3Y] (zh:…
      火线评论｜“催捐”为自导自演，流量生意何以屡次重创舆论场 opinion.caixin.com
  - (2026-09-12) 视线｜9·11事件尘封档案公开 25年来超9000人死于相关疾病 - photos.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1XT0hvQkdRMF9OUjA5M0UySkltSE9tVnlZdmpVRnhibWY4V1F6TERESDZuSExBWllxV3BRME] (zh:…
      视线｜9·11事件尘封档案公开 25年来超9000人死于相关疾病 photos.caixin.com
  - (2026-09-13) 人事观察｜江苏省委组织部长到位 女高官胡立杰履历跨三省 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFA4VGZnQUFfaHVJN1ZKUnNpWllSbF9xLURJRS1mNERodlprY1JkVng2TG85UGN0YXRZbno5TFdzQjN6] (zh:…
      人事观察｜江苏省委组织部长到位 女高官胡立杰履历跨三省 china.caixin.com
  - (2026-09-13) 财新闻｜主持人敬一丹去世 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9IRGJsT2NvXzAyUEpKZjZsV2M1SkZZWkZZV2VoVDZ6czhtdnlzdlpWc2ktenREYS1xa1p5QjVtTTd2a1Y1UTBPTzVWVTdx] (zh:…
      财新闻｜主持人敬一丹去世 mini.caixin.com
  - (2026-09-13) 王竞：该哀嚎还是该欢呼｜热点 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9LYWYtWDBXZG0wN1NoZUx3TkJISjl4aHFRZENpcWRISEhZaGp1Wjcxa0lFd1ZjUTJXb0oyb0l5elJSRDBvTXJpTzNZaG] (zh:…
      王竞：该哀嚎还是该欢呼｜热点 mini.caixin.com

### Local News: St. Louis + Atlanta — 118 new of 219 total
  - (2026-09-12) [St. Louis] Sobremesa in St. Charles closing September 13
      Sobremesa (1650 Beale, #130), the Mexican restaurant that replaced Session Taco Joint at the Streets of St. Charles just three months ago, will close after dinner service this Sunday, September 13. In a social media anno…
  - (2026-09-12) [St. Louis] Teachers union in Cahokia school district authorizes strike if deal isn’t reached
  - (2026-09-13) [St. Louis] 80-year-old man with dementia missing out of St. Peters
      Samuel Gilliland was last seen driving his 2002 black Monte Carlo near Timberidge Drive. It is believed he may still be in the area.
  - (2026-09-13) [St. Louis] Federal judge rules Trump administration's DHS plan for 50% FEMA staffing cuts was unlawful
      A federal judge ruled that a plan by the Trump administration to slash staffing at the federal agency tasked with responding to disasters by 50% was unlawful.
  - (2026-09-13) [St. Louis] An Iranian commercial ship is struck near Strait of Hormuz with 1 dead, Iranian media say
      State-run media in Iran say an Iranian commercial vessel was struck off Qeshm Island in the Strait of Hormuz, with one person killed and four injured.
  - (2026-09-13) [St. Louis] Yadier Molina, Albert Pujols enjoy special day together at their induction into Cardinals Hall of Fame
      A journey they shared since playing their first game together on June 3, 2004, when the Cardinals beat the Pirates 4-2 in Pittsburgh.

### U.S. Weather + Severe / Climate Outlooks — 116 new of 119 total
  - (2026-09-13) [Severe] Flash Flood Warning: Flash Flood Warning issued September 13 at 8:29AM EDT until September 13 at 11:30AM EDT by NWS Upton NY
      FFWOKX The National Weather Service in Upton has issued a * Flash Flood Warning for... Central Fairfield County in southern Connecticut... Middlesex County in southern Connecticut... Southern New Haven County in southern…
  - (2026-09-13) [Moderate] Heat Advisory: Heat Advisory issued September 13 at 7:28AM CDT until September 13 at 7:00PM CDT by NWS Memphis TN
      * WHAT...Heat index values up to 109 degrees expected. * WHERE...Portions of East Arkansas, North Mississippi, Southeast Missouri, and West Tennessee. * WHEN...From 11 AM this morning to 7 PM CDT this evening. * IMPACTS.…
  - (2026-09-13) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-13) [Severe] Flash Flood Warning: Flash Flood Warning issued September 13 at 8:21AM EDT until September 13 at 11:15AM EDT by NWS Upton NY
      FFWOKX The National Weather Service in Upton has issued a * Flash Flood Warning for... Northeastern Bergen County in northeastern New Jersey... Rockland County in southeastern New York... * Until 1115 AM EDT. * At 821 AM…
  - (2026-09-13) [Moderate] Special Weather Statement: Special Weather Statement issued September 13 at 7:20AM CDT by NWS Tulsa OK
      At 719 AM CDT, Doppler radar indicated a strong thunderstorm 3 miles east of Ramona, moving east at 35 mph. HAZARD...Wind gusts up to 50 mph and penny size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock…
  - (2026-09-13) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 13 at 4:16AM AKDT until September 13 at 10:00AM AKDT by NWS Juneau AK
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...City and Borough of Yakutat. * WHEN...Until 10 AM AKDT this morning. * IMPACTS...Low visibility could make travel conditions hazardous. * ADDITIONAL DE…

### State-Level News — 89 new of 459 total
  - (2026-09-12) [California] With mail-in rules uncertain, here’s how Californians can prepare to vote in November
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/110525_Election-Counting-Fresno_LV_CM_18.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-09-13) [Connecticut] How this CT ceramic artist applies AI to an ancient art form
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/AI-CERAMICS-01-sg-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriorit…
  - (2026-09-13) [Connecticut] The museum that owns its own railroad
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/09/Loco-2798-RRMNE-dot-org-1024x682.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loadin…
  - (2026-09-12) [Hawaii] Office of the Governor – News Release – Kauaʻi State Offices, Most Public Schools, Kauaʻi Community College and Courts to Reopen Monday
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA KAUAʻI STATE OFFICES, MOST PUBLIC SCHOOLS, KAUAʻI COMMUNITY COLLEGE AND COURTS TO REOPEN MONDAY […]
  - (2026-09-13) [Hawaii] Will Caron: Never Forget
  - (2026-09-13) [Hawaii] Lee Cataluna: Sometimes The Best Campaign Ad Is No Campaign Ad

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Océanie . Vanuatu : le naufrage dun ferry fait au moins un mort et 30 disparus , un avion français déployé
      ledauphine.com · French · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Własne uprawy , własne przetwórstwo . Rodzina Kuchtów robi wszystko od pola do butelki
      farmer.pl · Polish · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Трамп може опинитися в епіцентрі нових гучних розслідувань з боку демократів
      rbc.ua · Ukrainian · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Comparing Mammoth Energy Services ( NASDAQ : TUSK ) & united states Compression Partners ( NYSE : USAC )
      themarketsdaily.com · English · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Chelmsford charity Sanctus now helps up to 100 people daily | Maldon and Burnham Standard
      maldonandburnhamstandard.co.uk · English · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Ce datorie karmică ai în această viață , în funcție de ultima cifră a zilei tale de naștere
      ziarulprofit.ro · Romanian · tone NA

### Ukrainian Internal News (national + local Kyiv) — 62 new of 137 total
  - (2026-09-13) У Краматорську внаслідок російських атак загинули 2 людини, ще 10 поранені | LEDE: Унаслідок двох російських ударів по Краматорську загинули двоє цивільних, десять людей отримали поранення. Ост] (uk:…
      Унаслідок двох російських ударів по Краматорську загинули двоє цивільних, десять людей отримали поранення. Остаточні наслідки уточнюються.
  - (2026-09-13) Польща назвала Росію "ворогом вільного світу" після останньої атаки по Україні | LEDE: Глава МВС Польщі Марчин Кервінський підтвердив напад на поїзд поблизу кордону з Україною. Польська влада у] (uk:…
      Глава МВС Польщі Марчин Кервінський підтвердив напад на поїзд поблизу кордону з Україною. Польська влада уважно стежить за ситуацією.
  - (2026-09-13) Генштаб: Сили оборони уразили місце запуску дронів та ретранслятори на окупованих територіях | LEDE: У Донецьку знищено об'єкти для дронів, а на Херсонщині та в Криму – ретранслятори управління] (uk:…
      У Донецьку знищено об'єкти для дронів, а на Херсонщині та в Криму – ретранслятори управління БпЛА. Деталі операції від Генштабу.
  - (2026-09-13) Глава МЗС Естонії заявив, що атака РФ ускладнила перетин кордону його команді | LEDE: ] (uk: Глава МЗС Естонії заявив, що атака РФ ускладнила перетин кордону його команді)
  - (2026-09-13) Росіяни атакували залізничну інфраструктуру на Вінниччині | LEDE: Внаслідок удару по залізничній інфраструктурі у Вінницькій області виникла пожежа, яку ліквідували. Жертв і постраждалих немає.] (uk:…
      Внаслідок удару по залізничній інфраструктурі у Вінницькій області виникла пожежа, яку ліквідували. Жертв і постраждалих немає.
  - (2026-09-13) Прокопенко очолив новостворене угруповання військ "Азов" | LEDE: Бригадний генерал Прокопенко 13 вересня став командувачем угруповання військ "Азов" у складі 1-го корпусу Нацгвардії. Деталі про] (uk:…
      Бригадний генерал Прокопенко 13 вересня став командувачем угруповання військ "Азов" у складі 1-го корпусу Нацгвардії. Деталі про об'єднання підрозділів.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 25 new of 26 total
  - (2026-09-13) CFC4001 (Canada)
      icao24: c2b3f5 · position: (56.7912, 14.2099) · alt: 10668m · 894km/h
  - (2026-09-13) JAF3325 (Belgium)
      icao24: 44d1ba · position: (50.9036, 4.4943) · on ground · 26km/h
  - (2026-09-13) JAF6EJ (Belgium)
      icao24: 44d1a6 · position: (46.1414, 0.512) · alt: 11887m · 872km/h
  - (2026-09-13) JAF29J (Belgium)
      icao24: 44d1a5 · position: (50.885, 5.1846) · alt: 2438m · 462km/h
  - (2026-09-13) JAF5KH (Belgium)
      icao24: 44d1b3 · position: (50.8942, 4.5025) · alt: -30m · 173km/h
  - (2026-09-13) JAF2LG (Belgium)
      icao24: 44d1b4 · position: (48.3385, 2.3549) · alt: 10668m · 835km/h

### Paper Trading Scorecard — 19 new of 123 total
  - (2026-09-13) [Kalshi] Which Millennium Prize Problem will be solved next?
      Before 2045
  - (2026-09-13) [Kalshi] When will all Millennium Prize Problems be solved?
      Before 2040
  - (2026-09-13) [Manifold] Will Tesla announce on October 1, 2026 that the new Roadster can accelerate from 0 to 60 mph in under 1 second?
  - (2026-09-13) [Manifold] Tadej Pogacar win Hell of the North in 2027 (11th April)
  - (2026-09-13) [Manifold] All Millennium Prize Problems solved before EOY?
  - (2026-09-13) [Manifold] Will there be any public agreement on frontier AI between China and the US or American AI companies before 2028?

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-13) Will Brighton & Hove Albion FC win on 2026-09-13?
      yes price: 52% · 24h volume: $2,297,065 · resolves 2026-09-13
  - (2026-09-13) Will RC Celta de Vigo win on 2026-09-13?
      yes price: 56% · 24h volume: $2,098,560 · resolves 2026-09-13
  - (2026-09-13) LoL: Bilibili Gaming vs Anyone's Legend (BO5) - LPL Playoffs
      yes price: 1% · 24h volume: $2,020,705 · resolves 2026-09-13
  - (2026-09-13) LoL: Bilibili Gaming vs Anyone's Legend - Game 3 Winner
      yes price: 100% · 24h volume: $1,614,716 · resolves 2026-09-13
  - (2026-09-13) Counter-Strike: G2 vs Legacy (BO5) - FISSURE PLAYGROUND Playoffs
      yes price: 0% · 24h volume: $1,603,525 · resolves 2026-09-13
  - (2026-09-13) LoL: Bilibili Gaming vs Anyone's Legend - Game 2 Winner
      yes price: 0% · 24h volume: $1,420,432 · resolves 2026-09-13

### IT, InfoSys & cybersecurity news (last 7 days) — 13 new of 57 total
  - (2026-09-13) [The Hacker News] Attackers Use Passkey Phishing to Hijack Microsoft Cloud Accounts and Exfiltrate Data
      Microsoft has disclosed details of two campaigns in which threat actors are abusing third-party email delivery infrastructure to blast financial fraud scam messages and using passkey-themed social engineering to breach c…
  - (2026-09-13) [The Register] Security through obscurity is dead, and AI delivered the fatal blow
      RIP, you won't be mourned
  - (2026-09-13) [The Register] How to make Xfce look like almost any desktop you want
      Panel Profiles handles the heavy lifting, once you've installed the plugins it expects
  - (2026-09-13) [Ars Technica] I fixed a tractor using John Deere’s self-repair service. Farmers aren’t sold on it.
      The manufacturer has a service that lets owners repair their own equipment.
  - (2026-09-12) [BleepingComputer] Dutch NCSC: Critical Check Point VPN flaws exploitation is imminent
      The Dutch Nationaal Cyber Security Centrum (NCSC) is warning of imminent exploitation of two critical flaws in Check Point VPN tracked as CVE-2026-85102 and CVE-2026-85103. [...]
  - (2026-09-12) [The Hacker News] CISA Adds 5 Actively Exploited Artifactory, ScreenConnect, and RouterOS Flaws to KEV
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) has added five security flaws impacting JFrog Artifactory, ConnectWise ScreenConnect, and MikroTik RouterOS to its Known Exploited Vulnerabilities (KEV) ca…

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 110 total
  - (2026-09-09) [OFAC] 74 - Office of Foreign Assets Control (.gov)
      74 Office of Foreign Assets Control (.gov)
  - (2026-09-09) [OFAC] 76 - Office of Foreign Assets Control (.gov)
      76 Office of Foreign Assets Control (.gov)
  - (2026-09-13) [USASpending] $41,519,790,022 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-09-13) [USASpending] $22,652,874,442 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-09-13) [USASpending] $2,594,633,228 → SAVANNAH RIVER MISSION COMPLETION, LLC: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMP
      Agency: Department of Energy. Description: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMPLETION CONTRACT - TASK ORDER 6 (LIQUID WASTE OPERATIONS).
  - (2026-09-13) [USASpending] $2,193,106,300 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-09-08) U.S. Court of Appeals, 10th Cir.: Spiehs v. Morgan
  - (2026-09-08) U.S. Court of Appeals, 10th Cir.: Spiehs v. Morgan
  - (2026-09-08) U.S. Court of Appeals, 10th Cir.: United States v. Ostertag
  - (2026-09-08) U.S. Court of Appeals, 3rd Cir.: National Shooting Sports Foundation v. Attorney General New Jersey
  - (2026-09-08) U.S. Court of Appeals, 3rd Cir.: Natural Resources Defense Council Inc v. New Jersey Department of Environmental Protection
  - (2026-09-08) U.S. Court of Appeals, D.C. Cir.: Gina Latture v. Priority Life Care, LLC

### USGS earthquakes (M4.5+, past day) — 7 new of 7 total
  - (2026-09-13) M 5.2 - 43 km ESE of Port-Olry, Vanuatu
      M5.2 · 43 km ESE of Port-Olry, Vanuatu · depth 135.084 km
  - (2026-09-12) M 5.1 - 101 km S of Yudomari, Japan
      M5.1 · 101 km S of Yudomari, Japan · depth 45.513 km
  - (2026-09-13) M 5.0 - southeast of the Loyalty Islands
      M5.0 · southeast of the Loyalty Islands · depth 98.813 km
  - (2026-09-13) M 4.9 - Bonin Islands, Japan region
      M4.9 · Bonin Islands, Japan region · depth 10 km
  - (2026-09-12) M 4.8 - 17 km WSW of Lixoúri, Greece
      M4.8 · 17 km WSW of Lixoúri, Greece · depth 33.956 km
  - (2026-09-13) M 4.7 - 25 km N of Mutsu, Japan
      M4.7 · 25 km N of Mutsu, Japan · depth 120.372 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-13) [South Korea] SK chairman says Ulsan AI data center expansion nearing 900 megawatts
      koreatimes.co.kr · English
  - (2026-09-13) [South Korea] Controversial gender minister nominee withdraws candidacy
      koreatimes.co.kr · English
  - (2026-09-13) [South Korea] Controversial gender minister nominee withdraws candidacy
      koreatimes.co.kr · English
  - (2026-09-13) [South Korea] Life at the American gold mines in northern Korea [ 3 ]: When tigers reigned
      koreatimes.co.kr · English
  - (2026-09-13) [South Korea] HD Hyundai , Hanwha Ocean to showcase next - gen gas tech in Bangkok
      koreatimes.co.kr · English
  - (2026-09-13) [South Korea] Korea nuclear - powered submarines could take on broader Indo - Pacific role
      koreatimes.co.kr · English

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-13) [Marginal Revolution] Diversity Is Our Strength?
      Diversity is our strength is a common motto. Indeed it is one of GMU’s core values but what is the scientific evidence for this thesis? A new scoping review: Recent years have witnessed many strong claims that ‘diversity…
  - (2026-09-13) [Marginal Revolution] A simple model of AI-aided economic growth
      The Solow model has its uses, but it fails when it comes to major changes stemming from AI. Consider instead an economy with (at least) two factors of production: 1. Intelligence. Yes, formal smarts. Playing chess, provi…
  - (2026-09-12) [Marginal Revolution] The mathematicians rebel against AI
      Here is the statement, signed by Terry Tao among many other math notables, most of you probably have read it by now. I do not accept the most cynical interpretations of this proclamation. Some of you for instance may rec…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-13) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=19, 14d-median=18; carrying terms: proposed, national, safety, final, special, certain, program, commission, unless, existing, changes, guard
- state_bills: today=97, 7d-median=97, 14d-median=84; carrying terms: electronic, child, procedures, payment, making, include, except, programs, agreements, action, allow, agencies
- state_news: today=459, 7d-median=549, 14d-median=586; carrying terms: vtdigger, continues, kentucky, clean, target, making, election, published, opinion, found, finds, again
- local_news: today=219, 7d-median=226, 14d-median=226; carrying terms: target, election, found, atlantamagazine, magazine, following, north, across, charged, killed, games, record
- foreign_news: today=928, 7d-median=995, 14d-median=1006; carrying terms: criticism, planned, temple, continues, clash, cargo, coach, falklands, greater, match, qatar, target
- chinese_internal: today=256, 7d-median=284, 14d-median=283; carrying terms: target, china, cbmibefvx, cbmia, title, cbmickfvx, cbmizkfvx, cbmidefvx, cbmib, lxtfa, politics, cbmiakfvx
- russian_internal: today=914, 7d-median=1059, 14d-median=1050; carrying terms: patriot, bloomberg, reuters, raquo, httperror, title, politico, media, europe, telegram, found, novaya
- ukrainian_internal: today=137, 7d-median=135, 14d-median=132; carrying terms: least, offensive, putin, major, found, odesa, targets, strikes, error, following, reportedly, kyivindependent
- ukraine_theater: today=530, 7d-median=486, 14d-median=550; carrying terms: jzzkxmu, oumhmdghidgdva, zzdmthlrmvjlwvl, ncvmwrexzrkpvr, aelnktkjpuutpwmnfr, deepstatemap, target, trophylab, jjvgnycxjibzdf, ugvhdvpumzz, yvvqrxnnnktzdjj, wbepivxpqy
- paper_bets: today=123, 7d-median=128, 14d-median=131; carrying terms: leader, goals, florida, earthquake, manifold, human, predictit, district, jackson, starts, johnny, leaders
- weather: today=119, 7d-median=105, 14d-median=112; carrying terms: continues, highs, ruskin, northwest, portions, areas, conditions, messages, locally, include, expected, service
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: sheet, openings, dexjpus, recession, payems, total, spread, nonfarm, consumption, commodities, personal, labor
- markets: today=6, 7d-median=21, 14d-median=21; carrying terms: large, russell, close, range, nasdaq, china, equities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=110, 7d-median=107, 14d-median=106; carrying terms: respect, extra, transnistrian, google, target, congo, specific, aeronautics, areas, russia, oblasts, serious
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, httperror, https, congresstrading, unauthorized, client, quiverquant, error, quantitative
- billionaires: today=0, 7d-median=0, 14d-median=15
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, supreme, appeals, court, state, connecticut, national, center, williams, university, perez, florida
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, holdings, therapeutics, group, technology, health, andrew, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, graham, talarico, committee, cortez, david, robert, angels, house, disbursements, booker, ossoff
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, south, korea
- gdelt_gkg: today=75, 7d-median=25, 14d-median=25; carrying terms: english, israel, killed, hezbollah, turkish, keywords, israeli, press, sanctions
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, germany, kingdom, ground, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: geographically, consecutive, expanded, continues, continued, hygiene, avian, distributed, response, sylvatic, pregnant, related
- cisa_kev: today=24, 7d-median=21, 14d-median=21; carrying terms: papercut, command, improper, remediation, authentication, server, microsoft, bounds, citrix, request, function, unsafe
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=7, 7d-median=9, 14d-median=11; carrying terms: depth, islands, region, vanuatu, japan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: change, price, shakhtar, donetsk, resolves, volume, league, decrease, interest, rates, september, champions
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, conversable, economist, marginal, class, https, recent, conversableeconomist, evidence, economy, government, economists
- tech_news: today=57, 7d-median=57, 14d-median=56; carrying terms: vulnerabilities, target, software, newsletter, microsoft, service, published, become, https, people, record, artificial
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: julie, betty, vince, victoria, madeleine, wittman, norcross, coney, dingell, salud, rochester, neguse
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, module, markets, evidence, market, consensus, placement, converges, paper, unavailable, decision, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-08] ECB press: Frank Elderson: Fireside chat
- [2026-09-09] ECB press: Christine Lagarde: The choice facing Europeans
- [2026-09-10] ECB press: Monetary policy decisions
- [2026-09-10] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-11] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*