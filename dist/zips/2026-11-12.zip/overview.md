# WORLDSCOPE morning brief — 2026-11-12

## Headline
2759 new items across 21 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (684) · Russian Internal News (state + in-exile) (537) · World leaders & government officials (324) · State-Level News (243) · Chinese Internal News (221) · Local News: St. Louis + Atlanta (201) · U.S. Weather + Severe / Climate Outlooks (107) · Ukraine Theater (total-war monitoring) (97) · State Legislative Action (60) · GDELT GKG — themes / entities / watch areas (50) · Ukrainian Internal News (national + local Kyiv) (49) · GDACS — global disaster alerts (48)

## What changed today
### International News + Multilateral Institutions — 684 new of 990 total
  - (2026-11-11) [Global] Two skulls likely belonging to enslaved people returned to Brazil after Harvard used them in eugenics studies
  - (2026-11-11) [Global] Ex-member of radical Marxist group scales balcony, escapes house arrest in Argentina
  - (2026-11-11) [Global] Argentinian lawyer mocks UK’s sovereignty claim in Falklands oil case
  - (2026-11-12) [Global] Thursday briefing: What we do (and don’t) know about Alice Huang and the Nvidia affair
  - (2026-11-12) [Global] Fewer hours and higher wages – or more burnout and surveillance: employers told to prepare for AI
  - (2026-11-12) [Global] Teenager in critical condition after likely ‘train surfing’ on Sydney Harbour Bridge, police say

### Russian Internal News (state + in-exile) — 537 new of 1029 total
  - (2026-11-12) Блогер Лерчек (Валерия Чекалина) попросила Путина о помиловании | LEDE: Валерия Чекалина (блогер Лерчек), осужденная на условный срок по обвинению в незаконном выводе средств за границу, об] (ru: Блог…
      Валерия Чекалина (блогер Лерчек), осужденная на условный срок по обвинению в незаконном выводе средств за границу, обратилась к президенту РФ Владимиру Путину с просьбой о помиловании. Об этом сообщил российским госагент…
  - (2026-11-12) В Петербурге при взрыве автомобиля убит полковник | LEDE: В Петербурге взорвался автомобиль, за рулем которого находился полковник. Взрыв произошел в Шушарах на Колпинском шоссе. ] (ru: В Петербурге п…
      В Петербурге взорвался автомобиль, за рулем которого находился полковник. Взрыв произошел в Шушарах на Колпинском шоссе.
  - (2026-11-12) Уиткофф и Кушнер приехали в Москву на переговоры с Путиным | LEDE: В столицу России утром 12 ноября прилетели спецпредставители президента США Дональда Трампа Джаред Кушнер и Стив Уиткофф.<p] (ru: Уит…
      В столицу России утром 12 ноября прилетели спецпредставители президента США Дональда Трампа Джаред Кушнер и Стив Уиткофф.
  - (2026-11-12) Почему ни Россия, ни Украина не могут переломить ход войны? И за счет чего им все же удаются успешные наступления — вроде операции ВСУ «Вивальди»? Изучаем тактику обеих армий | LEDE: Украинс] (ru: Поч…
      Украинские военные, участвовавшие в операции «Вивальди», утверждают, что успех наступления у реки Северский Донец к северу от Славянска стал возможен благодаря новой тактике. Деталей они не раскрывают — чтобы вновь испол…
  - (2026-11-12) «Если ты все время в движении — это можно назвать побегом». Многие россияне в эмиграции переезжали уже не один раз. Но есть и те, кто в принципе не останавливается — и проводит всю жизнь в доро] (ru:…
      Большинство россиян в эмиграции стараются как можно скорее вернуться к привычному образу жизни: снимают квартиру или дом, работают или стремятся найти стабильную работу — и проводят основную часть времени в одной стране.…
  - (2026-11-11) «РБК-Украина»: во второй день переговоров РФ отказалась обсуждать прекращение огня и территории. Вместо этого говорили о новой архитектуре безопасности Европы | LEDE: Российская делегация во] (ru: «РБ…
      Российская делегация во второй день переговоров в Абу-Даби отказалась обсуждать с Украиной территориальные вопросы, прекращения огня, энергетику и безопасность в Черном море. Об этом сообщили источники «РБК-Украина».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 243 new of 760 total
  - (2026-11-11) [California] Malas noticias para la reparación de escuelas en California: casi la mitad de las medidas de bonos están en camino de fracasar
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2023/11/111523_Keyes-School_LV_05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-11-11) [California] Tras el derroche de dinero de Silicon Valley, demócratas más moderados se dirigen al Capitolio
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/101526-Chris-Larsen-KQED-CM-01.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-11-11) [California] Nuevo gobernador de California inicia la “era Becerra” congraciándose con los demócratas del Capitolio
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110526-Becerra-Presser-MG-CM-03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-11-11) [California] Demanda presentada por jueza despedida alega que California estaba aprobando ilegalmente aumentos en tarifas de seguros
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/010625-Limon-Senate-Pro-Tem-MG-CM-24.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-11-11) [California] Governor Newsom is delivering for veterans — with more opportunities, education, and support
      Source
  - (2026-11-11) [California] On Veterans Day, California honors and serves veterans, investing in services and expanding opportunities
      Source

### Chinese Internal News — 221 new of 316 total
  - (2026-11-11) Spain Pushes for TikTok Suspension Over Child Abuse Content - Caixin Global
      Spain Pushes for TikTok Suspension Over Child Abuse Content Caixin Global
  - (2026-11-11) China’s Nonfinancial State Firms’ Assets More Than Double Since 2017 - Caixin Global
      China’s Nonfinancial State Firms’ Assets More Than Double Since 2017 Caixin Global
  - (2026-11-11) Offshore Trust Taxes Help Fuel China’s 90% Personal Income Tax Surge - Caixin Global
      Offshore Trust Taxes Help Fuel China’s 90% Personal Income Tax Surge Caixin Global
  - (2026-11-11) BYD Apologizes for Wheel Rim Mix-Up on Some Datang SUVs - Caixin Global
      BYD Apologizes for Wheel Rim Mix-Up on Some Datang SUVs Caixin Global
  - (2026-11-12) Analysis: China’s Insurance Law Revision Aims to Bring Shadowy Owners Into the Light - Caixin Global
      Analysis: China’s Insurance Law Revision Aims to Bring Shadowy Owners Into the Light Caixin Global
  - (2026-11-12) 纪念孙中山先生诞辰160周年大会在京举行 习近平出席大会并发表重要讲话 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5idWVheXpYZVBUU0MtTmlXRFVQNUVfbWJQdlNaYmw4MGV1bWQ3OFpVSHR6V2JaMThQdVRyTmludEM2] (zh:…
      纪念孙中山先生诞辰160周年大会在京举行 习近平出席大会并发表重要讲话 人民网-图片频道

### Local News: St. Louis + Atlanta — 201 new of 265 total
  - (2026-11-12) [St. Louis] Where in Clayton 11/12/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-11-12) [St. Louis] Where in the Lou – 11/12/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-11-11) [St. Louis] This new series helps St. Louis families find sensory-friendly places to play
      Is there somewhere quiet to take a break? How crowded will it be? Are there loud hand dryers in the bathrooms? What happens if a child becomes overwhelmed? A trip to the Saint Louis Zoo, a morning at The Magic House, or…
  - (2026-11-11) [St. Louis] St. Louis nonprofit seeks donors to provide adapted holiday toys for 250 kids
      Every child deserves the excitement of unwrapping a new toy during the holidays. But for children with disabilities, finding one they can actually play with isn’t always easy, and the options can come with a hefty price…
  - (2026-11-11) [St. Louis] A bold idea for eyesore parking garage spiral downtown: The Louggenheim
      The eight-level Famous Barr parking garage is—for better or worse—among the most recognizable structures in downtown St. Louis. A “fusilli-like spiral of concrete” was how one local writer once described it. It resembles…
  - (2026-11-11) [St. Louis] The Sports Bra opens in Maplewood November 13
      On November 13, the first sports bar dedicated exclusively to women’s sports will open its first franchise location in St. Louis. As reported by SLM earlier this year, St. Louis is one of several U.S. cities chosen to op…

### U.S. Weather + Severe / Climate Outlooks — 107 new of 114 total
  - (2026-11-12) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-11) [Severe] Winter Storm Warning: Winter Storm Warning issued November 11 at 11:43PM PST until November 14 at 4:00PM PST by NWS Las Vegas NV
      * WHAT...Heavy snow possible above 7000 feet. Total snow accumulations of 5 to 10 inches expected...with up to 1 foot near the Sierra Crest. * WHERE...Eastern Sierra Slopes. * WHEN...From 1 PM Friday to 4 PM PST Saturday…
  - (2026-11-12) [Moderate] Gale Watch: Gale Watch issued November 12 at 2:05AM EST until November 13 at 7:00PM EST by NWS Caribou ME
      * WHAT...Northeast winds 15 to 25 kt with gusts up to 35 kt and seas 6 to 9 ft possible. * WHERE...Coastal Waters from Eastport, ME to Schoodic Point, ME out 25 NM, Coastal Waters from Schoodic Point, ME to Stonington, M…
  - (2026-11-12) [Moderate] Gale Watch: Gale Watch issued November 12 at 1:58AM EST until November 13 at 3:00PM EST by NWS Gray ME
      * WHAT...Northeast winds 20 to 30 kt with gusts up to 35 kt and seas 6 to 9 ft possible. * WHERE...Portions of Atlantic coastal waters. * WHEN...From this evening through Friday afternoon. * IMPACTS...Strong winds can ca…
  - (2026-11-11) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued November 11 at 10:48PM PST until November 13 at 6:00PM PST by NWS San Francisco CA
      * WHAT...For the first Coastal Flood Advisory, Up to 1.5 ft of inundation above ground level is possible in low-lying areas near shorelines and tidal waterways. For the Beach Hazards Statement, An increased risk for snea…
  - (2026-11-11) [Moderate] High Surf Warning: High Surf Warning issued November 11 at 10:48PM PST until November 15 at 4:00AM PST by NWS San Francisco CA
      * WHAT...For the Beach Hazards Statement, An increased risk for sneaker waves and strong rip currents with breaking waves of 15 to 20 ft expected. For the High Surf Warning, Dangerously large breaking waves of 25 to 35 f…

### Ukraine Theater (total-war monitoring) — 97 new of 261 total
  - (2026-11-12) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-11) [Liveuamap] Explosions were reported near the Omsk oil refinery – Omsk Oblast, Russia - Liveuamap
      Explosions were reported near the Omsk oil refinery – Omsk Oblast, Russia Liveuamap
  - (2026-11-10) [Liveuamap] Today since morning and until 19:00 Russia launched 155 drones of different types, 2 guided aviation missiles Kh-59/69 and several S8000 Banderol/Dan-T cruise missiles, - Ukrainian Air For…
      Today since morning and until 19:00 Russia launched 155 drones of different types, 2 guided aviation missiles Kh-59/69 and several S8
  - (2026-11-10) [Liveuamap] At Orikhiv direction clashes yesterday near Stepove, - General Staff of Armed Forces of Ukraine reports - Liveuamap
      At Orikhiv direction clashes yesterday near Stepove, - General Staff of Armed Forces of Ukraine reports <font colo
  - (2026-11-11) [Liveuamap] 1 person killed, 4 wounded as result of Russian strike at the market in Chornomorsk, Odesa region - Liveuamap
      1 person killed, 4 wounded as result of Russian strike at the market in Chornomorsk, Odesa region <font color
  - (2026-11-09) [Liveuamap] Russian Air Force Tu-154M (RA-85042), which arrived in Tel Aviv yesterday, remains parked at Ben Gurion Airport as of Monday morning – Ben-Gurion Airport,Center District - Liveuamap
      Russian Air Force Tu-154M (RA-85042), which arrived in Tel Aviv yesterday, remains parked at Ben

### State Legislative Action — 60 new of 178 total
  - (2026-11-12) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-11-12) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-11-12) [Alaska HB 264] An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; and providing for an effec…
      An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; and providing for an effective date.
  - (2026-11-11) [District of Columbia B 26-0602] Guiding Renewable Interconnection and Distribution (GRID) Amendment Act of 2026
      Guiding Renewable Interconnection and Distribution (GRID) Amendment Act of 2026
  - (2026-11-11) [District of Columbia B 26-0707] Rodent Education and Management Yields ("REMY") Results Amendment Act of 2026
      Rodent Education and Management Yields ("REMY") Results Amendment Act of 2026
  - (2026-11-11) [District of Columbia B 26-0594] Contracting and Procurement Reform Amendment Act of 2026
      Contracting and Procurement Reform Amendment Act of 2026

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] UN Security Council to meet on situation in the Middle East
      news.webindia123.com · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Israel claims Hamas hit in deadly Gaza hospital strike
      queanbeyanage.com.au · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Trump and Netanyahu Clash Over Iran : Heated Debate on War Strategy Reported
      openthemagazine.com · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Israeli strike on a Gaza hospital kills 6 people , health authorities say
      newsday.com · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Bibi Netanyahu legacy - Daily Press
      dailypress.net · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Israeli strike on Gaza hospital kills six , including surgeon
      cyprus-mail.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 49 new of 139 total
  - (2026-11-12) Литва надасть частину обладнання, необхідного українській енергетиці | LEDE: ] (uk: Литва надасть частину обладнання, необхідного українській енергетиці)
  - (2026-11-12) Понад 40 тисяч: Рютте порівняв місячні втрати РФ в Україні з американськими за 14 років війни у В’єтнамі | LEDE: Генсек НАТО Марк Рютте заявив, що Росія щомісяця втрачає в Україні понад 40 тися] (uk:…
      Генсек НАТО Марк Рютте заявив, що Росія щомісяця втрачає в Україні понад 40 тисяч військових загиблими й тяжкопораненими, та порівняв ці втрати з американськими за 14 років війни у В'єтнамі.
  - (2026-11-12) На фронті за добу відбулося 167 боїв, росіяни втратили понад дві тисячі військових | LEDE: Протягом минулої доби на лінії фронту відбулося 167 бойових зіткнень із російськими загарбниками. Втра] (uk:…
      Протягом минулої доби на лінії фронту відбулося 167 бойових зіткнень із російськими загарбниками. Втрати окупаційної армії склали 2150 військових убитими й пораненими.
  - (2026-11-12) Після нічної атаки РФ понад 160 населених пунктів Рівненщини залишаються без світла | LEDE: На Рівненщині станом на 08:30 12 листопада понад 160 населених пунктів залишаються без електропостача] (uk:…
      На Рівненщині станом на 08:30 12 листопада понад 160 населених пунктів залишаються без електропостачання через нічні російські удари.
  - (2026-11-12) Axios: США закликали РФ викласти вимоги та кроки для деескалації в новій безпековій угоді з Європою | LEDE: США запропонували Росії підготувати новий проєкт угоди про безпеку з Європою, у якому] (uk:…
      США запропонували Росії підготувати новий проєкт угоди про безпеку з Європою, у якому Москва має визначити не лише свої вимоги, а й власні кроки для зниження напруженості.
  - (2026-11-12) Дрон влучив у дев’ятиповерхівку в Києві: загинула жінка, ще 5 постраждали | LEDE: Вранці 12 листопада в Солом'янському районі Києва російський безпілотник влучив у житлову дев'ятиповерхівку. За] (uk:…
      Вранці 12 листопада в Солом'янському районі Києва російський безпілотник влучив у житлову дев'ятиповерхівку. Загинула 44-річна жінка, ще п'ятеро людей постраждали.

### GDACS — global disaster alerts — 48 new of 100 total
  - (2026-11-12) [Green] Earthquake in Off East Coast Of Honshu, Japan
      Earthquake · Green alert · Off East Coast Of Honshu, Japan · Magnitude 4.8M, Depth:33.039km
  - (2026-11-12) [Green] Earthquake in South Sandwich Islands Region
      Earthquake · Green alert · South Sandwich Islands Region · Magnitude 5.4M, Depth:121.557km
  - (2026-11-12) [Green] Earthquake in Russia
      Earthquake · Green alert · Russia · Magnitude 4.8M, Depth:74.47km
  - (2026-11-10) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-11-11) [Green] Earthquake in Nepal
      Earthquake · Green alert · Nepal · Magnitude 4.6M, Depth:10km
  - (2026-11-11) [Green] Earthquake in Ascension Island Region
      Earthquake · Green alert · Ascension Island Region · Magnitude 4.9M, Depth:10km

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 63 total
  - (2026-11-12) [The Hacker News] Attacker Used 4,837 Hijacked GitHub Accounts to Run a CI Secret Stealer in 1,806+ Repositories
      Starting Tuesday, an attacker used stolen credentials for 4,837 GitHub accounts to plant a secret stealer in repositories those accounts could write to, according to Aikido Security, a security software company. The stea…
  - (2026-11-12) [The Hacker News] Critical Apache HTTP/2 Flaw Could Let Unauthenticated Attackers Execute Code Remotely
      A critical flaw in Apache HTTP Server's HTTP/2 module, mod_http2, can let a remote attacker run code on the server. Tracked as CVE-2026-119618, it affects versions 2.4.55 through 2.4.70 and is fixed in version 2.4.71, re…
  - (2026-11-12) [The Hacker News] ScreenConnect Attacks Target at Least 288 Endpoints Across 48 Organizations With Rogue Clients
      ConnectWise has taken the precautionary step of disabling five third-party extensions in partner environments following reports of unauthorized access. In an advisory posted on its site, the company said there is no evid…
  - (2026-11-12) [The Register] AWS distills its cloud into a local emulator that runs on your PC
      Hyperscale meets micro-computing by offering APIs to test your apps
  - (2026-11-12) [The Register] Disgraced former CA eMudhra blames buggy script for hopelessly weak certificates
      Couldn’t get the hardware it needed to generate certs, so tried to code a workaround
  - (2026-11-12) [The Register] Russian cloud Yandex says drone attacks on its datacenters caused data loss
      Now enables backup by default and hints a little on-prem infra never hurt anyone

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 19 new of 71 total
  - (2026-11-12) [Polymarket] Will Arizona Cardinals win the 2027 NFL NFC Championship?
      This market will resolve according to the team that wins the 2027 NFC championship game. If at any point it becomes impossible for a listed team to win the 2027 NFL NFC championship per the rules of the NFL (e.g., they a…
  - (2026-11-12) [Manifold] Jensen Huang resignation announced by end of Thursday ET?
  - (2026-11-12) [Manifold] Jensen Huang's affair is a cover for something worse.
  - (2026-11-12) [Manifold] Will 0x7055d60F50D98578d8C18DBCc84872B11862feCc receive more than $250.00 USDC Base by November 16th 11:59pm PST
  - (2026-11-12) [Manifold] Will the next CEO of NVIDIA flaunt a leather jacket?
  - (2026-11-12) [Manifold] Will evidence that Alice Huang is a Chinese spy become publicly available before November 11, 2027?

### Government & military aircraft airborne (OpenSky) — 14 new of 14 total
  - (2026-11-12) SAMPOL3 (Spain)
      icao24: 344349 · position: (41.2993, 2.0929) · on ground · 35km/h
  - (2026-11-12) JAF4GM (Belgium)
      icao24: 44d1a6 · position: (44.2774, 17.1384) · alt: 11277m · 944km/h
  - (2026-11-12) JAF7YC (Belgium)
      icao24: 44d1a7 · position: (46.2085, -5.7944) · alt: 10668m · 813km/h
  - (2026-11-12) JAF78M (Belgium)
      icao24: 44d1a5 · position: (37.2824, -12.5782) · alt: 11277m · 714km/h
  - (2026-11-12) JAF1TE (Belgium)
      icao24: 44d1a1 · position: (35.8434, -3.2425) · alt: 5440m · 585km/h
  - (2026-11-12) FAF4130 (France)
      icao24: 3b756a · position: (43.4275, 4.7653) · alt: 2537m · 472km/h

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-11-12) Jensen Huang announced resignation or removal by November 12, 2026?
      yes price: 60% · 24h volume: $2,659,311 · resolves 2026-11-13
  - (2026-11-12) Jensen Huang announced resignation or removal by November 13, 2026?
      yes price: 66% · 24h volume: $851,040 · resolves 2026-11-14
  - (2026-11-12) Counter-Strike: FUT Esports vs MOUZ (BO3) - BLAST Rivals Group B
      yes price: 34% · 24h volume: $822,218 · resolves 2026-11-12
  - (2026-11-12) Counter-Strike: FUT Esports vs MOUZ - Map 1 Winner
      yes price: 70% · 24h volume: $708,795 · resolves 2026-11-12
  - (2026-11-12) Jensen Huang announced resignation or removal by March 31, 2027?
      yes price: 86% · 24h volume: $582,606 · resolves 2027-04-01
  - (2026-11-12) Jensen Huang announced resignation or removal by November 30, 2026?
      yes price: 76% · 24h volume: $578,570 · resolves 2026-12-01

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 97 total
  - (2026-11-12) [USASpending] $44,093,914,875 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-11-12) [USASpending] $17,730,321,031 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy. Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-11-12) [USASpending] $560,006,589 → BOOZ ALLEN HAMILTON INC: ENGINEERING DEVELOPMENT INTEGRATION AND TECHNOLOGYBASED SOLU
      Agency: General Services Administration. Description: ENGINEERING DEVELOPMENT INTEGRATION AND TECHNOLOGYBASED SOLUTIONS EDITS
  - (2026-11-12) [USASpending] $449,655,716 → CACI, INC. - FEDERAL: EXECUTE TASK ORDER FOR COMMERCIAL BASED TECHNOLOGY ANALYSIS
      Agency: General Services Administration. Description: EXECUTE TASK ORDER FOR COMMERCIAL BASED TECHNOLOGY ANALYSIS (CBTA.
  - (2026-11-12) [USASpending] $398,925,093 → LEIDOS BIOMEDICAL RESEARCH INC: NCI FY25 OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services. Description: NCI FY25 OPERATIONAL TASK ORDER
  - (2026-11-12) [USASpending] $395,964,462 → LEIDOS, INC.: HOMELAND ENTERPRISE INFORMATION TECHNOLOGY SECURE SERVICES A
      Agency: General Services Administration. Description: HOMELAND ENTERPRISE INFORMATION TECHNOLOGY SECURE SERVICES AND SUPPORT (HEITS) TASK ORDER (47QFCA23F0039) AWARD FROM TASK ORDER REQUEST (47QFCA23R0021) IN SUPPORT OF…

### USGS earthquakes (M4.5+, past day) — 10 new of 15 total
  - (2026-11-12) M 5.4 - South Sandwich Islands region
      M5.4 · South Sandwich Islands region · depth 121.557 km
  - (2026-11-11) M 5.1 - 80 km W of Panguna, Papua New Guinea
      M5.1 · 80 km W of Panguna, Papua New Guinea · depth 58.822 km
  - (2026-11-11) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 104.66 km
  - (2026-11-11) M 5.0 - 48 km NW of Ancud, Chile
      M5.0 · 48 km NW of Ancud, Chile · depth 34.893 km
  - (2026-11-11) M 4.9 - 116 km E of Georgetown, Saint Helena
      M4.9 · 116 km E of Georgetown, Saint Helena · depth 10 km
  - (2026-11-12) M 4.8 - 155 km E of Noda, Japan
      M4.8 · 155 km E of Noda, Japan · depth 33.039 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-12) [Marginal Revolution] My excellent Conversation with Terence Tao
      Here is the audio, video, and transcript. Here is part of the episode summary: Tyler opens by asking Terence what it feels like to contemplate Euler’s identity, quantum mechanics, the Riemann hypothesis, and Gödel’s inco…
  - (2026-11-11) [Marginal Revolution] Richard Posner, RIP…
      One of the greats. The post Richard Posner, RIP… appeared first on Marginal REVOLUTION.
  - (2026-11-11) [Marginal Revolution] Experimentally validated digital twins
      There is a new paper by Raj Chetty, Jamie Fogel, Lawrence F. Katz, Kadeem Noray, Sonya Porter, and James Reisinger: Modern program evaluation prioritizes evidence from randomized controlled trials (RCTs) because prior re…
  - (2026-11-11) [Conversable Economist] Cities of Africa: Explosive Growth, Corresponding Challenges
      The number of people living in urban areas in countries of sub-Saharan Africa has more than quintupled in the last 50 years, and is projected to double again in the next 25 years. Thus, a key question for human welfare i…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-12) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=28, 7d-median=26, 14d-median=19; carrying terms: agency, provide, regulatory, certain, changes, final, service, existing, action, commission, safety, services
- state_bills: today=178, 7d-median=97, 14d-median=100; carrying terms: providing, review, insurance, emergency, income, program, health, authority, vehicle, relating, approval, production
- state_news: today=760, 7d-median=675, 14d-median=752; carrying terms: srcset, relief, consider, article, might, wants, patients, republicans, university, power, living, scaled
- local_news: today=265, 7d-median=265, 14d-median=256; carrying terms: trump, country, injured, class, illinois, constitution, stlmag, announced, killed, suspect, state, friday
- foreign_news: today=990, 7d-median=990, 14d-median=1008; carrying terms: restore, tamil, relief, srcset, might, wants, republicans, crisis, supply, today, living, began
- chinese_internal: today=316, 7d-median=321, 14d-median=308; carrying terms: lxtfa, title, cbmixkfvx, china, https, cbmiy, market, target, google, blank, articles, color
- russian_internal: today=1029, 7d-median=951, 14d-median=951; carrying terms: street, apple, server, title, client, journal, istories, gazeta, europe, media, telegram, times
- ukrainian_internal: today=139, 7d-median=139, 14d-median=134; carrying terms: vladimir, power, three, europe, civilian, chief, ceasefire, zelensky, trump, critical, provide, ministers
- ukraine_theater: today=261, 7d-median=269, 14d-median=273; carrying terms: htktvv, cvzqrwiwufdsdljoalbrtnkzt, dobxrwbwrbq, wgvqtdljtf, cbmijafbvv, cuxnd, rqwkvpawktof, cuxotgjkajvzrkvhqxm, eehhetrxnf, piwxp, hospital, cuxqv
- paper_bets: today=71, 7d-median=66, 14d-median=67; carrying terms: colonize, jinping, levels, humans, fuentes, growth, patrick, experience, world, nuclear, rippling, mahomes
- weather: today=114, 7d-median=135, 14d-median=134; carrying terms: below, temperatures, winds, please, tonight, afdphi, gusts, evening, upper, conditions, mount, today
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: pcepilfe, total, inflation, balance, supply, effective, indicator, commodities, headline, implied, spread, growth
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, silver, natural, agriculture, credit, futures, treasury, commodities, russell, crypto, range, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=97, 7d-median=99, 14d-median=99; carrying terms: republic, manufacturing, designations, operating, mufswgh, operations, content, contractor, mission, homeland, activities, solutions
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, unauthorized, httperror, quiver, congresstrading, https, client, quantitative, quiverquant
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, holdings, finance, michael, global, jonathan, scott, natera, nicholas
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, senate, ossoff, david, warner, receipts, raised, cooper, house, alexandria, jonathan
- gdelt_regions: today=0, 7d-median=3, 14d-median=3
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, themes, chinese, spanish, sanctions, trump, turkish, keywords, against, israel, hezbollah, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=14, 7d-median=26, 14d-median=30; carrying terms: position, belgium, france, germany, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: republic, province, reported, measures, confined, respiratory, individual, being, driving, biena, britain, welfare
- cisa_kev: today=17, 7d-median=14, 14d-median=17; carrying terms: vendor, missing, unchecked, product, authentication, return, value, google, vulnerability, remediation, edition, secure
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: australia, fires, maximum, depth, magnitude, japan, green, sudan, cyclone, speed, botswana, impact
- usgs_quakes: today=15, 7d-median=15, 14d-median=15; carrying terms: depth, japan, islands, region, indonesia, south, vanuatu, russia, papua, guinea, sandwich, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, presidential, election, champions, league, championship, shakhtar, democratic, donetsk, december
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, conversable, economist, class, https, marginal, published, world, since, american, economic, conversableeconomist
- tech_news: today=63, 7d-median=61, 14d-median=61; carrying terms: techcrunch, three, today, agency, weekday, critical, information, blogging, review, provides, founder, brought
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: bernie, richmond, charles, delia, chris, fernandez, ronny, agriculture, warner, jamieson, sheehy, pressley
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, identify, evidence, sufficient, today, converges, consensus, decision, paper, placed, claude, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*