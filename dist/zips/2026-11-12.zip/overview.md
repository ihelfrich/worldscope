# WORLDSCOPE morning brief — 2026-11-12

## Headline
3836 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (866) · Russian Internal News (state + in-exile) (772) · State-Level News (549) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (271) · Chinese Internal News (266) · Ukraine Theater (total-war monitoring) (143) · U.S. Weather + Severe / Climate Outlooks (120) · Ukrainian Internal News (national + local Kyiv) (85) · Wikidata leader-roster changes (48h) (56) · GDACS — global disaster alerts (56) · IT, InfoSys & cybersecurity news (last 7 days) (49)

## What changed today
### International News + Multilateral Institutions — 866 new of 1062 total
  - (2026-11-12) [Global] Zimbabwean author Simbarashe Kundizeza cleared of using AI to write prize-winning story
  - (2026-11-11) [Global] Two skulls likely belonging to enslaved people returned to Brazil after Harvard used them in eugenics studies
  - (2026-11-11) [Global] Ex-member of radical Marxist group scales balcony, escapes house arrest in Argentina
  - (2026-11-11) [Global] Argentinian lawyer mocks UK’s sovereignty claim in Falklands oil case
  - (2026-11-12) [Global] China rules out hosting Cop33 climate summit in 2028
  - (2026-11-12) [Global] Thursday briefing: What we do (and don’t) know about Alice Huang and the Nvidia affair

### Russian Internal News (state + in-exile) — 772 new of 1012 total
  - (2026-11-12) Норвегия вслед за Финляндией собирается запретить въезд российским спортсменам — «пока продолжается война в Украине» | LEDE: Министерство юстиции и общественной безопасности Норвегии даст ук] (ru: Нор…
      Министерство юстиции и общественной безопасности Норвегии даст указание Управлению по делам иностранцев и Управлению полиции, чтобы те отказывали во въезде российским и белорусским спортсменам, сообщили в правительстве.
  - (2026-11-12) Reuters: у главы Nvidia Дженсена Хуанга были отношения с еще одной сотрудницей его компании | LEDE: У гендиректора Nvidia Дженсена Хуанга были отношения с еще одной сотрудницей компании, рас] (ru: Reu…
      У гендиректора Nvidia Дженсена Хуанга были отношения с еще одной сотрудницей компании, рассказали два источника Reuters.
  - (2026-11-12) В Петербурге мужчина зарезал бывшую девушку у дверей центра помощи женщинам | LEDE: В Калининском районе Петербурга мужчина напал с ножом на 27-летнюю девушку у входа в центр помощи женщинам] (ru: В П…
      В Калининском районе Петербурга мужчина напал с ножом на 27-летнюю девушку у входа в центр помощи женщинам, пишет «Фонтанка».
  - (2026-11-12) «Агентство»: у Путина, вероятно, родился четвертый внук. Его назвали Адрианом | LEDE: У Катерины Тихоновой, младшей дочери Владимира Путина, родился сын, которого назвали Адриан, выяснило из] (ru: «Аг…
      У Катерины Тихоновой, младшей дочери Владимира Путина, родился сын, которого назвали Адриан, выяснило издание «Агентство», изучившее утечку записей ЗАГСа.
  - (2026-11-12) Путин предложил повторить в Константиновке гуманитарную миссию по схеме Алешек. Почему именно там? И не уловка ли это? | LEDE: Владимир Путин перед встречей со спецпосланниками президента СШ] (ru: Пут…
      Владимир Путин перед встречей со спецпосланниками президента США Стивом Уиткоффом и Джаредом Кушнером предложил организовать гуманитарную операцию в Константиновке Донецкой области — по примеру недавней аналогичной мисси…
  - (2026-11-12) «Первый отдел» опубликовал «секретный реестр Росфинмониторинга». В нем больше трех тысяч человек, включая Бориса Гребенщикова и Леонида Парфенова | LEDE: Правозащитный проект «Первый отдел» ] (ru: «Пе…
      Правозащитный проект «Первый отдел» получил доступ к закрытому реестру Росфинмониторинга. Туда вносят тех, кого российские власти заподозрят в причастности к террористической, экстремистской или диверсионной деятельности…

### State-Level News — 549 new of 1021 total
  - (2026-11-12) [Alabama] Governor Ivey Announces Partnership with Heartland Forward’s Center for Investment Readiness
      MONTGOMERY – Governor Kay Ivey on Thursday announced Alabama is partnering with nonpartisan, nonprofit think-and-do tank Heartland Forward to bring its Center for Investment Readiness (CIR) to communities across the stat…
  - (2026-11-12) [Alabama] First state audit of Alabama prisons finds need for "fundamental change"
  - (2026-11-12) [Alabama] Britt urges Senate to pass retirement investment options for public-sector workers
  - (2026-11-12) [Alabama] Cleaning up the ADOC mess is your responsibility
  - (2026-11-12) [Alabama] Margaret Ann Knott died protesting for civil rights. No one was indicted.
  - (2026-11-12) [Alabama] Bipartisan support grows for Tuskegee Airmen memorial in Washington

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 271 new of 305 total
  - (2026-11-12) [St. Louis] In Sugar Creek Valley, a contemporary house rises up among the trees
      How do you design a home when the house itself is a work of art? Thoughtfully and deliberately. Two years ago, when Tiffany Shell and Doug Eilert moved into their new house in Kirkwood, they had a vision for how they wou…
  - (2026-11-12) [St. Louis] Truman Kennedy and the Grassy Knolls bring the bluegrass in ‘Live! At the Legendary White Water Tavern’
      St. Louis-based Americana artist Truman Kennedy and his band, the Grassy Knolls, joined by Adam Faucett, are bringing their signature bluegrass sound to the Venice Café on November 18 to celebrate the release of their ne…
  - (2026-11-12) [St. Louis] Adam Pearson’s annual quest: Helping St. Louisans survive the winter’s cold
      For years, the City of St. Louis seemed caught off guard by winter. It wasn’t just the lack of urgency around snow plows (although that was certainly striking to anyone moving from a colder climate). It was also that see…
  - (2026-11-12) [St. Louis] Autonomous railcar company Intramotev taps Gabe Angieri for new strategy role
      Gabe Angieri, the outgoing executive director of Arch Grants, has a new job. Starting in January, he’s set to become the new head of growth and strategy for the local autonomous railcar startup, Intramotev. It’s a bit of…
  - (2026-11-12) [St. Louis] Where in Clayton 11/12/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-11-12) [St. Louis] Where in the Lou – 11/12/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…

### Chinese Internal News — 266 new of 344 total
  - (2026-11-12) Baidu’s Robin Li Urges Companies to Reorganize Around AI - Caixin Global
      Baidu’s Robin Li Urges Companies to Reorganize Around AI Caixin Global
  - (2026-11-12) Caixin Summit: TCL Chairman Urges Manufacturers to Embrace AI and Localize Overseas - Caixin Global
      Caixin Summit: TCL Chairman Urges Manufacturers to Embrace AI and Localize Overseas Caixin Global
  - (2026-11-11) Spain Pushes for TikTok Suspension Over Child Abuse Content - Caixin Global
      Spain Pushes for TikTok Suspension Over Child Abuse Content Caixin Global
  - (2026-11-12) Caixin Summit: U.S.-China Stability Is Tactical, Not Strategic, Rudd Says - Caixin Global
      Caixin Summit: U.S.-China Stability Is Tactical, Not Strategic, Rudd Says Caixin Global
  - (2026-11-11) China’s Nonfinancial State Firms’ Assets More Than Double Since 2017 - Caixin Global
      China’s Nonfinancial State Firms’ Assets More Than Double Since 2017 Caixin Global
  - (2026-11-12) Caixin Summit: China’s Growth and Global Prosperity Must Advance Together, Ex-Singapore DPM Says - Caixin Global
      Caixin Summit: China’s Growth and Global Prosperity Must Advance Together, Ex-Singapore DPM Says Caixin Global

### Ukraine Theater (total-war monitoring) — 143 new of 264 total
  - (2026-11-12) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-11) [Liveuamap] Explosions were reported near the Omsk oil refinery – Omsk Oblast, Russia - Liveuamap
      Explosions were reported near the Omsk oil refinery – Omsk Oblast, Russia Liveuamap
  - (2026-11-11) [Liveuamap] Egypt&039;s foreign minister… – Cairo, Egypt - Liveuamap
      Egypt&039;s foreign minister… – Cairo, Egypt Liveuamap
  - (2026-11-11) [Liveuamap] Russia had reportedly lost 2 military helicopters overnight: Ka-52 and Mi-8 – Leningrad Oblast, Russia - Liveuamap
      Russia had reportedly lost 2 military helicopters overnight: Ka-52 and Mi-8 – Leningrad Oblast, Russia <
  - (2026-11-10) [Liveuamap] Explosion was reported in Pavlohrad – Dnipropetrovsk Oblast, Ukraine - Liveuamap
      Explosion was reported in Pavlohrad – Dnipropetrovsk Oblast, Ukraine Liveuamap
  - (2016-04-27) [Liveuamap] Israel and Gaza live map: news today | Liveuamap - Liveuamap
      Israel and Gaza live map: news today | Liveuamap Liveuamap

### U.S. Weather + Severe / Climate Outlooks — 120 new of 122 total
  - (2026-11-12) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-12) [Severe] Special Marine Warning: Special Marine Warning issued November 12 at 6:39PM EST until November 12 at 7:00PM EST by NWS Mount Holly NJ
      For the following areas... Coastal waters from Sandy Hook to Manasquan Inlet NJ out 20 NM... Waters from Sandy Hook NJ to Manasquan Inlet NJ from 20 to 40 NM... At 639 PM EST, strong thunderstorms were located along a li…
  - (2026-11-12) [Severe] Special Marine Warning: Special Marine Warning issued November 12 at 6:37PM EST until November 12 at 7:30PM EST by NWS Mount Holly NJ
      SMWPHI The National Weather Service in Mount Holly NJ has issued a * Special Marine Warning for... Coastal and outer waters from Sandy Hook to Little Egg Inlet NJ... * Until 730 PM EST. * At 636 PM EST, severe thundersto…
  - (2026-11-12) [Moderate] High Surf Warning: High Surf Warning issued November 12 at 3:28PM PST until November 15 at 4:00AM PST by NWS Eureka CA
      * WHAT...For the High Surf Warning, Dangerously large breaking waves 30 to 35 feet. For the Coastal Flood Advisory, High astronomical tides will cause minor flooding in low lying areas around Humboldt Bay. 1.5 to 2.2 fee…
  - (2026-11-12) [Moderate] High Surf Warning: High Surf Warning issued November 12 at 3:28PM PST until November 15 at 4:00AM PST by NWS Eureka CA
      * WHAT...Dangerously large breaking waves 30 to 40 feet. * WHERE...Southwestern Humboldt and Coastal Mendocino Counties. * WHEN...From 4 PM Friday to 4 AM PST Sunday. . * IMPACTS...Breaking waves can sweep people off jet…
  - (2026-11-12) [Moderate] High Surf Warning: High Surf Warning issued November 12 at 3:28PM PST until November 15 at 4:00AM PST by NWS Eureka CA
      * WHAT...Dangerously large breaking waves 30 to 40 feet. * WHERE...Coastal Del Norte County. * WHEN...From 1 PM Friday to 4 AM PST Sunday. . * IMPACTS...Breaking waves can sweep people off jetties and docks, and into dan…

### Ukrainian Internal News (national + local Kyiv) — 85 new of 139 total
  - (2026-11-13) Росіяни влучили безпілотником у багатоповерхівку в Рівному: п'ятеро поранених | LEDE: Російський безпілотник влучив у житловий будинок у Рівному вночі. Постраждали п’ятеро людей, у квартирах ст] (uk:…
      Російський безпілотник влучив у житловий будинок у Рівному вночі. Постраждали п’ятеро людей, у квартирах сталася пожежа.
  - (2026-11-13) На Сумщині через російський обстріл загинули двоє людей – ОВА | LEDE: У Шосткинському районі Сумщини атаковано FPV-дроном, загинуло двоє чоловіків.] (uk: На Сумщині через російський обстріл загинули д…
      У Шосткинському районі Сумщини атаковано FPV-дроном, загинуло двоє чоловіків.
  - (2026-11-13) Кушнер заявив, що Путін готовий допустити Європу до наступних переговорів щодо України | LEDE: Джаред Кушнер заявив, що Володимир Путін погодився на участь європейців у мирних переговорах по Ук] (uk:…
      Джаред Кушнер заявив, що Володимир Путін погодився на участь європейців у мирних переговорах по Україні.
  - (2026-11-13) Зеленський і Мелоні обговорили посилення ППО та захист енергетики України | LEDE: Президент Зеленський і премʼєрка Мелоні обговорили зміцнення протиповітряної оборони та постачання ракет для за] (uk:…
      Президент Зеленський і премʼєрка Мелоні обговорили зміцнення протиповітряної оборони та постачання ракет для захисту енергетики взимку
  - (2026-11-13) Зеленський анонсує найбільший обмін військовополоненими | LEDE: Президент України Володимир Зеленський за підсумками зустрічі з представниками президента США Джаредом Кушнером та Стівом Віткофф] (uk:…
      Президент України Володимир Зеленський за підсумками зустрічі з представниками президента США Джаредом Кушнером та Стівом Віткоффом 12 листопада анонсував "найбільший" обмін військовополоненими з РФ.
  - (2026-11-12) У Норвегії попереджають про ризик російських диверсій наступного року | LEDE: ] (uk: У Норвегії попереджають про ризик російських диверсій наступного року)

### Wikidata leader-roster changes (48h) — 56 new of 56 total
  - (2026-11-12) [Comoros] Azali Assoumani (Q515602) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/67274|batch #67274]]: add P396 using AI: similarity 70
  - (2026-11-12) [Kingdom of Denmark] Frederik X of Denmark (Q1004037) edited
      /* wbsetaliases-add:3|lv */ Dānijas Frederiks X, Frederiks Desmitais, Frederiks Andrē Henriks Kristiāns
  - (2026-11-12) [Cuba] Miguel Díaz-Canel (Q1932603) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/67274|batch #67274]]: add P396 using AI: similarity 80
  - (2026-11-12) [Benin] Romuald Wadagni (Q24951128) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/67274|batch #67274]]: add P396 using AI: similarity 70
  - (2026-11-12) [Democratic Republic of the Congo] Félix Tshisekedi (Q29032770) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/67274|batch #67274]]: add P396 using AI: similarity 70
  - (2026-11-12) [Ivory Coast] Alassane Ouattara (Q57413) edited
      /* wbsetclaim-update-references:1||1|1 */ [[Property:P569]]: 1 January 1942, source for date of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])

### GDACS — global disaster alerts — 56 new of 89 total
  - (2022-09-21) [Orange] Drought in Aruba, , Brazil, Colombia, Costa Rica, , French Guiana, Guyana, Panama, Suriname, Venezuela
      Drought · Orange alert · Aruba, , Brazil, Colombia, Costa Rica, , French Guiana, Guyana, Panama, Suriname, Venezuela · Medium impact for agricultural drought in 1735191 km2
  - (2026-11-12) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 5.8M, Depth:10km
  - (2026-11-12) [Green] Earthquake in Iceland
      Earthquake · Green alert · Iceland · Magnitude 4.6M, Depth:10km
  - (2026-11-12) [Green] Earthquake in Western Indian-Antarctic Ridge
      Earthquake · Green alert · Western Indian-Antarctic Ridge · Magnitude 5.1M, Depth:10km
  - (2026-11-12) [Green] Earthquake in China
      Earthquake · Green alert · China · Magnitude 4.9M, Depth:10km
  - (2026-11-12) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.5M, Depth:39.203km

### IT, InfoSys & cybersecurity news (last 7 days) — 49 new of 63 total
  - (2026-11-12) [BleepingComputer] New worm-like 'SCKit' malware targets MSPs in ScreenConnect attacks
      A new worm-like malware toolkit named SCKit was deployed in the recent ScreenConnect attacks targeting managed service providers (MSPs), designed to spread from infected customer devices to MSP technicians' computers and…
  - (2026-11-12) [BleepingComputer] Hackers compromise 4,800 GitHub accounts to steal cloud credentials
      A new campaign dubbed 'wfx-loot' has unfolded on GitHub where threat actors used 4,837 compromised accounts to probe 61,764 repositories, open pull requests, and push secrets-stealing malware. [...]
  - (2026-11-12) [BleepingComputer] Massive Microsoft 365 outage disrupts Outlook, Teams, Copilot worldwide
      Microsoft is investigating a widespread outage affecting multiple Microsoft 365 services, including Outlook, Microsoft Teams, and Copilot, as users report connectivity problems worldwide. [...]
  - (2026-11-12) [BleepingComputer] New N-able "4EverAble2Shell" zero-day exploited hours after PoC released
      Hackers are actively exploiting a newly disclosed N-able N-central zero-day vulnerability dubbed "4EverAble2Shell" to compromise servers and deploy cryptocurrency miners, with researchers reporting at least 21 affected s…
  - (2026-11-12) [BleepingComputer] Apache HTTP Server patches critical HTTP/2 remote code execution flaw
      A critical vulnerability in the HTTP/2 module of Apache HTTP Server could be exploited by an unauthenticated attacker to obtain remote code execution (RCE). [...]
  - (2026-11-12) [The Hacker News] Webinar: See How Identity Blind Spots Put Your SOC at Risk and How to Close Them
      Security teams have more alerts, logs, and monitoring tools than ever. Yet when an attack happens, one simple question can still take too long to answer: Who or what is behind this activity, and what can they access? A s…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-12) [Liang Charles] Form 4 (Reporting)
      filed 2026-11-12 23:44 UTC · role: Reporting — Filed: 2026-11-12 AccNo: 0001392942-26-000018 Size: 16 KB
  - (2026-11-12) [Super Micro Computer, Inc.] Form 4 (Issuer)
      filed 2026-11-12 23:44 UTC · role: Issuer — Filed: 2026-11-12 AccNo: 0001392942-26-000018 Size: 16 KB
  - (2026-11-12) [Chaudhuri Sarbani] Form 4 (Reporting)
      filed 2026-11-12 23:44 UTC · role: Reporting — Filed: 2026-11-12 AccNo: 0001140361-26-043480 Size: 5 KB
  - (2026-11-12) [ROCKET PHARMACEUTICALS, INC.] Form 4 (Issuer)
      filed 2026-11-12 23:44 UTC · role: Issuer — Filed: 2026-11-12 AccNo: 0001140361-26-043480 Size: 5 KB
  - (2026-11-12) [Anderson Aaron] Form 4 (Reporting)
      filed 2026-11-12 23:43 UTC · role: Reporting — Filed: 2026-11-12 AccNo: 0000950103-26-017401 Size: 9 KB
  - (2026-11-12) [Meta Platforms, Inc.] Form 4 (Issuer)
      filed 2026-11-12 23:43 UTC · role: Issuer — Filed: 2026-11-12 AccNo: 0000950103-26-017401 Size: 9 KB

### Court opinions of consequence (federal & state) — 36 new of 60 total
  - (2026-11-12) U.S. Court of Appeals, 9th Cir.: Sabrina Beram v. City of Sedona
  - (2026-11-12) U.S. Court of Appeals, 9th Cir.: United States v. Grandy
  - (2026-11-12) D.C. Court of Appeals: In re Warren
  - (2026-11-12) D.C. Court of Appeals: Lovern v. Jackson
  - (2026-11-12) U.S. Court of Appeals, 11th Cir.: Colburn Clifton Gooden Kelly v. Deputy Cody Jett
  - (2026-11-12) U.S. Court of Appeals, 11th Cir.: United States v. Justin Dale Sigmon

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-11-12) #1 Elon Musk — $894.26B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-11-12) #2 Jeff Bezos — $385.27B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-11-12) #3 Larry Page — $246.78B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-11-12) #4 Sergey Brin — $227.17B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-11-12) #5 Michael Dell — $219.17B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-11-12) #6 Mark Zuckerberg — $214.30B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 27 new of 79 total
  - (2026-11-12) [Polymarket] Will Ethereum reach $2,600 in November?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for ETH/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-11-12) [Polymarket] Will Donald Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-11-12) [Polymarket] Will Arizona Cardinals win the 2027 NFL NFC Championship?
      This market will resolve according to the team that wins the 2027 NFC championship game. If at any point it becomes impossible for a listed team to win the 2027 NFL NFC championship per the rules of the NFL (e.g., they a…
  - (2026-11-12) [Polymarket] Will Joe Kent win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-11-12) [Manifold] Will Intermex (IMXI) be acquired by Western Union (WU) before 3/31/2027.
  - (2026-11-12) [Manifold] NCAAF: If Indiana loses to USC, will they make the college football playoff?

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] UN Security Council to meet on situation in the Middle East
      news.webindia123.com · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Israel claims Hamas hit in deadly Gaza hospital strike
      queanbeyanage.com.au · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Trump and Netanyahu Clash Over Iran : Heated Debate on War Strategy Reported
      openthemagazine.com · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Israeli strike on a Gaza hospital kills 6 people , health authorities say
      newsday.com · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Bibi Netanyahu legacy - Daily Press
      dailypress.net · English · tone NA
  - (2026-11-12) [Israel-Iran-Hezbollah axis · keywords] Israeli strike on Gaza hospital kills six , including surgeon
      cyprus-mail.com · English · tone NA

### State Legislative Action — 20 new of 122 total
  - (2026-11-12) [Alaska HB 289] An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; an…
      An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; and providing for an effective date.
  - (2026-11-12) [Alaska SB 83] An Act relating to health care insurance; relating to insurance reimbursement for health care services provided through telehealth; relating to telehealth; providing for an effective da…
      An Act relating to health care insurance; relating to insurance reimbursement for health care services provided through telehealth; relating to telehealth; providing for an effective date by repealing the effective date…
  - (2026-11-12) [Alaska HB 211] An Act relating to prepaid legal plans.
      An Act relating to prepaid legal plans.
  - (2026-11-12) [Alaska HB 350] An Act establishing an income tax on certain entities in the state; and providing for an effective date.
      An Act establishing an income tax on certain entities in the state; and providing for an effective date.
  - (2026-11-12) [Alaska HB 316] An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
      An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
  - (2026-11-12) [Alaska HB 324] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.

### Government & military aircraft airborne (OpenSky) — 15 new of 16 total
  - (2026-11-12) NCR370 (United States)
      icao24: ab4ec6 · position: (34.4109, -104.8551) · alt: 11887m · 933km/h
  - (2026-11-12) SAMU59 (France)
      icao24: 39b5d1 · position: (50.3535, 3.5901) · alt: 647m · 246km/h
  - (2026-11-12) PAT26 (United States)
      icao24: ae77f0 · position: (38.6039, -77.0833) · alt: 426m · 218km/h
  - (2026-11-12) PAT660 (United States)
      icao24: ae08fa · position: (40.2973, -78.9272) · alt: 8221m · 547km/h
  - (2026-11-12) PAT612 (United States)
      icao24: ae0876 · position: (43.8628, -101.9273) · alt: 7962m · 387km/h
  - (2026-11-12) RCH101 (United States)
      icao24: ae1471 · position: (-33.6048, 150.7935) · alt: -7m

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-11-12) Raptors vs. 76ers
      yes price: 28% · 24h volume: $1,574,051 · resolves 2026-11-13
  - (2026-11-12) Commanders vs. Giants
      yes price: 46% · 24h volume: $1,302,591 · resolves 2026-11-13
  - (2026-11-12) Will Jesus Christ return before 2027?
      yes price: 1% · 24h volume: $1,288,036 · resolves 2027-01-01
  - (2026-11-12) WTA Finals, Group A: Jessica Pegula vs Linda Noskova
      yes price: 66% · 24h volume: $1,193,006 · resolves 2026-11-17
  - (2026-11-12) Spread: 76ers (-7.5)
      yes price: 48% · 24h volume: $616,557 · resolves 2026-11-13
  - (2026-11-12) Will Mike Pence win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $566,297 · resolves 2028-11-08

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 99 total
  - (2026-11-10) [FARA] DOJ Privacy Impact Assessments - Department of Justice (.gov)
      DOJ Privacy Impact Assessments Department of Justice (.gov)
  - (2026-11-12) [USASpending] $44,093,914,875 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-11-12) [USASpending] $17,730,321,031 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy. Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-11-12) [USASpending] $560,006,589 → BOOZ ALLEN HAMILTON INC: ENGINEERING DEVELOPMENT INTEGRATION AND TECHNOLOGYBASED SOLU
      Agency: General Services Administration. Description: ENGINEERING DEVELOPMENT INTEGRATION AND TECHNOLOGYBASED SOLUTIONS EDITS
  - (2026-11-12) [USASpending] $449,655,716 → CACI, INC. - FEDERAL: EXECUTE TASK ORDER FOR COMMERCIAL BASED TECHNOLOGY ANALYSIS
      Agency: General Services Administration. Description: EXECUTE TASK ORDER FOR COMMERCIAL BASED TECHNOLOGY ANALYSIS (CBTA.
  - (2026-11-12) [USASpending] $398,925,093 → LEIDOS BIOMEDICAL RESEARCH INC: NCI FY25 OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services. Description: NCI FY25 OPERATIONAL TASK ORDER

### Campaign finance (FEC: top fundraisers + recent filings) — 10 new of 27 total
  - (2026-11-11) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2047176
  - (2026-11-11) [F99] NEVADA COUNTY REPUBLICAN PARTY
      cycle 2026 · filing #2047148
  - (2026-11-11) [F2] CAMPBELL, CHRISTOPHER TODD MR
      cycle 2026 · filing #2047189
  - (2026-11-11) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2047119
  - (2026-11-11) [F1] TYRONE BROWN FOR CONGRESS
      cycle 2026 · filing #2047143
  - (2026-11-11) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2047170

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-11-12) M 5.8 - 148 km NW of Kavieng, Papua New Guinea
      M5.8 · 148 km NW of Kavieng, Papua New Guinea · depth 10 km
  - (2026-11-12) M 5.4 - South Sandwich Islands region
      M5.4 · South Sandwich Islands region · depth 121.557 km
  - (2026-11-12) M 5.1 - western Indian-Antarctic Ridge
      M5.1 · western Indian-Antarctic Ridge · depth 10 km
  - (2026-11-12) M 4.9 - 41 km N of Weining, China
      M4.9 · 41 km N of Weining, China · depth 10 km
  - (2026-11-12) M 4.8 - 155 km E of Noda, Japan
      M4.8 · 155 km E of Noda, Japan · depth 33.039 km
  - (2026-11-12) M 4.8 - 43 km SE of Severo-Kuril’sk, Russia
      M4.8 · 43 km SE of Severo-Kuril’sk, Russia · depth 74.47 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-11-12) [Japan] Japan to Contribute 294 M . Yen for Gaza Health Care System
      nippon.com · English
  - (2026-11-12) [Japan] Russia Justifies Control of Japan Tobacco Assets
      nippon.com · English
  - (2026-11-12) [Japan] Japan 1st Bird Flu Case This Season Confirmed in Kyoto
      nippon.com · English
  - (2026-11-12) [Japan] Yankii Fashion for Coming - of - Age Ceremony Showcased in London
      nippon.com · English
  - (2026-11-12) [Japan] Trio of masked thugs hold taxi driver at knifepoint in Osaka robbery
      tokyoreporter.com · English
  - (2026-11-12) [Japan] Man arrested for stealing ¥46 million luxury watch in Nakano Broadway claims fell in love with it
      tokyoreporter.com · English

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-12) [Marginal Revolution] My Barcelona talk on AI
      The post My Barcelona talk on AI appeared first on Marginal REVOLUTION.
  - (2026-11-12) [Marginal Revolution] Thursday assorted links
      1. New Texas A&M podcast: Economists Unscripted. 2. A new tool for AI-proof homework assignments. “It’s called https://deb8.tv — students get paired and have live video debates with one another.” 3. “The average French p…
  - (2026-11-12) [Marginal Revolution] The Everywhere Rent Seekers
      Zidar and Zwick have a good post on the political power of billionaires versus the power of many millionaires, based on their excellent book The Everywhere Millionaire. First, they point out that despite the attention gi…
  - (2026-11-11) [Conversable Economist] Cities of Africa: Explosive Growth, Corresponding Challenges
      The number of people living in urban areas in countries of sub-Saharan Africa has more than quintupled in the last 50 years, and is projected to double again in the next 25 years. Thus, a key question for human welfare i…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-12) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=28, 7d-median=26, 14d-median=22; carrying terms: changes, directives, action, existing, final, service, commission, provide, regulatory, agency, safety, certain
- state_bills: today=122, 7d-median=97, 14d-median=98; carrying terms: establishing, access, program, income, authority, vehicle, review, providing, emergency, health, production, enforcement
- state_news: today=1021, 7d-median=675, 14d-median=716; carrying terms: wants, figure, public, development, parties, residents, government, montana, featured, calmatters, resize, strong
- local_news: today=305, 7d-median=265, 14d-median=260; carrying terms: louis, trump, football, early, november, target, night, atlantamagazine, https, times, election, business
- foreign_news: today=1062, 7d-median=1008, 14d-median=1010; carrying terms: wants, parties, government, bnegeneric, largest, float, vancouver, leave, despite, warning, airport, healthcare
- chinese_internal: today=344, 7d-median=334, 14d-median=312; carrying terms: global, lxtfa, target, title, https, cbmiy, articles, color, caixin, cbmiykfvx, cbmizkfvx, cbmiakfvx
- russian_internal: today=1012, 7d-median=951, 14d-median=948; carrying terms: forbidden, telegram, novaya, financial, group, https, times, novayagazeta, bloomberg, httperror, laquo, raquo
- ukrainian_internal: today=139, 7d-median=139, 14d-median=136; carrying terms: world, struck, hromadske, government, update, dhabi, largest, refinery, several, infrastructure, russia, trump
- ukraine_theater: today=264, 7d-median=269, 14d-median=272; carrying terms: itnzmmmhryuvzevh, lxbthbvmvtv, xfturhrs, fzuvo, vylvmve, development, wckfmwkzsd, wuznhaefh, dsmtr, zkywukptvuvnm, uefinmjjtklmdxbizuthqy, zcvbjofk
- paper_bets: today=79, 7d-median=66, 14d-median=68; carrying terms: passing, allen, successor, nuclear, world, majors, solved, millennium, jpmorgan, chase, sachs, rushing
- weather: today=122, 7d-median=135, 14d-median=134; carrying terms: message, louis, hazardous, offshore, entrance, afdfwd, below, angeles, flood, vessels, afdokx, twoat
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpilfesl, latest, treasury, growth, dexchus, cpiaucsl, dexjpus, vixcls, jtsjol, jolts, spread, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, equities, russell, large, rates, silver, treasury, china, proxy, natural, yield, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=99, 14d-median=99; carrying terms: administration, mission, operating, institute, public, republic, xskfisuh, content, ambassador, technology, btdyc, articles
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, https, httperror, error, quiverquant, quantitative, quiver, client, unauthorized
- billionaires: today=30, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, supreme, international, company, blanche, florida, connecticut, appeals, thomas, arkansas, trade
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, filing, jonathan, ocasio, peltola, sayed, robert, james, sherrod, receipts, senate, cooper
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, sanctions, trump, keywords, hezbollah, against, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=26, 14d-median=30; carrying terms: france, position, canada, adfdd
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: viruses, employee, ratio, nigeria, countries, reporting, world, october, aware, ventilatory, dungu, stands
- cisa_kev: today=17, 7d-median=14, 14d-median=16; carrying terms: cisco, software, return, dereference, value, firewall, vulnerability, edition, unchecked, community, remediation, pointer
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=56, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=89, 7d-median=100, 14d-median=100; carrying terms: botswana, forestfire, south, sudan, australia, forest, speed, fires, japan, green, impact, brazil
- usgs_quakes: today=10, 7d-median=14, 14d-median=13; carrying terms: depth, japan, islands, region, ridge, indonesia, south, russia, indian, guinea, papua, sandwich
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, presidential, league, shakhtar, donetsk, champions, championship, republican, israel, senate
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, https, marginal, economist, revolution, class, published, world, since, american, perspectives, conversableeconomist
- tech_news: today=63, 7d-median=61, 14d-median=61; carrying terms: company, world, provides, computerweekly, investigation, going, download, infrastructure, technology, cybersecurity, software, critical
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: currency, pressley, administration, sherman, angus, louis, harold, ansari, summer, hinds, vicente, simpson
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, placed, decision, paper, evidence, claude, unavailable, today, market, sufficient, module, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*