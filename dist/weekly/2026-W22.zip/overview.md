# WORLDSCOPE weekly brief — 2026-W22
*2026-05-25 → 2026-05-31*

## Headline

This week's run covered 10 sections. 266 items total; 266 new since the previous run.

## Macro recap

**7-day macro changes**:

  DGS10            4.5700  ▼ -0.0400 (-0.87% in 7d)
  DGS2             4.0800  ▲ +0.0100 (+0.25% in 7d)
  T10Y2Y           0.4300  ▼ -0.1100 (-20.37% in 7d)
  DFF              3.6200  ▼ -0.0100 (-0.28% in 7d)
  VIXCLS          16.7600  ▼ -1.0600 (-5.95% in 7d)
  DCOILWTICO     112.2500  ▼ +0.0000 (+0.00% in 7d)
  DEXUSEU          1.1627  ▼ +0.0000 (+0.00% in 7d)
  DEXJPUS        158.6900  ▼ +0.0000 (+0.00% in 7d)
  DEXCHUS          6.8092  ▼ +0.0000 (+0.00% in 7d)

**Anomalies (z > 1.5σ over trailing 30d)**:

  DEXUSEU      2026-05-15 = 1.1627  (-2.53σ)
  T10Y2Y       2026-05-22 = 0.43  (-2.36σ)
  DFF          2026-05-21 = 3.62  (-2.11σ)
  SOFR         2026-05-21 = 3.51  (-1.79σ)
  DCOILWTICO   2026-05-18 = 112.25  (+1.66σ)
  VIXCLS       2026-05-21 = 16.76  (-1.50σ)

## What happened (by section)

### 🏛️ U.S. Federal Action — 25 new / 25 total
- (2026-05-22) Restoring Integrity to America's Financial System
- (2026-05-22) Integrating Financial Technology Innovation Into Regulatory Frameworks
- (2026-05-22) To Implement Certain Provisions in the Consolidated Appropriations Act, 2026, and for Other Purposes
- (2026-05-22) Airworthiness Directives; Pratt & Whitney RTX Corporation (Type Certificate Previously Held by Pratt & Whitney Division United Technologies Corporation) Engines
- (2026-05-22) Removal of Environmental Clearance Officer Review and Comment for Assessments for Projects Over 200 Lots/Dwelling Units or Beds
- (2026-05-22) Amendment of United States Area Navigation Route T-306 and Establishment of United States Area Navigation Route T-647
- _… and 19 more in the data bundle_

### 📊 Macro indicators — latest values (FRED) — 21 new / 21 total
- (2026-05-21) [Rates] Fed Funds Effective Rate (DFF)
- (2026-05-21) [Rates] 2-Year Treasury (DGS2)
- (2026-05-21) [Rates] 10-Year Treasury (DGS10)
- (2026-05-21) [Rates] 30-Year Treasury (DGS30)
- (2026-05-21) [Rates] SOFR (SOFR)
- (2026-05-22) [Rates] 10y–2y Spread (recession indicator) (T10Y2Y)
- _… and 15 more in the data bundle_

### 📈 Markets snapshot (Finnhub) — 21 new / 21 total
- (2026-05-22) [US equities] S&P 500 (SPY): 745.64 ▲ +0.39%
- (2026-05-22) [US equities] Nasdaq 100 (QQQ): 717.54 ▲ +0.42%
- (2026-05-22) [US equities] Russell 2000 (IWM): 285.12 ▲ +0.93%
- (2026-05-22) [Intl equities] MSCI EAFE (EFA): 103.98 ▼ -0.20%
- (2026-05-22) [EM equities] MSCI EM (EEM): 65.88 ▼ -0.23%
- (2026-05-22) [China equities] China large-cap (FXI): 35.52 ▼ -1.03%
- _… and 15 more in the data bundle_

### 💰 Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new / 30 total
- (2026-05-26) #1 Elon Musk — $827.68B
- (2026-05-26) #2 Larry Page — $311.48B
- (2026-05-26) #3 Sergey Brin — $287.25B
- (2026-05-26) #4 Jeff Bezos — $273.43B
- (2026-05-26) #5 Larry Ellison — $239.61B
- (2026-05-26) #6 Mark Zuckerberg — $209.44B
- _… and 24 more in the data bundle_

### ⚖️ Court opinions of consequence (federal) — 30 new / 30 total
- (2026-05-21) [SCOTUS] Hamm v. Smith
- (2026-05-21) [SCOTUS] Havana Docks Corp. v. Royal Caribbean Cruises, Ltd.
- (2026-05-21) [SCOTUS] M & K Employee Solutions, Inc. v. Trustees of IAM Nat. Pension
- (2026-05-14) [SCOTUS] Jules v. Andre Balazs Properties
- (2026-05-14) [SCOTUS] Montgomery v. Caribe Transport II, LLC
- (2026-05-22) [CIT] Toyo Kohan Co., Ltd. v. United States
- _… and 24 more in the data bundle_

### 🗳️ Campaign finance (FEC: top fundraisers + recent filings) — 27 new / 27 total
- (2026-05-25) [Top] OSSOFF, T. JONATHAN (DEM, Senate GA): $81.15M raised
- (2026-05-25) [Top] TALARICO, JAMES (DEM, Senate TX): $40.28M raised
- (2026-05-25) [Top] BOOKER, CORY A. (DEM, Senate NJ): $32.26M raised
- (2026-05-25) [Top] KRISHNAMOORTHI, S (DEM, Senate IL): $31.39M raised
- (2026-05-25) [Top] OCASIO-CORTEZ, ALEXANDRIA (DEM, House NY): $27.73M raised
- (2026-05-25) [Top] COOPER, ROY (DEM, Senate NC): $26.82M raised
- _… and 21 more in the data bundle_

### 🌍 World News (by country, top stories) — 80 new / 80 total
- (2026-05-26) [Japan] Outfit 3 DLC revealed for Ingrid , Sagat , Alex and C . Viper in Street Fighter 6
- (2026-05-26) [Japan] Tekken 8 sales have suddenly jumped after the announcement of Yujiro Hanma for Season 3
- (2026-05-26) [Japan] How to turn off aging in Paralives
- (2026-05-26) [South Korea] South Korea slow shift for single mothers , through their eyes
- (2026-05-26) [Israel] The six graves in Alaska oldest Jewish cemetery – The Forward
- (2026-05-26) [Israel] Israeli Security Forces Secretly Helped to Smuggle Unsupervised Goods Into Gaza
- _… and 74 more in the data bundle_

### ⚔️ Conflict & unrest (GDELT, last 48h) — 0 new / 0 total
  (no items)

### 🔮 Prediction Markets — most-traded (Polymarket) — 20 new / 20 total
- (2026-05-26) Knicks vs. Cavaliers
- (2026-04-28) Will Bitcoin hit $150k by June 30, 2026?
- (2026-05-26) US x Iran permanent peace deal by May 26, 2026?
- (2026-05-26) Will the Iran ceasefire continue through May 24?
- (2026-05-26) Will the Iran ceasefire continue through May 25?
- (2026-05-26) US x Iran permanent peace deal by May 31, 2026?
- _… and 14 more in the data bundle_

### 💬 Commentary & analysis (last 7 days) — 12 new / 12 total
- (2026-05-25) [Adam Tooze] Top Links 1112 Semiconductor decoupling. Powell's politics. Industrializing Ogaden. Free trade and the Magna Carta.
- (2026-05-25) [Noah Smith] Are you tired of the Trump era yet?
- (2026-05-25) [Marginal Revolution] *Silent Friend*
- (2026-05-25) [Marginal Revolution] New Aesthetics awards
- (2026-05-25) [Marginal Revolution] Monday assorted links
- (2026-05-24) [Adam Tooze] Top Links 1111 The unlikeliness of an Nvidia default. The end of the beginning in Hormuz. The Economist on Mao & Zoroastrian Zeligs.
- _… and 6 more in the data bundle_

## What to watch (next 14 days)

- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations